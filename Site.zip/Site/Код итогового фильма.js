(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.АСЦАЦ6363 = function() {
	this.initialize(img.АСЦАЦ6363);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1840,1276);


(lib.ВКВ22 = function() {
	this.initialize(img.ВКВ22);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.ВКВ22pngкопия = function() {
	this.initialize(img.ВКВ22pngкопия);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.ЫИЫВПМ67 = function() {
	this.initialize(img.ЫИЫВПМ67);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1118,803);


(lib.вкорме10 = function() {
	this.initialize(img.вкорме10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.газета60 = function() {
	this.initialize(img.газета60);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1025,1170);


(lib.городскиежильцыперсонажиЦ2346 = function() {
	this.initialize(img.городскиежильцыперсонажиЦ2346);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2141,1937);


(lib.городскиежильцыперсонажи23 = function() {
	this.initialize(img.городскиежильцыперсонажи23);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.городскиежильцыперсонажи27 = function() {
	this.initialize(img.городскиежильцыперсонажи27);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.городскиежильцыперсонажи28 = function() {
	this.initialize(img.городскиежильцыперсонажи28);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.городскиежильцыперсонажи29 = function() {
	this.initialize(img.городскиежильцыперсонажи29);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.городскиежильцыперсонажи33 = function() {
	this.initialize(img.городскиежильцыперсонажи33);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.городскиежильцыперсонажи37 = function() {
	this.initialize(img.городскиежильцыперсонажи37);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1534);


(lib.городскиежильцыперсонажи41 = function() {
	this.initialize(img.городскиежильцыперсонажи41);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1533);


(lib.городскиежильцыперсонажи43 = function() {
	this.initialize(img.городскиежильцыперсонажи43);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1533);


(lib.городскиежильцыперсонажи45 = function() {
	this.initialize(img.городскиежильцыперсонажи45);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2336,1533);


(lib.городскиежильцыперсонажи46 = function() {
	this.initialize(img.городскиежильцыперсонажи46);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,2141,1937);


(lib.городскиежильцыперсонажи47 = function() {
	this.initialize(img.городскиежильцыперсонажи47);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1367,1286);


(lib.городскиежильцыперсонажи58 = function() {
	this.initialize(img.городскиежильцыперсонажи58);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1674,1464);


(lib.городскиежильцыперсонажи59pngкопия = function() {
	this.initialize(img.городскиежильцыперсонажи59pngкопия);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1674,1464);


(lib.городскиежильцыперсонажи60 = function() {
	this.initialize(img.городскиежильцыперсонажи60);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1485,1522);


(lib.городскиежильцыперсонажи61 = function() {
	this.initialize(img.городскиежильцыперсонажи61);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1017,914);


(lib.городскиежильцыперсонажи62 = function() {
	this.initialize(img.городскиежильцыперсонажи62);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1017,914);


(lib.городскиежильцыперсонажи63 = function() {
	this.initialize(img.городскиежильцыперсонажи63);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1840,1276);


(lib.городскиежильцыперсонажи64 = function() {
	this.initialize(img.городскиежильцыперсонажи64);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,245,314);


(lib._656665 = function() {
	this.initialize(img._656665);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1516,978);


(lib._656665pngкопия = function() {
	this.initialize(img._656665pngкопия);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1516,978);


(lib._656666 = function() {
	this.initialize(img._656666);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1862,911);


(lib._656666pngкопия = function() {
	this.initialize(img._656666pngкопия);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1862,911);


(lib._656666pngкопия2 = function() {
	this.initialize(img._656666pngкопия2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1862,911);


(lib._676867 = function() {
	this.initialize(img._676867);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1118,803);


(lib._676868 = function() {
	this.initialize(img._676868);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1277,820);


(lib.фоны_фонкорм = function() {
	this.initialize(img.фоны_фонкорм);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2986);


(lib.фоны_фонокно = function() {
	this.initialize(img.фоны_фонокно);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2986);


(lib.фоны_фонприхожаяcopy = function() {
	this.initialize(img.фоны_фонприхожаяcopy);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2986);


(lib.фоны_фонприхожая = function() {
	this.initialize(img.фоны_фонприхожая);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2987);


(lib.фоны_фонстол = function() {
	this.initialize(img.фоны_фонстол);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2986);


(lib.фоны_фонстол2copy3 = function() {
	this.initialize(img.фоны_фонстол2copy3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2987);


(lib.фоны_фонстол2copy4 = function() {
	this.initialize(img.фоны_фонстол2copy4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2987);


(lib.фоны_фонстол2copy5 = function() {
	this.initialize(img.фоны_фонстол2copy5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2987);


(lib.фоны_фонстол2 = function() {
	this.initialize(img.фоны_фонстол2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,4696,2986);


(lib.Анимация58 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.городскиежильцыперсонажи37();
	this.instance.setTransform(-610.4,-400.85,0.5226,0.5226);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-610.4,-400.8,1220.9,801.7);


(lib.Анимация57 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.городскиежильцыперсонажи37();
	this.instance.setTransform(-610.45,-400.85,0.5226,0.5226);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-610.4,-400.8,1220.8,801.7);


(lib.Анимация56 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666pngкопия2();
	this.instance.setTransform(-470.45,-230.15,0.5053,0.5053);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-470.4,-230.1,940.8,460.29999999999995);


(lib.Анимация55 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666pngкопия2();
	this.instance.setTransform(-931,-455.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-931,-455.5,1862,911);


(lib.Анимация53 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666pngкопия();
	this.instance.setTransform(89.7,-139.3,0.2614,0.2614);

	this.instance_1 = new lib._656665pngкопия();
	this.instance_1.setTransform(-576.3,-116.3,0.2614,0.2614);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-576.3,-139.3,1152.6999999999998,278.6);


(lib.Анимация52 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666pngкопия();
	this.instance.setTransform(211.2,-139.3,0.2614,0.2614);

	this.instance_1 = new lib._656665pngкопия();
	this.instance_1.setTransform(-697.8,-116.3,0.2614,0.2614);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-697.8,-139.3,1395.6999999999998,278.6);


(lib.Анимация51 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666pngкопия();
	this.instance.setTransform(255.7,-139.3,0.2614,0.2614);

	this.instance_1 = new lib._656665pngкопия();
	this.instance_1.setTransform(-742.3,-116.3,0.2614,0.2614);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-742.3,-139.3,1484.6999999999998,278.6);


(lib.Анимация50 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656665();
	this.instance.setTransform(-245.6,-158.45,0.324,0.324);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.6,-158.4,491.29999999999995,316.9);


(lib.Анимация49 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656665();
	this.instance.setTransform(-245.6,-158.45,0.324,0.324);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.6,-158.4,491.29999999999995,316.9);


(lib.Анимация48 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656665();
	this.instance.setTransform(-245.6,-158.45,0.324,0.324);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.6,-158.4,491.29999999999995,316.9);


(lib.Анимация47 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656665();
	this.instance.setTransform(-245.6,-158.45,0.324,0.324);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-245.6,-158.4,491.29999999999995,316.9);


(lib.Анимация46 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666();
	this.instance.setTransform(-243,-118.9,0.261,0.261);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-243,-118.9,486.1,237.8);


(lib.Анимация45 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666();
	this.instance.setTransform(-243,-118.9,0.261,0.261);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-243,-118.9,486.1,237.8);


(lib.Анимация44 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666();
	this.instance.setTransform(-243,-118.9,0.261,0.261);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-243,-118.9,486.1,237.8);


(lib.Анимация43 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._656666();
	this.instance.setTransform(-243,-118.9,0.261,0.261);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-243,-118.9,486.1,237.8);


(lib.Анимация42 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._676867();
	this.instance.setTransform(425.7,-42.4,0.6216,0.6216,0,29.9989,-150.0011);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-425.7,-389.8,851.4,779.7);


(lib.Анимация41 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._676867();
	this.instance.setTransform(425.7,-42.4,0.6216,0.6216,0,29.9989,-150.0011);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-425.7,-389.8,851.4,779.7);


(lib.Анимация40 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._676867();
	this.instance.setTransform(425.7,-42.4,0.6216,0.6216,0,29.9989,-150.0011);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-425.7,-389.8,851.4,779.7);


(lib.Анимация39 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._676867();
	this.instance.setTransform(-175,-125.7,0.3131,0.3131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-175,-125.7,350,251.4);


(lib.Анимация38 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._676867();
	this.instance.setTransform(-175,-125.7,0.3131,0.3131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-175,-125.7,350,251.4);


(lib.Анимация37 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib._676867();
	this.instance.setTransform(-175,-125.7,0.3131,0.3131);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-175,-125.7,350,251.4);


(lib.Анимация34 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAYt1QABGigGCNQgGCQgaDmQgIBCgBBaQgBASAACMIAAByQAAAsABArQAAA4ABA1QACC4AGAe");
	this.shape.setTransform(-90.1673,-42.85);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#232323").ss(4,1,1).p("AY88gQDzWrgRXBIslAAIgOEuQgKF9AYGLQDTAzBmBNQBbBEgNBIQgNBFhmAuQhqAxi3gtQi2guh8AtQh8AsiQgqQiPgqBAjOQA7i/gYoUQgHimgPi1IgNiUIraAAQgMo6AQpJQAWs0BMtTAmkRMIgOEuQgKF9AYGLQDSAzBmBNQBcBEgNBIQgNBFhmAuQhqAxi3g4Qi2g3h8AVQh8AUiQgIQiPgIBAjOQA7i/gYoUQgHimgPi1IgNiUIrbAAQgMo6AQpJQAWs0BMtTAl7RMIgpAAIqaAAAPkRMIqFAAA6x7cQAlmbAxmjEAWrgoaQBNFoA+Fq");
	this.shape_1.setTransform(0.0327,3.5155);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#232323").ss(2,1,1).p("A4CAAIF3AAAQ9AAIHGAAAxdAAMAhoAAA");
	this.shape_2.setTransform(-8.825,-255.15);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EAGuAoGQiPgqBAjOQA7i/gYoUQgHimgPi1IgNiUIKFAAIqFAAIraAAQgFj1AAj4QAAlJAJlNQAWs0BMtTQhMNTgWM0QgJFNAAFJQAAD4AFD1IgpAAIqaAAIKaAAIgOEuQgKF9AYGLQDSAzBmBNQBcBEgNBIQgNBFhmAuQhqAxi3g4Qi2g3h8AVQh8AUiQgIQiPgIBAjOQA7i/gYoUQgHimgPi1IgNiUIrbAAQgMo6AQpJQAWs0BMtTQADAGAJACQAJADALgBQAbgDAdgTQASgNAdgcIB5h0QAsgqAVgdQASgYAZg0QAhhDAQgmQAXg4AShBQAMgwAUhzIAKhAQAJg1AFgmMAhnAAAQALBlAKAyQAFAeAQBBQAHAcAGAMQAFALANAQIAVAaQAKAOAMAaIAVAqQAMAUATAWIAlAmQA5A4AdAaQAxAsArAeQAXAQAvAcQAqAaAXAGQAIADAdAFQAXAEANAGIASAJQALAGAIAAQALACAJgFIACgBQDzWrgRXBIslAAIgOEuQgKF9AYGLQDTAzBmBNQBbBEgNBIQgNBFhmAuQhqAxi3gtQi2guh8AtQhAAXhEAAQhCAAhGgVgAudAMIABBXIABBtQACC4AGAeQgGgegCi4IgBhtIgBhXIAAhxIABieQABhaAIhCQAbjnAGiQQAFh3AAk/IAAh5IAAB5QAAE/gFB3QgGCQgbDnQgIBCgBBaIgBCeIAABxgEgZbgoaIF4AAIAAAHQAAAPgFATIgJAgQgKAlgGApIgHAyQgDAegEATQgJA5gVA6QgRAxgmBNQgTAogLATQgSAhgSAXQgVAcg0AxIhUBQQglAigZAKQgbAHgMAHQgFAEgEAFQAlmbAxmjgAYy9KQghgWgogIIgcgFQgRgDgKgEQgPgFgVgQIhNg0QgkgYgQgMQgUgRglgkIhGhEQghgigLgTQgFgJgIgRIgNgbIgTgdQgOgTgGgKQgSgfgNg5QgXhigHhiIHHAAQBNFoA+FqIgEgCg");
	this.shape_3.setTransform(0.0327,3.5155);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#232323").s().p("A5uHUQgIgCgEgGIgCgDQgFgJAFgLIAEgHQAEgFAGgEQAMgHAbgHQAYgKAlgiIBVhQQAzgxAWgcQASgXARghQALgTATgoQAmhNASgwQAVg6AJg5QADgTAEgeIAGgyQAGgpAKglIAKggQAFgTAAgPIgBgHIgCgTQgBgQADgKQADgOANgHQANgIAKAIQALAJgCAYIgCAhQgEAmgJA1IgLBAQgUBzgMAwQgRBBgYA3QgQAmghBDQgZA0gRAYQgVAdgsAqIh5B0QgeAcgSANQgcATgcADIgHAAQgHAAgGgCgAZgFuQgIAAgLgGIgSgJQgNgGgYgEQgdgFgIgDQgWgGgqgaQgwgcgWgQQgsgegwgsQgegag4g4IglgmQgUgWgMgUIgVgpQgMgagKgOIgUgaQgNgQgGgLQgFgMgIgcQgPhBgFgeQgKgygLhlIgBgDQgCgUADgKQADgIAFgFQAGgFAIAAQAMAAAHAOQAGALACASIABAIQAHBiAWBiQAOA5ASAfQAFAKAOATIATAdIANAbQAIARAGAJQALASAhAiIBFBEQAmAkAUARQAPAMAkAYIBOA0QAVAQAOAFQALAEARADIAcAFQAoAIAhAWIADACQATAMgDAOQgBAJgIAFIgCABQgHAEgHAAIgGgBg");
	this.shape_4.setTransform(-5.7167,-215.1565);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-184.3,-262.1,368.70000000000005,526.3);


(lib.Анимация33 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(2,1,1).p("AAZulQABG5gGCUQgHCYgbDyQgIBGgCBfQAAATAACTIAAB4QAAAvAAAtQABA7AAA4QACDCAHAg");
	this.shape.setTransform(-94.9929,-46.675);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f().s("#232323").ss(2,1,1).p("AR3AAIHfAAA5VAAIGLAAAyZAAMAjbAAA");
	this.shape_1.setTransform(-9.3,-270.4);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f().s("#232323").ss(4,1,1).p("EAX5gq0QBRF7BBF9AmQR4IgqAAIgPE+QgLGSAaGgQDdA2BsBRQBgBIgOBMQgNBIhsAxQhvAzipADQjYAFhogEQidgGhagaQjVg/BDjZQA/jIgZoyQgIivgQi+IgOicIsCAAQgMpYAQppQAXtgBQuBAFyR4IsCAAQgMpZARpoQAXtgBQuBAaS+RQEAX5gSYQItQAAIgPE+QgKGSAZGgQDeA2BrBRQBhBIgOBMQgOBIhrAxQhwAzipADQjYAFhogEQidgGhagaQjVg/BEjZQA+jIgZoyQgIivgPi+IgOicAQaR4IqoAAA8N9KQAnmxA0m5Am6R4Iq/AA");
	this.shape_2.setTransform(0.0233,3.7016);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("EAL6AqzQidgGhagaQjVg/BEjZQA+jIgZoyQgIivgPi+IgOicIKoAAIqoAAIsCAAQgFj9AAkAQAAlgAKlkQAXtgBQuBQhQOBgXNgQgKFkAAFgQAAEAAFD9IgqAAIq/AAIsCAAQgMpYAQppQAXtgBQuBQAEAGAJACQAKAEALgCQAdgDAegUQATgNAfgeICAh7QAugrAWgfQATgaAag2QAjhHARgoQAYg7AThEQANgzAVh5IALhDQAKg4AEgoMAjbAAAQAMBrAKA0QAGAfAQBFQAIAdAGANQAGAMANAQIAWAbQAKAPANAcIAWAsQANAVAUAXIAnApQA8A6AfAcQAzAvAuAfQAYARAyAeQAsAaAYAHQAIADAfAFQAYAFAOAGIATAKQAMAFAIABQALACAKgFIACgBQEAX5gSYQItQAAIgPE+QgKGSAZGgQDeA2BrBRQBhBIgOBMQgOBIhrAxQhwAzipADQh5ADhWAAQhDAAgugCgAvOgCIAABbIABBzQACDCAHAgQgHgggCjCIgBhzIAAhbIAAh4IAAimQAChfAIhGQAcjzAHiYQAFh/AAlXIAAh3IAAB3QAAFXgFB/QgHCYgcDzQgIBGgCBfIAACmIAAB4gEgLwAqzQidgGhagaQjVg/BDjZQA/jIgZoyQgIivgQi+IgOicIK/AAIgPE+QgLGSAaGgQDdA2BsBRQBgBIgOBMQgNBIhsAxQhvAzipADQh6ADhWAAQhDAAgtgCgAm6R4gEgaygq0IGLAAIABAHQAAAQgFATIgKAjQgLAmgGAsIgHA0IgHA0QgKA8gWA9QgSAzgpBSQgUAqgLAUQgTAjgTAYQgWAeg2AzIhaBUQgmAlgaAKQgdAHgMAIQgGAEgEAFQAnmxA0m5gAaI++QgjgXgqgJIgegFQgSgDgLgEQgPgGgWgQIhSg3QgmgZgQgNQgVgSgogmIhJhIQgjgjgLgUQgGgJgIgTIgOgcIgUgfQgPgUgGgKQgTghgOg8QgYhngHhnIHfAAQBRF7BBF9IgDgCg");
	this.shape_3.setTransform(0.0233,3.7016);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#232323").s().p("A7GHtQgJgDgFgGIgCgDQgEgKAFgLIAEgIQAEgFAGgEQANgHAcgIQAagKAngkIBZhVQA2gzAXgdQATgZASgiQAMgVAUgpQAohSATgyQAWg+AJg7IAIg0IAGg1QAHgrAKgnIAKgiQAFgUAAgPIAAgIIgCgUQgCgRADgLQAEgOANgIQAOgIALAJQAMAJgCAZIgDAjQgEApgKA3IgLBEQgVB5gNAyQgSBFgZA5QgRApgiBGQgbA3gSAaQgWAegvAsIh/B7QgfAdgTANQgeAVgdADIgHAAQgIAAgGgCgAa4GCQgJgBgLgGIgTgJQgOgHgZgEQgegGgJgCQgYgHgsgbQgygegYgQQgtggg0guQgfgcg7g7IgngoQgVgXgMgWIgWgqQgNgcgLgPIgVgbQgOgRgGgMQgGgNgHgdQgRhEgFggQgLg0gMhrIAAgDQgCgVADgLQADgIAGgFQAGgGAIAAQANAAAIAPQAGAMABASIABAJQAIBnAYBoQAOA7ATAhQAGALAOAUIAUAeIAOAdQAIASAGAKQAMATAjAjIBJBHQAnAnAWARQAQANAmAaIBRA3QAXAQAPAFQALAFASADIAdAFQAqAIAjAXIADADQAUANgCAPQgCAJgIAFIgCABQgIAEgIAAIgFAAg");
	this.shape_4.setTransform(-6.0193,-228.2464);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-194.1,-277.8,388.29999999999995,557.6);


(lib.Анимация30 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#232323").ss(0.1,1,1).p("AAAgBIAAAD");
	this.shape.setTransform(-22.6,8.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("AEbB/QgSg1AAhKQAAhKASg0QATg1AaAAQAaAAASA1QATA0AABKQAABKgTA1QgSA1gaAAQgaAAgTg1gAlzB/QgOgkgDgvQgCgQAAgSIAAgHIAAgDQAAhKATg0QASg1AaAAQAaAAASA1QATA0AABKIAAADIAAAHQAAASgCAQQgEAvgNAkQgSA1gaAAQgaAAgSg1g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-39.1,-18,78.2,36);


(lib.Анимация29 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#232323").ss(0.1,1,1).p("Ag8ATQgCgQAAgRIAAgEAA/gOQAAARgCAQ");
	this.shape.setTransform(-32.8,2.5125);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("AEcB/QgTg0AAhLQAAhJATg1QASg1AaAAQAaAAATA1QASA1AABJQAABLgSA0QgTA1gaAAQgaAAgSg1gAlzB/QgNgkgEgvQgCgQAAgRIAAgFIAAgDIAAgDQAAhJATg1QASg1AaAAQAaAAATA1QASA1AABJIAAADIAAAIQAAARgCAQQgEAvgMAkQgTA1gaAAQgaAAgSg1g");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-40.1,-18,79.2,36);


(lib.Анимация26 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AC1BuIgFgEQgrgsAAg+QAAg+ArgsQAsgrA/AAQA+AAAsArQAcAdAKAjQAGAVAAAVQAAA+gsAsQgsAsg+AAQg8AAgqgogAmABuIgFgEQgrgsAAg+QAAg+ArgsQAtgrA+AAQA+AAAsArQAcAdAKAjQAGAVAAAVQAAA+gsAsQgsAsg+AAQg8AAgqgog");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.3,-15,86.6,30);


(lib.Анимация25 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AC0BuIgDgEQgsgrAAg/QAAg9AsgtQArgrA/AAQA+AAAsArQAcAdAKAjQAGAVAAAVQAAA/gsArQgsAsg+AAQg8AAgrgogAmBBuIgDgEQgsgrAAg/QAAg9AsgtQArgrA/AAQA+AAAsArQAcAdAKAjQAGAVAAAVQAAA/gsArQgsAsg+AAQg7AAgsgog");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-43.3,-15,86.6,30);


(lib.Анимация24 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.газета60();
	this.instance.setTransform(-214.9,-258.55,0.4323,0.4323,1.4825);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-228,-258.5,456.1,517.1);


(lib.Анимация23 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.газета60();
	this.instance.setTransform(-221.55,-252.9,0.4323,0.4323);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-221.5,-252.9,443.1,505.8);


(lib.Анимация17 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Am2DeQhAgUgtg3Qgtg3gHhCQgHg9Acg7QAcg7A0gjQAzgiBBgEQBBgEA4AcQAuAXAfAoQAeAmANAxQAMAxgKAwQgJAwgdAqQgdApgqAZQgrAZgyAGIgbABQgkAAgigLgAFmDhQhAgEg2gnQg3gmgZg7QgYg7AKhBQALhCAqgxQApgwBAgUQBAgTA+AQQA+AQAuAwQAuAxANA+QAJApgHApQgHAqgVAkQggA4g7AfQg0Adg4AAIgOgBg");
	this.shape.setTransform(13.1968,62.4632);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("AKZPhIg+gIIg+gJQg5gHhlgCInbgKQh2gDhBABQhlABhRAKIhfALQg3AEgogJIgngLQgagIgOgDQgegHgpABIhIAFQgsACgdgCQgegDgYgJQgIAPgKAMQgiAlg5gFQg4gFgbgrQgOgXgFgiQgDgWABgoQABjpADh1QAFjDAOibIALiSQACgiAAhVQABhMADgrQALi0BHirQBGiqB3iJQA0g7AsgRQBYgfB+BTQBfA+AqBAQAhAzAZBgQAhB7AMAfQAOAhAXApIArBHIAhA2QAUAdAUAUQAXAXAiAWQAVAOArAXQAvAbAbAHQAiAIA2gGIBYgKIA1gBQAeAAAVgHQAugOAkg0QAWggAchEQBAieBHiEQAkhCAeg0QAXgmAQgVQAXgfAYgTQAuglA/gHQA+gHA1AbQA7AdAlBAQAjA7AIBHQAHA9gKBMQgGAlgNA5IACD1QAABjgCAyQgCA7gFAzIAlBsQBnEnAiE3QAEApgBAaQgDAlgPAaQgUAigpANQgkALghgLQgUALgcAEQgVADgoAAIiHAAIgbAAQhPAAgvgFgAj6GNQhBAEg0AjQg0AjgbA7QgcA6AGA+QAHBDAtA3QAtA3BAAUQAvAPAzgGQAygGAqgZQArgYAdgqQAdgpAJgxQAIgwgLgxQgMgygfgmQgfgngugXQgxgZg5AAIgOAAgAG0GSQhAAUgqAwQgqAwgKBCQgLBCAZA7QAZA7A2AnQA2AnBAAEQBAAEA7ggQA7ggAgg3QAVgkAGgqQAHgqgIgpQgNg/gugwQgugxg+gQQgcgHgcAAQgjAAgjALg");
	this.shape_1.setTransform(0.0152,0.0257);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-121,-99.8,242.1,199.7);


(lib.Анимация16 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("Am2DeQhAgUgtg3Qgtg3gHhCQgHg9Acg7QAcg7A0gjQAzgiBBgEQBBgEA4AcQAuAXAfAoQAeAmANAxQAMAxgKAwQgJAwgdAqQgdApgqAZQgrAZgyAGIgbABQgkAAgigLgAFmDhQhAgEg2gnQg3gmgZg7QgYg7AKhBQALhCAqgxQApgwBAgUQBAgTA+AQQA+AQAuAwQAuAxANA+QAJApgHApQgHAqgVAkQggA4g7AfQg0Adg4AAIgOgBg");
	this.shape.setTransform(13.1968,62.4632);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("AKZPhIg+gIIg+gJQg5gHhlgCInbgKQh2gDhBABQhlABhRAKIhfALQg3AEgogJIgngLQgagIgOgDQgegHgpABIhIAFQgsACgdgCQgegDgYgJQgIAPgKAMQgiAlg5gFQg4gFgbgrQgOgXgFgiQgDgWABgoQABjpADh1QAFjDAOibIALiSQACgiAAhVQABhMADgrQALi0BHirQBGiqB3iJQA0g7AsgRQBYgfB+BTQBfA+AqBAQAhAzAZBgQAhB7AMAfQAOAhAXApIArBHIAhA2QAUAdAUAUQAXAXAiAWQAVAOArAXQAvAbAbAHQAiAIA2gGIBYgKIA1gBQAeAAAVgHQAugOAkg0QAWggAchEQBAieBHiEQAkhCAeg0QAXgmAQgVQAXgfAYgTQAuglA/gHQA+gHA1AbQA7AdAlBAQAjA7AIBHQAHA9gKBMQgGAlgNA5IACD1QAABjgCAyQgCA7gFAzIAlBsQBnEnAiE3QAEApgBAaQgDAlgPAaQgUAigpANQgkALghgLQgUALgcAEQgVADgoAAIiHAAIgbAAQhPAAgvgFgAj6GNQhBAEg0AjQg0AjgbA7QgcA6AGA+QAHBDAtA3QAtA3BAAUQAvAPAzgGQAygGAqgZQArgYAdgqQAdgpAJgxQAIgwgLgxQgMgygfgmQgfgngugXQgxgZg5AAIgOAAgAG0GSQhAAUgqAwQgqAwgKBCQgLBCAZA7QAZA7A2AnQA2AnBAAEQBAAEA7ggQA7ggAgg3QAVgkAGgqQAHgqgIgpQgNg/gugwQgugxg+gQQgcgHgcAAQgjAAgjALg");
	this.shape_1.setTransform(0.0152,0.0257);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-121,-99.8,242.1,199.7);


(lib.Анимация15 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AmLDDQg5gJgqgkQgpgjgRg3QgRg3APg0QAPg1ArgnQAqgmA3gJQA2gJA1AWQA1AWAfAuQAjAygBA+QAAA3ggAwQggAwgyAWQglARgpAAQgOAAgPgCgAFqC/Qg3gCgwgiQgwghgVgzQgVg0AKg4QALg5AmgpQAmgoA5gOQA4gOA1ASQA0ASAkAuQAkAuAFA3QAGA2gZAxQgZAygyAeQgvAcg0AAIgGAAg");
	this.shape.setTransform(-0.0067,-0.0013);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.2,-19.6,112.4,39.3);


(lib.Анимация14 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AmLDDQg5gJgqgkQgpgjgRg3QgRg3APg0QAPg1ArgnQAqgmA3gJQA2gJA1AWQA1AWAfAuQAjAygBA+QAAA3ggAwQggAwgyAWQglARgpAAQgOAAgPgCgAFqC/Qg3gCgwgiQgwghgVgzQgVg0AKg4QALg5AmgpQAmgoA5gOQA4gOA1ASQA0ASAkAuQAkAuAFA3QAGA2gZAxQgZAygyAeQgvAcg0AAIgGAAg");
	this.shape.setTransform(-0.0067,-0.0013);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-56.2,-19.6,112.4,39.3);


(lib.Анимация12 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AhGDpQAAgOANgTQANgTAOAAQAJAAAOAIQANAIgBAFQAAAkgRAPQgSAPgNAAQgbAAAAgjgAgTBbQgQgDgGgEQgFgoAXhqQAThXAAgjQAAgxARgRQARgRANAAQAJAAAKAHQAJAIAAAJQAAAJgpCxQgQBJgBAnQAAAagIANQgIAAgQgDg");
	this.shape.setTransform(28.85,2.225);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("AhGDpQAAgOANgTQANgTAOAAQAJAAAOAIQANAIgBAFQAAAkgRAPQgSAPgNAAQgbAAAAgjgAgTBbQgQgDgGgEQgFgoAXhqQAThXAAgjQAAgxARgRQARgRANAAQAJAAAKAHQAJAIAAAJQAAAJgpCxQgQBJgBAnQAAAagIANQgIAAgQgDg");
	this.shape_1.setTransform(4.55,2.225);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#232323").s().p("AiVEUQgNgLAAgRQAAgOAYgPIAIgGQAIgHAMAAQAJAAAQANQAaAAAAAWQAAASgWAOQgWAOgRAAQgRAAgMgLgAhvBxQgDgPAAgHQAAgaAdg4IAEgJQAagXBJgbIAtgRQAWgJALgWQAKgWAAgUQAAgMgGgeQgHgdgWgJQgXgIgUAAQgrAAgUAMQgUAMgDAPQgDARgUAGQgLACgKAAQgUAAAAgWQAAgeAsgiQAsgiAdAAIAygCQAjgBAWAOQAWAOAUAVQATAWAAA/QAAA2gUAgQgUAfgfARQgfAQhhAfQgNAhgHAlQgEASgMAGQgMAGgWAAQgDAAgCgPg");
	this.shape_2.setTransform(-24.075,2.818);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#232323").ss(8,1,1).p("ATnAkQA2Fcl5EdQl4EdoUAAQoTAAl5kdQl4kdAAmTQAAmTF4keQF5kdHmAuQHlAuFwEmQFvEmA4Fdg");
	this.shape_3.setTransform(-0.0117,0.0299);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("At0KdQl4kdAAmTQAAmTF4keQF5kdHmAuQHlAuFwEmQFvEmA4FdQA2Fcl5EdQl4EdoUAAQoTAAl5kdg");
	this.shape_4.setTransform(-0.0117,0.0299);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-130.1,-99.4,260.29999999999995,198.9);


(lib.Анимация11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("Ag3C3QAAgLALgPQAKgPALAAQAHAAALAGQAKAGgBAFQAAAcgNAMQgOAMgKAAQgWAAAAgcgAgPBHQgMgCgFgEQgDgeAShUQAOhEAAgbQAAgnANgOQAOgNAKAAQAHAAAIAGQAHAGAAAIQAAAGggCLQgNA5AAAgQgBATgGAKQgGABgNgDg");
	this.shape.setTransform(22.675,1.75);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("Ag3C3QAAgLALgPQAKgPALAAQAHAAALAGQAKAGgBAFQAAAcgNAMQgOAMgKAAQgWAAAAgcgAgPBHQgMgCgFgEQgDgeAShUQAOhEAAgbQAAgnANgOQAOgNAKAAQAHAAAIAGQAHAGAAAIQAAAGggCLQgNA5AAAgQgBATgGAKQgGABgNgDg");
	this.shape_1.setTransform(3.575,1.75);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#232323").s().p("Ah1DZQgKgJAAgNQAAgLASgMIAHgFQAGgFAKAAQAHAAAMAKQAVAAAAARQAAAOgRALQgRALgOAAQgNAAgKgIgAhXBYIgDgRQAAgUAXgsIADgHQAVgSA5gVIAjgOQASgGAIgSQAJgRAAgQQgBgJgFgYQgGgXgQgGQgSgHgQAAQghAAgRAJQgPAKgCAMQgCANgRAEQgIACgIAAQgQAAAAgRQAAgYAjgaQAjgbAWAAIAngBQAcgCARAMQARAKAQARQAPARAAAxQAAAsgQAYQgPAZgYANQgZAMhMAZQgKAagGAdQgDAOgKAEQgJAFgRAAQgDAAgBgMg");
	this.shape_2.setTransform(-18.9,2.2163);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f().s("#232323").ss(8,1,1).p("APaAcQAqERkoDgQknDgmiAAQmhAAkojgQkojgAAk8QAAk9EojgQEojgF+AkQF9AkEhDnQEgDnAsESg");
	this.shape_3.setTransform(-0.0082,0.0003);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("Aq2INQkojfAAk9QAAk9EojgQEojgF+AkQF9AkEhDnQEgDnAsESQAqERkoDgQknDgmiAAQmhAAkojgg");
	this.shape_4.setTransform(-0.0082,0.0003);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-103.1,-78.9,206.2,157.9);


(lib.Анимация10 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.фоны_фонприхожаяcopy();
	this.instance.setTransform(-821.7,-522.75,0.35,0.3501);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Eh/ChBCMD+FAAAMAAACCFMj+FAAAg");
	this.shape.setTransform(-8.975,71.775);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Eh/CBBDMAAAiCFMD+FAAAMAAACCFg");
	this.shape_1.setTransform(-8.975,71.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-823,-522.7,1645.1,1045.5);


(lib.Анимация9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.instance = new lib.фоны_фонприхожаяcopy();
	this.instance.setTransform(-814.35,-522.75,0.35,0.3501);

	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#FFFFFF").ss(1,1,1).p("Eh/ChBCMD+FAAAMAAACCFMj+FAAAg");
	this.shape.setTransform(-16.325,72.025);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Eh/CBBDMAAAiCFMD+FAAAMAAACCFg");
	this.shape_1.setTransform(-16.325,72.025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-830.4,-522.7,1659.8,1045.5);


(lib.Анимация5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AD0E2IAAprICBAAIAAJrgAl0E2IAAprICAAAIAAD7IC9AAQBYABAyAeQAxAdAUAqQAUArAAAmQAAAxgXAqQgYAqgxAaQgzAahQAAgAj0DNIDCAAQAugBAYgUQAZgVAAgmQAAglgagVQgYgUgvgBIjAAAg");
	this.shape.setTransform(194.975,61.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("ADRGxIAAj2IobAAIAAprIB6AAIAAICIE4AAIAAoCIB5AAIAAICIBqAAIAAFfg");
	this.shape_1.setTransform(111.5,74.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#232323").s().p("AkQE2IAAprICBAAIAAD7IC7AAQBZABAyAeQAyAdAUAqQAUArgBAmQAAAxgXAqQgXAqgyAaQgyAahSAAgAiPDNIDAAAQAvgBAYgUQAZgVAAgmQAAglgZgVQgZgUgvgBIi/AAg");
	this.shape_2.setTransform(38.1506,61.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#232323").s().p("ADkE2IjjnmIjkHmIiEAAIEmprICDAAIElJrg");
	this.shape_3.setTransform(-35.65,61.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#232323").s().p("ACgE2IAAnDIk3HDIiIAAIAAprICBAAIAAHCIE1nCICJAAIAAJrg");
	this.shape_4.setTransform(-113.45,61.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#232323").s().p("AEDE2IjIkvIAAEvIh1AAIAAkvIjIEvIiPAAIDolUIjokXICPAAIDIEDIAAkDIB1AAIAAEDIDIkDICPAAIjoEXIDoFUg");
	this.shape_5.setTransform(-197.875,61.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#232323").s().p("AiYEbQhMgtgohKQgohKgBhaQABheArhJQAshKBLgrQBLgqBggBQBbABA/ArQA/AqAiBEQAhBEABBNIAAA7InvAAQAHAwAaApQAaAqAuAZQAvAZBFABQBNgBA2gQQA3gPAegQIAegQIAAB0QABABgZAPQgZAQg3APQg2APhaABQhtgBhNgsgAC0hFQgBgTgJgZQgIgagTgYQgTgagggQQghgQgzgBQgyABgiAQQgjAQgWAaQgWAYgLAaQgLAZgCATIFnAAIAAAAg");
	this.shape_6.setTransform(304.925,-40.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#232323").s().p("ACfE2IAAnDIk2HDIiIAAIAAprICBAAIAAHCIE1nCICKAAIAAJrg");
	this.shape_7.setTransform(229.7,-40.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#232323").s().p("ABsE2Ij4kPIAAEPIiCAAIAAprICCAAIAADjIDjjjICjAAIkoEXIE8FUg");
	this.shape_8.setTransform(160.8,-40.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#232323").s().p("AiAEbQhPgsgnhKQgohKAAhbQABhbArhKQAqhKBMgsQBMgrBlgBQAnAAAoAIQApAHAlARQAlAQAcAaIAACGQAAgCgOgNQgOgOgbgSQgcgSgqgPQgpgOg4AAQg9AAgwAdQgwAdgcAwQgbAwgBA7QABBhA8A6QA8A6BoABQBJgBAxgQQAygPAZgQQAZgPAAgBIAAB3QgdAXgoAMQgnANgpAGQgoAFghAAQhzgBhOgsg");
	this.shape_9.setTransform(90.275,-40.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#232323").s().p("ADjGBIAAiWInFAAIAACWIiBAAIAAj/IBRAAQAMgrAQhMQAQhMAMhlQAMhlABh1IHQAAIAAICIBhAAIAAD/gAhhisQgGAygJA3QgIA3gKAyQgJAzgJApIEUAAIAAmIIjZAAQgCAngGAzg");
	this.shape_10.setTransform(14.125,-32.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#232323").s().p("AirEcQhMgsgthKQguhKAAhbQAAhbAuhLQAthJBMgsQBNgsBfgBQBfABBMAsQBMAsAtBJQAuBLAABbQAABbguBKQgtBKhMAsQhMArhfABQhfgBhNgrgAhti2QgxAdgbAvQgcAwAAA7QAAA6AcAwQAbAwAxAcQAwAcA+ABQA9gBAwgcQAxgcAbgwQAdgwAAg6QAAg7gdgwQgbgvgxgdQgwgcg9gBQg+ABgwAcg");
	this.shape_11.setTransform(-66.05,-40.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#232323").s().p("AlKG/IAAtqICCAAIAAA7QAgghA3gWQA1gVBDgBQBfAABKAtQBIAsApBJQApBLABBbQgBBcgpBJQgpBJhIAtQhKArhfABQhLgBgzgYQgzgZgegiIAAFBgAhikxQgxAZgeAvQgeAwgBBEQABBEAeAwQAeAtAxAaQAyAZA5AAQA7gBAsgcQAsgcAYgvQAZgwAAg8QAAg7gZgwQgYgwgsgdQgsgcg7gBQg5AAgyAZg");
	this.shape_12.setTransform(-143.75,-28.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#232323").s().p("AirEcQhMgsgthKQgthKgChbQAChbAthLQAthJBMgsQBNgsBegBQBfABBNAsQBMAsAuBJQAsBLACBbQgCBbgsBKQguBKhMAsQhNArhfABQhegBhNgrgAhti2QgwAdgcAvQgcAwgBA7QABA6AcAwQAcAwAwAcQAxAcA8ABQA+gBAwgcQAwgcAcgwQAcgwABg6QgBg7gcgwQgcgvgwgdQgwgcg+gBQg8ABgxAcg");
	this.shape_13.setTransform(-226.2,-40.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#232323").s().p("AktGXIAAsuIJbAAIAAB7InaAAIAAKzg");
	this.shape_14.setTransform(-300.625,-49.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-349.4,-125,698.9,250);


(lib.Анимация4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Слой_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AD0E2IAAprICBAAIAAJrgAl0E2IAAprICAAAIAAD7IC9AAQBYABAyAeQAxAdAUAqQAUArAAAmQAAAxgXAqQgYAqgxAaQgzAahQAAgAj0DNIDCAAQAugBAYgUQAZgVAAgmQAAglgagVQgYgUgvgBIjAAAg");
	this.shape.setTransform(194.975,61.975);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("ADRGxIAAj2IobAAIAAprIB6AAIAAICIE4AAIAAoCIB5AAIAAICIBqAAIAAFfg");
	this.shape_1.setTransform(111.5,74.275);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#232323").s().p("AkQE2IAAprICBAAIAAD7IC7AAQBZABAyAeQAyAdAUAqQAUArgBAmQAAAxgXAqQgXAqgyAaQgyAahSAAgAiPDNIDAAAQAvgBAYgUQAZgVAAgmQAAglgZgVQgZgUgvgBIi/AAg");
	this.shape_2.setTransform(38.1506,61.975);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#232323").s().p("ADkE2IjjnmIjkHmIiEAAIEmprICDAAIElJrg");
	this.shape_3.setTransform(-35.65,61.975);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#232323").s().p("ACgE2IAAnDIk3HDIiIAAIAAprICBAAIAAHCIE1nCICJAAIAAJrg");
	this.shape_4.setTransform(-113.45,61.975);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#232323").s().p("AEDE2IjIkvIAAEvIh1AAIAAkvIjIEvIiPAAIDolUIjokXICPAAIDIEDIAAkDIB1AAIAAEDIDIkDICPAAIjoEXIDoFUg");
	this.shape_5.setTransform(-197.875,61.975);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#232323").s().p("AiYEbQhMgtgohKQgohKgBhaQABheArhJQAshKBLgrQBLgqBggBQBbABA/ArQA/AqAiBEQAhBEABBNIAAA7InvAAQAHAwAaApQAaAqAuAZQAvAZBFABQBNgBA2gQQA3gPAegQIAegQIAAB0QABABgZAPQgZAQg3APQg2APhaABQhtgBhNgsgAC0hFQgBgTgJgZQgIgagTgYQgTgagggQQghgQgzgBQgyABgiAQQgjAQgWAaQgWAYgLAaQgLAZgCATIFnAAIAAAAg");
	this.shape_6.setTransform(304.925,-40.025);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#232323").s().p("ACfE2IAAnDIk2HDIiIAAIAAprICBAAIAAHCIE1nCICKAAIAAJrg");
	this.shape_7.setTransform(229.7,-40.025);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#232323").s().p("ABsE2Ij4kPIAAEPIiCAAIAAprICCAAIAADjIDjjjICjAAIkoEXIE8FUg");
	this.shape_8.setTransform(160.8,-40.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#232323").s().p("AiAEbQhPgsgnhKQgohKAAhbQABhbArhKQAqhKBMgsQBMgrBlgBQAnAAAoAIQApAHAlARQAlAQAcAaIAACGQAAgCgOgNQgOgOgbgSQgcgSgqgPQgpgOg4AAQg9AAgwAdQgwAdgcAwQgbAwgBA7QABBhA8A6QA8A6BoABQBJgBAxgQQAygPAZgQQAZgPAAgBIAAB3QgdAXgoAMQgnANgpAGQgoAFghAAQhzgBhOgsg");
	this.shape_9.setTransform(90.275,-40.025);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#232323").s().p("ADjGBIAAiWInFAAIAACWIiBAAIAAj/IBRAAQAMgrAQhMQAQhMAMhlQAMhlABh1IHQAAIAAICIBhAAIAAD/gAhhisQgGAygJA3QgIA3gKAyQgJAzgJApIEUAAIAAmIIjZAAQgCAngGAzg");
	this.shape_10.setTransform(14.125,-32.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#232323").s().p("AirEcQhMgsgthKQguhKAAhbQAAhbAuhLQAthJBMgsQBNgsBfgBQBfABBMAsQBMAsAtBJQAuBLAABbQAABbguBKQgtBKhMAsQhMArhfABQhfgBhNgrgAhti2QgxAdgbAvQgcAwAAA7QAAA6AcAwQAbAwAxAcQAwAcA+ABQA9gBAwgcQAxgcAbgwQAdgwAAg6QAAg7gdgwQgbgvgxgdQgwgcg9gBQg+ABgwAcg");
	this.shape_11.setTransform(-66.05,-40.025);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#232323").s().p("AlKG/IAAtqICCAAIAAA7QAgghA3gWQA1gVBDgBQBfAABKAtQBIAsApBJQApBLABBbQgBBcgpBJQgpBJhIAtQhKArhfABQhLgBgzgYQgzgZgegiIAAFBgAhikxQgxAZgeAvQgeAwgBBEQABBEAeAwQAeAtAxAaQAyAZA5AAQA7gBAsgcQAsgcAYgvQAZgwAAg8QAAg7gZgwQgYgwgsgdQgsgcg7gBQg5AAgyAZg");
	this.shape_12.setTransform(-143.75,-28.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#232323").s().p("AirEcQhMgsgthKQgthKgChbQAChbAthLQAthJBMgsQBNgsBegBQBfABBNAsQBMAsAuBJQAsBLACBbQgCBbgsBKQguBKhMAsQhNArhfABQhegBhNgrgAhti2QgwAdgcAvQgcAwgBA7QABA6AcAwQAcAwAwAcQAxAcA8ABQA+gBAwgcQAwgcAcgwQAcgwABg6QgBg7gcgwQgcgvgwgdQgwgcg+gBQg8ABgxAcg");
	this.shape_13.setTransform(-226.2,-40.025);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#232323").s().p("AktGXIAAsuIJbAAIAAB7InaAAIAAKzg");
	this.shape_14.setTransform(-300.625,-49.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-349.4,-125,698.9,250);


// stage content:
(lib.фильм = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = false; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	// timeline functions:
	this.frame_0 = function() {
		playSound("a5230bf64dffcb6");
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1308));

	// Слой_105
	this.instance = new lib.городскиежильцыперсонажи41();
	this.instance.setTransform(-67,-99,0.712,0.712);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1055).to({_off:false},0).to({_off:true},65).wait(188));

	// Слой_104
	this.instance_1 = new lib.Анимация57("synched",0);
	this.instance_1.setTransform(-413.55,299.85);
	this.instance_1._off = true;

	this.instance_2 = new lib.Анимация58("synched",0);
	this.instance_2.setTransform(1215.4,299.85);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_1}]},1033).to({state:[{t:this.instance_1}]},11).to({state:[{t:this.instance_2}]},10).to({state:[]},1).wait(253));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1033).to({_off:false},0).to({scaleX:0.8276,scaleY:0.8276,x:738.2,y:437.15},11).to({_off:true,scaleX:1,scaleY:1,x:1215.4,y:299.85},10).wait(254));

	// Слой_103
	this.instance_3 = new lib.Анимация55("synched",0);
	this.instance_3.setTransform(1364,688.5);
	this.instance_3._off = true;

	this.instance_4 = new lib.Анимация56("synched",0);
	this.instance_4.setTransform(-598.55,689.35,2.2064,2.2064,0,0,0,0,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_3}]},1033).to({state:[{t:this.instance_4}]},21).to({state:[]},1).wait(253));
	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(1033).to({_off:false},0).to({_off:true,regY:0.1,scaleX:2.2064,scaleY:2.2064,x:-598.55,y:689.35},21).wait(254));

	// Слой_102
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#232323").s().p("AgVBCQgSgGgNgPQgNgPgDgTQgDgRAIgSQAHgTAPgLQASgOAXAAQAUgBASANQASAMAIATQAIATgFAVQgEAWgQAOQgNANgTAEQgIABgHAAQgLAAgKgDg");
	this.shape.setTransform(513.7033,185.679);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#232323").s().p("Ag3CfQgugPghgkQghglgHgsQgIgsATgsQASgtAmgcQAughA9AAQAzgBAvAeQAvAeAUAuQAUAugMAzQgMA2gnAiQgjAfgxAKQgUAEgSAAQgdAAgagJg");
	this.shape_1.setTransform(472.974,257.3025);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape,p:{x:513.7033,y:185.679}}]},1003).to({state:[{t:this.shape,p:{x:507.8533,y:184.929}}]},10).to({state:[{t:this.shape_1}]},11).to({state:[]},9).wait(275));

	// Слой_99
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhoBFQgrgcAAgpQAAgnArgdIAFgCQApgbA6AAQA7AAAqAbIAEACQArAdAAAnQAAApgrAcQgsAcg9ABQg8gBgsgcg");
	this.shape_2.setTransform(513.5,185);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AjtCdQhjhBAAhcQAAhaBjhBIAJgGQBgg8CEAAQCHAABgA9IAHAFQBjBBAABaQAABchjBBQhjBBiLAAQiLAAhihBg");
	this.shape_3.setTransform(484,256.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_2}]},1003).to({state:[{t:this.shape_3}]},21).to({state:[]},9).wait(275));

	// Слой_98
	this.instance_5 = new lib.городскиежильцыперсонажи33();
	this.instance_5.setTransform(108,86,0.3973,0.3973);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1003).to({_off:false},0).wait(21).to({scaleX:0.9052,scaleY:0.9052,x:-440,y:30},0).to({_off:true},9).wait(275));

	// Слой_94
	this.instance_6 = new lib.ВКВ22pngкопия();
	this.instance_6.setTransform(-86,-435,1.1352,1.1352);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(960).to({_off:false},0).to({_off:true},25).wait(323));

	// Слой_93
	this.instance_7 = new lib.городскиежильцыперсонажи29();
	this.instance_7.setTransform(313,-37,0.5574,0.5574);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(928).to({_off:false},0).to({_off:true},32).wait(348));

	// Слой_90
	this.instance_8 = new lib.городскиежильцыперсонажи28();
	this.instance_8.setTransform(235,52,0.4936,0.4936);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(905).to({_off:false},0).to({_off:true},23).wait(380));

	// Слой_92
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#232323").s().p("AEGFMIo2gWQghgBgXgMQgcgPACgZQADgWAbgLQAUgIAfAAIJPANIAAnHQAAgbACgPQADgXALgPQAMgSAWgGQAXgFAOAOQAKAJADASQABALgBAUQgQDuAKDtQABAigDASQgEAcgQARQgQAQgcAFQgOACgUAAIgSAAg");
	this.shape_4.setTransform(1004.5024,667.6699);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#232323").s().p("Am5F5QgQgNgDgTQgEgTAKgSQAKgSARgJQAOgIAVgCIAlgBQA1AAAwgFQBWgIBAgVQAggLAOgEQAZgGAzgBIC7gFQAZgBAKgGQAMgIAIgWQAIgYAFgoQAGg3ACgMQAJgiADgRIADgdQABgSADgKQADgOAJgTIAPggQAOgiANhJIAShnQAEgbALgKQALgKAQABQAQABALALQATASACAjQABAbgJAlIgSA+IgJAuQgFAbgGASQgGASgQAkQgJAZgGAjQgDASgHA+QgGAygHAeQgNAygZApQgSAcgTALQgVAMgsABIjLAEQgaABgOADQgLACgRAGIgbAJQgjALhAAGIiNAPQgkAEgOAGIgQAGQgKADgHABIgFABQgQAAgPgMg");
	this.shape_5.setTransform(976.0344,673.3036);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_4}]},905).to({state:[{t:this.shape_5}]},9).to({state:[]},14).wait(380));

	// Каркас_33
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#232323").s().p("APRVSQgtAAgtgOQgtgUgbgtQgbgpgSgtIgOgeIgTACQhcAKh7gCQi3gDi1gqQhcgahSg2QhOgphDhEIgKAKQgZAcgVASQg0Atg9AfQhKAqhUAXQg7ANg8gBIhCABQjhABjhAUQg6AGg7ANQg0AQg0AJQhLgCgkhVQgahlB0hHQBcgyBvAJIH9gaQA8gDA9gKIAYgGQBzgiBShiIAfgiQgShZAGhlQATnGFHlrQBuhzCmgWIBSAKIAKgCQhOiMAgi8QACiGAliBQBVizDbhBQBggvBmgiQBtgdB0AUQBnAUBPBNQA9BKAGBnQAKBggKBgIgBBmIABABQBLCJgiCpQgFCoAFClQAWBBACBEQAhF9i0FpQgFAagIAYQgmBzhfBcIAGAHQA2BGgDBfQgIAkgUAgQgjBBg7AvQgsAZg1AAIgYgBg");
	this.shape_6.setTransform(513.7361,567.6475);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#232323").s().p("APSVSQguAAgtgOQgtgUgagtQgbgpgTgtIgOgeIgTACQhcAKh6gCQi4gDi1gqQhbgahTg2QhOgqhDhEIgJALQgaAcgVARQgzAtg+AgQhKAqhWAYQg6AMg/gCIhCgCQjhgGjhANQg7AEg7ALQg1ANg0AIQhLgFghhWQgXhmB3hCQBegvBuAMIH+gJQA8gCA5gIIAXgGQBzgjBShhIAggjQgShZAGhlQATnFFHlrQBuhzCmgWIBSAKIAKgCQhOiMAgi8QACiGAliBQBVizDbhBQBggvBmgiQBugdBzAUQBoAUBOBNQA+BKAFBnQAKBggKBgIgBBmIABABQBLCJgiCpQgFCoAFClQAWBBACBEQAhF9i0FpQgFAagJAYQgmBzheBcIAFAHQA3BGgEBfQgHAkgVAgQgjBBg6AvQgsAZg1AAIgYgBg");
	this.shape_7.setTransform(513.6116,567.6475);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#232323").s().p("APTVSQguAAgtgPQgtgTgagtQgbgpgTguIgOgdIgTACQhcAKh6gCQi4gDi1grQhbgahTg2QhOgqhDhDIgJAKQgaAcgVASQgzAtg+AfQhKAqhYAaQg7ALhBgEIhCgEQjggOjhAFQg7ACg8AJQg1AMg1AGQhKgHgehYQgUhmB5g/QBfgsBuARIH+AIQA8ABA1gJIAXgGQBzgiBShiIAggiQgShZAGhlQATnGFHlqQBvh0CmgVIBRAJIALgBQhOiMAfi9QADiFAkiCQBVizDchBQBgguBmgiQBtgdB0AUQBnAUBOBNQA/BKAFBnQAKBggLBgIAABmIABABQBLCJgjCpQgECoAEClQAWBBACBEQAhF9i0FpQgFAagJAYQgmBzheBcIAFAHQA3BGgEBfQgHAkgVAgQgjBBg6AvQgsAZg1AAIgYgBg");
	this.shape_8.setTransform(513.5377,567.6975);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#232323").s().p("APTVSQgvAAgsgOQgtgUgagtQgbgpgTgtIgOgeIgTACQhcAKh6gCQi4gDi1grQhbgahTg2QhOgqhDhDIgJAKQgaAcgVASQgzAtg+AfQhKAqhaAbQg7AKhDgGIhCgGQjggWjhgCQg7AAg8AHQg1AKg1AEQhKgJgchZQgQhnB7g6QBhgpBtAUIH+AZQA8ADAwgIIAXgGQBzgiBShiIAggiQgShZAGhlQATnGFHlqQBvh0CmgVIBRAJIALgBQhOiMAgi9QACiFAliCQBVizDbhAQBggvBmgiQBugdBzAUQBoAVBOBNQA+BJAFBoQAKBfgKBhIgBBlIABACQBLCIgjCqQgECnAEClQAWBCADBEQAfF9izFoQgFAbgJAYQgmBzheBbIAFAHQA3BGgEBfQgHAkgVAgQgjBBg6AvQgtAZg0AAIgYgBg");
	this.shape_9.setTransform(513.5125,567.6975);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#232323").s().p("APTVSQgvAAgsgPQgtgTgbgtQgbgpgSguIgOgdIgTACQhcAKh6gCQi4gEi1gqQhbgahTg2QhOgqhDhEIgJALQgaAcgVARQgzAtg+AgQhKAqhdAbQg6AJhGgIIhBgIQjggdjggKQg7gCg9AFQg1AIg1ADQhKgMgYhaQgNhnB9g2QBigmBtAYIH8AqQA8AFAsgIIAXgFQBzgjBShhIAggjQgShZAGhlQATnFFIlrQBuhzCmgWIBSAKIAKgBQhOiNAgi8QADiGAkiBQBVizDchBQBgguBmgiQBtgdB0AUQBnAUBOBNQA/BLAFBnQAKBfgLBhIAABlIABACQBKCIgiCqQgFCnAEClQAWBCADBEQAfF9izFoQgFAagJAYQgmBzheBcIAFAHQA3BGgEBfQgIAkgUAgQgjBBg7AvQgsAZg0AAIgYgBg");
	this.shape_10.setTransform(513.5281,567.7475);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#232323").s().p("APSVSQguAAgtgPQgtgTgagtQgbgpgTgtIgOgeIgTACQhcAJh6gCQi4gCi1gsQhbgahSg2QhOgphDhEIgKAKQgZAdgVARQg0Atg9AgQhKAqhfAcQg7AIhIgKIhBgLQjegkjggSQg7gDg9ACQg2AHg1ABQhJgOgVhbQgJhoB+gyQBjgiBsAbIH7A8QA8AGAogHIAXgGQBzghBShiIAggjQgThZAGhlQAUnFFHlrQBvhzCmgVIBRAJIALgBQhNiMAfi9QACiFAliCQBVizDchAQBggvBmgiQBtgdB0AUQBnAUBOBOQA/BJAFBoQAKBfgLBhQgCA0ABAxIABABQBLCJgjCpQgECoAEClQAWBCACBEQAhF9i1FoQgFAbgIAXQgmB0hfBbIAGAHQA3BHgFBeQgHAlgVAfQgjBCg6AuQgtAZg1AAIgXgBg");
	this.shape_11.setTransform(513.5931,567.7497);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#232323").s().p("APQVSQguAAgsgPQgtgTgbgtQgbgpgSguIgOgdIgTACQhcAKh7gDQi3gDi1grQhbgahTg2QhNgqhEhDIgJAKQgaAcgUASQg0Atg+AfQhKAqhhAeQg7AHhJgMIhBgNQjdgtjfgYQg8gGg8ABQg2AEg1gBQhJgRgShbQgFhoB/gtQBlgfBrAfIH4BMQA8AJAkgHIAWgGQBzgjBShhIAhgiQgThZAGhlQATnGFIlqQBvh0CmgVIBRAKIALgCQhOiMAgi8QADiGAkiBQBVizDchBQBgguBmgiQBtgdB0AUQBnAVBOBNQA/BJAFBoQAKBfgLBhIAABlIABACQBKCIgjCqQgECnAEClQAWBCACBEQAgF9i0FoQgFAbgJAYQgmBzheBbIAGAHQA1BGgDBfQgIAkgUAgQgjBBg7AvQgsAZg0AAIgZgBg");
	this.shape_12.setTransform(513.7001,567.7975);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#232323").s().p("APPVSQguAAgtgPQgtgTgagtQgagpgTguIgOgeIgTACQhcAKh7gCQi3gDi1grQhcgahSg2QhOgqhDhEIgJALQgaAcgVARQg0Atg9AfQhKAqhkAfQg7AGhLgOIhAgPQjbg0jfggQg7gIg8gBQg2ADg1gEQhJgSgPhcQgChoCCgqQBlgbBqAiIH2BeQA7AKAfgHIAXgGQBzgiBShhIAggjQgShZAGhlQATnFFIlrQBvhzCmgVIBSAJIAKgBQhOiMAgi9QADiFAliCQBVizDbhAQBgguBmgiQBugdBzAUQBoAUBOBOQA+BJAFBoQAKBfgLBhIAABlIABACQBKCIgiCqQgFCnAEClQAWBCACBEQAgF9i0FoQgFAagJAYQgmBzhfBcIAGAHQA3BGgEBfQgIAkgUAgQgkBBg6AvQgsAZgzAAIgagBg");
	this.shape_13.setTransform(513.8331,567.8149);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#232323").s().p("APNVSQguAAgtgPQgtgUgagtQgbgpgTgtIgNgeIgTACQhcAKh7gCQi3gEi1grQhcgahSg2QhOgqhDhDIgJAKQgaAcgVASQg0Atg9AfQhKAqhmAfQg7AFhNgQIhAgRQjZg7jegoQg6gKg8gDQg2ABg1gFQhIgWgMhcQABhoCDglQBmgXBpAlIHyBvQA8AMAagIIAXgFQBzgjBShhIAggiQgShaAGhkQAUnGFIlqQBuh0CmgVIBSAKIAKgBQhNiNAgi8QACiGAliBQBVizDchAQBggvBmghQBtgdB0AUQBnAUBOBNQA/BLAFBnQAJBfgKBhIgBBlIABACQBLCIgjCqQgFCnAEClQAWBCACBEQAgF9i0FoQgFAagJAYQgmBzhfBcIAGAHQA3BGgEBfQgIAkgVAgQgjBBg6AvQgsAZg1AAIgYgBg");
	this.shape_14.setTransform(514.0096,567.8563);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#232323").s().p("APKVSQguAAgsgPQgtgTgbgtQgbgqgSgtIgOgeIgTACQhcAKh7gCQi3gDi1gsQhbgahTg2QhOgqhDhDIgJAKQgaAcgVASQgzAtg+AfQhKAqhoAgQg7AEhPgTIg/gTQjXhCjcgwQg7gMg7gFQg2AAg1gHQhHgYgJhdQAFhoCEggQBngUBnApIHuB/QA7APAWgJIAYgGQBzghBShiIAggjQgThZAGhlQAVnFFHlqQBvh0CmgVIBSAKIAKgBQhOiMAgi9QADiFAliCQBVizDchAQBgguBmgiQBtgdB0AUQBnAVBOBNQA/BJAFBoQAJBfgKBhIgBBlIABACQBLCJgjCpQgFCoAEClQAWBBACBEQAgF9i1FoQgFAbgIAYQgmBzhfBbIAFAHQA3BGgEBfQgIAkgUAgQgjBBg7AvQgrAZg0AAIgagBg");
	this.shape_15.setTransform(514.259,567.877);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#232323").s().p("APIVSQgvAAgsgPQgtgUgagsQgbgpgTguIgOgdIgTACQhcAJh6gCQi4gEi1gqQhbgbhSg2QhOgqhDhDIgKAKQgZAcgVASQg0Asg9AfQhKArhrAgQg7ADhQgVIg/gVQjVhKjag2Qg6gOg8gHQg2gDg0gIQhGgagGheQAJhnCFgcQBngSBmAuIHqCPQA6ARASgJIAXgGQBzghBShjIAggiQgShZAGhlQAUnFFIlqQBvhzCmgVIBRAJIALgCQhNiLAfi9QADiFAliCQBVizDchAQBgguBmgiQBtgdB0AUQBnAVBOBNQA/BKAFBnQAJBggKBgQgCA0ABAyIABABQBLCJgkCpQgECoAEClQAWBBACBEQAfF+i0FnQgFAbgJAYQgmByhfBcIAGAHQA3BHgFBfQgHAkgVAfQgjBCg7AvQgsAYg1AAIgXgBg");
	this.shape_16.setTransform(514.534,567.8997);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#232323").s().p("APEVSQguAAgtgPQgtgTgaguQgbgpgSgtIgOgeIgTACQhcAKh7gCQi3gEi1grQhcgbhSg1QhOgqhDhEIgJALQgaAcgVARQgzAtg+AfQhLAqhsAhQg7AChSgXIg+gXQjShRjYg+Qg5gQg8gJQg1gFg1gKQhFgdgDhcQAMhoCGgYQBpgMBjAvIHlChQA5ASAOgKIAYgFQBzgjBShhIAggiQgThZAHhlQATnGFJlqQBvhyCmgWIBRAKIALgCQhOiMAgi8QADiGAliBQBVizDchAQBggvBmghQBtgdB0AUQBnAVBOBNQA/BKAEBnQAKBggLBgIAABmIABABQBKCJgjCpQgFCoAEClQAWBBACBEQAgF9i1FoQgFAbgIAYQgmBzhfBbIAFAHQA3BHgEBfQgIAkgVAfQgjBCg6AuQgsAZgzAAIgagBg");
	this.shape_17.setTransform(514.884,567.9357);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#232323").s().p("APAVSQgvAAgsgPQgtgTgaguQgbgogTguIgNgdIgTABQhcAKh7gCQi3gEi1grQhcgbhSg2QhNgphEhEIgJAKQgaAdgVAQQgzAug+AfQhKAqhwAhQg6ABhTgZIg+gaQjPhXjWhGQg5gRg7gLQg1gHg0gMQhFgeABheQAQhmCGgUQBpgJBiAyIHfCxQA5AVAJgLIAYgGQBzgiBShhIAggiQgThaAHhkQAUnGFIlqQBvhzCmgVIBRAKIALgBQhNiNAgi9QACiFAliBQBWizDbhAQBgguBmgiQBugdBzAUQBoAVBOBNQA+BKAFBoQAKBfgLBgIgBBmIABACQBLCIgjCqQgFCnAEClQAVBCADBEQAfF9i1FoQgFAagIAYQgnBzheBbIAFAHQA2BHgDBfQgIAjgVAgQgjBCg6AvQgtAYg1AAIgXgBg");
	this.shape_18.setTransform(515.2765,567.9497);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#232323").s().p("AO8VSQgvAAgsgPQgtgTgaguQgbgpgTgtIgOgeIgTACQhcAJh6gCQi4gDi0grQhcgahSg3QhOgqhDhDIgJAKQgaAcgVARQg0Atg9AgQhKAphyAiQg7AAhUgcIg8gbQjNhfjThMQg4gUg7gNQg1gIg0gOQhEghAEhdQAThnCHgOQBpgGBhA2IHZDBQA4AWAFgLIAYgGQBzgiBShhIAggjQgThZAHhlQAUnFFIlqQBvhzCmgVIBSAKIAKgCQhNiNAgi7QADiGAliBQBVizDchAQBggvBmghQBtgdB0AUQBnAVBOBNQA/BKAEBnQAKBggLBgIgBBmIABABQBLCKgjCpQgFCnAEClQAWBCACBEQAfF9i1FoQgFAagIAYQgnBzheBbIAFAHQA3BHgFBfQgHAkgVAfQgjBCg7AuQgrAZg0AAIgZgBg");
	this.shape_19.setTransform(515.691,567.9857);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#232323").s().p("AO3VSQguAAgtgPQgtgUgagtQgbgpgSgtIgPgeIgTACQhcAKh6gDQi4gDi0gsQhbgahTg2QhOgqhDhEIgJALQgZAbgWASQg0Atg9AfQhKAqh1AiQg6gChWgeIg7gdQjJhljRhUQg4gVg6gQQg1gKgzgPQhCgjAHhdQAWhmCIgKQBpgCBfA5IHSDRQA3AYABgNIAYgGQBzghBShiIAggiQgThZAHhlQAVnGFIlqQBvhyCmgWIBSAKIAKgBQhOiMAhi9QACiFAliCQBWizDbhAQBhgtBlgiQBugdBzAUQBoAVBOBNQA+BKAFBnQAKBggLBgIgBBmIABABQBLCKgkCoQgECoADClQAWBCACBEQAfF9i1FoQgEAZgJAZQgnBzheBbIAFAHQA3BHgEBfQgIAkgUAfQgkBBg7AvQgrAZg0AAIgZgBg");
	this.shape_20.setTransform(516.1501,568.0149);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#232323").s().p("AOxVSQguAAgsgPQgtgTgbguQgbgpgSgtIgOgeIgTACQhcAJh6gCQi4gDi1gsQhbgahSg2QhOgqhDhEIgJALQgaAbgVASQg0Atg9AfQhKAqh3AiQg7gChWghIg7ggQjFhsjOhaQg3gXg6gSQg0gMgzgRQhBglAKhdQAahlCIgFQBqABBcA9IHLDgQA2AagDgOIAXgGQB0ghBShiIAggiQgThZAHhlQAUnGFJlqQBvhyCmgVIBRAJIALgBQhNiMAgi9QACiFAmiCQBViyDchAQBggvBmghQBtgdB0AUQBnAVBOBNQA/BLAEBnQAKBfgLBhQgCA0ABAxIABACQBLCIgkCqQgECnADClQAWBCACBEQAfF9i1FoQgFAagIAYQgnBzhfBbIAGAHQA3BHgFBfQgHAkgVAfQgjBCg7AvQgsAYg1AAIgYgBg");
	this.shape_21.setTransform(516.66,568.0455);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#232323").s().p("AOsVSQguAAgtgPQgtgUgagtQgbgpgSguIgOgdIgTACQhcAKh6gDQi4gEi1grQhbgahSg3QhOgqhDhDIgJAKQgaAcgVARQg0Atg9AfQhLAqh5AiQg5gDhZgjIg5giQjChyjLhiQg2gZg5gTQg0gOgygSQg/goANhcQAdhkCIgBQBpAEBbBBIHDDvQAaAOgEACQADADAVgHIAXgFQB0gjBShhIAggiQgThaAHhkQAVnFFIlqQBvhzCmgVIBSAKIAKgBQhNiNAgi8QADiGAliBQBWizDbhAQBggtBmgiQBugdBzAUQBoAVBOBNQA+BLAFBnQAJBfgLBhIAABlIABACQBKCIgjCqQgFCnADClQAWBCACBEQAfF9i1FoQgFAagIAYQgnBzhfBbIAGAHQA3BHgFBfQgIAkgUAfQgjBCg7AuQgsAZgzAAIgagBg");
	this.shape_22.setTransform(517.1912,568.0736);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#232323").s().p("AOmVSQguAAgtgPQgtgTgaguQgagpgTgtIgOgeIgTACQhcAJh7gCQi3gDi1gsQhbgahSg3QhOgqhDhDIgJAKQgaAcgVARQg0Atg+AfQhKAqh8AiQg5gDhZgnIg4gjQi+h6jIhoQg0gbg5gVQg0gPgxgUQg+gqAQhcQAhhjCIAEQBoAIBZBDIG6D/QAbAOgHADQABACAVgHIAXgGQBzghBThiIAggiQgThZAHhlQAVnFFIlqQBvhzCmgVIBSAKIAKgBQhNiNAgi8QADiGAmiBQBVizDcg/QBggvBmghQBtgdB0AUQBnAVBOBOQA/BJAEBoQAJBggKBgIgBBmIABABQBKCJgjCpQgFCoAEClQAVBBADBEQAeF9i1FoQgFAbgIAYQgnByhfBbIAGAHQA2BIgEBeQgIAkgUAgQgkBAg6AwQgsAYg1AAIgYgBg");
	this.shape_23.setTransform(517.7588,568.0955);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#232323").s().p("AOgVSQgvAAgsgPQgtgUgagtQgbgqgSgtIgOgdIgTACQhcAJh7gCQi3gEi1gsQhbgahTg2QhNgqhDhEIgKAKQgZAcgVASQg0Atg+AfQhKAph+AjQg5gFhagpIg3glQi5iAjFhvQg0gcg4gXQgzgRgwgWQg9gsAThbQAkhiCIAIQBpAMBWBGIGxENQAaAQgJABQAAADAUgHIAXgGQBzgiBThhIAggjQgThZAHhlQAVnFFJlpQBvh0CmgUIBRAKIALgCQhNiMAgi8QADiGAliBQBWizDbhAQBggtBmgiQBugdBzAUQBoAVBOBOQA+BJAFBoQAJBfgLBhIgBBlIABACQBLCJgkCpQgFCoAEClQAWBBACBEQAfF9i2FoQgFAagIAYQgnBzhfBbIAGAHQA2BHgEBfQgIAkgUAfQgkBCg6AuQgsAZg0AAIgZgBg");
	this.shape_24.setTransform(518.3741,568.1357);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#232323").s().p("AOZVSQgugBgtgOQgtgUgagtQgbgpgSguIgOgdIgTABQhcAKh6gDQi4gDi1gsQhagbhTg2QhNgqhEhEIgJALQgaAcgVARQgzAtg+AfQhKAqiBAiQg4gGhcgrIg1gnQi2iGjAh2Qgzgeg3gZQgzgSgvgYQg7guAWhaQAohiCGAOQBpAPBTBJIGpEbQAZARgMABQgBACAUgHIAXgGQBzghBShiIAggiQgShZAHhlQAUnGFJlpQBvhzCngVIBRAKIALgBQhOiMAhi9QADiFAliCQBViyDchAQBgguBmgiQBugcBzAUQBoAVBOBNQA+BLAFBnQAJBfgLBhQgCA0ABAxIABACQBLCJgkCpQgFCnAEClQAVBCACBEQAfF9i1FoQgFAagJAYQgnBzheBbIAFAHQA2BHgEBfQgHAkgVAfQgjBCg7AuQgsAZgzAAIgagBg");
	this.shape_25.setTransform(519.0024,568.1692);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#232323").s().p("AOTVSQgvAAgsgPQgtgUgagtQgbgqgTgtIgNgdIgTACQhcAJh7gDQi3gDi1gsQhcgbhSg2QhOgqhChEIgKALQgZAcgVARQg1Atg9AfQhKAqiDAiQg4gIhcgtIg1gpQiwiMi8h8Qgyggg2gbQgygUgvgZQg6gwAZhaQArhfCHASQBnASBRBMIGfEqQASAMgCAEQgBACgEAAQAEAAABgCIALgEIAXgGQBzghBThiIAggiQgThZAHhlQAVnGFKlpQBuhyCmgVIBSAKIAKgCQhNiNAhi8QACiFAmiBQBVizDchAQBgguBmghQBvgdByAUQBoAVBOBOQA+BKAFBnQAJBggLBgQgCA0ABAyIABABQBLCJgkCpQgFCoADClQAWBBACBEQAeF+i1FnQgFAbgIAYQgnByhfBbIAFAHQA3BIgEBeQgIAkgVAgQgjBAg7AwQgsAYg0AAIgYgBg");
	this.shape_26.setTransform(519.6845,568.1788);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#232323").s().p("AOLVSQgugBgsgOQgtgUgbgtQgagpgTguIgOgeIgTACQhcAJh6gCQi3gEi1grQhbgbhTg2QhOgqhChEIgKAKQgZAcgVASQg1Asg9AfQhKAqiGAiQg4gIhcgxIgzgqQiriSi5iCQgwgig2gcQgwgXgvgaQg4gyAchZQAuhdCGAVQBnAWBPBPIGUE3QAOALAAAEIAAABQAAADgGAAQAGAAAAgDIAAgBIAIgDIAXgGQBzghBThhIAggjQgThZAHhlQAVnFFKlpQBuhzCngVIBRAKIALgBQhNiNAgi8QADiGAliBQBWizDcg/QBgguBmgiQBugcBzAUQBnAVBOBOQA/BJAEBoQAKBggMBgIgBBmIABABQBLCJgkCpQgFCoADClQAWBBACBEQAeF9i1FoQgFAagIAYQgnBzhfBbIAFAHQA3BHgFBfQgHAkgVAfQgkBCg6AuQgsAZg0AAIgZgBg");
	this.shape_27.setTransform(520.3966,568.2192);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#232323").s().p("AOEVSQgvAAgsgPQgtgUgagtQgbgpgSguIgOgdIgTACQhcAJh7gDQi3gDi1gsQhagbhTg2QhOgqhDhEIgJAKQgaAcgVASQg0Asg9AfQhLAqiIAhQg3gJhdgzIgygsQimiYi0iIQgwgkg0geQgwgXgtgdQg2gzAfhYQAxhdCFAbQBmAaBMBRIGKFFQAKAIACAFQgOAGAHgBQAKAAgDgFIAEgCIAYgGQBzghBShhIAggjQgShZAHhlQAVnFFKlpQBuhzCmgVIBSAKIAKgBQhNiMAhi9QADiFAliCQBWiyDchAQBgguBmghQBugdBzAVQBnAUBOBOQA/BKAEBnQAKBggMBgIgBBmIABABQBLCKgkCpQgGCnAEClQAVBCADBEQAeF9i1FnQgFAbgJAYQgmBzhgBbIAGAHQA3BGgFBfQgIAkgVAgQgjBBg7AvQgsAYg0AAIgYgBg");
	this.shape_28.setTransform(521.148,568.2374);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_6}]},905).to({state:[{t:this.shape_7}]},1).to({state:[{t:this.shape_8}]},1).to({state:[{t:this.shape_9}]},1).to({state:[{t:this.shape_10}]},1).to({state:[{t:this.shape_11}]},1).to({state:[{t:this.shape_12}]},1).to({state:[{t:this.shape_13}]},1).to({state:[{t:this.shape_14}]},1).to({state:[{t:this.shape_15}]},1).to({state:[{t:this.shape_16}]},1).to({state:[{t:this.shape_17}]},1).to({state:[{t:this.shape_18}]},1).to({state:[{t:this.shape_19}]},1).to({state:[{t:this.shape_20}]},1).to({state:[{t:this.shape_21}]},1).to({state:[{t:this.shape_22}]},1).to({state:[{t:this.shape_23}]},1).to({state:[{t:this.shape_24}]},1).to({state:[{t:this.shape_25}]},1).to({state:[{t:this.shape_26}]},1).to({state:[{t:this.shape_27}]},1).to({state:[{t:this.shape_28}]},1).to({state:[]},1).wait(380));

	// Слой_88
	this.instance_9 = new lib.городскиежильцыперсонажи27();
	this.instance_9.setTransform(109,-107,0.5642,0.5642);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(889).to({_off:false},0).to({_off:true},16).wait(403));

	// Слой_86
	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#232323").s().p("AHPERQhWgMg9g3Qg8g2gVhUQgVhTAchNQATg2ApgrQApgrA1gWQA1gWA7ACQA7ACA0AZQBLAkArBPQAqBNgIBTQgHBGgoA7QgpA8g+AfQg3Abg/AAQgUAAgUgCgAn9ETQhKgEg8gmQg8gmgjhBQgjhCAChGQAChPAvhGQAwhFBKgeQBhgnBrAqQBqAqAsBgQAsBfgmBsQgmBshdAvQg6AehDAAIgNAAg");
	this.shape_29.setTransform(821.7661,482.333);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#232323").s().p("AHQELQhUgLg7g2Qg7g2gVhSQgVhQAchMQATg1AogqQAogqA0gVQAzgWA7ACQA5ACAzAYQBJAkArBNQApBMgJBRQgHBEgnA5QgoA7g8AeQg2Abg9AAQgUAAgUgCgAn8ENQhIgDg8glQg7gmgihAQgihAAChFQAChNAuhFQAvhDBIgeQBggmBoApQBpApAqBeQArBegkBpQgmBqhbAuQg5AdhCAAIgMAAg");
	this.shape_30.setTransform(821.7425,482.3343);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#232323").s().p("An8EHQhHgDg6gkQg6glghg/Qgig/AChDQAChMAuhDQAuhCBGgdQBegmBmApQBnAoApBcQArBcgkBnQglBnhaAuQg3AdhAAAIgNgBgAHREEQhSgLg6g0Qg6g0gUhRQgUhOAahKQATg0AngpQAngpAzgVQAygVA5ABQA5ACAyAYQBHAjApBLQApBKgJBQQgGBCgnA5QgnA5g7AeQg1Aag7AAQgTAAgUgDg");
	this.shape_31.setTransform(821.7181,482.3582);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#232323").s().p("An7ECQhGgEg5gkQg4gkghg9Qghg+AChBQAChLAshBQAthBBGgcQBbgmBkAoQBkAoApBaQAqBZgkBlQgjBmhYAtQg3AchAAAIgKAAgAHSD+QhQgLg5gzQg5gzgThOQgUhOAahHQASgzAmgoQAmgoAygVQAygUA3ABQA3ACAxAXQBGAiAoBKQAnBIgHBOQgHBBglA3QgnA4g6AdQgzAag7AAQgSAAgTgDg");
	this.shape_32.setTransform(821.7048,482.4022);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#232323").s().p("An7D8QhEgDg3gjQg4gkggg7Qggg9AChAQAChJArhAQAshABEgbQBaglBiAnQBiAnAoBYQAoBYgiBjQgjBjhWAsQg2Acg+AAIgLgBgAHTD4QhOgKg4gzQg3gxgThNQgThLAZhGQASgyAlgnQAlgnAxgUQAwgUA2ABQA2ACAwAXQBEAhAnBIQAnBGgIBMQgGBAglA1QglA3g5AcQgyAag6AAQgSAAgSgDg");
	this.shape_33.setTransform(821.6803,482.4023);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#232323").s().p("An6D3QhDgDg2gjQg3gigfg7Qggg7ACg/QAChHArg/QArg+BCgbQBYgkBgAnQBgAlAnBWQAoBWgiBhQgiBhhUArQg1Abg9AAIgKAAgAHUDyQhMgKg3gxQg2gwgShLQgThKAZhEQARgxAkgmQAlgmAvgUQAvgTA1ABQA1ACAuAWQBDAhAmBGQAmBFgIBKQgGA+gkA0QgkA2g3AbQgxAZg3AAQgSAAgTgDg");
	this.shape_34.setTransform(821.6565,482.4084);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#232323").s().p("An6DxQhBgDg1ghQg1gigfg6Qgfg5ACg+QAChGAqg9QAqg9BBgaQBWgjBeAmQBdAkAnBVQAmBUghBeQghBfhSAqQg0Abg7AAIgLgBgAHVDsQhKgKg1gvQg1gwgShJQgThHAZhDQARgwAjglQAkglAugTQAugTA0ABQAzACAtAVQBBAgAmBEQAkBEgHBIQgGA8gjA0QgkA0g2AbQgvAYg3AAQgRAAgSgDg");
	this.shape_35.setTransform(821.6105,482.4085);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#232323").s().p("An5DsQhAgDg0ghQg0ghgeg4Qgeg4ACg9QAChEApg8QApg7A/gaQBUgiBcAlQBcAkAlBSQAmBSggBdQghBchQApQgzAag6AAIgKAAgAHWDmQhIgJg0gvQgzgugShHQgShGAYhBQARgvAigjQAjglAsgTQAtgSAzABQAyACAsAVQBAAfAkBCQAkBCgIBGQgFA7gjAyQgiAzg1AaQguAYg1AAQgRAAgSgDg");
	this.shape_36.setTransform(821.5861,482.4086);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#232323").s().p("An5DnQg+gEgzggQgygggeg3Qgdg3ABg7QAChCAog7QApg6A+gZQBRghBaAkQBZAjAlBQQAlBQggBbQggBbhOAnQgyAag5AAIgJAAgAHXDhQhHgKgygtQgygtgRhFQgShFAYg/QAQgtAhgjQAigkAsgSQAsgSAxABQAwACArAUQA+AeAkBBQAiBAgGBFQgGA5ghAxQgiAygzAZQguAXg0AAQgQAAgRgCg");
	this.shape_37.setTransform(821.5729,482.4244);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#232323").s().p("An4DhQg9gDgxgfQgygggdg1Qgcg2ABg5QAChCAng4QAog5A8gZQBQggBYAjQBXAiAkBOQAkBPgfBYQgfBZhNAnQgxAYg4AAIgIAAgAHYDbQhEgKgxgsQgxgrgRhEQgRhCAXg+QAQgsAggiQAhgjAqgRQArgSAwABQAvACAqAUQA9AdAiA/QAiA+gHBDQgFA4ghAwQghAwgyAZQgsAWgzAAQgQAAgQgCg");
	this.shape_38.setTransform(821.5484,482.4246);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#232323").s().p("An4DcQg7gDgwgfQgxgfgcg0Qgcg0ACg4QAChAAmg3QAmg4A7gYQBOgfBWAiQBVAhAjBNQAjBMgeBWQgfBXhKAmQgwAYg2AAIgJAAgAHZDVQhDgJgvgrQgwgrgQhBQgRhBAWg8QAQgrAfghQAggiAqgRQApgRAvABQAuACApATQA6AdAiA9QAhA9gHBBQgFA2ggAuQggAvgwAYQgrAWgxAAQgQAAgQgCg");
	this.shape_39.setTransform(821.5247,482.4247);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#232323").s().p("AqeEkQhPgEhAgoQhBgpglhGQglhFAChLQAChVAzhJQAzhKBPggQBngqByAtQBxAtAvBlQAuBmgnBzQgpBzhjAzQg/AfhIAAIgMAAgAJ2EbQhZgMg/g5QhAg5gWhXQgWhWAehQQAUg5AqgsQArgtA3gXQA3gWA+ABQA9ACA3AaQBOAmAsBSQAsBQgJBXQgHBJgqA9QgqA+hBAgQg5AdhBAAQgVAAgVgDg");
	this.shape_40.setTransform(832.8964,508.279);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#232323").s().p("AqdEcQhMgDg/goQg/gogkhDQgkhEAChJQAChSAxhIQAyhIBNgfQBkgpBvAsQBuAsAuBjQAtBjgnBvQgnBwhhAyQg8AfhGAAIgNgBgAJ4ERQhVgMg9g3Qg9g3gVhTQgVhTAchNQAUg3AogqQApgrA1gXQA1gVA8ABQA7ACA0AZQBLAkArBPQAqBOgIBTQgHBGgpA7QgoA8g/AfQg2Acg/AAQgUAAgVgDg");
	this.shape_41.setTransform(832.7656,508.2735);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#232323").s().p("AqaEVQhLgEg9gmQg9gngjhCQgjhCABhHQADhQAwhFQAwhGBLgfQBignBsArQBrAqAsBgQAsBggmBtQgnBthdAwQg8AehDAAIgMAAgAJ8EGQhSgLg7g1Qg6g1gVhQQgUhPAbhKQATg1AngpQAngpA0gVQAygVA6ABQA4ACAyAYQBIAjAqBLQAoBLgIBQQgHBDgmA4QgoA6g7AeQg1Aag9AAQgTAAgTgCg");
	this.shape_42.setTransform(832.5957,508.2919);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#232323").s().p("AqZENQhIgEg8glQg7gmgihAQgjhAAChFQADhNAuhEQAvhEBJgdQBfgnBpAqQBoApAqBdQArBegkBpQgmBqhbAvQg5AdhCAAIgMAAgAJ+D7QhPgLg3gzQg5gygThNQgUhMAahHQATgyAlgnQAlgoAygUQAwgUA3ABQA2ACAxAXQBFAhAnBJQAnBHgIBNQgGBAglA2QgmA4g5AcQgzAag6AAQgSAAgTgDg");
	this.shape_43.setTransform(832.4626,508.274);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#232323").s().p("AqXEFQhGgDg6glQg6gkghg+Qghg+AChDQAChMAthBQAuhCBGgdQBdgmBlApQBlAoAqBaQApBcgjBmQgkBmhZAuQg4AchBAAIgKAAgAKBDwQhLgKg2gxQg2gvgShKQgThJAZhEQASgwAjgmQAkgmAvgTQAvgTA1ABQAzACAuAWQBDAgAlBFQAmBEgIBKQgGA9gkA0QgkA1g2AbQgwAZg3AAQgSAAgTgDg");
	this.shape_44.setTransform(832.3319,508.2888);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#232323").s().p("AqVD9QhFgDg3gjQg4gkggg8Qghg8AChBQAChJAshAQAthABDgcQBagkBjAnQBiAnAoBYQAoBYgiBjQgjBkhWAsQg2Abg+AAIgLAAgAKEDmQhIgKgzgvQg0gtgRhHQgShGAYhAQAQguAigkQAjgkAtgTQAsgTAzACQAxABAsAWQA/AeAkBCQAkBCgHBGQgGA6giAyQgiAyg1AbQguAXg1AAQgRAAgRgCg");
	this.shape_45.setTransform(832.1543,508.2833);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#232323").s().p("AqTD1QhDgDg2giQg2gigfg7Qgfg6ABg/QAChHArg+QArg+BCgbQBXgjBgAmQBfAmAnBVQAnBWgiBfQgiBhhTArQg0Abg7AAIgMgBgAKHDbQhEgKgxgsQgxgrgRhEQgRhCAWg+QAQgrAhgjQAggiAsgSQAqgSAwACQAvABAqAVQA8AcAjBAQAhA+gGBDQgGA4ggAvQghAwgyAZQgsAWgyAAQgQAAgRgCg");
	this.shape_46.setTransform(832.0244,508.275);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#232323").s().p("AqSDuQhAgEg0ghQg1ghgeg5Qgeg4ABg9QADhEApg8QAqg8A/gaQBVgjBcAmQBcAkAmBSQAmBTggBdQgiBdhQAqQgzAag6AAIgLAAgAKKDQQhBgJgugqQgvgpgQhBQgRg+AWg7QAPgqAfggQAfghApgRQAogRAuACQAsABApATQA5AcAhA8QAgA7gHA/QgFA2gfAsQgfAugvAYQgqAVgwAAQgPAAgQgCg");
	this.shape_47.setTransform(831.8514,508.2837);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#232323").s().p("AqQDmQg+gDgyggQgzgggdg3Qgeg3ACg7QAChCAog6QAog6A+gZQBRghBaAkQBZAjAkBPQAlBRgfBZQggBbhOAoQgxAZg4AAIgLAAgAKNDFQg+gIgsgoQgsgngPg9QgQg8AVg3QAOgoAdgfQAegfAngQQAmgQArACQAqABAmASQA3AaAfA5QAeA4gGA8QgFAzgdAqQgeAsgtAWQgnAUgtAAQgPAAgPgCg");
	this.shape_48.setTransform(831.7207,508.2715);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_29}]},859).to({state:[{t:this.shape_30}]},1).to({state:[{t:this.shape_31}]},1).to({state:[{t:this.shape_32}]},1).to({state:[{t:this.shape_33}]},1).to({state:[{t:this.shape_34}]},1).to({state:[{t:this.shape_35}]},1).to({state:[{t:this.shape_36}]},1).to({state:[{t:this.shape_37}]},1).to({state:[{t:this.shape_38}]},1).to({state:[{t:this.shape_39}]},1).to({state:[]},1).to({state:[{t:this.shape_40}]},10).to({state:[{t:this.shape_41}]},1).to({state:[{t:this.shape_42}]},1).to({state:[{t:this.shape_43}]},1).to({state:[{t:this.shape_44}]},1).to({state:[{t:this.shape_45}]},1).to({state:[{t:this.shape_46}]},1).to({state:[{t:this.shape_47}]},1).to({state:[{t:this.shape_48}]},1).to({state:[]},1).wait(419));

	// Слой_85
	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#0B88F0").s().p("EAEoAqTMg7DgD3QSp1plN7OIYr/3MBGwANGUgNYAmbANYAhEgAwaNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_49.setTransform(808.7,470.025);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#0B88F0").s().p("EAE2AqTMg7ggDeQRO12jU7aIYr/3UAjcAH3AjUAFPUgMhAmTAMhAhMgAwLNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_50.setTransform(807.225,470.025);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#0B88F0").s().p("EAFFAqTMg7+gDGQPy2Chb7mIYs/3UAjgAJLAjQAD7UgLpAmKALpAhVgAv8NDIdWAAIIIBAIFMzsMgqqgExg");
	this.shape_51.setTransform(805.75,470.025);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#0B88F0").s().p("EAFUAqTMg8cgCtQOX2OAe7zIYr/3UAjlAKfAjLACnUgKxAmBAKxAhegAvuNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_52.setTransform(804.3,470.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#0B88F0").s().p("EAFiAqTMg84gCUQM62bCY7/IYr/3UAjpALzAjHABTUgJ5Al5AJ5AhmgAvfNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_53.setTransform(802.825,470.025);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#0B88F0").s().p("EAFxAqTMg9WgB7QLf2oEQ8LIYs/3UAjtANIAjDgACUgJBAlwAJBAhvgAvQNDIdWAAIIIBAIFMzsMgqqgExg");
	this.shape_54.setTransform(801.35,470.025);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#0B88F0").s().p("EAGAAqTMg90gBjQKD20GK8XIYs/3UAjyAOcAi+gBWUgIJAloAIJAh3gAvCNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_55.setTransform(799.875,470.025);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#0B88F0").s().p("EAGPAqTMg+SgBKQIo3BID8jIYr/3UAj3APwAi5gCqUgHQAlfAHQAiAgAuzNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_56.setTransform(798.4,470.025);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#0B88F0").s().p("EAGdAqTMg+ugAxQHM3OJ78vIYs/3UAj6AREAi2gD+UgGYAlWAGYAiJgAukNDIdWAAIIIBAIFMzsMgqqgExg");
	this.shape_57.setTransform(796.95,470.025);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#0B88F0").s().p("EAGsAqTMg/MgAZQFw3aL187IYs/3UAj/ASYAixgFSUgFhAlOAFhAiRgAuWNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_58.setTransform(795.475,470.025);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#0B88F0").s().p("EAG7AqTMg/qAAAQEU3nNv9HIYr/3UAkEATsAisgGmUgEoAlFAEoAiagAuHNDIdWAAIIJBAIFMzsMgqrgExg");
	this.shape_59.setTransform(794,470.025);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#0B88F0").s().p("EAJNA4RMhUrAAAUAFvgfaASQgmvMAg2gqYUAv+AaNAuKgIzUgGLAxWAGLAtxgAyxRWMAnCAAAIK1BWIG56NMg4wgGWg");
	this.shape_60.setTransform(796.3,491.8);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#0B88F0").s().p("EhL3A3wUAIYgf7APogmOQRDz4P31eUAv5AZKAu7gGSUgG7Au2AGLAtxgAzKQ1MAnDAAAIK1BVIHd56Mg5VgGog");
	this.shape_61.setTransform(798.75,495.15);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#0B88F0").s().p("EhMPA3PUAK/ggeANAglsQRqyhPV1yUAv1AYIAvsgDyUgHtAsVAGLAtygAziQUMAnCAAAIK1BVIIA5pMg53gG5g");
	this.shape_62.setTransform(801.2,498.475);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#0B88F0").s().p("EhMoA2tUANogg/AKYglKQSRxNOy2DUAvxAXEAwdgBRUgIeAp1AGLAtxgAz7PyMAnDAAAIK1BVIIk5XMg6cgHLg");
	this.shape_63.setTransform(803.65,501.825);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#0B88F0").s().p("EhNAA2MUAQQghhAHvgkoQS5v4OP2WUAvsAWCAxOABPUgJPAnUAGLAtygA0TPRMAnCAAAIK1BVIJI5FMg6/gHdg");
	this.shape_64.setTransform(806.1,505.15);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#0B88F0").s().p("EhNYA1qUAS4giCAFHgkHQTgujNs2nUAvoAU+Ax+ADwUgJ/Ak0AGLAtxgA0sOvMAnDAAAIK1BWIJr40Mg7jgHvg");
	this.shape_65.setTransform(808.525,508.5);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#0B88F0").s().p("EhNxA1JUAVggikACggjlQUHtNNJ27UAvjAT8AywAGQUgKwAiUAGKAtxgA1EOOMAnCAAAIK1BVIKP4hMg8GgIBg");
	this.shape_66.setTransform(810.975,511.825);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#0B88F0").s().p("EhOJA0oUAYIgjGgAJgjEQUur4Mn3NUAvfAS6AzgAIvUgLhAf0AGLAtygA1dNtMAnDAAAIK1BVIKy4QMg8qgISg");
	this.shape_67.setTransform(813.425,515.175);

	this.shape_68 = new cjs.Shape();
	this.shape_68.graphics.f("#0B88F0").s().p("EAGJA0GMhUrAAAUAaxgjngCxgiiQVVqjME3gUAvaAR4A0SALPUgMSAdUAGKAtxgA11NLMAnCAAAIK1BWILW3/Mg9NgIkg");
	this.shape_68.setTransform(815.875,518.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_49}]},859).to({state:[{t:this.shape_50}]},1).to({state:[{t:this.shape_51}]},1).to({state:[{t:this.shape_52}]},1).to({state:[{t:this.shape_53}]},1).to({state:[{t:this.shape_54}]},1).to({state:[{t:this.shape_55}]},1).to({state:[{t:this.shape_56}]},1).to({state:[{t:this.shape_57}]},1).to({state:[{t:this.shape_58}]},1).to({state:[{t:this.shape_59}]},1).to({state:[]},1).to({state:[{t:this.shape_60}]},10).to({state:[{t:this.shape_61}]},1).to({state:[{t:this.shape_62}]},1).to({state:[{t:this.shape_63}]},1).to({state:[{t:this.shape_64}]},1).to({state:[{t:this.shape_65}]},1).to({state:[{t:this.shape_66}]},1).to({state:[{t:this.shape_67}]},1).to({state:[{t:this.shape_68}]},1).to({state:[]},1).wait(419));

	// CAT
	this.shape_69 = new cjs.Shape();
	this.shape_69.graphics.f("#FFFFFF").s().p("ArnEEQhqhkgGiFQgGiFBghtQBfhuCFgLQCFgMBxBcQBxBbARCEQAHA2gKA3QgLA3gaAwQgtBRhTAxQhTAxhcABIgDAAQiEAAhohjgAHAFLQhXgQhHg7QhHg6gghSQguhzAsh9QAsh+Brg/QBrg+CDAYQCEAZBNBgQBOBhgFCFQgECFhUBbQg7BBhXAdQg5ASg4AAQgfAAgegFg");
	this.shape_69.setTransform(822.8917,481.3406);

	this.shape_70 = new cjs.Shape();
	this.shape_70.graphics.f("#232323").s().p("Egv8AquQiohIgfiaQgWhvA9iAQArhZBlh7IE8l5QC+jjB2icQFSnACUmJQBBiuAVgrQAihFAqgwIABgIQAGhJAciDQBHlRA4jfQBPk4BUjjQBqkcCKjcQCcj6DPizQDhjCEBhUQA4gSBzgfQBmgeA/giQAigSBBgsQBAgsAjgSQBVgtB0gYQBOgQCHgMQFwghF/gGQCdgCBiAHQCMAKBwAfQDLA4C4CQQCoCCCIC+QB1ChBoDbQBJCYBjD+QBBCmAkBmQA0CVAfB9QBFETAQFNQALD9gSFsIgJCyQANAtALA3QA3EKAZFEQATDyAGFiQADCvgdBsQgpCYhtA9QhNAshjgKQhXA+hjgDQhSgDhOgwIgOgJQgfAfgoAaQhlBBhxgDQgYAAhBgIQg4gHghACQgvAChBATQhJAaglALQh0AkiZALQhcAGi4AAI0kgFQhYAAgxgEQhMgHg5gUQhFgYgxgvQg2gzgPhAIqAgTQgsgBgXADQglAEgZAPQghATgaAwQgPAagbA5QgtBThYAwQhXAwhfgGQhfgFhRg6QhRg6gkhYQhWAIhVgaQhUgZhEg1QiMCihXBLQiKB4iKAqQhFAVhDAAQheAAhdgogAD12VQiFAMhgBtQhfBuAHCFQAGCFBoBkQBqBkCFgBQBdAABTgxQBTgyAshRQAbgwAKg3QALg3gHg2QgRiFhxhbQhlhRh0AAIgdABgARf19QhrA+gsB+QgsB+AtB0QAhBSBHA6QBHA6BWAQQBXAQBXgdQBXgdA8hBQBThbAFiFQAEiGhNhgQhOhhiDgYQglgHgjAAQhZAAhNAtg");
	this.shape_70.setTransform(744.649,590.5782);

	this.shape_71 = new cjs.Shape();
	this.shape_71.graphics.f("#FFFFFF").s().p("AvdFZQiNiFgIixQgIixB/iRQB/iSCxgPQCxgPCXB5QCWB5AXCxQAJBHgOBJQgOBJgjBAQg7BshvBCQhuBBh7ABIgEAAQivAAiLiEgAJTG4QhzgWhehOQhfhNgrhtQg8iaA6imQA7ioCOhTQCOhSCvAgQCvAgBnCBQBnCAgGCxQgGCxhvB5QhPBXh0AmQhMAZhKAAQgpAAgpgHg");
	this.shape_71.setTransform(834.715,506.8537);

	this.shape_72 = new cjs.Shape();
	this.shape_72.graphics.f("#232323").s().p("Eg/yA41QjghggpjNQgdiUBRipQA6h3CGikIGkn1QD9kuCdjQQHCpTDEoLQBXjoAcg5QAthcA4hAIABgLQAJhhAkiuQBfnABLkpQBpmgBwktQCNl6C3klQDQlNETjtQErkCFWhwQBLgYCZgqQCHgoBUgtQAugYBWg6QBVg6AvgZQBxg8CagfQBogVC0gRQHpgsH9gHQDRgDCDAKQC6ANCVAoQEOBMD1C+QDgCuC1D8QCbDWCLEkQBgDKCEFSQBXDdAvCIQBFDGAqCmQBbFuAWG7QAPFRgYHkIgNDtQASA8APBJQBJFiAhGvQAaFCAIHWQAEDpgoCRQg2DJiRBSQhmA6iDgNQh0BTiFgEQhsgEhohAIgTgMQgpApg1AiQiGBXiXgEQggAAhWgLQhLgJgsACQg/ADhWAaQhhAigxAOQibAwjLAPQh6AJj1gBI7XgGQh2AAhAgFQhlgKhNgaQhbgghCg/QhHhEgUhVItUgZQg6gCgfAEQgxAFgiAUQgrAagiA/QgUAkgkBLQg9Buh0BAQh1BAh9gHQh/gIhrhNQhthNgwh0QhyAKhxgiQhwgihbhGQi6DXhzBkQi3Cfi5A5QhaAchaAAQh9AAh8g2gAFF9tQixAPh/CSQh+CRAICyQAICxCMCFQCMCFCygBQB7gBBuhBQBvhCA7hsQAjhAAOhJQAOhJgJhIQgXixiWh5QiHhsiaAAQgTAAgUACgAXQ9OQiOBTg7CoQg6CnA8CaQArBtBfBNQBeBOBzAWQBzAVB1gnQB0gmBPhXQBvh5AGiyQAGixhniAQhniBivggQgxgJguAAQh4AAhmA7g");
	this.shape_72.setTransform(730.6378,652.169);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_70},{t:this.shape_69}]},859).to({state:[]},11).to({state:[{t:this.shape_72},{t:this.shape_71}]},10).to({state:[]},9).wait(419));

	// Слой_83
	this.shape_73 = new cjs.Shape();
	this.shape_73.graphics.f("#FFFFFF").s().p("AjHB4Qg6gCglgUQgagPgSgYQgTgbAGgVIAFgNQACgFAAgKQgBgRACgIQADgTARgOQAQgNAVgEQAbgFA0AMQAqAIAXANQAjAUAGAgIAAAbIAAAcQgBAQgHAJIgIAKIgJAJIgMAQQgRASgoAAIgEgBgACkBdQgSAAgMgHQgKgGgKgQIgLgTQgIgUgCgQQgBgVALgOQAFgIANgMIARgYQANgTAXgNQAYgOAggDIAigBQAXAAALADQAXAFAPAUQAQATABAXQAAALgEAVIgHAYQgHASgSARQgLALgYARQgeAUgQADQgIACgMgBIgVAAIgXABIgIgBg");
	this.shape_73.setTransform(810.778,149.7026);

	this.shape_74 = new cjs.Shape();
	this.shape_74.graphics.f("#232323").s().p("AoICAIgSAAQgLAAgHgCQgQgFgYgYQgOgPgDgIQgDgHAAgWIAAgWQABgNADgJIAKgQQAOgUAKgFQAJgDAWAAQAfgBALABQAYABAOAOIAKAJIANALQANAJAEATQADAKAAAXQgBAfgNANIgRANQgRAMgFACQgIAEgNAAIgWAAgAG+A0QgVgNgMgbQgJgVACgdQAAgNAEgMQAFgMAOgTQAMgTALgGQAIgEAMgDQAbgEAbAHIAfALQAaAJAGAGQANAJAIAVQAIAVgBARQgBANgKAYIgKAUQgEAGgLAKQgPAMgQAFQgNADgUAAQgyAAgVgMg");
	this.shape_74.setTransform(810.9738,174.6656);

	this.shape_75 = new cjs.Shape();
	this.shape_75.graphics.f("#FFFFFF").s().p("AiVByQgRgCgKgGQgIgEgJgJIgQgRIgWgYQgNgOgEgNQgEgKgBgVQgBgfAIgTQAKgZAXgNQAOgHAQgDQAUgFASABQAPABAPAGQAbAMAWAdQAKAMADALQADAIABAXQAAAmgEATQgCALgEAIQgCAGgJAMQgLAPgJAGQgNAIgUAAQgLAAgPgDgABQBYQgbgLgIgYQgDgJAAgYQAAgbADgIIAIgVQAKgWAEgFQAIgLAVgOQAYgQARgGQAfgLApAJQASAEAJAHQAQANACAjQACA3gaAiQgKAOgbAWQgQANgJAEQgOAGgXAAQgfAAgUgHg");
	this.shape_75.setTransform(814.7764,157.5713);

	this.shape_76 = new cjs.Shape();
	this.shape_76.graphics.f("#FFFFFF").s().p("Ai8CGQgVgDgMgGQgKgGgLgLIgTgUQgTgTgIgKQgQgRgFgQQgEgNgCgZQgBgnAJgWQANgfAcgPQARgKATgDQAZgGAVABQATACATAHQAgAOAbAjQAMAQAEAMQADALABAcQAAAugEAYQgDANgEAJQgDAHgLAPQgOASgLAIQgPAKgYAAQgOAAgSgEgABoB9QghgNgKgeQgEgLAAgdQAAgiAEgJIAKgZQAMgcAEgGQAKgNAagRQAdgUAWgIQAlgNAyALQAWAFALAIQATAQADArQACBEgfAqQgMARghAbQgUAQgLAFQgRAHgcAAQgmAAgYgJg");
	this.shape_76.setTransform(830.0293,170.0237);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_73}]},840).to({state:[{t:this.shape_75},{t:this.shape_74}]},10).to({state:[]},9).to({state:[{t:this.shape_76}]},11).to({state:[]},10).wait(428));

	// Слой_82
	this.instance_10 = new lib.городскиежильцыперсонажи23();
	this.instance_10.setTransform(111,0,0.5391,0.5391);
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(840).to({_off:false},0).to({_off:true},19).wait(11).to({_off:false,scaleX:0.6757,scaleY:0.6757,x:-49,y:-25},0).to({_off:true},10).wait(428));

	// монолог
	this.shape_77 = new cjs.Shape();
	this.shape_77.graphics.f("#232323").s().p("AggBtQAAgHAGgIQAGgKAGABQAFAAAGADQAGAEgBADQAAAQgHAIQgJAGgGAAQgMAAAAgQgAgIAqQgIgBgDgCQgCgSALgyQAJgpAAgPQAAgXAHgJQAIgHAGgBQAEAAAFAEQAEAEAAAEQAAAEgTBTQgHAhgBATQAAAMgEAGIgKgCg");
	this.shape_77.setTransform(1022.275,221.3);

	this.shape_78 = new cjs.Shape();
	this.shape_78.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgbAXgpAXQgKAFAAAHQAAAOAJAJQAIAIAQAAQAkAAAmgoQAGgGADAAQAFAAAAAJQAAARgfAZQgfAYggAAQgbAAgPgQgAgOgxQgUAXgIAgQBHgqAAgaQAAgKgJAAQgPAAgTAXg");
	this.shape_78.setTransform(1007.6,225.125);

	this.shape_79 = new cjs.Shape();
	this.shape_79.graphics.f("#232323").s().p("AihAwQAAgZALhBQAEgbAAgLQAAgLAKAAQAUAAgBAbQABANgHAlQgHAqAAAJQAKgKAUgiQAegvANgNQAPgNAOAAQALAAAHAPQAGAPACA3QAAAOACAHQACAHABAAQAHAAAcg2QAOgdAOgPQANgPAQAAQAOAAAGAOQAHAPACAcQADAbAFAXQAGAYAOAHQAKAEAAAHQAAAFgIAHQgJAGgGAAQgOAAgLgRQgLgQgFg3IgEggQgDgJgEAAQgIAAgKANQgJAOgWApQgRAhgJALQgJAKgHAAQgHAAgGgGQgGgFgBgJQgCgIgCghQgDg1gGgIQgQAAg0BdQgSAfgDADQgCADgJACQgHACgFAAQgMAAAAgsg");
	this.shape_79.setTransform(981.35,225.025);

	this.shape_80 = new cjs.Shape();
	this.shape_80.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgaAXgrAXQgIAFgBAHQABAOAHAJQAJAIAQAAQAjAAAngoQAFgGADAAQAGAAAAAJQAAARgfAZQgeAYghAAQgbAAgPgQgAgOgxQgTAXgJAgQBHgqABgaQgBgKgIAAQgQAAgTAXg");
	this.shape_80.setTransform(953.45,225.125);

	this.shape_81 = new cjs.Shape();
	this.shape_81.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgbAXgqAXQgJAFAAAHQAAAOAIAJQAJAIAQAAQAkAAAmgoQAGgGACAAQAGAAAAAJQAAARgfAZQgeAYghAAQgbAAgPgQgAgOgxQgUAXgIAgQBHgqAAgaQAAgKgJAAQgPAAgTAXg");
	this.shape_81.setTransform(935.25,225.125);

	this.shape_82 = new cjs.Shape();
	this.shape_82.graphics.f("#232323").s().p("AiHBpQgFgEAAgEQACgHABgBQAPgTALgVQAKgUARgoQARgqAEgbQACgLAPABQAJgBACADQAEADADAHQADAIAAAHIAGAgIAFAgQADAPAGAXQAFAXADAAQADAAAEgKIAPghIAIgSIAUgnQAPgiAKgPQAIgPADgDQADgDAEAAQAGAAAIAEQAIADAAAEIACAkIADA1QABAZACASQABASAGALQAHARABAKQAAAIgHADQgHADgGAAQgMAAgGgTQgHgUgDhZQgBgbgCgGQgNAWgZA0IgMAXIgHAQQgSAqgOAAQgJgBgFgCQgFgDgFgLQgEgLgJgrQgKgvgDgLQgMAagJAXQgNAkgOAXQgMAWgGAFQgGAEgFAAQgFAAgEgEg");
	this.shape_82.setTransform(910.4,224.95);

	this.shape_83 = new cjs.Shape();
	this.shape_83.graphics.f("#232323").s().p("Ag5BVQgOgOAAgbQAAgsAjgxQAkgxAeAAQAOAAAJAOQAKAPAAARQAAAKgEAIQgEAGgFABQgKAAgEgVQgEgVgJAAQgSAAgYArQgYAoABAeQAAAdAgAAQAYgBAjgXQAMgJAFAAQAGAAAAAHQAAAOgfATQgeAUgdAAQgZAAgOgPg");
	this.shape_83.setTransform(886.4,225.2);

	this.shape_84 = new cjs.Shape();
	this.shape_84.graphics.f("#232323").s().p("AhVBiQgEgFAAgEQAAgGAEgXQAIgqAJhfQAAgJAHgHQAGgIAIAAQAEAAADAFQADAFAAAHQAAAGgCAIQgJAjgDAkQApgGAfgtQAPgVALgJQAMgJAMAAQAGAAAFAFQAFAFAAAGQAAAIgQAFQgIADgIAGQgHAGgVAXQgQASgMAHIgBABIACABQALAHAOATQAUAcAKAHQAKAHANAAIAGAAQAGAAAAAGQAAAGgHAHQgIAHgRAAQgNAAgMgLQgMgLgQgZQgIgPgIgIQgIgIgJAAIgNAEQgKADgCADQgBAEAAATIgBAgQAAAGgGAFQgGAFgHAAQgHAAgEgEg");
	this.shape_84.setTransform(854.475,225.075);

	this.shape_85 = new cjs.Shape();
	this.shape_85.graphics.f("#232323").s().p("AA0AMQgHgCgFAAIgMABQgGAAgOgBIgQgBIgZABIgXABQgJAAgFgBQgFgCAAgHQAAgBADgEQACgEANgCIATgCIANABIAMAAQAgAAAPgCIAPAAQADgBALAEQAKAEABADQACADAAADQAAAHgDACQgCADgIgBIgLgCg");
	this.shape_85.setTransform(834.7,224.2);

	this.shape_86 = new cjs.Shape();
	this.shape_86.graphics.f("#232323").s().p("AhhCXQgHgGAAgDQAAgKAFgQQAfh9AAhgIAAgOQgBgTAHgIQAHgJAJAAQAEAAAEAHQAEAGAAAMQAAARgEAXIgEAiQAZgsAcgZQAcgZAZAAQARAAAMANQAMANAAATQAAA4grAtQgrAtgnAAQgKAAgGgFQgGgGgHgNQgIAfgHA3IgFAhQgBAGgFAHQgFAHgFAAQgFAAgHgFgAgChLQgkAuAAAZQAAAFAHAGQAHAFALAAQAYAAAfgjQAggkAAgjQAAgMgFgHQgFgHgHAAQgZAAgiAtg");
	this.shape_86.setTransform(809.025,230.525);

	this.shape_87 = new cjs.Shape();
	this.shape_87.graphics.f("#232323").s().p("AhhCXQgHgGAAgDQAAgKAFgQQAfh9AAhgIAAgOQgBgTAHgIQAHgJAJAAQAEAAAEAHQAEAGAAAMQAAARgEAXIgEAiQAZgsAcgZQAcgZAZAAQARAAAMANQAMANAAATQAAA4grAtQgrAtgnAAQgKAAgGgFQgGgGgHgNQgIAfgHA3IgFAhQgBAGgFAHQgFAHgFAAQgFAAgHgFgAgChLQgkAuAAAZQAAAFAHAGQAHAFALAAQAYAAAfgjQAggkAAgjQAAgMgFgHQgFgHgHAAQgZAAgiAtg");
	this.shape_87.setTransform(786.425,230.525);

	this.shape_88 = new cjs.Shape();
	this.shape_88.graphics.f("#232323").s().p("AAsBPQgJgSAAgiQgYAggWARQgXAPgUAAQgNAAgJgLQgKgLAAgRQAAgtAogzQAog0AnAAQAOAAAHAQQADAGAEAAQAOAAAAAKQAAAGgCAJQgJAxAAAWQAAApAPAIQAIAEAAAGQAAAFgHAFQgHAGgIAAQgNAAgIgSgAgbgaQgdApAAAcQgBAUANAAQAUAAAfgmQAigkAAghQAAgYgQAAQgXAAgdAqg");
	this.shape_88.setTransform(765.6,225.25);

	this.shape_89 = new cjs.Shape();
	this.shape_89.graphics.f("#232323").s().p("AiNB8IABgbQAFgtADhMIAChOIAAgHQAAgfAUAAQAHAAAEAGQAEAGAAAFQAAAsgGAtIgCAhIABADIACAEQATgLApgnQAogoAPgLIAHgGQAUgUAJAAQAFAAAIAGQAHAFAAADIgBACQgSAWgmAfQgpAjggAeQAeAOAuAQIACABIANAGQAJACAGADQAXAKAVAHQAVAGAEAAIAEgCIAEgBQAHAAAGAHQAFAIAAAFQAAAIgFAFQgGAFgIAAQgMAAgigMQghgMgRgIIg6gXQgxgTgHAAQgNAAgGAGIABAJIgDAlIgDAgQAAAHgHAGQgIAFgIAAQgHAAAAgRg");
	this.shape_89.setTransform(740.475,221.025);

	this.shape_90 = new cjs.Shape();
	this.shape_90.graphics.f("#232323").s().p("AggBtQAAgHAGgIQAGgKAGABQAFAAAGADQAGAEgBADQAAAQgHAIQgJAGgGAAQgMAAAAgQgAgIAqQgIgBgDgCQgCgSALgyQAJgpAAgPQAAgXAHgJQAIgHAGgBQAEAAAFAEQAEAEAAAEQAAAEgTBTQgHAhgBATQAAAMgEAGIgKgCg");
	this.shape_90.setTransform(702.125,221.3);

	this.shape_91 = new cjs.Shape();
	this.shape_91.graphics.f("#232323").s().p("AhmBUQgKgPAAgcQAAgfAHgkQAIglAFgNIADgLQACgHAPgDQACgBADAAQAEAAADALQAAAIgEALQgLAgAAANQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAQAngmAiAAQATAAAOAPQAOARAAANQAAAmgoAkQgoAlgpAAQgSAAgKgPgAgfgZQgNAIgQAPIgKAIQgEACgGABQgDAUAAASQAAAaAUAAQAXABAcgcQAcgbAAgZQAAgLgGgHQgGgHgJAAQgNAAgNAGgAA9BBQAAgdANhHQAFgaAAgFQAAgLAEgHQAEgIAHAAQAJgBAFAFQAFAEAAAFQAAAFgCAKQgOAwgDASQgDAUAAAbQAAANAEAQIAAAFQAAADgFAFQgGAFgGAAQgRAAAAgfg");
	this.shape_91.setTransform(683.875,224.6);

	this.shape_92 = new cjs.Shape();
	this.shape_92.graphics.f("#232323").s().p("AgnCGQgKgEAAgDQAAgWAeAAIASAAQAIAAAPgGQAOgGAMgKQANgKAFgJQAGgLAAgIQAAgQgOgMQgNgMgXAAQgDAAgNAGQgMAFgDAAQgOAAgDgEQgDgDAAgIQAAgGAcgLQAbgLAXgXQAXgXAAgOQAAgJgKgHQgJgHgRAAQgVAAgbAGQgcAFgCAGQgDAFgMBPQgMBMAAAMIABAMIAAAMQAAAYgWAAQgHAAgEgJQgEgKAAgHIAGgaQAHggAGg0IAHg6QAAgIgCgDQgCgDgHAAIgFAAQgDAAgCgDQgDgDAAgGQAAgNAtgPQAtgPA9AAQAWAAASAPQASAQAAAQQAAALgQAVQgPAWgYAQQAAADANAGQAQAIAHAFQAHAGAFALQAEAKAAAQQAAANgSAXQgSAYgdAQQgeAPgeAAQgGAAgLgDg");
	this.shape_92.setTransform(657.725,221.7);

	this.shape_93 = new cjs.Shape();
	this.shape_93.graphics.f("#232323").s().p("AgnApIABgEQAggIAJgOQAIgPABgFQgBgSgFgHQgBgDAAgDQgBgDADgEQACgFADAAQADAAAIACQAHADACACQABACADALQAEALAAAHQgBADgGAOQgHAPgLAJQgKAIgJACIgIACQgNAGgJAAQgEAAgBgIg");
	this.shape_93.setTransform(624.05,233.775);

	this.shape_94 = new cjs.Shape();
	this.shape_94.graphics.f("#232323").s().p("AArB3QgHgSAAgjIAAgFIAAgGQgWAlgWAUQgXAUgTAAQgLAAgMgNQgMgNAAgcQAAgWALgsQAJgjAAgPQAFgKAKAAQAIAAAEAFQAEAFAAAGQAAAMgIAVQgQAqAAAfQAAAcANAAQARAAAZgcQAZgcASgyQAHgUAFgGQAEgGAIAAQAMAAAAAQIgEAMQgKAkAAAiQAAAoANAMQAHAGAAAEQAAAFgHADQgHAEgFAAQgMAAgIgRgAgFhGQgJgDgHgEQgIgEgGgGQgGgGgEgHIgDgFIgCgFIgBgFIAAgDIABgIIADgEQABgBAAAAQAAgBABAAQAAAAABAAQAAgBABAAIAEgBQAFAAAEACQADACABAEQAAAIADAHQACAHAFAFQAFAFAIADQAIADALAAIAGAAIAIgCIAHgCIAGgEQAEgCADgEIAFgIIAEgIIACgIQACgFADgCQADgCAEAAQAGAAADADQAEAEAAAIIgCAIQgCAFgDAGIgIAKQgFAGgFAEIgKAFIgMAEIgNADIgNABQgKAAgIgCg");
	this.shape_94.setTransform(606.975,221.275);

	this.shape_95 = new cjs.Shape();
	this.shape_95.graphics.f("#232323").s().p("AhVB7QgTgNAAgTQAAgTAOAAQAJAAAGANQAFAJANAHQAMAIAMAAQAfAAAYgSQAagRAJgbQAKgbAAgJQAAgHgSAAIgVABIgUABIgdACIgeACQgRAAAAgMQAAgIAGgDQAFgDAVgBIAcgCQATgCAQAAIAYgBQAMAAAEgFQAEgFAAgMQAAgJgEgRQgFgSgOgJQgOgKgWAAQgRAAgZANIgTAKQgGADgFAAQgEAAgFgDQgGgEAAgDQAAgIAPgKQAOgLAHgCIAMgEQAcgKAUAAQAYAAAVANQAUAMAKAbQAJAbAAALQAAArgMAqQgNArgmAbQgmAcguAAQgZAAgSgOg");
	this.shape_95.setTransform(583.625,221.375);

	this.shape_96 = new cjs.Shape();
	this.shape_96.graphics.f().s("#232323").ss(4,1,1).p("EAxKgCGQhdKIw+CdQw+CewwALQwyAMwGjfQwGjfDRpRQDSpRNbgeQNbgePQAAQPPgBTWAdQTWAdhdKJg");
	this.shape_96.setTransform(801.2394,226.1512);

	this.shape_97 = new cjs.Shape();
	this.shape_97.graphics.f("#FFFFFF").s().p("Egj3AJ1QwGjfDRpRQDSpRNbgeQNbgePQAAQPPgBTWAdQTWAdhdKJQhdKIw+CdQw+CewwALIhnABQv8AAvVjUg");
	this.shape_97.setTransform(801.2394,226.1512);

	this.shape_98 = new cjs.Shape();
	this.shape_98.graphics.f("#232323").s().p("AhFBUQgKgPAAgdQAAgeAHgkQAIglAFgNIADgLQACgGAPgEQACgBADAAQAEAAADALQAAAIgEALQgLAgAAANQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAQAngmAhAAQAUAAAOAPQAOAQAAANQAAAngoAlQgoAkgpAAQgSAAgKgPgAABgZQgMAHgQAQIgKAIQgEADgGABQgDASAAATQAAAaAUAAQAXABAbgcQAdgbAAgZQAAgLgGgHQgGgHgKAAQgNAAgNAGg");
	this.shape_98.setTransform(947.675,252.4);

	this.shape_99 = new cjs.Shape();
	this.shape_99.graphics.f("#232323").s().p("AihAwQAAgZALhBQAEgbAAgLQAAgLAKAAQATAAAAAbQAAANgGAlQgHAqAAAJQAKgKAUgiQAegvAOgNQANgNAPAAQALAAAHAPQAGAPACA3QAAAOACAHQABAHACAAQAHAAAbg2QAOgdAPgPQANgPARAAQANAAAGAOQAHAPACAcQADAbAGAXQAFAYAOAHQAKAEAAAHQAAAFgIAHQgIAGgHAAQgOAAgKgRQgMgQgFg3IgEggQgCgJgFAAQgIAAgJANQgKAOgWApQgRAhgJALQgJAKgHAAQgHAAgGgGQgGgFgCgJQgBgIgCghQgDg1gGgIQgQAAg1BdQgRAfgDADQgDADgIACQgHACgFAAQgMAAAAgsg");
	this.shape_99.setTransform(920.5,252.825);

	this.shape_100 = new cjs.Shape();
	this.shape_100.graphics.f("#232323").s().p("AAsBPQgJgSABgiQgYAggXARQgXAPgUAAQgNAAgKgLQgJgKAAgSQAAgtAogzQAog0AnAAQAOAAAHAQQADAGAEAAQAOAAAAAKQAAAGgCAJQgJAyAAAVQAAApAQAIQAHAEAAAGQAAAFgHAFQgHAGgIAAQgMAAgJgSgAgagaQgfApAAAcQAAAUAOAAQASAAAhgmQAhgkAAghQAAgYgQAAQgXAAgcAqg");
	this.shape_100.setTransform(891.2,253.05);

	this.shape_101 = new cjs.Shape();
	this.shape_101.graphics.f("#232323").s().p("AiGBlQgGgFAAgEQAAgLAUgUQAUgWAYgOQAdgTALgKQgFgGgOgJQgPgIgMgLIgEgDQgWgPgHgHQgIgIAAgIQAAgGAFgEQAEgFAEgBQADAAAGAEQAHACADADIAIAIQAsArAaAMQABAAAAAAQAAAAABgBQAAAAABgBQAAAAABgBQABgGAAgMQAAgNgCgOIgCgKQAAgIAHgGQAFgEAHAAQAJgBADAEQADADAAAIIgCA3IAAADIAAAEQAGAAAGgEQAHgGAMgNQA5g7AJAAQAFAAAEAFQAEAEAAAFQAAADgTAUQgTAVgUARIgZAXQAAABAVAQQAXARAJAIIADACQAaAQAGAHQAGAIAAAFQAAAFgEAFQgEAGgEAAQgQAAg3g0QgZgWgFgCIgDgBIgGAAQgFAAAAABQgCAngFAlQgDAHgJAAQgPAAAAgPQAAgHADgRIADgUIABgMIAAgKQgJABgbAUQgbATgTATIgIANQgJASgLABQgFAAgGgFg");
	this.shape_101.setTransform(865.875,252.85);

	this.shape_102 = new cjs.Shape();
	this.shape_102.graphics.f("#232323").s().p("AAtBLQgHgSAAgjIAAgFIAAgGQgWAlgWAUQgXAUgUAAQgLAAgLgNQgMgNAAgcQAAgWAKgrQAJgkAAgPQAGgJAKgBQAHABAEAFQAFAEAAAGQAAAMgJAWQgPAqgBAfQABAbANAAQAQAAAagbQAYgdATgyQAHgTAFgHQAEgFAIAAQAMAAgBAPIgDAMQgKAmAAAgQAAAoANAMQAHAGAAAEQAAAFgHADQgHAFgFAAQgMAAgIgSg");
	this.shape_102.setTransform(839.8,253.45);

	this.shape_103 = new cjs.Shape();
	this.shape_103.graphics.f("#232323").s().p("AhNCGQgLgVAAgZQAAgtAcgnQAbgnAfAAQADAAAGAFQAGAFACgBQgGgRgXgVQgWgTAAgOQAAgLAHgGQAIgHATgGQAXgGAZgJIAfgLQADgBADAAQAGAAAAAKQAAAGgOAJQgNAKgjAIQgWAGgFADQgEACAAADQAAAGANAMQAyAsAABBQAAAcgPAhQgPAhgZAPQgYAQgYAAQgWAAgLgVgAgkAUQgWAlAAAgQAAATAFAKQAFALAIAAQALAAATgNQARgOAMgaQALgbAAgXQAAgTgFgLQgGgMgEAAQgeAAgVAkg");
	this.shape_103.setTransform(821.975,246.925);

	this.shape_104 = new cjs.Shape();
	this.shape_104.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAdgrQAegrAoAAQAcAAARAVQARAVAAAdQAAAsgjAmQgjAmglAAQgYAAgPgSgAgfgiQgTAiAAAeQAAARAHALQAHALAMAAQAZAAAagcQAZgcAAghQAAgVgJgNQgLgNgQAAQgaAAgVAhg");
	this.shape_104.setTransform(801.4,253.275);

	this.shape_105 = new cjs.Shape();
	this.shape_105.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAegrQAdgrApAAQAbAAARAVQARAVAAAdQAAAsgjAmQgkAmglAAQgXAAgPgSgAgegiQgUAiAAAeQAAARAHALQAIALAMAAQAYAAAZgcQAagcAAghQAAgVgKgNQgKgNgQAAQgbAAgTAhg");
	this.shape_105.setTransform(767.6,253.275);

	this.shape_106 = new cjs.Shape();
	this.shape_106.graphics.f("#232323").s().p("AgzBWQgPgKgCgQIAAgEQgCgRAMgTQANgTAxgYQAfgQAAgNQAAgHgFgEQgGgEgEAAQgNAAgkASIgDACQgOAAAAgKQAAgQAcgLQAagLAVAAQANAAAOALQAOAKAAARQAAAOgJANQgJANglATQgcAQgLALQgKAKAAAOQAAAJAJADQAJAEAEAAQAfAAAagOQAIgEAFAAQAJAAAAAKQAAAPgZAKQgYAKgkAAQgSAAgPgKg");
	this.shape_106.setTransform(749.3862,253.075);

	this.shape_107 = new cjs.Shape();
	this.shape_107.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAegrQAdgrApAAQAbAAARAVQARAVAAAdQAAAsgjAmQgkAmglAAQgXAAgPgSgAgfgiQgTAiAAAeQAAARAHALQAIALAMAAQAYAAAZgcQAagcAAghQAAgVgKgNQgKgNgQAAQgbAAgUAhg");
	this.shape_107.setTransform(730.8,253.275);

	this.shape_108 = new cjs.Shape();
	this.shape_108.graphics.f("#232323").s().p("AhNCGQgLgVAAgZQAAgtAcgnQAbgnAfAAQADAAAGAFQAGAFACgBQgGgRgXgVQgWgTAAgOQAAgLAHgGQAIgHATgGQAXgGAZgJIAfgLQADgBADAAQAGAAAAAKQAAAGgOAJQgNAKgjAIQgWAGgFADQgEACAAADQAAAGANAMQAyAsAABBQAAAcgPAhQgPAhgZAPQgYAQgYAAQgWAAgLgVgAgkAUQgWAlAAAgQAAATAFAKQAFALAIAAQALAAATgNQARgOAMgaQALgbAAgXQAAgTgFgLQgGgMgEAAQgeAAgVAkg");
	this.shape_108.setTransform(713.525,246.925);

	this.shape_109 = new cjs.Shape();
	this.shape_109.graphics.f("#232323").s().p("AAsBPQgJgSAAgiQgXAggXARQgYAPgTAAQgNAAgJgLQgKgKAAgSQAAgtAogzQAog0AnAAQAOAAAHAQQACAGAFAAQAOAAAAAKIgCAPQgJAyAAAVQAAApAPAIQAIAEAAAGQAAAFgHAFQgIAGgGAAQgOAAgIgSgAgbgaQgeApABAcQgBAUANAAQAUAAAfgmQAigkAAghQAAgYgQAAQgWAAgeAqg");
	this.shape_109.setTransform(692.45,253.05);

	this.shape_110 = new cjs.Shape();
	this.shape_110.graphics.f("#232323").s().p("AhdBWQAAgMARgUQAQgTAagsQAaguAPgkQAEgGAGAAIAIACQAHACACADQACADAHAdQAUBoAYATIAGAHIABAEQAAAFgDAFQgDAEgEABQgDABgKAAQgEAAgNgRQgNgSgRhOQgFgVgDgHQgEAAgEAIQgjBGgSAZIgDAGQgWAmgKAAQgNAAAAgMg");
	this.shape_110.setTransform(671.55,253.075);

	this.shape_111 = new cjs.Shape();
	this.shape_111.graphics.f("#232323").s().p("Ag5BVQgOgPAAgaQAAgsAkgxQAjgxAdAAQAOAAALAOQAJAPAAARQAAAKgEAIQgEAGgFAAQgKABgEgVQgEgVgKAAQgRAAgXArQgYApAAAcQgBAeAiAAQAYgBAhgXQAMgJAGAAQAGAAAAAIQAAANgfATQgeATgcABQgaAAgOgPg");
	this.shape_111.setTransform(652.35,253);

	this.shape_112 = new cjs.Shape();
	this.shape_112.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAdgrQAegrApAAQAbAAARAVQARAVAAAdQAAAsgjAmQgkAmgkAAQgYAAgPgSgAgfgiQgTAiAAAeQAAARAHALQAIALALAAQAZAAAagcQAZgcAAghQAAgVgKgNQgJgNgRAAQgaAAgVAhg");
	this.shape_112.setTransform(985.25,190.275);

	this.shape_113 = new cjs.Shape();
	this.shape_113.graphics.f("#232323").s().p("AhFBUQgKgPAAgdQAAgeAHgkQAIglAFgNIADgLQACgGAPgEQACgBADAAQAEAAADALQAAAIgEALQgLAgAAANQAAABAAABQAAAAAAABQAAAAABABQAAAAABAAQAngmAhAAQAUAAAOAPQAOAQAAANQAAAngoAlQgoAkgpAAQgSAAgKgPgAABgZQgMAHgQAQIgKAIQgEADgGAAQgDATAAATQAAAaAUAAQAXABAbgcQAdgbAAgZQAAgLgGgHQgGgHgKAAQgNAAgNAGg");
	this.shape_113.setTransform(946.125,189.4);

	this.shape_114 = new cjs.Shape();
	this.shape_114.graphics.f("#232323").s().p("AhdBWQAAgMAQgUQARgTAagsQAaguAPgkQAEgGAGAAIAJACQAGACACADQACADAHAdQAUBoAYATIAGAHIABAEQAAAFgDAFQgEAEgDABQgDABgKAAQgEAAgNgRQgNgSgRhOQgFgVgDgHQgEAAgEAIQgjBGgRAZIgEAGQgVAmgLAAQgNAAAAgMg");
	this.shape_114.setTransform(925.25,190.075);

	this.shape_115 = new cjs.Shape();
	this.shape_115.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAegrQAdgrAoAAQAcAAARAVQARAVAAAdQAAAsgjAmQgkAmglAAQgXAAgPgSgAgegiQgUAiAAAeQAAARAHALQAHALANAAQAYAAAZgcQAagcAAghQAAgVgJgNQgLgNgQAAQgaAAgUAhg");
	this.shape_115.setTransform(905.2,190.275);

	this.shape_116 = new cjs.Shape();
	this.shape_116.graphics.f("#232323").s().p("AihAwQAAgZALhBQAFgbAAgLQAAgLAKAAQASAAABAbQgBANgGAlQgHAqgBAJQALgKAVgiQAdgvANgNQAOgNAPAAQALAAAHAPQAHAPAAA3QABAOACAHQABAHABAAQAJAAAbg2QANgdAOgPQAOgPAQAAQAOAAAHAOQAGAPADAcQACAbAGAXQAFAYAPAHQAJAEAAAHQAAAFgIAHQgJAGgGAAQgOAAgKgRQgLgQgGg3IgFggQgBgJgGAAQgHAAgJANQgLAOgVApQgSAhgIALQgJAKgHAAQgHAAgGgGQgGgFgBgJQgCgIgCghQgCg1gHgIQgQAAg1BdQgRAfgDADQgDADgHACQgIACgGAAQgLAAAAgsg");
	this.shape_116.setTransform(878.25,189.825);

	this.shape_117 = new cjs.Shape();
	this.shape_117.graphics.f("#232323").s().p("AAtBLQgIgSAAgjIAAgFIABgGQgWAlgWAUQgXAUgTAAQgLAAgNgNQgLgNAAgcQAAgWAKgrQAKgkgBgPQAFgJALgBQAIABAEAFQAEAEAAAGQAAAMgIAWQgRAqABAfQgBAbANAAQASAAAZgbQAYgdATgyQAHgTAEgHQAFgFAHAAQAMAAABAPIgEAMQgKAmAAAgQAAAoANAMQAHAGAAAEQAAAFgHADQgHAFgGAAQgMAAgHgSg");
	this.shape_117.setTransform(834.45,190.45);

	this.shape_118 = new cjs.Shape();
	this.shape_118.graphics.f("#232323").s().p("AhdBWQAAgMAQgUQAQgTAbgsQAaguAPgkQADgGAGAAIAJACQAHACACADQACADAGAdQAVBoAXATIAHAHIABAEQAAAFgDAFQgDAEgEABQgDABgKAAQgEAAgNgRQgNgSgShOQgEgVgDgHQgEAAgEAIQgjBGgRAZIgFAGQgVAmgJAAQgOAAAAgMg");
	this.shape_118.setTransform(813.25,190.075);

	this.shape_119 = new cjs.Shape();
	this.shape_119.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgaAYQgaAXgpAXQgKAFABAHQgBAOAJAJQAIAIAQAAQAkAAAmgoQAFgGAEAAQAFAAAAAJQAAARgeAZQgfAYggAAQgcAAgPgQgAgOgxQgUAXgIAgQBHgqAAgaQABgKgKAAQgPAAgTAXg");
	this.shape_119.setTransform(794.1,189.925);

	this.shape_120 = new cjs.Shape();
	this.shape_120.graphics.f("#232323").s().p("AiHBpQgEgEgBgEQABgHACgBQAPgTAKgVQAMgUAQgpQAQgpAGgaQACgLAOAAQAJAAADACQACADADAHQAEAIAAAHIAFAgIAGAgQADAPAGAXQAFAXADAAQACAAAFgKIAOghIAJgSIAUgoQAQghAIgPQAJgPADgDQADgDADAAQAHAAAIAEQAIADABAEIABAkIACA2QACAYACASQACASAEALQAIARAAAKQABAIgHADQgHADgGAAQgMAAgGgTQgHgUgDhZQgBgbgBgGQgOAWgaA0IgLAXIgIAQQgRAqgNAAQgKgBgFgCQgFgCgFgMQgEgLgIgrQgLgvgDgLQgMAagJAXQgOAkgMAXQgNAWgGAFQgFAEgFAAQgGAAgEgEg");
	this.shape_120.setTransform(769.25,189.75);

	this.shape_121 = new cjs.Shape();
	this.shape_121.graphics.f("#232323").s().p("Ag5BVQgOgPAAgaQAAgsAjgxQAkgxAdAAQAOAAAKAOQAKAPAAARQAAAKgEAIQgFAGgEAAQgKABgEgVQgFgVgIAAQgSAAgXArQgZApAAAcQAAAeAiAAQAYgBAhgXQAMgJAGAAQAGAAAAAIQAAANgeATQgfATgdABQgZAAgOgPg");
	this.shape_121.setTransform(745.25,190);

	this.shape_122 = new cjs.Shape();
	this.shape_122.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAegrQAdgrApAAQAbAAARAVQARAVAAAdQAAAsgjAmQgkAmglAAQgXAAgPgSgAgegiQgUAiAAAeQAAARAHALQAIALAMAAQAYAAAZgcQAagcAAghQAAgVgKgNQgKgNgQAAQgbAAgTAhg");
	this.shape_122.setTransform(726.65,190.275);

	this.shape_123 = new cjs.Shape();
	this.shape_123.graphics.f("#232323").s().p("AhpBDQAAgHADgPQAJgzAAg6QAAgGAGgHQAGgJAFAAQAIAAAEAGQAEAFAAARQAAARgKA1QgEASAAAEQAAABAAABQAAAAABAAQAAABAAAAQAAAAABAAQACAAAVgoQAWgpAQgRQAPgRATAAQAQAAAJAOQAKAOAEAlQAFApAEALQAEAKAIAAQAFAAAJgEIACAAQAHgBAAAJQAAAIgKAIQgKAIgOAAQgPAAgIgLQgIgLgEgzQgFgxgQAAQgJAAgJAMQgLAMgVAnQgcA2gJAHQgIAIgFAAQgVAAAAgUg");
	this.shape_123.setTransform(705.775,190.45);

	this.shape_124 = new cjs.Shape();
	this.shape_124.graphics.f("#232323").s().p("AhVBiQgEgFAAgEQAAgGAEgXQAIgqAJhfQAAgJAHgHQAGgIAIAAQAEAAADAFQADAFAAAHQAAAGgCAIQgJAjgDAkQApgGAfgtQAPgVALgJQAMgJAMAAQAGAAAFAFQAFAFAAAGQAAAIgQAFQgIADgIAGQgHAGgVAXQgQASgMAHIgBABIACABQALAHAOATQAUAcAKAHQAKAHANAAIAGAAQAGAAAAAGQAAAGgHAHQgIAHgRAAQgNAAgMgLQgMgLgQgZQgIgPgIgIQgIgIgJAAIgNAEQgKADgCADQgBAEAAATIgBAgQAAAGgGAFQgGAFgHAAQgHAAgEgEg");
	this.shape_124.setTransform(670.375,189.875);

	this.shape_125 = new cjs.Shape();
	this.shape_125.graphics.f("#232323").s().p("AAsBPQgJgSAAgiQgYAggWARQgXAPgUAAQgNAAgJgLQgKgKAAgSQAAgtAogzQAog0AnAAQAOAAAHAQQACAGAFAAQAOAAAAAKQAAAGgCAJQgJAyAAAVQAAApAPAIQAIAEAAAGQAAAFgHAFQgIAGgGAAQgOAAgIgSgAgbgaQgdApAAAcQgBAUANAAQAUAAAfgmQAigkAAghQAAgYgQAAQgXAAgdAqg");
	this.shape_125.setTransform(649.15,190.05);

	this.shape_126 = new cjs.Shape();
	this.shape_126.graphics.f("#232323").s().p("Ag1BBQgIgMAAgWQAAgXAGgcQAGgcADgKIADgIQABgGAMgCIAEgBQADAAADAJQAAAFgEAJQgIAZgBAKQAAAAABABQAAAAAAABQAAAAAAAAQABABAAAAQAegeAZAAQAQAAALANQALAMAAAKQAAAdgfAcQgfAcgfAAQgPAAgHgLgAAAgSQgJAFgMALIgHAGQgDADgFABQgDAOABAPQAAAUAPAAQARAAAWgVQAWgVgBgTQABgJgFgFQgEgGgIAAQgLAAgKAGg");
	this.shape_126.setTransform(931.2,246.325);

	this.shape_127 = new cjs.Shape();
	this.shape_127.graphics.f("#232323").s().p("Ah8AlQAAgUAIgxQAEgVAAgJQAAgIAIAAQAOAAAAAVQAAAKgFAcIgGAoQAJgIAPgaQAXglALgKQAKgJALAAQAJAAAFALQAFAMABAqQAAALACAFQABAFABAAQAGAAAVgpQALgWAKgMQALgMAMAAQALAAAFAMQAFAKACAWQACAVAEASQAEASALAGQAIADAAAFQAAAEgGAFQgHAFgFAAQgLAAgIgNQgIgNgEgqQgCgRgCgHQgCgHgDAAQgGAAgHAKQgIALgRAfQgNAZgHAJQgHAIgFAAQgGAAgEgFQgFgEgBgHQgBgGgBgZQgCgpgGgHQgMABgoBHIgQAbIgIAEIgKABQgJAAAAgig");
	this.shape_127.setTransform(910.225,246.675);

	this.shape_128 = new cjs.Shape();
	this.shape_128.graphics.f("#232323").s().p("AAiA9QgHgOAAgaQgSAZgRAMQgSAMgPAAQgLAAgHgIQgHgJAAgNQAAgjAfgnQAfgoAdAAQALAAAGANQABAEAEAAQALAAAAAIIgCALQgHAmAAAQQAAAgAMAGQAGAEAAAEQAAAEgGAEQgFAFgGAAQgKAAgGgOgAgUgUQgXAgAAAVQAAAPAKAAQAOAAAZgdQAZgcAAgZQAAgSgMAAQgRAAgWAgg");
	this.shape_128.setTransform(887.625,246.875);

	this.shape_129 = new cjs.Shape();
	this.shape_129.graphics.f("#232323").s().p("AhnBOQgFgDAAgEQAAgIAPgQQAPgQAUgMQAWgOAIgHQgEgGgKgGQgLgHgKgIIgEgCQgRgMgFgFQgFgGAAgHQAAgEACgEQAEgDADAAIAIACQAEACADACIAGAGQAiAiAUAJIADgDIABgOQAAgJgCgMIgBgIQAAgGAFgEQAEgDAFAAQAHAAACACQACADAAAGIgBAqIAAADIAAADQAFAAAEgEQAGgDAKgLQArgtAHAAQADAAAEADQADADAAAEQAAACgPAQQgOAQgPANQgUARAAABQAAABAQALIAZAUIACACQAUAMAFAGQAFAGAAAEQAAADgEAFQgDAEgDAAQgLAAgsgoQgTgSgDAAIgDgBIgFAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAABAAAAQgCAdgEAdQgCAFgHAAQgLAAAAgMIACgSIACgPIABgKQAAgFgBgCQgGAAgVAQQgVAPgOAPIgGAJQgHAOgIAAQgEAAgFgDg");
	this.shape_129.setTransform(868.05,246.675);

	this.shape_130 = new cjs.Shape();
	this.shape_130.graphics.f("#232323").s().p("AAjA6QgGgOAAgaIAAgFIAAgEQgRAcgQAPQgSAQgPAAQgJAAgJgKQgJgKAAgVQAAgSAJggQAHgdAAgKQADgIAJAAQAFAAADADQAEAEAAAEQAAAKgHARQgMAgAAAXQAAAWAKAAQANAAAUgWQASgVAOgmQAGgQADgFQAEgEAGAAQAJAAAAALIgDAKQgIAdAAAZQAAAfALAJQAFAEAAAEQAAADgFADQgGADgEABQgJAAgGgOg");
	this.shape_130.setTransform(847.925,247.15);

	this.shape_131 = new cjs.Shape();
	this.shape_131.graphics.f("#232323").s().p("AAfALQAAgBAAgBQgBAAAAgBQAAAAgBgBQAAAAgBAAIgeABQgSACgHACQgIACgCACQgCACgBAIQgBAIAAAJIAAARQAAANgNAAQgLAAAAgNQAAgKACgOQAFgaAEg/IABgLIAFgEQAEgDAFAAQAJAAAAAHIgDAUQgDATAAALQAAAGAFAAQAKAAAagDQAagDABgCQACgDADgeQACgZANAAQALAAAAALIgCAKQgKArAAAbQAAAfAKAJQAFAEAAAEQAAADgFADQgFADgFABQgUAAAAhAg");
	this.shape_131.setTransform(832.125,246.85);

	this.shape_132 = new cjs.Shape();
	this.shape_132.graphics.f("#232323").s().p("AgxBdQgUgNAAgJQAAgFACgEQACgEADAAQABAAAAAAQAAAAABAAQAAABABAAQAAABABAAQARAbAkAAQAWAAALgcQALgcADgrQgUASgUALQgTAKgLAAQgMAAgHgKQgHgLAAgOQAAgWAIgeQAJgfAEgEQAEgEAIAAQAEAAACAFQACAEAAAFQAAADgDAGQgRAeAAAgQAAAHADAGQADAEAFAAQAHAAALgDQAKgFANgKQANgKAFgGQAFgGACgIQABgIABgaQABgbAMAAQAHAAACAEQACAEAAAKIgCAjIgBALQgEBFgRAoQgRAoggAAQgaAAgUgOg");
	this.shape_132.setTransform(815.225,250.375);

	this.shape_133 = new cjs.Shape();
	this.shape_133.graphics.f("#232323").s().p("AhHBDQAAgUAtgpIAHgGQgbgmAAgVQAAgTAQAAQAEAAACAEQACAEACANQABAVARAYQAjggANgZIAHgKQACgCAEAAQAFAAAEAEQAEAEAAAFQAAANhAA7QAWAcAZAOIAGADIABAEQgBAGgEAEQgEAFgGAAQgSAAglgzQgeAagKAaQgDAIgEAFQgQgBAAgOg");
	this.shape_133.setTransform(789.8,247.175);

	this.shape_134 = new cjs.Shape();
	this.shape_134.graphics.f("#232323").s().p("AhOBBQgIgMAAgWQAAgXAGgcQAGgcADgKIADgIQABgGAMgCIAEgBQADAAACAJQAAAFgDAJQgJAZAAAKQAAAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAegeAaAAQAPAAALANQALAMAAAKQAAAdggAcQgeAcgfAAQgPAAgHgLgAgYgSQgKAFgMALIgIAGQgDADgEABQgDAOAAAPQAAAUAQAAQARAAAWgVQAVgVAAgTQAAgJgEgFQgFgGgGAAQgLAAgKAGgAAvAzQAAgYALg2IADgYQAAgIADgGQADgGAGAAQAHAAADADQAEAEAAAEIgCALQgKAlgCAOQgDAPAAAVQAAAKADAMIABAEQAAADgFAEQgEADgFAAQgNAAAAgXg");
	this.shape_134.setTransform(772.975,246.325);

	this.shape_135 = new cjs.Shape();
	this.shape_135.graphics.f("#232323").s().p("Ag7BoQgJgRAAgTQABgjAVgeQAVgeAYAAQACAAAFAEQAEAEACgBQgFgNgRgQQgRgPAAgKQAAgJAFgFQAGgFAPgFIAlgLIAYgJIAEgBQAFAAAAAIQAAAEgLAIQgLAHgaAHQgRAEgEACQgCACAAACQAAAFAJAJQAmAiAAAyQAAAWgLAZQgMAZgTANQgSAMgTAAQgRAAgIgQgAgbAQQgRAcgBAYQAAAPAEAIQAFAJAGAAQAIAAAOgLQAOgKAJgVQAIgUABgSQAAgPgFgIQgEgJgEAAQgWAAgQAcg");
	this.shape_135.setTransform(756.95,242.125);

	this.shape_136 = new cjs.Shape();
	this.shape_136.graphics.f("#232323").s().p("AAiA9QgHgOAAgaQgSAZgRAMQgSAMgPAAQgLAAgHgIQgHgJAAgNQAAgjAfgnQAfgoAdAAQALAAAGANQABAEAEAAQALAAAAAIIgCALQgHAmAAAQQAAAgAMAGQAGAEAAAEQAAAEgGAEQgFAFgGAAQgKAAgGgOgAgUgUQgXAgAAAVQAAAPAKAAQAOAAAZgdQAZgcAAgZQAAgSgMAAQgRAAgWAgg");
	this.shape_136.setTransform(740.725,246.875);

	this.shape_137 = new cjs.Shape();
	this.shape_137.graphics.f("#232323").s().p("AhHBCQAAgJAMgPQANgPAUgiQAUgjALgcQADgFAFAAIAHACQAFACACACQABACAFAWQAQBQASAPIAFAFIABAEQAAAEgDADQgDADgCABQgDABgHAAQgDAAgKgNQgLgOgNg8IgGgWQgCAAgEAGQgaA2gOATIgDAFQgQAegIAAQgLAAABgKg");
	this.shape_137.setTransform(724.6,246.875);

	this.shape_138 = new cjs.Shape();
	this.shape_138.graphics.f("#232323").s().p("AgsBCQgKgLAAgVQAAgiAbgmQAbgmAXAAQAKAAAIAMQAIALAAANQgBAIgDAGQgDAFgEAAQgHAAgEgPQgDgRgHAAQgOAAgRAgQgSAggBAWQAAAXAZAAQATAAAagSQAKgGAEgBQAFAAgBAGQAAAKgXAPQgYAPgVAAQgUAAgLgLg");
	this.shape_138.setTransform(709.8,246.8);

	this.shape_139 = new cjs.Shape();
	this.shape_139.graphics.f("#232323").s().p("AAiA9QgHgOAAgaQgSAZgRAMQgSAMgPAAQgLAAgHgIQgHgJAAgNQAAgjAfgnQAfgoAdAAQALAAAGANQABAEAEAAQALAAAAAIIgCALQgHAmAAAQQAAAgAMAGQAGAEAAAEQAAAEgGAEQgFAFgGAAQgKAAgGgOgAgUgUQgXAgAAAVQAAAPAKAAQAOAAAZgdQAZgcAAgZQAAgSgMAAQgRAAgWAgg");
	this.shape_139.setTransform(684.275,246.875);

	this.shape_140 = new cjs.Shape();
	this.shape_140.graphics.f("#232323").s().p("Ag3BnQgJgLAAgQQAAgfANgWQANgXARgNQAQgOAcgKIANgEQADgCAAgDQgFgVgHgIQgHgIgMgFQgKgFgJABQgEAAgHACQgHADgDADQgGACgEAAQgFAAAAgFQAAgGAJgJQAIgKAWAAIAGAAQAUAAARALQAQALAHAVQAHAVAAAjQAAAXgPAiQgPAjgYARQgWASgbAAQgJgBgIgKgAgDAAQglAhAAArQAAAGACAFQACAEACAAQAKABAIgEQAIgDALgLQALgLAKgQQAJgQAFgPQAEgPAAgHIAAgNQgeAFgPAOg");
	this.shape_140.setTransform(670.025,243.15);

	this.shape_141 = new cjs.Shape();
	this.shape_141.graphics.f("#232323").s().p("AgeAgIABgEQAZgFAGgMQAHgLAAgDQAAgOgEgGQgCgCAAgCIACgGQACgEACAAQADAAAGACQAFACABACQACABADAJQABAIAAAGIgEANQgFAMgJAGQgJAHgGABIgFACQgLAEgGAAQgFAAAAgGg");
	this.shape_141.setTransform(1037.45,204.35);

	this.shape_142 = new cjs.Shape();
	this.shape_142.graphics.f("#232323").s().p("Ag1BBQgIgMAAgWQAAgXAGgcQAGgcADgKIADgIQABgGAMgCIAEgBQADAAACAJQAAAFgCAJQgKAZABAKQAAAAAAABQAAAAAAABQAAAAAAAAQABABAAAAQAfgeAYAAQAQAAALANQALAMAAAKQAAAdgfAcQgfAcgfAAQgOAAgIgLgAABgSQgKAFgMALIgIAGQgDADgEABQgCAOgBAPQAAAUAQAAQASAAAUgVQAXgVAAgTQAAgJgFgFQgFgGgHAAQgLAAgJAGg");
	this.shape_142.setTransform(1025.55,197.275);

	this.shape_143 = new cjs.Shape();
	this.shape_143.graphics.f("#232323").s().p("Ah8AlQAAgUAIgxQAEgVAAgJQAAgIAIAAQAOAAAAAVQAAAKgFAcIgGAoQAJgIAPgaQAXglALgKQAKgJALAAQAJAAAFALQAFAMABAqQAAALACAFQABAFABAAQAGAAAVgpQALgWAKgMQALgMAMAAQALAAAFAMQAFAKACAWQACAVAEASQAEASALAGQAIADAAAFQAAAEgGAFQgHAFgFAAQgLAAgIgNQgIgNgEgqQgCgRgCgHQgCgHgDAAQgGAAgHAKQgIALgRAfQgNAZgHAJQgHAIgFAAQgGAAgEgFQgFgEgBgHQgBgGgBgZQgCgpgGgHQgMABgoBHIgQAbIgIAEIgKABQgJAAAAgig");
	this.shape_143.setTransform(1004.575,197.625);

	this.shape_144 = new cjs.Shape();
	this.shape_144.graphics.f("#232323").s().p("AAiA9QgHgOAAgaQgSAZgRAMQgSAMgPAAQgLAAgHgIQgHgJAAgNQAAgjAfgnQAfgoAdAAQALAAAGANQABAEAEAAQALAAAAAIIgCALQgHAmAAAQQAAAgAMAGQAGAEAAAEQAAAEgGAEQgFAFgGAAQgKAAgGgOgAgUgUQgXAgAAAVQAAAPAKAAQAOAAAZgdQAZgcAAgZQAAgSgMAAQgRAAgWAgg");
	this.shape_144.setTransform(981.975,197.825);

	this.shape_145 = new cjs.Shape();
	this.shape_145.graphics.f("#232323").s().p("AgwBlQgNgSAAgiQAAgpAPgpQAOgqAWgVQAUgWAWABQAOAAAIAIQAIAJAAAQQAAAMgLARQgLARgRAPQAeANAAAsQAAAhgWAaQgVAZgYAAQgWAAgMgRgAgXAOIgNAKQgCALAAAOQAAAXAHANQAHAMANAAQAQAAAMgSQAMgTAAgXQAAgTgIgMQgHgMgJAAQgCABgaATgAgGhHQgRAagKAtQAxgmAMgRQAMgRAAgJQAAgQgMAAQgRAAgRAag");
	this.shape_145.setTransform(967.875,193.65);

	this.shape_146 = new cjs.Shape();
	this.shape_146.graphics.f("#232323").s().p("AhOBBQgIgMAAgWQAAgXAGgcQAGgcADgKIADgIQABgGAMgCIAEgBQADAAACAJQAAAFgDAJQgJAZAAAKQAAAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAegeAaAAQAPAAALANQALAMAAAKQAAAdggAcQgeAcgfAAQgPAAgHgLgAgYgSQgKAFgMALIgIAGQgDADgEABQgDAOAAAPQAAAUAQAAQARAAAWgVQAVgVAAgTQAAgJgEgFQgFgGgGAAQgLAAgKAGgAAvAzQAAgYALg2IADgYQAAgIADgGQADgGAGAAQAHAAADADQAEAEAAAEIgCALQgKAlgCAOQgDAPAAAVQAAAKADAMIABAEQAAADgFAEQgEADgFAAQgNAAAAgXg");
	this.shape_146.setTransform(950.625,197.275);

	this.shape_147 = new cjs.Shape();
	this.shape_147.graphics.f("#232323").s().p("AgqBFQgOgIAAgKQAAgHAKAAIAEACQAOAMAUAAQARAAAMgJQANgKAAgOQAAgKgHgGQgHgHgKAAQgHAAgRAGIgIABQgIAAAAgJQAAgFAEgBQAEgDAMgDQAlgJAAgVQAAgHgFgEQgFgEgHgBQgNABgPAMQgKAHgEAAQgIAAAAgHQAAgKASgLQATgKAQAAQARAAAKAJQAKAJAAAKQAAAYgdANQARADAJAJQAKAKAAAOQAAAWgTAPQgTAPgeAAQgSAAgNgIg");
	this.shape_147.setTransform(933.325,197.75);

	this.shape_148 = new cjs.Shape();
	this.shape_148.graphics.f("#232323").s().p("AAiA9QgHgOAAgaQgSAZgRAMQgSAMgPAAQgLAAgHgIQgHgJAAgNQAAgjAfgnQAfgoAdAAQALAAAGANQABAEAEAAQALAAAAAIIgCALQgHAmAAAQQAAAgAMAGQAGAEAAAEQAAAEgGAEQgFAFgGAAQgKAAgGgOgAgUgUQgXAgAAAVQAAAPAKAAQAOAAAZgdQAZgcAAgZQAAgSgMAAQgRAAgWAgg");
	this.shape_148.setTransform(919.275,197.825);

	this.shape_149 = new cjs.Shape();
	this.shape_149.graphics.f("#232323").s().p("AhCBLQgCgDgBgDQABgFADgRQAGghAHhJQAAgHAFgFQAFgHAGABQAEAAACADQACAEAAAGIgCALQgHAbgCAbQAggFAYgiQALgQAJgHQAIgHALAAQADAAAFADQADAEAAAFQAAAGgMAEQgHACgFAFQgGAEgQATQgMAOgJAEIgBABIABABQAJAGALAOQAPAVAIAGQAIAGAKAAIAEAAQAFAAgBADQABAGgGAFQgFAFgNAAQgKAAgKgIQgKgJgMgTQgFgLgGgHQgHgFgHgBIgKADQgIADgBACQgBACgBAQIAAAYQAAAFgFAEQgEAEgGgBQgFAAgEgDg");
	this.shape_149.setTransform(904.25,197.65);

	this.shape_150 = new cjs.Shape();
	this.shape_150.graphics.f("#232323").s().p("AgyA8QgMgOABgUQgBghAXghQAXghAfAAQAVAAAOAQQAMARAAAWQAAAhgbAeQgbAdgcAAQgSAAgMgOgAgXgaQgQAaAAAXQAAANAHAJQAFAIAJAAQATAAAUgVQATgWAAgZQAAgRgHgKQgIgKgMAAQgVAAgPAag");
	this.shape_150.setTransform(888.3,197.975);

	this.shape_151 = new cjs.Shape();
	this.shape_151.graphics.f("#232323").s().p("AhRA0QAAgGADgMQAHgnAAgsQAAgFAEgGQAEgGAEAAQAHAAADAEQADAEAAANQAAANgIApIgDARQAAABAAAAQAAABABAAQAAAAAAAAQAAAAAAAAQACAAARgeQAQggANgNQALgNAPAAQAMAAAHALQAIAKADAdQAEAgADAIQADAIAGAAQAEAAAGgDIACgBQAGAAAAAHQAAAGgIAGQgIAHgLAAQgLAAgGgJQgGgJgEgnQgEgmgLAAQgHAAgHAJQgJAJgQAfQgWApgGAGQgHAGgEAAQgQAAAAgPg");
	this.shape_151.setTransform(872.175,198.125);

	this.shape_152 = new cjs.Shape();
	this.shape_152.graphics.f("#232323").s().p("AgxBdQgUgNAAgJQAAgFACgEQACgEADAAQABAAAAAAQAAAAABAAQAAABABAAQAAABABAAQARAbAkAAQAWAAALgcQALgcADgrQgUASgUALQgTAKgLAAQgMAAgHgKQgHgLAAgOQAAgWAIgeQAJgfAEgEQAEgEAIAAQAEAAACAFQACAEAAAFQAAADgDAGQgRAeAAAgQAAAHADAGQADAEAFAAQAHAAALgDQAKgFANgKQANgKAFgGQAFgGACgIQABgIABgaQABgbAMAAQAHAAACAEQACAEAAAKIgCAjIgBALQgEBFgRAoQgRAoggAAQgaAAgUgOg");
	this.shape_152.setTransform(843.225,201.325);

	this.shape_153 = new cjs.Shape();
	this.shape_153.graphics.f("#232323").s().p("AhHBCQAAgJAMgPQANgPAUgiQAUgjALgcQADgFAFAAIAHACQAFACACACQABACAFAWQAQBQASAPIAFAFIABAEQgBAEgCADQgCADgDABQgDABgHAAQgDAAgKgNQgLgOgNg8IgGgWQgCAAgEAGQgaA2gOATIgDAFQgQAegIAAQgKAAAAgKg");
	this.shape_153.setTransform(827.75,197.825);

	this.shape_154 = new cjs.Shape();
	this.shape_154.graphics.f("#232323").s().p("AAjA6QgGgOAAgaIAAgFIAAgEQgRAcgQAPQgSAQgPAAQgJAAgJgKQgJgKAAgVQAAgSAJggQAHgdAAgKQADgIAJAAQAFAAADADQAEAEAAAEQAAAKgHARQgMAgAAAXQAAAWAKAAQANAAAUgWQASgVAOgmQAGgQADgFQAEgEAGAAQAJAAAAAMIgDAJQgIAdAAAZQAAAfALAJQAFAEAAAEQAAADgFADQgGADgEABQgJAAgGgOg");
	this.shape_154.setTransform(811.525,198.1);

	this.shape_155 = new cjs.Shape();
	this.shape_155.graphics.f("#232323").s().p("AgsBCQgLgLAAgVQAAgiAcgmQAbgmAXAAQAKAAAIAMQAHALABANQAAAIgDAGQgEAFgDAAQgIAAgDgPQgEgRgHAAQgNAAgSAgQgSAgAAAWQAAAXAZAAQASAAAbgSQAIgGAFgBQAFAAAAAGQgBAKgXAPQgYAPgVAAQgUAAgLgLg");
	this.shape_155.setTransform(796.5,197.75);

	this.shape_156 = new cjs.Shape();
	this.shape_156.graphics.f("#232323").s().p("AgyA8QgMgOAAgUQAAghAYghQAWghAfAAQAVAAAOAQQANARgBAWQABAhgcAeQgbAdgcAAQgSAAgMgOgAgXgaQgPAaAAAXQAAANAFAJQAGAIAJAAQATAAATgVQAVgWAAgZQAAgRgIgKQgIgKgNAAQgUAAgPAag");
	this.shape_156.setTransform(771.35,197.975);

	this.shape_157 = new cjs.Shape();
	this.shape_157.graphics.f("#232323").s().p("AhCBLQgCgDAAgDQAAgFADgRQAGghAHhJQAAgHAFgFQAFgHAGABQADAAADADQACAEAAAGIgCALQgHAbgCAbQAggFAXgiQAMgQAJgHQAJgHAKAAQADAAAFADQADAEAAAFQAAAGgMAEQgHACgFAFQgGAEgPATQgNAOgJAEIgBABIABABQAJAGALAOQAPAVAIAGQAHAGALAAIAEAAQAFAAgBADQABAGgGAFQgFAFgNAAQgKAAgKgIQgKgJgMgTQgFgLgGgHQgHgFgHgBIgKADQgIADgBACQgBACAAAQIgBAYQAAAFgFAEQgEAEgGgBQgFAAgEgDg");
	this.shape_157.setTransform(756.55,197.65);

	this.shape_158 = new cjs.Shape();
	this.shape_158.graphics.f("#232323").s().p("Ag1BBQgIgMAAgWQAAgXAGgcQAGgcAEgKIACgIQABgGAMgCIAEgBQADAAADAJQAAAFgEAJQgIAZgBAKQAAAAABABQAAAAAAABQAAAAAAAAQABABAAAAQAegeAZAAQAQAAALANQALAMAAAKQAAAdggAcQgeAcgfAAQgPAAgHgLgAAAgSQgJAFgMALIgHAGQgDADgFABQgCAOAAAPQAAAUAPAAQARAAAWgVQAVgVAAgTQABgJgFgFQgFgGgHAAQgKAAgLAGg");
	this.shape_158.setTransform(741.2,197.275);

	this.shape_159 = new cjs.Shape();
	this.shape_159.graphics.f("#232323").s().p("AhIBCQABgJANgPQAMgPAUgiQAUgjAMgcQACgFAFAAIAHACQAFACABACQACACAFAWQAQBQASAPIAFAFIAAAEQABAEgDADQgDADgCABQgCABgJAAQgCAAgKgNQgKgOgOg8IgFgWQgEAAgCAGQgbA2gOATIgDAFQgRAegHAAQgLAAAAgKg");
	this.shape_159.setTransform(725.1,197.825);

	this.shape_160 = new cjs.Shape();
	this.shape_160.graphics.f("#232323").s().p("AgyA8QgMgOABgUQgBghAXghQAXghAfAAQAVAAANAQQANARAAAWQAAAhgbAeQgbAdgcAAQgSAAgMgOgAgXgaQgQAaAAAXQAAANAHAJQAFAIAJAAQATAAAUgVQATgWABgZQgBgRgHgKQgIgKgMAAQgVAAgPAag");
	this.shape_160.setTransform(709.65,197.975);

	this.shape_161 = new cjs.Shape();
	this.shape_161.graphics.f("#232323").s().p("Ah8AlQAAgUAIgxQAEgVAAgJQAAgIAIAAQAOAAAAAVQAAAKgFAcIgGAoQAJgIAPgaQAXglALgKQAKgJALAAQAJAAAFALQAFAMABAqQAAALACAFQABAFABAAQAGAAAVgpQALgWAKgMQALgMAMAAQALAAAFAMQAFAKACAWQACAVAEASQAEASALAGQAIADAAAFQAAAEgGAFQgHAFgFAAQgLAAgIgNQgIgNgEgqQgCgRgCgHQgCgHgDAAQgGAAgHAKQgIALgRAfQgNAZgHAJQgHAIgFAAQgGAAgEgFQgFgEgBgHQgBgGgBgZQgCgpgGgHQgMABgoBHIgQAbIgIAEIgKABQgJAAAAgig");
	this.shape_161.setTransform(688.875,197.625);

	this.shape_162 = new cjs.Shape();
	this.shape_162.graphics.f("#232323").s().p("AhOBBQgIgMAAgWQAAgXAGgcQAGgcADgKIADgIQABgGAMgCIAEgBQADAAACAJQAAAFgDAJQgJAZAAAKQAAAAAAABQAAAAABABQAAAAAAAAQAAABABAAQAegeAaAAQAPAAALANQALAMAAAKQAAAdggAcQgeAcgfAAQgPAAgHgLgAgYgSQgKAFgMALIgIAGQgDADgEABQgDAOAAAPQAAAUAQAAQARAAAWgVQAVgVAAgTQAAgJgEgFQgFgGgGAAQgLAAgKAGgAAvAzQAAgYALg2IADgYQAAgIADgGQADgGAGAAQAHAAADADQAEAEAAAEIgCALQgKAlgCAOQgDAPAAAVQAAAKADAMIABAEQAAADgFAEQgEADgFAAQgNAAAAgXg");
	this.shape_162.setTransform(653.775,197.275);

	this.shape_163 = new cjs.Shape();
	this.shape_163.graphics.f("#232323").s().p("Ag7BoQgIgRgBgTQAAgjAWgeQAVgeAYAAQACAAAEAEQAFAEACgBQgFgNgRgQQgRgPgBgKQAAgJAGgFQAGgFAPgFIAlgLIAXgJIAGgBQADAAAAAIQAAAEgKAIQgLAHgaAHQgRAEgDACQgEACAAACQAAAFAKAJQAnAiAAAyQAAAWgMAZQgLAZgUANQgTAMgRAAQgRAAgJgQgAgcAQQgQAcAAAYQAAAPADAIQAFAJAFAAQAJAAAPgLQANgKAIgVQAKgUgBgSQAAgPgDgIQgFgJgDAAQgXAAgRAcg");
	this.shape_163.setTransform(637.75,193.075);

	this.shape_164 = new cjs.Shape();
	this.shape_164.graphics.f("#232323").s().p("AhoBRQgDgDAAgDIABgHQAMgOAIgQQAIgQANgfQANggAEgUQABgJAMAAQAGAAACACQADACACAGIADALIAEAZIAFAZQABALAFASQAEASACAAQACAAAEgIIALgaIAGgOIAPgeIATglIAJgOQADgCADAAQAFAAAGADQAGACAAAEIABAbIACApQABATACAOQABAOAEAIQAGANAAAIQAAAGgFADQgFACgFAAQgJAAgFgPQgFgPgChFQgBgUgBgFQgLARgUAoIgIASIgGAMQgOAggKAAQgHAAgEgCQgEgCgDgJQgEgJgGggIgLgtIgQAmQgKAcgKARQgKARgEAEQgFADgEAAQgEAAgDgDg");
	this.shape_164.setTransform(606.675,197.575);

	this.shape_165 = new cjs.Shape();
	this.shape_165.graphics.f("#232323").s().p("AAiA9QgHgOAAgaQgSAZgRAMQgSAMgPAAQgLAAgHgIQgHgJAAgNQAAgjAfgnQAfgoAdAAQALAAAGANQABAEAEAAQALAAAAAIIgCALQgHAmAAAQQAAAgAMAGQAGAEAAAEQAAAEgGAEQgFAFgGAAQgKAAgGgOgAgUgUQgXAgAAAVQAAAPAKAAQAOAAAZgdQAZgcAAgZQAAgSgMAAQgRAAgWAgg");
	this.shape_165.setTransform(587.125,197.825);

	this.shape_166 = new cjs.Shape();
	this.shape_166.graphics.f("#232323").s().p("AgeBnQgIgDAAgDQAAgQAYAAIAOAAQAGgBALgEQALgEAJgIQAKgIAEgHQAEgIAAgHQAAgMgKgJQgKgJgSAAQgCAAgKAEQgJAEgDAAQgKAAgDgCQgCgDAAgHQAAgDAWgJQAUgJASgRQARgSAAgLQAAgHgHgFQgHgGgNAAQgQAAgVAFQgVAEgCAEQgDAFgJA8QgJA6AAAKIABAJIAAAJQAAASgRAAQgFAAgDgHQgEgHAAgFIAFgVQAFgYAFgoIAGgtQAAgFgCgDQgBgDgGAAIgEABQgCAAgCgDQgCgDAAgDQAAgLAigLQAjgMAvAAQARAAAOAMQAOALAAANQAAAJgMAQQgMARgTANQAAACALAEQALAGAGAEQAGAFADAIQAEAIAAAMQAAAKgOATQgOASgXAMQgWAMgYAAQgEAAgJgDg");
	this.shape_166.setTransform(569.475,195.075);

	this.shape_167 = new cjs.Shape();
	this.shape_167.graphics.f("#232323").s().p("AgMAOQgCgCAAgMQAAgJABgCQABgCAEgBQAFgBAHgBIACAAQADABADACQADACAAAEQABAHgDAEQgDADgGAFQgGAEgCABQgFgBgDgCg");
	this.shape_167.setTransform(478.6,118.75);

	this.shape_168 = new cjs.Shape();
	this.shape_168.graphics.f("#232323").s().p("AgMAOQgCgCgBgMQAAgJABgCQABgCAGgBQAEgBAGgBIADAAQADABADACQADACAAAEQAAAHgDAEQgCADgGAFQgGAEgCABQgGgBgCgCg");
	this.shape_168.setTransform(471.8,118.75);

	this.shape_169 = new cjs.Shape();
	this.shape_169.graphics.f("#232323").s().p("AgMAOQgDgCAAgMQAAgJACgCQABgCAEgBQAEgBAIgBIADAAQACABADACQADACABAEQAAAHgDAEQgDADgGAFQgFAEgDABQgFgBgDgCg");
	this.shape_169.setTransform(465,118.75);

	this.shape_170 = new cjs.Shape();
	this.shape_170.graphics.f("#232323").s().p("AAhBcQgFgOAAgbIAAgEIAAgFQgRAdgRAPQgRAQgQAAQgIAAgJgKQgJgLAAgVQAAgRAIghQAHgcAAgLQAEgIAIAAQAGAAADAEQADAEAAAEQAAAJgGAQQgNAiAAAXQAAAVAKAAQANAAAUgVQATgWAOgmQAFgPAEgFQADgFAGAAQAJAAAAAMIgCAKQgIAbAAAbQAAAfAKAIQAFAFAAADQAAAEgFADQgFADgFAAQgJAAgGgNgAgDg2IgNgFQgGgEgFgEQgFgFgDgFIgCgDIgBgFIgBgEIAAgCIABgGIACgEIADgCIADAAQAEAAADABQADACAAADQAAAGACAGQACAFAEADQAEAEAGADQAFACAJAAIAFAAIAGgBIAGgCIAEgDIAGgEIAEgHIACgGIACgGQACgEACgCIAFgBQAFAAADACQACADAAAGIgBAHIgEAIIgGAIQgEAFgEADIgIADIgJAEIgKACIgKABQgHAAgGgCg");
	this.shape_170.setTransform(453.525,110.8);

	this.shape_171 = new cjs.Shape();
	this.shape_171.graphics.f("#232323").s().p("AguBAQgMgNAAgVQAAgmAaghQAZgjAeABQAJAAAHAGQAGAHAAAIQAAAVgUATQgUARggASQgHADAAAGQAAALAGAHQAHAGAMAAQAbABAeggQAEgFACAAQAFABAAAGQAAAOgYATQgYASgYABQgVAAgMgNgAgLgmQgPASgGAZQA3ghAAgTQAAgJgHAAQgMAAgPASg");
	this.shape_171.setTransform(438.375,113.75);

	this.shape_172 = new cjs.Shape();
	this.shape_172.graphics.f("#232323").s().p("Ag7BoQgIgRAAgTQgBgjAWgeQAVgeAYAAQACAAAEAEQAFAEACgBQgFgNgRgQQgSgPAAgKQABgJAFgFQAGgFAPgFIAlgLIAXgJIAGgBQADAAAAAIQAAAEgKAIQgKAHgbAHQgRAEgEACQgCACgBACQAAAFAKAJQAnAigBAyQABAWgMAZQgLAZgUANQgSAMgSAAQgSAAgIgQgAgcAQQgRAcAAAYQAAAPAFAIQADAJAHAAQAIAAAOgLQAOgKAIgVQAKgUgBgSQAAgPgDgIQgFgJgDAAQgXAAgRAcg");
	this.shape_172.setTransform(425.6,109.125);

	this.shape_173 = new cjs.Shape();
	this.shape_173.graphics.f("#232323").s().p("AhHBCQgBgJANgPQANgPAUgiQAUgjALgcQADgFAFAAIAHACQAFACACACQABACAFAWQAQBQASAPIAFAFIABAEQgBAEgCADQgCADgDABQgDABgHAAQgDAAgKgNQgLgOgNg8IgGgWQgCAAgDAGQgbA2gOATIgDAFQgQAegIAAQgKAAAAgKg");
	this.shape_173.setTransform(393.15,113.875);

	this.shape_174 = new cjs.Shape();
	this.shape_174.graphics.f("#232323").s().p("AgyA8QgMgOAAgUQAAghAYghQAWghAfAAQAVAAAOAQQANARgBAWQAAAhgbAeQgaAdgdAAQgSAAgMgOgAgXgaQgPAaAAAXQAAANAFAJQAGAIAJAAQATAAATgVQAVgWAAgZQAAgRgIgKQgIgKgMAAQgVAAgPAag");
	this.shape_174.setTransform(377.7,114.025);

	this.shape_175 = new cjs.Shape();
	this.shape_175.graphics.f("#232323").s().p("AgnBCQgMgIgBgMIgBgDQgBgNAKgPQAJgOAmgTQAYgMAAgKQAAgGgEgDQgFgDgDAAQgKAAgbAOIgDACQgKAAAAgIQAAgMAVgJQAUgIAQAAQAKAAALAIQALAIAAANQAAALgHAKQgHAKgcAOQgWANgIAIQgIAIAAALQAAAHAHACQAHADADAAQAYAAATgKQAHgEADAAQAHAAAAAIQAAALgSAIQgTAIgcAAQgOAAgLgIg");
	this.shape_175.setTransform(363.6702,113.875);

	this.shape_176 = new cjs.Shape();
	this.shape_176.graphics.f("#232323").s().p("AhHBDQAAgUAtgpIAGgGQgagmAAgVQAAgTAQAAQAEAAADAEQACAEABANQACAVAPAYQAkggANgZIAGgKQADgCAEAAQAFAAAEAEQAEAEAAAFQAAANhAA7QAWAcAZAOIAGADIAAAEQABAGgFAEQgEAFgGAAQgRAAgmgzQgeAagKAaQgEAIgEAFQgPgBAAgOg");
	this.shape_176.setTransform(338.75,114.175);

	this.shape_177 = new cjs.Shape();
	this.shape_177.graphics.f("#232323").s().p("AhRA0QAAgGADgMQAHgnAAgsQAAgFAEgGQAEgGAEAAQAHAAADAEQADAEAAANQAAANgIApIgDARQAAABAAAAQAAABAAAAQABAAAAAAQAAAAAAAAQACAAARgeQAQggANgNQALgNAPAAQAMAAAHALQAIAKADAdQAEAgADAIQADAIAGAAQAEAAAGgDIACgBQAGAAAAAHQAAAGgIAGQgIAHgLAAQgLAAgGgJQgGgJgEgnQgEgmgLAAQgHAAgHAJQgJAJgQAfQgWApgGAGQgHAGgEAAQgQAAAAgPg");
	this.shape_177.setTransform(303.075,114.175);

	this.shape_178 = new cjs.Shape();
	this.shape_178.graphics.f("#232323").s().p("AhIBCQAAgJAOgPQAMgPAUgiQAUgjAMgcQACgFAFAAIAHACQAFACABACQACACAFAWQAQBQASAPIAFAFIAAAEQAAAEgCADQgDADgCABQgCABgJAAQgCAAgKgNQgKgOgOg8IgFgWQgDAAgEAGQgaA2gOATIgDAFQgRAegHAAQgLAAAAgKg");
	this.shape_178.setTransform(269.45,113.875);

	this.shape_179 = new cjs.Shape();
	this.shape_179.graphics.f("#232323").s().p("AgnBCQgMgIgBgMIgBgDQgBgNAKgPQAJgOAmgTQAYgMAAgKQAAgGgEgDQgFgDgDAAQgKAAgbAOIgDACQgKAAAAgIQAAgMAVgJQAUgIAQAAQAKAAALAIQALAIAAANQAAALgHAKQgHAKgcAOQgWANgIAIQgIAIAAALQAAAHAHACQAHADADAAQAYAAATgKQAHgEADAAQAHAAAAAIQAAALgSAIQgTAIgcAAQgOAAgLgIg");
	this.shape_179.setTransform(255.2202,113.875);

	this.shape_180 = new cjs.Shape();
	this.shape_180.graphics.f("#232323").s().p("AAjA6QgGgOAAgaIAAgFIAAgEQgRAcgQAQQgSAPgPAAQgJAAgJgKQgJgKAAgVQAAgRAJghQAHgcAAgLQADgJAJABQAFAAADADQAEAFAAADQAAAKgHAQQgMAhAAAXQAAAWAKAAQANAAAUgWQASgVAOgmQAGgQADgFQAEgEAGAAQAJAAAAALIgDAKQgIAdAAAZQAAAfALAJQAFAFAAADQAAADgFADQgGAEgEAAQgJAAgGgOg");
	this.shape_180.setTransform(229.325,114.15);

	this.shape_181 = new cjs.Shape();
	this.shape_181.graphics.f("#232323").s().p("AhHBDQAAgUAtgpIAGgGQgagmAAgVQAAgTAQAAQAFAAACAEQABAEABANQACAVAQAYQAkggANgZIAGgKQADgCAEAAQAFAAAEAEQAEAEAAAFQAAANhAA7QAWAcAZAOIAGADIAAAEQABAGgFAEQgEAFgGAAQgRAAgmgzQgeAagKAaQgEAIgEAFQgPgBAAgOg");
	this.shape_181.setTransform(203.05,114.175);

	this.shape_182 = new cjs.Shape();
	this.shape_182.graphics.f("#232323").s().p("AAjA6QgGgOAAgaIAAgFIAAgEQgRAcgQAQQgSAPgPAAQgJAAgJgKQgJgKAAgVQAAgRAJghQAHgcAAgLQADgJAJABQAFAAADADQAEAFAAADQAAAKgHAQQgMAhAAAXQAAAWAKAAQANAAAUgWQASgVAOgmQAGgQADgFQAEgEAGAAQAJAAAAALIgDAKQgIAdAAAZQAAAfALAJQAFAFAAADQAAADgFADQgGAEgEAAQgJAAgGgOg");
	this.shape_182.setTransform(187.525,114.15);

	this.shape_183 = new cjs.Shape();
	this.shape_183.graphics.f("#232323").s().p("AhBBLQgEgDAAgDQABgFADgSQAHggAFhJQABgHAFgFQAFgHAGAAQAEAAACAFQACADAAAGIgBALQgIAagBAcQAegEAZgjQALgQAJgHQAIgHAKAAQAEAAAEAEQAEADAAAFQAAAGgMAEQgGACgGAFQgGAFgQASQgMANgJAFIgBABIABABQAJAFAKAPQAQAWAIAGQAHAFALAAIAEgBQAFAAAAAFQAAAFgGAFQgGAGgNgBQgKABgJgJQgJgJgNgTQgGgLgGgHQgGgFgHAAIgKACQgIADgBADQgBACgBAPIAAAYQAAAFgEAEQgFAEgFAAQgGgBgDgDg");
	this.shape_183.setTransform(172.3,113.7);

	this.shape_184 = new cjs.Shape();
	this.shape_184.graphics.f("#232323").s().p("AgyA8QgLgOAAgUQAAghAWghQAXghAfAAQAVAAANAQQAOARAAAWQAAAhgbAeQgbAdgdAAQgSAAgMgOgAgXgaQgQAaAAAXQABANAGAJQAFAIAJAAQATAAATgVQAUgWAAgZQAAgRgHgKQgIgKgNAAQgUAAgPAag");
	this.shape_184.setTransform(156.35,114.025);

	this.shape_185 = new cjs.Shape();
	this.shape_185.graphics.f("#232323").s().p("AgsBBQgKgKgBgVQABgiAbglQAbgnAXAAQAKAAAIAMQAIALAAANQgBAIgDAGQgDAFgEAAQgHAAgEgPQgDgRgHAAQgOAAgRAhQgSAfgBAXQAAAWAZAAQATAAAagSQAKgHAEAAQAFABgBAEQAAALgXAPQgYAPgVAAQgUAAgLgMg");
	this.shape_185.setTransform(114,113.8);

	this.shape_186 = new cjs.Shape();
	this.shape_186.graphics.f("#232323").s().p("AguBAQgMgNAAgVQAAgmAaghQAZgjAeABQAJAAAHAGQAGAHAAAIQAAAVgUATQgUARggASQgHADAAAGQAAALAGAHQAHAGAMAAQAbABAeggQAEgFACAAQAFABAAAGQAAAOgYATQgYASgYABQgVAAgMgNgAgLgmQgPASgGAZQA3ghAAgTQAAgJgHAAQgMAAgPASg");
	this.shape_186.setTransform(100.325,113.75);

	this.shape_187 = new cjs.Shape();
	this.shape_187.graphics.f("#232323").s().p("AhnBOQgFgDAAgEQAAgIAQgQQAPgQASgMQAXgOAJgHQgEgGgMgGQgLgHgJgIIgDgCQgSgMgFgFQgGgGAAgHQABgEADgEQADgDADAAIAHACQAGACABACIAHAGQAjAiATAJIADgDIABgOQAAgJgCgMIgBgIQAAgGAFgEQAEgDAGAAQAGAAACACQACADABAGIgCAqIAAADIAAADQAFAAAFgEQAFgDAJgLQAsgtAHAAQAEAAADADQADADAAAEQAAACgOAQQgPAQgPANQgUARAAABQAAABARALIAYAUIADACQATAMAFAGQAFAGAAAEQAAADgDAFQgEAEgDAAQgMAAgrgoQgSgSgFAAIgCgBIgFAAQgBAAAAAAQgBAAAAAAQgBAAAAAAQAAABgBAAQgBAdgEAdQgCAFgHAAQgMAAAAgMIADgSIACgPIABgKQAAgFAAgCQgHAAgVAQQgUAPgPAPIgGAJQgHAOgJAAQgEAAgEgDg");
	this.shape_187.setTransform(81.5,113.675);

	this.shape_188 = new cjs.Shape();
	this.shape_188.graphics.f("#232323").s().p("AhHBCQAAgJAMgPQANgPAUgiQAUgjALgcQADgFAFAAIAHACQAFACACACQABACAFAWQAQBQASAPIAFAFIABAEQAAAEgDADQgDADgCABQgDABgHAAQgDAAgKgNQgLgOgNg8IgFgWQgDAAgEAGQgaA2gOATIgDAFQgQAegIAAQgLAAABgKg");
	this.shape_188.setTransform(437.5,64.825);

	this.shape_189 = new cjs.Shape();
	this.shape_189.graphics.f("#232323").s().p("AAZBEIABgHQACgFAIg9QgUARgTALQgVAKgKAAQgNAAgHgKQgHgMAAgNQAAgTAHgZQAHgYARAAQADAAADAFQACAFAAAFQAAAHgHAMQgJAQAAALQAAAHACAFQACAGAGAAQAOAAAVgNQAWgPAFgKQAFgMAAgFIgBgGIAAgEQAAgGADgGQADgGAGAAQAHAAACACQADADAAANIgDAgIAAAMQgBAPgFAgQgFAggDAEQgCAEgFABQgNgBAAgHg");
	this.shape_189.setTransform(406.625,64.5);

	this.shape_190 = new cjs.Shape();
	this.shape_190.graphics.f("#232323").s().p("AgxBdQgUgNAAgJQAAgFACgEQACgEADAAQABAAAAAAQAAAAABAAQAAABABAAQAAABABAAQARAbAkAAQAWAAALgcQALgcADgrQgUASgUALQgTAKgLAAQgMAAgHgKQgHgLAAgOQAAgWAIgeQAJgfAEgEQAEgEAIAAQAEAAACAFQACAEAAAFQAAADgDAGQgRAeAAAgQAAAHADAGQADAEAFAAQAHAAALgDQAKgFANgKQANgKAFgGQAFgGACgIQABgIABgaQABgbAMAAQAHAAACAEQACAEAAAKIgCAjIgBALQgEBFgRAoQgRAoggAAQgaAAgUgOg");
	this.shape_190.setTransform(390.475,68.325);

	this.shape_191 = new cjs.Shape();
	this.shape_191.graphics.f("#232323").s().p("AgyA8QgMgOAAgUQAAghAXghQAXghAfAAQAVAAAOAQQAMARAAAWQAAAhgbAeQgbAdgcAAQgSAAgMgOgAgXgaQgQAaAAAXQAAANAHAJQAFAIAJAAQATAAAUgVQATgWABgZQgBgRgHgKQgIgKgMAAQgVAAgPAag");
	this.shape_191.setTransform(375.65,64.975);

	this.shape_192 = new cjs.Shape();
	this.shape_192.graphics.f("#232323").s().p("AgyA8QgMgOAAgUQAAghAYghQAWghAfAAQAVAAAOAQQANARgBAWQAAAhgaAeQgcAdgcAAQgSAAgMgOgAgXgaQgPAaAAAXQAAANAFAJQAGAIAJAAQATAAATgVQAVgWAAgZQAAgRgIgKQgIgKgNAAQgUAAgPAag");
	this.shape_192.setTransform(331.7,64.975);

	this.shape_193 = new cjs.Shape();
	this.shape_193.graphics.f("#232323").s().p("AgnBCQgMgIgBgMIgBgDQgBgNAKgPQAJgOAmgTQAYgMAAgKQAAgGgEgDQgFgDgDAAQgKAAgbAOIgDACQgKAAAAgIQAAgMAVgJQAUgIAQAAQAKAAALAIQALAIAAANQAAALgHAKQgHAKgcAOQgWANgIAIQgIAIAAALQAAAHAHACQAHADADAAQAYAAATgKQAHgEADAAQAHAAAAAIQAAALgSAIQgTAIgcAAQgOAAgLgIg");
	this.shape_193.setTransform(317.6702,64.825);

	this.shape_194 = new cjs.Shape();
	this.shape_194.graphics.f("#232323").s().p("AhHBCQgBgJANgPQANgPAUgiQAUgjALgcQADgFAFAAIAHACQAFACACACQABACAFAWQAQBQASAPIAFAFIABAEQgBAEgCADQgCADgDABQgDABgHAAQgDAAgKgNQgLgOgNg8IgGgWQgCAAgDAGQgbA2gOATIgDAFQgQAegIAAQgKAAAAgKg");
	this.shape_194.setTransform(302.7,64.825);

	this.shape_195 = new cjs.Shape();
	this.shape_195.graphics.f("#232323").s().p("AgyA8QgMgOAAgUQAAghAYghQAWghAfAAQAVAAAOAQQANARgBAWQAAAhgbAeQgaAdgdAAQgSAAgMgOgAgXgaQgPAaAAAXQAAANAFAJQAGAIAJAAQATAAATgVQAVgWAAgZQAAgRgIgKQgIgKgMAAQgVAAgPAag");
	this.shape_195.setTransform(287.25,64.975);

	this.shape_196 = new cjs.Shape();
	this.shape_196.graphics.f("#232323").s().p("Ag3BnQgJgMAAgPQAAgeANgXQANgXARgNQAQgOAcgKIANgEQADgCAAgEQgFgUgHgIQgHgJgMgEQgKgEgJgBQgEAAgHADQgHADgDADQgGACgEAAQgFABAAgGQAAgFAJgKQAIgLAWABIAGAAQAUgBARALQAQAMAHAVQAHAVAAAjQAAAXgPAiQgPAigYASQgWARgbAAQgJABgIgLgAgDAAQglAhAAArQAAAGACAEQACAFACABQAKAAAIgEQAIgEALgKQALgLAKgQQAJgQAFgPQAEgPAAgHIAAgOQgeAHgPANg");
	this.shape_196.setTransform(273.225,61.1);

	this.shape_197 = new cjs.Shape();
	this.shape_197.graphics.f("#232323").s().p("AguBVQgMgMAAgWQAAgmAaghQAZgiAeAAQAJAAAHAGQAGAHAAAJQAAAUgUASQgUASggASQgHAEAAAFQAAALAGAHQAHAHAMAAQAbAAAeggQAEgEACAAQAFAAAAAHQAAANgYATQgYATgYAAQgVAAgMgNgAgLgRQgPARgGAaQA3ggAAgUQAAgIgHAAQgMAAgPARgAgXhGQgGgCAAgDQAAgRAJAAQAIAAAGAFQAFAEAAAJQAAAGgOAAIgIgCgAAZhLQgDgEAAgFQAAgFACgCQADgDAKgCIACgBQAEgBADADQACADAAAFQAAAPgOAAQgFAAgEgDg");
	this.shape_197.setTransform(247.625,62.5625);

	this.shape_198 = new cjs.Shape();
	this.shape_198.graphics.f("#232323").s().p("ABRBeQAAgDAHgTQAFgQAAgHQAAgFgBAAIgGACIgIADQgGAAgDgEQgDgFAAgMQAAgNAHggIABgEQgSAdgUASQgTASgPAAQgHAAgJgKQgJgKAAgWQAAgJACgQQgQAcgTARQgTARgPAAQgHAAgJgJQgJgIAAgPQAAgQACgJIACgQIACgMQAFgdgBgIQACgJAKAAQAEAAAEADQAEADAAAIQAAAMgGASQgHAYAAATQAAAKACAFQABAGAGAAQAOAAAWgbQAWgbAPgoQAGgPAJAAQAFAAAEAEQADADAAAFQAAAJgGARQgMAgAAAXQAAAVAJAAQAEAAAHgDQAGgCAJgJQAIgIAJgMIAMgTQAEgHAKgfQAFgQAEgFQADgFAGAAIADAAQAFAAADACQADACAAAKQAAAFgGATQgKAjgCAuQAAABAAABQAAAAABABQAAAAABABQAAAAABAAIABgBQAGgEAGAAQAJAAABAKIABAJQAAAKgEAJIgFAOIgCAEQgIARgJACIgDAAQgBAAgBAAQAAAAgBgBQAAAAgBgBQAAAAAAgBg");
	this.shape_198.setTransform(228.725,67.525);

	this.shape_199 = new cjs.Shape();
	this.shape_199.graphics.f("#232323").s().p("AguBAQgMgNAAgVQAAgmAaghQAZgjAeABQAJAAAHAGQAGAHAAAIQAAAVgUATQgUARggASQgHADAAAGQAAALAGAHQAHAGAMAAQAbABAeggQAEgFACAAQAFABAAAGQAAAOgYATQgYASgYABQgVAAgMgNgAgLgmQgPASgGAZQA3ghAAgUQAAgIgHAAQgMAAgPASg");
	this.shape_199.setTransform(208.575,64.7);

	this.shape_200 = new cjs.Shape();
	this.shape_200.graphics.f("#232323").s().p("AAfALQAAgEgDAAIgeABQgSABgHADQgIACgCACQgCACgBAIQgBAJAAAIIAAAQQAAAPgNAAQgLAAAAgPQAAgJACgOQAFgaAEg/IABgLIAFgEQAEgDAFAAQAJAAAAAHIgDAVQgDASAAALQAAAGAFABQAKgBAagDQAagDABgCQACgDADgeQACgYANgBQALAAAAALIgCALQgKAqAAAbQAAAfAKAJQAFAFAAADQAAADgFADQgFAEgFAAQgUAAAAhAg");
	this.shape_200.setTransform(182.925,64.8);

	this.shape_201 = new cjs.Shape();
	this.shape_201.graphics.f("#232323").s().p("AgyA8QgLgOAAgUQAAghAWghQAXghAfAAQAVAAANAQQAOARAAAWQAAAhgbAeQgbAdgdAAQgSAAgMgOgAgXgaQgQAaAAAXQABANAGAJQAFAIAJAAQATAAATgVQAUgWAAgZQAAgRgHgKQgIgKgNAAQgUAAgPAag");
	this.shape_201.setTransform(167.15,64.975);

	this.shape_202 = new cjs.Shape();
	this.shape_202.graphics.f("#232323").s().p("AhKB0QgGgEAAgDQAAgHAEgNQAYhgAAhKIAAgLQgBgOAGgHQAFgGAHAAQADAAADAFQADAFAAAJQAAANgDASIgEAaQAUgiAVgTQAWgUATAAQANAAAKALQAJAJAAAPQAAArghAjQghAigfAAQgHAAgFgEQgEgEgFgKQgHAYgFArIgEAYQgBAGgEAFQgEAFgDAAQgEAAgFgEgAgBg5QgcAiAAAUQAAAEAGAEQAFAFAIAAQASAAAZgbQAYgcAAgbQAAgKgEgFQgEgFgFAAQgTAAgaAjg");
	this.shape_202.setTransform(150.125,68.875);

	this.shape_203 = new cjs.Shape();
	this.shape_203.graphics.f("#232323").s().p("AgyA8QgMgOAAgUQAAghAYghQAWghAfAAQAVAAAOAQQAMARAAAWQAAAhgbAeQgbAdgcAAQgSAAgMgOgAgXgaQgPAaAAAXQgBANAHAJQAFAIAJAAQATAAAUgVQATgWABgZQgBgRgHgKQgIgKgMAAQgVAAgPAag");
	this.shape_203.setTransform(134.45,64.975);

	this.shape_204 = new cjs.Shape();
	this.shape_204.graphics.f("#FFFFFF").s().p("EgpfANCQynknDysSQDzsUPhgnQPhgnRqAAQRngBWYAmQWYAnhsNbQhrNbzoDRQzoDRzZAPIh0AAQydAAxwkYg");
	this.shape_204.setTransform(300.4534,95.4328);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_95},{t:this.shape_94},{t:this.shape_93},{t:this.shape_92},{t:this.shape_91},{t:this.shape_90},{t:this.shape_89,p:{x:740.475,y:221.025}},{t:this.shape_88},{t:this.shape_87},{t:this.shape_86},{t:this.shape_85},{t:this.shape_84,p:{x:854.475,y:225.075}},{t:this.shape_83},{t:this.shape_82},{t:this.shape_81},{t:this.shape_80},{t:this.shape_79},{t:this.shape_78},{t:this.shape_77}]},1055).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_89,p:{x:624.025,y:185.825}},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_84,p:{x:966.125,y:189.875}},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98}]},36).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_89,p:{x:624.025,y:185.825}},{t:this.shape_125},{t:this.shape_124},{t:this.shape_123},{t:this.shape_122},{t:this.shape_121},{t:this.shape_120},{t:this.shape_119},{t:this.shape_118},{t:this.shape_117},{t:this.shape_116},{t:this.shape_115},{t:this.shape_114},{t:this.shape_113},{t:this.shape_84,p:{x:966.125,y:189.875}},{t:this.shape_112},{t:this.shape_111},{t:this.shape_110},{t:this.shape_109},{t:this.shape_108},{t:this.shape_107},{t:this.shape_106},{t:this.shape_105},{t:this.shape_104},{t:this.shape_103},{t:this.shape_102},{t:this.shape_101},{t:this.shape_100},{t:this.shape_99},{t:this.shape_98}]},19).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_166,p:{x:569.475,y:195.075}},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152,p:{x:843.225,y:201.325}},{t:this.shape_151,p:{x:872.175,y:198.125}},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134,p:{x:772.975,y:246.325}},{t:this.shape_133},{t:this.shape_132,p:{x:815.225,y:250.375}},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128,p:{x:887.625,y:246.875}},{t:this.shape_127,p:{x:910.225,y:246.675}},{t:this.shape_126}]},1).to({state:[{t:this.shape_97},{t:this.shape_96},{t:this.shape_166,p:{x:569.475,y:195.075}},{t:this.shape_165},{t:this.shape_164},{t:this.shape_163},{t:this.shape_162},{t:this.shape_161},{t:this.shape_160},{t:this.shape_159},{t:this.shape_158},{t:this.shape_157},{t:this.shape_156},{t:this.shape_155},{t:this.shape_154},{t:this.shape_153},{t:this.shape_152,p:{x:843.225,y:201.325}},{t:this.shape_151,p:{x:872.175,y:198.125}},{t:this.shape_150},{t:this.shape_149},{t:this.shape_148},{t:this.shape_147},{t:this.shape_146},{t:this.shape_145},{t:this.shape_144},{t:this.shape_143},{t:this.shape_142},{t:this.shape_141},{t:this.shape_140},{t:this.shape_139},{t:this.shape_138},{t:this.shape_137},{t:this.shape_136},{t:this.shape_135},{t:this.shape_134,p:{x:772.975,y:246.325}},{t:this.shape_133},{t:this.shape_132,p:{x:815.225,y:250.375}},{t:this.shape_131},{t:this.shape_130},{t:this.shape_129},{t:this.shape_128,p:{x:887.625,y:246.875}},{t:this.shape_127,p:{x:910.225,y:246.675}},{t:this.shape_126}]},8).to({state:[{t:this.shape_204},{t:this.shape_166,p:{x:117.025,y:62.075}},{t:this.shape_203},{t:this.shape_202},{t:this.shape_201},{t:this.shape_200},{t:this.shape_199},{t:this.shape_198},{t:this.shape_197},{t:this.shape_196},{t:this.shape_195},{t:this.shape_194},{t:this.shape_193},{t:this.shape_192},{t:this.shape_151,p:{x:359.525,y:65.125}},{t:this.shape_191},{t:this.shape_190},{t:this.shape_189},{t:this.shape_128,p:{x:421.675,y:64.825}},{t:this.shape_188},{t:this.shape_187},{t:this.shape_186},{t:this.shape_185},{t:this.shape_127,p:{x:135.575,y:113.675}},{t:this.shape_184},{t:this.shape_183},{t:this.shape_182},{t:this.shape_181},{t:this.shape_180},{t:this.shape_179},{t:this.shape_178},{t:this.shape_152,p:{x:284.925,y:117.375}},{t:this.shape_177},{t:this.shape_134,p:{x:321.925,y:113.325}},{t:this.shape_176},{t:this.shape_175},{t:this.shape_174},{t:this.shape_173},{t:this.shape_132,p:{x:408.625,y:117.375}},{t:this.shape_172},{t:this.shape_171},{t:this.shape_170},{t:this.shape_169},{t:this.shape_168},{t:this.shape_167}]},1).to({state:[]},31).to({state:[]},121).wait(36));

	// Слой_121
	this.shape_205 = new cjs.Shape();
	this.shape_205.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAdgrQAegrAoAAQAcAAARAVQARAVAAAdQAAAsgjAmQgjAmgmAAQgXAAgPgSgAgegiQgUAiAAAeQAAARAHALQAHALAMAAQAZAAAagcQAZgcAAghQAAgVgJgNQgKgNgRAAQgbAAgTAhg");
	this.shape_205.setTransform(740.3,338.675);

	this.shape_206 = new cjs.Shape();
	this.shape_206.graphics.f("#232323").s().p("AhpBEQAAgIADgQQAJgyAAg6QAAgGAGgHQAGgJAFAAQAIAAAEAFQAEAGAAARQAAARgKA1QgEASAAAEQAAABAAABQAAAAABAAQAAABAAAAQAAAAABAAQACAAAVgoQAWgpAQgRQAPgRATAAQAQAAAJAOQAKAOAEAlQAFApAEALQAEAKAIAAQAFAAAJgEIACgBQAHAAAAAJQAAAHgKAJQgKAIgOAAQgPAAgIgLQgIgMgEgyQgFgxgQAAQgJAAgJAMQgLAMgVAnQgcA2gJAHQgIAIgFAAQgVAAAAgTg");
	this.shape_206.setTransform(719.425,338.85);

	this.shape_207 = new cjs.Shape();
	this.shape_207.graphics.f("#232323").s().p("AAtBLQgHgSAAgiIAAgGIAAgGQgWAlgWAUQgXAUgUAAQgLAAgLgNQgMgNAAgcQAAgWALgrQAIgkABgPQAEgJALgBQAHAAAFAGQAEAEAAAGQAAAMgJAWQgQAqAAAfQAAAbAOAAQAQAAAagbQAYgdATgyQAHgTAFgHQAEgFAHAAQAMAAAAAPIgDAMQgKAlAAAhQAAAoANAMQAHAGAAAEQAAAFgHADQgHAFgFAAQgMAAgIgSg");
	this.shape_207.setTransform(696.35,338.85);

	this.shape_208 = new cjs.Shape();
	this.shape_208.graphics.f("#232323").s().p("AihAwQAAgZALhBQAEgbABgLQgBgLALAAQASAAAAAbQAAANgGAlQgHAqAAAJQAKgKAUgiQAegvAOgNQANgNAPAAQALAAAHAPQAHAPABA3QAAAOACAHQABAHABAAQAIAAAbg2QAOgdAOgPQAOgPARAAQANAAAGAOQAHAPACAcQADAbAGAXQAFAYAOAHQAKAEAAAHQAAAFgIAHQgIAGgHAAQgOAAgKgRQgMgQgFg3IgEggQgDgJgEAAQgIAAgJANQgLAOgVApQgRAhgJALQgJAKgHAAQgHAAgGgGQgGgFgCgJQgBgIgCghQgCg1gHgIQgQAAg1BdQgRAfgDADQgDADgHACQgIACgGAAQgLAAAAgsg");
	this.shape_208.setTransform(668.85,338.225);

	this.shape_209 = new cjs.Shape();
	this.shape_209.graphics.f("#232323").s().p("AhFBUQgKgQAAgcQAAgeAHgkQAIglAFgNIADgLQACgGAPgEQACgBADAAQAEAAADALQAAAIgEALQgLAgAAANQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAQAngmAhAAQAUAAAOAPQAOAQAAANQAAAngoAlQgoAkgpAAQgSAAgKgPgAABgYQgMAHgQAOIgKAIQgEAEgGABQgDASAAATQAAAaAUAAQAXAAAbgbQAdgcAAgYQAAgLgGgHQgGgHgKAAQgNAAgNAHg");
	this.shape_209.setTransform(860.825,274.8);

	this.shape_210 = new cjs.Shape();
	this.shape_210.graphics.f("#232323").s().p("ABnBLQgHgSAAgiIAAgGIAAgGQgWAlgXAUQgWAUgUAAQgKAAgMgNQgMgNAAgbQAAgOADgRQgQAggaAXQgZAXgUAAQgKAAgLgLQgLgLAAgUQAAgWACgLIACgUIADgQQAGgkgBgLQADgMANAAQAFAAAFAEQAFAEAAAKQAAAQgHAXQgJAfAAAYQAAAOACAHQACAHAGAAQAXAAAcgoQAdgnAQgrQAHgUALAAQAHAAAEAFQAEAFAAAGQAAAMgIAWQgQApAAAeQAAAcANAAQAGAAAIgEQAJgEAMgNQANgNAMgSQALgRAEgJIAMgnQAGgUAFgHQAFgHAIAAQAMAAAAAQIgEAMQgEAQgEAaQgDAYAAAQQAAAoANAMQAHAGAAAEQAAAFgHAEQgHAEgFAAQgMAAgIgSg");
	this.shape_210.setTransform(834.625,275.825);

	this.shape_211 = new cjs.Shape();
	this.shape_211.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgbAXgqAXQgIAFgBAHQAAAOAIAJQAJAIAQAAQAkAAAmgoQAFgGADAAQAGAAAAAJQAAARgfAZQgeAYghAAQgbAAgPgQgAgOgxQgTAXgJAgQBHgqABgaQgBgKgIAAQgQAAgTAXg");
	this.shape_211.setTransform(809.8,275.325);

	this.shape_212 = new cjs.Shape();
	this.shape_212.graphics.f("#232323").s().p("AAsBPQgJgSAAgiQgYAggWAQQgYARgTgBQgNABgJgLQgKgLAAgSQAAgtAogzQAog0AnAAQAOAAAHAQQACAGAFAAQAOAAAAALQAAAFgCAJQgJAyAAAUQAAApAPAJQAIAEAAAGQAAAGgHAEQgIAGgGAAQgNAAgJgSgAgbgaQgeApAAAdQABATANAAQATAAAfgmQAigkAAghQAAgYgQAAQgWAAgeAqg");
	this.shape_212.setTransform(790.2,275.45);

	this.shape_213 = new cjs.Shape();
	this.shape_213.graphics.f("#232323").s().p("Ag/CDQgQgXAAgsQAAg1ATg2QASg2AcgcQAbgcAcAAQASAAAKAMQALALAAAUQAAAQgOAWQgOAWgXAUQAnAQAAA6QAAAsgcAhQgbAhgfAAQgdAAgQgXgAgfASIgRANQgCAOgBASQAAAfAKAQQAJAQARAAQAVAAAQgYQAPgYAAgdIAAgBQAAgZgJgQQgKgOgMAAQgDAAgiAZgAgIhcQgWAigOA6QBBgyAQgVQAPgWAAgNQAAgUgQAAQgWAAgWAig");
	this.shape_213.setTransform(771.95,270.075);

	this.shape_214 = new cjs.Shape();
	this.shape_214.graphics.f("#232323").s().p("AAtBLQgHgSAAgiIAAgGIAAgGQgWAlgWAUQgXAUgUAAQgLAAgLgNQgMgNAAgcQAAgWALgrQAIgkABgPQAEgJALgBQAHAAAFAGQAEAEAAAGQAAAMgJAWQgQAqAAAfQAAAbAOAAQAQAAAagbQAZgdASgyQAHgTAFgHQAEgFAHAAQAMAAAAAPIgDAMQgKAlAAAhQAAAoANAMQAHAGAAAEQAAAFgHADQgHAFgFAAQgMAAgIgSg");
	this.shape_214.setTransform(751.25,275.85);

	this.shape_215 = new cjs.Shape();
	this.shape_215.graphics.f("#232323").s().p("AhhCXQgHgGAAgDQAAgKAFgQQAfh9AAhgIAAgOQgBgTAHgIQAHgJAJAAQAEAAAEAHQAEAGAAAMQAAARgEAXIgEAiQAZgsAcgZQAcgZAZAAQARAAAMANQAMANAAATQAAA4grAtQgrAtgnAAQgKAAgGgFQgGgGgHgNQgIAfgHA3IgFAhQgBAGgFAHQgFAHgFAAQgFAAgHgFgAgChLQgkAuAAAZQAAAFAHAGQAHAFALAAQAYAAAfgjQAggkAAgjQAAgMgFgHQgFgHgHAAQgZAAgiAtg");
	this.shape_215.setTransform(728.625,280.725);

	this.shape_216 = new cjs.Shape();
	this.shape_216.graphics.f("#232323").s().p("AAsBPQgIgSAAgiQgYAggXAQQgYARgTgBQgNABgKgLQgJgLAAgSQAAgtAogzQAog0AnAAQAOAAAHAQQADAGAEAAQAOAAAAALIgCAOQgJAyAAAUQAAApAQAJQAHAEAAAGQAAAGgHAEQgHAGgIAAQgNAAgIgSgAgagaQgeApAAAdQAAATAMAAQATAAAhgmQAhgkAAghQAAgYgQAAQgWAAgdAqg");
	this.shape_216.setTransform(707.8,275.45);

	this.shape_217 = new cjs.Shape();
	this.shape_217.graphics.f("#232323").s().p("Ag/CDQgQgXAAgsQAAg1ASg2QATg2AdgcQAagcAdAAQARAAALAMQAKALAAAUQAAAQgOAWQgOAWgXAUQAnAQAAA6QAAAsgbAhQgcAhgfAAQgdAAgQgXgAgeASIgSANQgDAOAAASQAAAfAKAQQAKAQAPAAQAXAAAPgYQAPgYAAgdIAAgBQAAgZgKgQQgJgOgLAAQgEAAghAZgAgIhcQgWAigOA6QBBgyAPgVQAQgWAAgNQAAgUgQAAQgXAAgVAig");
	this.shape_217.setTransform(689.55,270.075);

	this.shape_218 = new cjs.Shape();
	this.shape_218.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAegrQAdgrAoAAQAcAAARAVQARAVAAAdQAAAsgjAmQgkAmglAAQgXAAgPgSgAgegiQgUAiAAAeQAAARAHALQAHALANAAQAYAAAZgcQAagcAAghQAAgVgKgNQgKgNgQAAQgbAAgTAhg");
	this.shape_218.setTransform(669.85,275.675);

	this.shape_219 = new cjs.Shape();
	this.shape_219.graphics.f("#232323").s().p("AgzBWQgPgKgCgQIAAgEQgCgRAMgTQANgTAxgYQAfgQAAgNQAAgHgFgEQgGgEgEAAQgNAAgkASIgDACQgOAAAAgKQAAgQAcgLQAagLAVAAQANAAAOALQAOAKAAARQAAAOgJANQgJANglATQgcAQgLALQgKAKAAAOQAAAJAJADQAJAEAEAAQAfAAAagOQAIgEAFAAQAJAAAAAKQAAAPgZAKQgYAKgkAAQgSAAgPgKg");
	this.shape_219.setTransform(651.6362,275.475);

	this.shape_220 = new cjs.Shape();
	this.shape_220.graphics.f("#232323").s().p("Ag3BZQgSgKAAgMQABgLAMAAQABAAADADQATARAaAAQAWAAAQgMQARgMAAgUQAAgMgKgJQgIgIgNAAQgKAAgWAHQgFACgFAAQgKAAAAgNQAAgFAFgDQAEgDARgDQAvgLAAgdQAAgIgFgGQgHgGgJAAQgRAAgUAQQgMAJgGAAQgLAAAAgJQAAgNAYgNQAYgOAWAAQAWAAANAMQANAMAAANQAAAfgmARQAWAEAMALQANANAAASQAAAdgZAUQgYATgnAAQgYAAgRgLg");
	this.shape_220.setTransform(633.95,275.375);

	this.shape_221 = new cjs.Shape();
	this.shape_221.graphics.f("#232323").s().p("AAsBPQgJgSABgiQgZAggWAQQgYARgTgBQgNABgJgLQgKgLAAgSQAAgtAogzQAog0AnAAQAOAAAHAQQADAGAEAAQAOAAAAALQAAAFgCAJQgJAyAAAUQAAApAPAJQAIAEAAAGQAAAGgHAEQgIAGgGAAQgNAAgJgSgAgagaQgfApAAAdQABATANAAQASAAAggmQAigkAAghQAAgYgQAAQgXAAgcAqg");
	this.shape_221.setTransform(615.7,275.45);

	this.shape_222 = new cjs.Shape();
	this.shape_222.graphics.f("#232323").s().p("AhhCXQgHgGAAgDQAAgKAFgQQAfh9AAhgIAAgOQgBgTAHgIQAHgJAJAAQAEAAAEAHQAEAGAAAMQAAARgEAXIgEAiQAZgsAcgZQAcgZAZAAQARAAAMANQAMANAAATQAAA4grAtQgrAtgnAAQgKAAgGgFQgGgGgHgNQgIAfgHA3IgFAhQgBAGgFAHQgFAHgFAAQgFAAgHgFgAgChLQgkAuAAAZQAAAFAHAGQAHAFALAAQAYAAAfgjQAggkAAgjQAAgMgFgHQgFgHgHAAQgZAAgiAtg");
	this.shape_222.setTransform(593.375,280.725);

	this.shape_223 = new cjs.Shape();
	this.shape_223.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgbAXgqAXQgJAFAAAHQAAAOAJAJQAIAIAQAAQAkAAAmgoQAGgGACAAQAGAAAAAJQAAARgfAZQgeAYghAAQgbAAgPgQgAgOgxQgTAXgJAgQBHgqAAgaQAAgKgJAAQgPAAgTAXg");
	this.shape_223.setTransform(559.95,275.325);

	this.shape_224 = new cjs.Shape();
	this.shape_224.graphics.f("#232323").s().p("AAnAPQAAgGgDAAIgnABQgXADgKADQgKADgCACQgCADgCAKQgCAKAAAMIAAAVQAAASgRABQgOgBAAgSQAAgMADgSQAFgiAHhSQAAgLABgCQABgDAGgEQAFgEAFABQANAAAAAKIgEAaQgEAXAAAOQAAAJAGAAQANAAAigEQAjgEAAgDQADgDADgoQADggARAAQAOAAABAPIgDAMQgNA3AAAkQAAAoANAMQAHAGAAAEQAAAFgHADQgHAFgGAAQgbAAAAhSg");
	this.shape_224.setTransform(540.75,275.45);

	this.shape_225 = new cjs.Shape();
	this.shape_225.graphics.f().s("#232323").ss(4,1,1).p("EAuVAB6QgrOxtzBNQtzBMxPAgQxNAgvMh5QvLh5AZs5QAas4NelLQNflKSxAKQSwALOPDUQOQDUgsOxg");
	this.shape_225.setTransform(707.7782,298.0838);

	this.shape_226 = new cjs.Shape();
	this.shape_226.graphics.f("#FFFFFF").s().p("A/kSLQvLh5AZs5QAas4NelLQNflKSxAKQSwALOPDUQOQDUgsOxQgrOxtzBNQtzBMxPAgQjmAHjiAAQtRAAsAhgg");
	this.shape_226.setTransform(707.7782,298.0838);

	this.shape_227 = new cjs.Shape();
	this.shape_227.graphics.f("#232323").s().p("AhVBiQgEgFAAgEQAAgGAEgXQAIgqAJhfQAAgJAHgHQAGgIAIAAQAEAAADAFQADAFAAAHQAAAGgCAIQgJAjgDAkQApgGAfgtQAPgVALgJQAMgJAMAAQAGAAAFAFQAFAFAAAGQAAAIgQAFQgIADgIAGQgHAGgVAXQgQASgMAHIgBABIACABQALAHAOATQAUAcAKAHQAKAHANAAIAGAAQAGAAAAAGQAAAGgHAHQgIAHgRAAQgNAAgMgLQgMgLgQgZQgIgPgIgIQgIgIgJAAIgNAEQgKADgCADQgBAEAAATIgBAgQAAAGgGAFQgGAFgHAAQgHAAgEgEg");
	this.shape_227.setTransform(956.425,243.675);

	this.shape_228 = new cjs.Shape();
	this.shape_228.graphics.f("#232323").s().p("AhmBUQgKgQAAgcQAAgeAHgkQAIgmAFgMIADgLQACgHAPgCQACgCADAAQAEAAADALQAAAIgEALQgLAgAAANQAAABAAABQAAAAAAABQAAAAABABQAAAAABAAQAngmAiAAQATAAAOAPQAOAQAAANQAAAngoAlQgoAkgpAAQgSAAgKgPgAgfgYQgNAGgQAPIgKAIQgEAEgGABQgDATAAASQAAAbAUAAQAXgBAcgbQAcgcAAgYQAAgLgGgHQgGgHgJAAQgNAAgNAHgAA9BCQAAgeANhHQAFgaAAgGQAAgKAEgIQAEgHAHgBQAJAAAFAFQAFAEAAAFQAAAGgCAIQgOAxgDASQgDAUAAAbQAAANAEAQIAAAFQAAAEgFAEQgGAFgGAAQgRAAAAgeg");
	this.shape_228.setTransform(933.025,243.2);

	this.shape_229 = new cjs.Shape();
	this.shape_229.graphics.f("#232323").s().p("AhJCFQgKgOAAgVQAAgnARgdQARgeAVgRQAVgTAlgMIAQgFQAFgCgBgFQgHgbgJgKQgIgLgPgGQgOgGgMAAQgFAAgJAEIgNAGQgHAEgGAAQgHAAABgHQAAgHALgNQALgNAcAAIAHAAQAbAAAWAPQAVAOAJAbQAJAcAAAtQAAAegUAtQgTAsgfAWQgdAXgjAAQgMAAgLgOgAgFAAQgvArAAA4QAAAHACAGQADAHADAAQAMAAALgFQAKgEAPgOQAOgPAMgUQANgVAGgTQAFgUAAgJIABgRQgoAHgUASg");
	this.shape_229.setTransform(911.35,239.05);

	this.shape_230 = new cjs.Shape();
	this.shape_230.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgbAXgqAXQgJAFAAAHQAAAOAIAJQAJAIAQAAQAkAAAmgoQAGgGACAAQAGAAAAAJQAAARgfAZQgeAYghAAQgbAAgPgQgAgOgxQgUAXgIAgQBHgqAAgaQAAgKgJAAQgPAAgTAXg");
	this.shape_230.setTransform(869.55,243.725);

	this.shape_231 = new cjs.Shape();
	this.shape_231.graphics.f("#232323").s().p("AhVBiQgEgFAAgEQAAgGAEgXQAIgqAJhfQAAgJAHgHQAGgIAIAAQAEAAADAFQADAFAAAHQAAAGgCAIQgJAjgDAkQApgGAfgtQAPgVALgJQAMgJAMAAQAGAAAFAFQAFAFAAAGQAAAIgQAFQgIADgIAGQgHAGgVAXQgQASgMAHIgBABIACABQALAHAOATQAUAcAKAHQAKAHANAAIAGAAQAGAAAAAGQAAAGgHAHQgIAHgRAAQgNAAgMgLQgMgLgQgZQgIgPgIgIQgIgIgJAAIgNAEQgKADgCADQgBAEAAATIgBAgQAAAGgGAFQgGAFgHAAQgHAAgEgEg");
	this.shape_231.setTransform(851.125,243.675);

	this.shape_232 = new cjs.Shape();
	this.shape_232.graphics.f("#232323").s().p("AhAB5QgagRAAgNQAAgGACgFQADgGAFAAQACAAACAEQAWAiAuAAQAdAAAPgkQAPgkADg4QgaAXgaAOQgZAOgNABQgQAAgKgOQgJgOAAgSQAAgdALgoQALgnAFgGQAHgFAJAAQAGAAACAGQADAGAAAHQAAAEgEAHQgXAnAAApQAAAJAFAIQADAGAIAAQAIAAAOgFQANgFASgNQARgNAFgJQAHgHACgLQADgKABgjQABghAPAAQAKAAACAEQADAFAAAOIgDAsIgBAPQgFBagWA0QgWA0grgBQghAAgagRg");
	this.shape_232.setTransform(1005.35,185.45);

	this.shape_233 = new cjs.Shape();
	this.shape_233.graphics.f("#232323").s().p("AiHBpQgFgEABgEQAAgHACgCQAPgSALgVQALgUAQgpQARgpAEgaQACgMAPAAQAIAAADADQAEACACAJQADAHABAGIAFAhIAHAhQACAOAGAXQAFAXAEAAQACAAAEgLIAOggIAJgSIATgoQAQghAKgOQAIgPADgDQADgEAEAAQAGAAAIAEQAIADAAAFIACAjIADA2QAAAYACASQADARAEAMQAJARAAAKQgBAIgGADQgHADgGAAQgLAAgHgTQgGgUgDhZQgCgbgCgGQgOAWgYA0IgMAXIgHAQQgSAqgOAAQgJAAgFgDQgFgCgEgMQgFgMgJgqQgKgvgDgLQgMAbgJAXQgOAjgNAXQgMAWgGAFQgGAEgFAAQgFAAgEgEg");
	this.shape_233.setTransform(980.35,180.55);

	this.shape_234 = new cjs.Shape();
	this.shape_234.graphics.f("#232323").s().p("AhBBOQgPgSAAgaQAAgrAdgrQAegrAoAAQAcAAARAVQARAVAAAdQAAAsgjAmQgkAmglAAQgXAAgPgSgAgegiQgUAiAAAeQAAARAHALQAIALALAAQAZAAAZgcQAagcAAghQAAgVgJgNQgKgNgRAAQgbAAgTAhg");
	this.shape_234.setTransform(955.5,181.075);

	this.shape_235 = new cjs.Shape();
	this.shape_235.graphics.f("#232323").s().p("AAnAPQAAgGgEAAIgmABQgXACgKAEQgKADgCACQgDACgCALQgBALAAALIAAAVQAAASgRABQgOgBAAgSQAAgMADgSQAGgiAFhSQABgKABgDQACgEAEgDQAFgDAGAAQANAAAAAKIgEAaQgEAXAAAOQAAAJAGAAQAOAAAhgEQAjgFABgCQACgDADgoQAEgfARgBQAOABgBAOIgCAMQgNA3AAAkQAAAoANAMQAHAGAAAEQAAAFgHADQgHAFgGAAQgbAAAAhSg");
	this.shape_235.setTransform(935.6,180.85);

	this.shape_236 = new cjs.Shape();
	this.shape_236.graphics.f("#232323").s().p("Ag8BTQgPgQAAgdQAAgwAhgsQAhgsAmAAQANAAAIAIQAIAJAAALQAAAbgZAYQgbAXgqAXQgJAFAAAHQAAAOAIAJQAJAIAQAAQAkAAAmgoQAGgGADAAQAFAAAAAJQAAARgfAZQgeAYghAAQgbAAgPgQgAgOgxQgTAXgJAgQBHgqAAgaQAAgKgJAAQgPAAgTAXg");
	this.shape_236.setTransform(893.4,180.725);

	this.shape_237 = new cjs.Shape();
	this.shape_237.graphics.f("#232323").s().p("AAgBXQABgFABgEQACgGALhPQgbAXgZANQgaAOgNAAQgRAAgJgOQgJgOAAgSQAAgZAJgfQAJgfAVAAQAFAAADAFQADAGAAAHQAAAKgJAPQgMAVAAAOQAAAIADAIQADAIAHAAQATAAAbgSQAcgTAGgOQAHgOAAgIIgBgGIAAgHQAAgGAEgIQAEgJAIAAQAIAAADAEQAEAEAAAPIgDArIgBAOQgBAVgGAqQgHAqgDAFQgEAFgGAAQgRAAAAgLg");
	this.shape_237.setTransform(874.9,180.475);

	this.shape_238 = new cjs.Shape();
	this.shape_238.graphics.f("#232323").s().p("AhAB5QgagRAAgNQAAgGACgFQADgGAEAAQACAAADAEQAWAiAuAAQAdAAAPgkQAPgkADg4QgaAXgZAOQgZAOgOABQgQAAgKgOQgJgOAAgSQAAgdALgoQALgnAFgGQAHgFAJAAQAFAAADAGQADAGAAAHQAAAEgEAHQgWAngBApQAAAJAFAIQADAGAHAAQAJAAAPgFQAMgFARgNQARgNAHgJQAGgHACgLQACgKACgjQAAghAQAAQAJAAADAEQADAFAAAOIgDAsIgBAPQgFBagWA0QgXA0gpgBQgiAAgagRg");
	this.shape_238.setTransform(839.95,185.45);

	this.shape_239 = new cjs.Shape();
	this.shape_239.graphics.f("#232323").s().p("AhAB5QgagRAAgNQAAgGACgFQADgGAEAAQACAAADAEQAWAiAuAAQAdAAAPgkQAPgkADg4QgaAXgZAOQgZAOgOABQgQAAgKgOQgJgOAAgSQAAgdALgoQALgnAFgGQAHgFAJAAQAFAAADAGQADAGAAAHQAAAEgEAHQgWAngBApQAAAJAFAIQADAGAHAAQAKAAAOgFQAMgFASgNQAQgNAHgJQAFgHADgLQACgKACgjQAAghAQAAQAJAAADAEQADAFAAAOIgDAsIgBAPQgFBagWA0QgXA0gpgBQgiAAgagRg");
	this.shape_239.setTransform(819.25,185.45);

	this.shape_240 = new cjs.Shape();
	this.shape_240.graphics.f("#232323").s().p("AhAB5QgagRAAgNQAAgGACgFQADgGAEAAQACAAADAEQAWAiAuAAQAdAAAPgkQAPgkADg4QgaAXgZAOQgZAOgOABQgQAAgKgOQgJgOAAgSQAAgdALgoQALgnAFgGQAHgFAJAAQAFAAADAGQADAGAAAHQAAAEgEAHQgWAngBApQAAAJAFAIQADAGAHAAQAKAAAOgFQAMgFASgNQAQgNAHgJQAGgHACgLQACgKACgjQABghAPAAQAJAAADAEQADAFAAAOIgDAsIgBAPQgFBagWA0QgXA0gpgBQgiAAgagRg");
	this.shape_240.setTransform(798.55,185.45);

	this.shape_241 = new cjs.Shape();
	this.shape_241.graphics.f().s("#232323").ss(4,1,1).p("AcxA6QASMCqMB5QqLB4qggDQqggEnZkrQnZkshcnNQhcnNHlkmQHmkmMegRQMdgQJMC4QJMC4ARMCg");
	this.shape_241.setTransform(904.6651,208.7622);

	this.shape_242 = new cjs.Shape();
	this.shape_242.graphics.f("#FFFFFF").s().p("Ah0QqQqggEnZkrQnZkshcnNQhcnNHlkmQHmkmMegRQMdgQJMC4QJMC4ARMCQASMCqMB5Qp5B1qMAAIgmAAg");
	this.shape_242.setTransform(904.6651,208.7622);

	this.shape_243 = new cjs.Shape();
	this.shape_243.graphics.f("#232323").s().p("AhmBUQgKgQAAgcQAAgeAHgkQAIgmAFgMIADgKQACgIAPgCQACgCADAAQAEAAADAMQAAAGgEAMQgLAgAAANQAAABAAABQAAAAAAABQABAAAAABQAAAAABAAQAngmAiAAQATAAAOAQQAOAPAAANQAAAngoAkQgoAlgpAAQgSAAgKgPgAgfgYQgNAGgQAPIgKAIQgEADgGACQgDASAAAUQAAAaAUAAQAXAAAcgcQAcgcAAgYQAAgLgGgHQgGgHgJAAQgNAAgNAHgAA9BCQAAgeANhHQAFgaAAgFQAAgLAEgIQAEgIAHAAQAJABAFAEQAFAEAAAFQAAAGgCAIQgOAxgDATQgDATAAAbQAAANAEAQIAAAFQAAADgFAFQgGAFgGAAQgRAAAAgeg");
	this.shape_243.setTransform(974.475,199.8);

	this.shape_244 = new cjs.Shape();
	this.shape_244.graphics.f("#232323").s().p("AAnAOQAAgFgDAAIgnACQgXABgKADQgKADgCADQgCACgCALQgCALAAALIAAAVQAAASgRAAQgOAAAAgSQAAgMADgSQAFgiAHhSQAAgKABgEQABgDAGgDQAEgEAHAAQAMABAAAJIgEAaQgEAZAAANQAAAJAGAAQANAAAigEQAigFABgCQACgDAEgoQADgfARAAQAOAAABAOIgDANQgNA2AAAkQAAAoANAMQAHAGAAAEQAAAFgHADQgHAEgGAAQgbAAAAhSg");
	this.shape_244.setTransform(951.05,200.45);

	this.shape_245 = new cjs.Shape();
	this.shape_245.graphics.f("#232323").s().p("AhcBXQAAgbA6g0IAIgIQgigyAAgbQAAgZAVAAQAFAAADAFQACAFACARQACAcAWAfQAugpARggQAFgLADgDQADgCAGAAQAFAAAGAEQAGAFAAAIQAAARhUBLQAdAlAgASIAIAFIAAAEQAAAIgFAGQgFAGgIgBQgXAAgxhCQgnAigNAiQgEALgFAGQgVgCABgRg");
	this.shape_245.setTransform(930.85,200.9);

	this.shape_246 = new cjs.Shape();
	this.shape_246.graphics.f().s("#232323").ss(4,1,1).p("APKAfQAKGWlYA/QlXBAligCQligCj5ieQj6iegwjzQgxjyEAibQEAibGlgJQGjgJE3BiQE2BhAIGVg");
	this.shape_246.setTransform(969.2515,197.0427);

	this.shape_247 = new cjs.Shape();
	this.shape_247.graphics.f("#FFFFFF").s().p("Ag9IyQligCj5ieQj6iegwjzQgxjyEAibQEAibGlgJQGjgJE3BiQE2BhAIGVQAKGWlYA/QlPA+lZAAIgRAAg");
	this.shape_247.setTransform(969.2515,197.0427);

	this.shape_248 = new cjs.Shape();
	this.shape_248.graphics.f("#232323").s().p("Ah2DaQgJgJgBgNQABgLASgMIAHgFQAGgFAKAAQAHAAAMAKQAVAAAAARQAAAOgSALQgRALgNAAQgOAAgKgIgAhXBZIgDgRQABgUAWgtIADgHQAVgSA5gVIAkgNQARgHAJgSQAIgRAAgQQAAgKgGgXQgFgXgRgHQgRgHgRAAQgiAAgQAKQgPAKgCALQgCAOgRAEIgQACQgQAAAAgSQAAgXAjgbQAjgbAWAAIAngBQAcgBARALQASALAPARQAPARABAxQAAArgQAZQgQAZgYANQgZANhMAYQgKAagGAdQgDAOgKAFQgJAFgRAAQgDAAgBgMg");
	this.shape_248.setTransform(966.6,195.221);

	this.shape_249 = new cjs.Shape();
	this.shape_249.graphics.f().s("#232323").ss(4,1,1).p("ALyAfQADGWj9A/Qj8BAlhgCQljgChmiTQhniThEj1QhFj0CBikQCCikGkgJQGkgJDhBhQDhBiADGVg");
	this.shape_249.setTransform(973.3394,197.0426);

	this.shape_250 = new cjs.Shape();
	this.shape_250.graphics.f("#FFFFFF").s().p("AhlIyQljgChmiTQhniThEj1QhFj0CBikQCCikGkgJQGkgJDhBhQDhBiADGVQADGWj9A/Qj2A+lXAAIgQAAg");
	this.shape_250.setTransform(973.3394,197.0426);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_226},{t:this.shape_225},{t:this.shape_224},{t:this.shape_223},{t:this.shape_222,p:{x:593.375,y:280.725}},{t:this.shape_221},{t:this.shape_220},{t:this.shape_219},{t:this.shape_218},{t:this.shape_217},{t:this.shape_216},{t:this.shape_215,p:{x:728.625,y:280.725}},{t:this.shape_214},{t:this.shape_213},{t:this.shape_212},{t:this.shape_211},{t:this.shape_210},{t:this.shape_209},{t:this.shape_208},{t:this.shape_207},{t:this.shape_206},{t:this.shape_205}]},933).to({state:[]},27).to({state:[{t:this.shape_242},{t:this.shape_241},{t:this.shape_240},{t:this.shape_239},{t:this.shape_238},{t:this.shape_237},{t:this.shape_236},{t:this.shape_222,p:{x:912.825,y:186.125}},{t:this.shape_235},{t:this.shape_234},{t:this.shape_233},{t:this.shape_232},{t:this.shape_231},{t:this.shape_230},{t:this.shape_215,p:{x:888.975,y:249.125}},{t:this.shape_229},{t:this.shape_228},{t:this.shape_227,p:{x:956.425,y:243.675}}]},3).to({state:[{t:this.shape_247},{t:this.shape_246},{t:this.shape_245},{t:this.shape_244},{t:this.shape_243},{t:this.shape_227,p:{x:997.875,y:200.275}}]},22).to({state:[]},17).to({state:[{t:this.shape_250},{t:this.shape_249},{t:this.shape_248}]},1).to({state:[]},21).to({state:[]},248).wait(36));

	// Слой_118___копия___копия
	this.shape_251 = new cjs.Shape();
	this.shape_251.graphics.f("#232323").s().p("AiADsQgKgJAAgPQAAgMAUgNIAHgFQAGgGALAAQAIAAANALQAXAAAAATQAAAQgTAMQgTALgPAAQgOAAgLgJgAhfBgQgCgMAAgGQAAgWAYgwIAEgIQAVgTBAgYIAmgOQASgHAKgTQAJgTAAgRQAAgLgGgZQgGgZgTgIQgTgHgRAAQglAAgRALQgRAKgCANQgDAOgRAFIgSACQgRAAAAgTQgBgZAmgeQAngdAYAAIArgBQAegBASAMQAUAMAQASQAQATAAA1QAAAvgRAbQgQAbgbAOQgbANhTAbQgLAcgGAgQgEAPgJAFQgKAFgUAAQgCAAgCgNg");
	this.shape_251.setTransform(583.3,130.2212);

	this.shape_252 = new cjs.Shape();
	this.shape_252.graphics.f().s("#232323").ss(4,1,1).p("AQHgsQhqFVkiDRQkiDRmYAAQmaAAkijRQkijRAAknQAAkmEijRQEijRGkgEQGjgFGBCnQGBCmhpFWg");
	this.shape_252.setTransform(585.6096,135.9177);

	this.shape_253 = new cjs.Shape();
	this.shape_253.graphics.f("#FFFFFF").s().p("Ar7H6QkijRAAknQAAkmEijRQEijRGkgEQGjgFGBCnQGBCmhpFWQhqFVkiDRQkiDRmYAAQmaAAkijRg");
	this.shape_253.setTransform(585.6096,135.9177);

	this.shape_254 = new cjs.Shape();
	this.shape_254.graphics.f("#232323").s().p("AgiAvQgIgJAAgQQAAgbASgaQATgZAWAAQAHAAAFAFQAEAFAAAHQAAAPgPANQgOANgYANQgFADAAAEQAAAIAFAFQAEAFAJAAQAUAAAWgXQAEgDABAAQADAAAAAFQAAAKgRAOQgSAOgSAAQgPAAgJgKgAgIgcQgLANgFASQApgXAAgPQAAgGgFAAQgJAAgLANg");
	this.shape_254.setTransform(897.775,236.875);

	this.shape_255 = new cjs.Shape();
	this.shape_255.graphics.f("#232323").s().p("AgpBMQgGgIAAgMQAAgWAKgRQAKgRAMgKQAMgLAUgFIAKgEQAAAAABgBQAAAAAAAAQABgBAAgBQAAAAAAgBQgEgPgFgHQgFgGgIgDQgIgDgHAAIgIACIgIAEQgDACgEAAQgEAAABgEQAAgEAGgIQAHgHAPAAIAFAAQAOAAANAIQAMAIAFAQQAFAQAAAaQAAAQgLAaQgLAZgRANQgRANgTAAQgIAAgGgIgAgCAAQgbAZAAAfQAAAFABADQABAEACAAQAIAAAGgDQAFgDAIgHQAJgJAHgLQAHgMADgMIADgPIAAgKQgWAEgLAKg");
	this.shape_255.setTransform(887.8,234.2);

	this.shape_256 = new cjs.Shape();
	this.shape_256.graphics.f("#232323").s().p("AAaArQgEgKAAgUIAAgDIAAgEQgMAVgMAMQgOALgLAAQgHAAgGgHQgHgIAAgPQAAgNAGgYQAGgVgBgIQAEgGAFAAQAEAAADADQACADAAADQABAHgGANQgIAXgBARQAAARAIgBQAJABAPgRQAOgPAKgdQAFgLACgDQACgEAFAAQAGAAABAJIgCAHQgGAVAAATQAAAWAIAHQADAEAAACQAAACgDADQgEACgEAAQgHAAgEgKg");
	this.shape_256.setTransform(875.75,237.15);

	this.shape_257 = new cjs.Shape();
	this.shape_257.graphics.f("#232323").s().p("AgjBLQgKgNAAgaQAAgeALgeQALgfAQgQQAPgQAQAAQAKAAAGAHQAGAGAAAMQAAAJgIAMQgIANgNALQAWAJAAAhQAAAZgPATQgQATgSAAQgQAAgJgNgAgRAKIgKAHQgBAJAAAKQAAASAFAJQAGAJAJAAQAMAAAJgOQAIgOAAgQQAAgPgFgJQgFgIgHAAQgCAAgTAOgAgEg0QgNATgHAhQAkgcAJgMQAJgNAAgHQAAgLgJAAQgNAAgMATg");
	this.shape_257.setTransform(865.125,233.875);

	this.shape_258 = new cjs.Shape();
	this.shape_258.graphics.f("#232323").s().p("AhNA8QgBgBAAAAQgBgBAAAAQAAgBAAgBQAAAAAAgBIABgFQAIgKAHgMIAPgiQAKgYACgPQACgHAIAAQAFAAABACQACABACAFQACAEAAAEIADATIADASIAFAVQADANACAAQABAAADgGIAIgTIAFgKIALgWIAOgbIAHgLQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQAEAAAFACQAEACAAACIABAVIACAeIABAYQACAKACAGQAFAKAAAGQAAAEgEACIgHACQgHAAgDgLQgEgLgCgzQAAgPgCgEQgIANgOAdIgGANIgFAJQgKAYgHAAQgFAAgDgBQgDgCgDgGQgCgHgFgYIgIghIgMAcQgIAUgHANQgHANgDADQgEACgDAAQgDAAgCgCg");
	this.shape_258.setTransform(842.625,236.775);

	this.shape_259 = new cjs.Shape();
	this.shape_259.graphics.f("#232323").s().p("AgkAsQgKgKABgPQgBgYASgYQAQgZAXAAQAQAAAJAMQALAMgBARQAAAYgTAWQgVAWgVAAQgNAAgIgLgAgRgTQgLATAAARQAAAKAEAGQAEAGAHAAQAOAAAPgQQAOgQAAgSQAAgMgFgIQgHgHgJAAQgOAAgMATg");
	this.shape_259.setTransform(828.4,237.075);

	this.shape_260 = new cjs.Shape();
	this.shape_260.graphics.f("#232323").s().p("AgwA4QgDgCAAgDIADgRQAFgXAFg2QAAgGAEgEQADgEAFAAQACAAACADQACACAAAFIgCAIQgFAUgBAUQAXgDARgaQAJgMAGgFQAHgFAHAAQADAAADADQADACAAAEQAAAFgJACQgFACgEADQgFAEgLANQgJAKgHAEIAAAAIAAABQAHAEAIALQALAQAGAEQAGAEAHAAIADAAQABAAABAAQAAAAABABQAAAAABABQAAAAAAABQAAAEgFAEQgEAEgJAAQgIAAgHgHQgHgGgJgOQgEgJgEgEQgFgFgFAAIgIACQgGACAAACQgBACAAALIgBASQAAAEgDACQgEADgEAAQgEAAgCgCg");
	this.shape_260.setTransform(817.475,236.825);

	this.shape_261 = new cjs.Shape();
	this.shape_261.graphics.f("#232323").s().p("AAZAtQgFgLAAgSQgOASgMAJQgNAJgMAAQgHAAgFgGQgGgHAAgJQAAgaAXgdQAXgdAWgBQAIAAAEAKQABADADAAQAIAAAAAGIgBAIQgGAcAAAMQAAAXAJAGQAFACAAADQAAADgFADQgEADgEAAQgHABgFgLgAgPgOQgRAXAAAPQAAAMAHAAQALAAASgVQATgVAAgTQAAgOgJABQgNAAgQAYg");
	this.shape_261.setTransform(805.425,236.95);

	this.shape_262 = new cjs.Shape();
	this.shape_262.graphics.f("#232323").s().p("AhcAcQAAgPAHgkIACgXQAAgGAGAAQALAAAAAQQAAAHgDAWQgFAXAAAFQAGgFAMgUQAQgbAIgHQAIgHAJAAQAGAAAEAIQADAJABAfIABAMIACAEQAEAAAPgfQAJgQAIgJQAHgIAKAAQAHAAAEAIQADAIADAQQABAQADANQADAOAIADQAFACABAEQgBADgEAFQgEADgFAAQgIAAgFgKQgGgKgEgeIgCgTQgCgEgDAAQgDAAgGAHQgGAIgNAXQgJASgFAHQgFAGgEAAQgEAAgEgEQgDgDgBgFIgBgXQgCgegEgEQgJgBgdA1IgMAUQgCACgEAAIgIACQgHAAAAgZg");
	this.shape_262.setTransform(789.85,236.8);

	this.shape_263 = new cjs.Shape();
	this.shape_263.graphics.f("#232323").s().p("AgjBLQgKgNAAgaQAAgeALgeQALgfAQgQQAPgQAQAAQAKAAAGAHQAGAGAAAMQAAAJgIAMQgIANgNALQAWAJAAAhQAAAZgPATQgQATgSAAQgQAAgJgNgAgRAKIgKAHQgBAJAAAKQAAASAFAJQAGAJAJAAQAMAAAJgOQAIgOAAgQQAAgPgFgJQgFgIgHAAQgCAAgTAOgAgEg0QgNATgHAhQAkgcAJgMQAJgNAAgHQAAgLgJAAQgNAAgMATg");
	this.shape_263.setTransform(766.375,233.875);

	this.shape_264 = new cjs.Shape();
	this.shape_264.graphics.f("#232323").s().p("AgsA1QgCgEgBgCQAAgDAKgIIAGgEQAOgKAOgOIgKAAQgFAAgIgEQgIgEgBgDIgCgKQAAgOAQgLQAPgMAUgEIAJgBIAHgBIAEABIAEgBQACAAADACQAEACABADQAAACgFAKQgDAHgDAVQgEAVAAANIABAQIABAIQAAAAAAAAQAAABgBAAQAAABgBAAQAAABgBAAQgDACgDAAQgGAAgBgDQgCgCAAgJIABggIgUASIgKAJQgOALgFAHIgDADIgDACQgFAAgCgFgAgEghQgRAJAAAMQAAADAFADQAEADAIAAQAOAAAHgEQADgBACgEIAGgbQAAgBgBAAQAAgBAAAAQAAAAgBAAQAAgBgBAAQgNAAgQAJg");
	this.shape_264.setTransform(747.45,236.85);

	this.shape_265 = new cjs.Shape();
	this.shape_265.graphics.f("#232323").s().p("AggAwQgIgHAAgQQAAgZAUgbQAUgdAQAAQAIAAAHAIQAFAJAAAKQAAAFgDAEQgCAFgCAAQgHAAgBgLQgDgNgFAAQgKAAgNAYQgOAYAAAQQAAAQATAAQANAAATgNQAHgFAEAAQAAAAABABQABAAAAAAQABABAAAAQAAABAAABQAAAHgSAMQgRALgQAAQgPAAgHgJg");
	this.shape_265.setTransform(737,236.9);

	this.shape_266 = new cjs.Shape();
	this.shape_266.graphics.f("#232323").s().p("Ag1AxQAAgHAKgLQAJgLAPgZQAPgaAIgVQACgDADAAIAFABQAEABABACIAFASQAMA7ANALIAEAEIABACQAAADgCADQgCACgCABQgCABgGAAQgCAAgHgKQgIgLgKgsIgEgQQgCAAgDAFQgTAngKAPIgCADQgNAWgFAAQgIAAAAgHg");
	this.shape_266.setTransform(725.875,236.975);

	this.shape_267 = new cjs.Shape();
	this.shape_267.graphics.f("#232323").s().p("AAaArQgEgKAAgUIAAgDIAAgEQgMAVgNAMQgNALgLAAQgHAAgGgHQgHgIAAgPQAAgNAGgYQAFgVABgIQACgGAHAAQAEAAACADQADADAAADQgBAHgEANQgKAXAAARQABARAHgBQAKABAOgRQANgPALgdQAEgLADgDQADgEAEAAQAHAAAAAJIgDAHQgFAVAAATQAAAWAIAHQADAEAAACQAAACgDADQgFACgDAAQgHAAgEgKg");
	this.shape_267.setTransform(713.8,237.15);

	this.shape_268 = new cjs.Shape();
	this.shape_268.graphics.f("#232323").s().p("Ag1AxQAAgHAKgLQAJgLAPgZQAPgaAIgVQACgDADAAIAFABQAEABABACIAFASQAMA7ANALIAEAEIABACQAAADgCADQgCACgCABQgCABgGAAQgCAAgHgKQgIgLgKgsIgEgQQgCAAgDAFQgTAngKAPIgCADQgNAWgFAAQgIAAAAgHg");
	this.shape_268.setTransform(701.725,236.975);

	this.shape_269 = new cjs.Shape();
	this.shape_269.graphics.f("#232323").s().p("Ag6AwQgGgIAAgRQAAgRAFgVIAHgcIACgGQABgEAIgBIADgBQADgBABAHIgCAKQgHATAAAHQAAABAAAAQAAABABAAQAAAAAAAAQAAABABAAQAWgWATAAQALAAAIAJQAIAJAAAIQAAAVgXAVQgWAVgYgBQgKAAgGgIgAgRgOQgIAFgJAIIgGAEQgCACgDAAQgCALAAAMQAAAOALAAQAOAAAQgPQAPgQAAgOQAAgGgDgEQgDgEgFAAQgIAAgHADgAAjAmQAAgRAIgoIACgSQAAgHADgEQACgEAEAAQAFAAADACQADADAAADIgCAIIgJAlQgCAMAAAPQAAAHACAKIABACQAAACgEAEQgDACgDAAQgKAAAAgRg");
	this.shape_269.setTransform(688.725,236.55);

	this.shape_270 = new cjs.Shape();
	this.shape_270.graphics.f("#232323").s().p("AhNA8QgBgBAAAAQAAgBgBAAQAAgBAAgBQAAAAAAgBIABgFQAIgKAHgMIAPgiQAKgYACgPQACgHAIAAQAFAAABACQACABACAFQACAEAAAEIADATIADASIAFAVQADANACAAQABAAADgGIAIgTIAFgKIALgWIAOgbIAHgLQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQAEAAAFACQAEACAAACIABAVIACAeIABAYQACAKACAGQAFAKAAAGQAAAEgEACIgHACQgHAAgDgLQgEgLgCgzQAAgPgCgEQgIANgOAdIgGANIgFAJQgKAYgHAAQgFAAgDgBQgDgCgDgGQgCgHgFgYIgIghIgMAcQgIAUgHANQgHANgDADQgEACgDAAQgDAAgCgCg");
	this.shape_270.setTransform(672.125,236.775);

	this.shape_271 = new cjs.Shape();
	this.shape_271.graphics.f("#232323").s().p("AAZAtQgFgLAAgSQgOASgMAJQgNAJgMAAQgHAAgFgGQgGgHAAgJQAAgaAXgdQAXgdAWgBQAIAAAEAKQAAABABAAQAAABABAAQAAABABAAQAAAAABAAQAIAAAAAGIgBAIQgGAcAAAMQAAAXAJAGQAFACAAADQAAADgFADQgEADgEAAQgHABgFgLgAgPgOQgRAXAAAPQAAAMAHAAQALAAASgVQATgVAAgTQAAgOgJABQgNAAgQAYg");
	this.shape_271.setTransform(657.675,236.95);

	this.shape_272 = new cjs.Shape();
	this.shape_272.graphics.f("#232323").s().p("AAXAIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAIgWABQgOABgFABIgHAEQgCABgBAGIgBANIAAAMQABAKgKAAQgIAAAAgKQAAgHACgLQADgSADgvIABgIIAEgDQACgDAEAAQAHABAAAFIgCAPQgDANAAAJQABAEAEABIAagDQATgDABgBIAEgZQABgRAKAAQAHAAABAHIgBAIQgIAgAAAUQAAAWAIAHQADAEAAACQAAACgDADQgFACgDAAQgPAAAAgvg");
	this.shape_272.setTransform(646.2,236.95);

	this.shape_273 = new cjs.Shape();
	this.shape_273.graphics.f("#232323").s().p("AAZAtQgFgKAAgTQgOASgMAJQgNAJgMAAQgHAAgFgGQgGgGAAgLQAAgZAXgdQAXgdAWAAQAIAAAEAJQABADADAAQAIAAAAAGIgBAJQgGAbAAAMQAAAXAJAFQAFACAAAEQAAADgFAEQgEACgEAAQgHAAgFgKgAgPgPQgRAYAAAQQAAALAHAAQALAAASgWQATgVAAgRQAAgPgJAAQgNAAgQAYg");
	this.shape_273.setTransform(916.075,200.1);

	this.shape_274 = new cjs.Shape();
	this.shape_274.graphics.f("#232323").s().p("AgoBMQgHgIAAgMQAAgXAKgQQAJgRANgKQAMgKAUgHIAJgDQABAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQgEgQgFgGQgFgFgIgEQgIgDgHAAIgIACIgIADQgEADgCAAQgFAAAAgEQABgFAGgHQAHgHAPAAIAFAAQAPAAAMAIQAMAJAFAPQAFAPAAAaQAAASgLAZQgLAZgSANQgQANgTAAQgIAAgFgIgAgCAAQgcAZABAfQgBAEACAEQACAEABAAQAHAAAHgDQAFgCAIgJQAJgHAHgNQAHgMADgKIAEgQIAAgKQgXAEgLAKg");
	this.shape_274.setTransform(905.55,197.35);

	this.shape_275 = new cjs.Shape();
	this.shape_275.graphics.f("#232323").s().p("AgkBFQgPgKAAgHIABgGQABgBAAAAQABgBAAAAQABgBAAAAQABAAAAAAIADACQANATAaABQAQgBAJgUQAIgVACgfQgPANgOAHQgOAJgJAAQgIAAgFgJQgGgHAAgKQAAgRAGgWQAHgXADgDQADgDAGAAQADAAABAEQACADAAAEQAAACgDAEQgNAWABAXQgBAGADAEQACADAEAAQAGAAAHgCQAHgDAKgIQAKgHAEgFQADgEABgGQACgGAAgUQABgTAIAAQAGAAABADQACADAAAHIgCAaIgBAIQgCAzgNAdQgMAegYAAQgUAAgOgKg");
	this.shape_275.setTransform(893.35,202.7);

	this.shape_276 = new cjs.Shape();
	this.shape_276.graphics.f("#232323").s().p("AgwA4QgDgCAAgDIADgRQAFgXAFg2QAAgGAEgEQADgEAFAAQACAAACADQACACAAAFIgCAIQgFAUgBAUQAXgDARgaQAJgMAGgFQAHgFAHAAQADAAADADQADACAAAEQAAAFgJACQgFACgEADQgFAEgLANQgJAKgHAEIAAAAIAAABQAHAEAIALQALAQAGAEQAGAEAHAAIADAAQABAAABAAQAAAAABABQAAAAABABQAAAAAAABQAAAEgFAEQgEAEgJAAQgIAAgHgHQgHgGgJgOQgEgJgEgEQgFgFgFAAIgIACQgGACAAACQgBACAAALIgBASQAAAEgDACQgEADgEAAQgEAAgCgCg");
	this.shape_276.setTransform(882.725,199.975);

	this.shape_277 = new cjs.Shape();
	this.shape_277.graphics.f("#232323").s().p("AgWAXQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAAAQASgFAEgHQAGgJAAgDQAAgJgDgEIgBgEIABgEQAAgBABgBQAAAAAAAAQABgBAAAAQAAAAABAAIAGACIAFACIADAIQACAFAAAFIgEAJQgEAJgGAFQgGAEgFABIgEABQgIAEgFAAQgDAAAAgFg");
	this.shape_277.setTransform(865.325,204.95);

	this.shape_278 = new cjs.Shape();
	this.shape_278.graphics.f("#232323").s().p("AAZBEQgEgKAAgUIAAgEIAAgDQgNAVgMAMQgNALgLAAQgHAAgGgHQgHgIAAgPQAAgNAGgZQAFgUAAgIQADgGAGAAQAEAAADADQACADAAADQAAAHgFALQgJAZAAARQAAAQAIAAQAJAAAPgQQANgQALgcQAEgLADgEQACgDAFAAQAGAAAAAJIgCAHQgFAUAAATQAAAXAHAHQAEADAAADQAAACgEADQgEACgDAAQgHAAgEgKgAgCgoIgKgEQgEgCgEgDQgDgEgCgEIgCgCIgBgEIgBgDIAAgBIABgEIACgDIACgCIACAAQADAAACABQABABAAAAQABAAAAABQAAAAAAABQAAAAAAABIACAIIAEAHIAIAEQAEACAGAAIAEAAIAEgBIAEgBIAEgCIAEgEIADgEIACgFIABgEIADgFIAEgBQADAAACACQACACAAAFIgBAEIgDAGIgEAHIgGAFIgGADIgHACIgHACIgHAAIgKgBg");
	this.shape_278.setTransform(855.575,197.825);

	this.shape_279 = new cjs.Shape();
	this.shape_279.graphics.f("#232323").s().p("AAaArQgEgKAAgUIAAgEIAAgCQgNAUgLAMQgNAMgMAAQgHAAgGgIQgHgHAAgQQAAgNAGgYQAGgVAAgIQACgGAHAAQADAAADADQACADABADQAAAHgGAMQgIAYgBASQAAAPAIABQAJgBAPgPQANgQALgcQAEgMADgEQACgDAFAAQAGAAABAJIgCAHQgGAWAAARQAAAYAIAGQADADAAADQAAADgDACQgEACgEAAQgHAAgEgKg");
	this.shape_279.setTransform(843.25,200.3);

	this.shape_280 = new cjs.Shape();
	this.shape_280.graphics.f("#232323").s().p("AgwA4QgDgCAAgDIADgRQAFgXAFg2QAAgGAEgEQADgEAFAAQACAAACADQACACAAAFIgCAIQgFAUgBAUQAXgDARgaQAJgMAGgFQAHgFAHAAQADAAADADQADACAAAEQAAAFgJACQgFACgEADQgFAEgLANQgJAKgHAEIAAAAIAAABQAHAEAIALQALAQAGAEQAGAEAHAAIADAAQABAAABAAQAAAAABABQAAAAABABQAAAAAAABQAAAEgFAEQgEAEgJAAQgIAAgHgHQgHgGgJgOQgEgJgEgEQgFgFgFAAIgIACQgGACAAACQgBACAAALIgBASQAAAEgDACQgEADgEAAQgEAAgCgCg");
	this.shape_280.setTransform(832.025,199.975);

	this.shape_281 = new cjs.Shape();
	this.shape_281.graphics.f("#232323").s().p("AgnAwQgGgIAAgQQAAgSAEgUIAIgcIABgHQABgEAJgCIADgBQACABACAGQAAAEgCAHQgHASAAAIQAAAAAAAAQAAABAAAAQABAAAAAAQAAAAAAAAQAXgVASAAQAMAAAIAJQAIAJAAAIQAAAVgXAVQgXAUgXABQgLAAgFgJgAABgNQgHADgJAJIgGAEQgCACgDABQgCALAAAKQgBAPAMAAQANAAAPgQQAQgPABgOQAAgGgDgEQgEgEgFAAQgIAAgHAEg");
	this.shape_281.setTransform(820.65,199.7);

	this.shape_282 = new cjs.Shape();
	this.shape_282.graphics.f("#232323").s().p("AAXAIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAAAAAIgWABQgOABgFACIgHADQgCABgBAHIgBAMIAAAMQAAALgJAAQgIAAAAgLQAAgHACgKQADgUADguIABgIIAEgEQADgBADAAQAHgBAAAHIgCAOQgCAOAAAIQAAAEADAAIAagCQAUgDABgBIAEgYQABgSAKAAQAHAAABAIIgBAHQgJAgABATQgBAYAJAGQADADAAADQAAADgDACQgFACgDAAQgPAAAAgvg");
	this.shape_282.setTransform(809.2,200.1);

	this.shape_283 = new cjs.Shape();
	this.shape_283.graphics.f("#232323").s().p("AgiAvQgIgJAAgQQAAgbASgaQATgZAWAAQAHAAAFAFQAEAFAAAHQAAAPgPANQgOANgYANQgFADAAAEQAAAIAFAFQAEAFAJAAQAUAAAWgXQAEgDABAAQADAAAAAFQAAAKgRAOQgSAOgSAAQgPAAgJgKgAgIgcQgLANgFASQApgXAAgPQAAgGgFAAQgJAAgLANg");
	this.shape_283.setTransform(798.025,200.025);

	this.shape_284 = new cjs.Shape();
	this.shape_284.graphics.f("#232323").s().p("AAXAIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAIgVABQgNABgGACIgHADQgCABAAAHIgBAMIAAAMQAAALgKAAQgIAAAAgLQAAgHACgKQADgUADguIACgIIADgEQADgBADAAQAHgBAAAHIgCAOQgCAOgBAIQABAEADAAIAagCQAUgDABgBIADgYQACgSAJAAQAJAAgBAIIgBAHQgHAggBATQAAAYAIAGQAEADAAADQAAADgEACQgEACgDAAQgPAAAAgvg");
	this.shape_284.setTransform(787.1,200.1);

	this.shape_285 = new cjs.Shape();
	this.shape_285.graphics.f("#232323").s().p("AAXAIQAAgBAAAAQAAgBgBAAQAAgBAAAAQgBAAgBAAIgVABQgNABgGACIgHADQgCABAAAHIgBAMIAAAMQAAALgKAAQgIAAAAgLQAAgHACgKQADgUADguIACgIIADgEQADgBADAAQAHgBAAAHIgCAOQgCAOgBAIQAAAEAEAAIAagCQAUgDABgBIADgYQACgSAJAAQAJAAgBAIIgBAHQgHAggBATQABAYAHAGQAEADAAADQAAADgEACQgEACgDAAQgPAAAAgvg");
	this.shape_285.setTransform(775.4,200.1);

	this.shape_286 = new cjs.Shape();
	this.shape_286.graphics.f("#232323").s().p("AAZAtQgFgKAAgTQgOASgMAJQgNAJgMAAQgHAAgFgGQgGgGAAgLQAAgZAXgdQAXgdAWAAQAIAAAEAJQABADADAAQAIAAAAAGIgBAJQgGAbAAAMQAAAXAJAFQAFACAAAEQAAADgFAEQgEACgEAAQgHAAgFgKgAgPgPQgRAYAAAQQAAALAHAAQALAAASgWQATgVAAgRQAAgPgJAAQgNAAgQAYg");
	this.shape_286.setTransform(763.475,200.1);

	this.shape_287 = new cjs.Shape();
	this.shape_287.graphics.f("#232323").s().p("Ag3BWQgEgDAAgCQAAgGADgJQARhHAAg3IAAgHQAAgLAEgFQAEgFAFAAQACAAADAEQACADAAAHQAAAKgCANIgDAUQAPgZAPgPQAQgOAOAAQAKAAAHAHQAHAIAAAKQAAAhgZAaQgYAYgWAAQgGAAgDgDQgEgCgDgJQgFATgEAfIgDATQgBADgDAFQgDADgCAAQgDAAgEgDgAgBgqQgUAaAAAOQAAADAEADQAEADAGAAQANAAASgTQASgVAAgUQAAgHgDgEQgCgEgFAAQgOAAgTAag");
	this.shape_287.setTransform(750.675,203.1);

	this.shape_288 = new cjs.Shape();
	this.shape_288.graphics.f("#232323").s().p("AhcAbQAAgOAHglIACgVQAAgHAGAAQALAAAAAQQAAAHgDAVQgFAYAAAGQAGgHAMgSQAQgbAJgIQAHgHAJAAQAGAAAEAIQADAJABAfIABAMIACADQAEAAAPgdQAJgRAIgJQAHgIAKAAQAHAAAEAIQADAIADAQQABAPADAOQADANAIAEQAFADABADQgBADgEAEQgEAEgFAAQgIAAgFgJQgGgLgEgeQgBgNgBgFQgCgFgDgBQgDAAgGAIQgGAIgNAXQgJATgFAGQgFAGgEAAQgEAAgEgDQgDgEgBgFIgBgXQgCgdgEgGQgJAAgdA1IgMAUQgCABgEACIgIABQgHAAAAgag");
	this.shape_288.setTransform(734.95,199.95);

	this.shape_289 = new cjs.Shape();
	this.shape_289.graphics.f("#232323").s().p("AggAxQgIgJAAgPQAAgZAUgcQAUgcAQAAQAIAAAHAJQAFAIAAAKQAAAGgDADQgCAFgCAAQgHAAgBgMQgDgMgFAAQgKAAgNAYQgOAXAAARQAAARATAAQANAAATgOQAHgEAEAAQAAAAABAAQABAAAAAAQABABAAAAQAAABAAABQAAAHgSAMQgRALgQAAQgPAAgHgIg");
	this.shape_289.setTransform(719,200.05);

	this.shape_290 = new cjs.Shape();
	this.shape_290.graphics.f("#232323").s().p("AgWAXIABgCQASgFAEgHQAGgJAAgDQAAgJgDgEIgBgEIABgEQAAgBABgBQAAAAAAAAQABgBAAAAQAAAAABAAIAGACIAFACIADAIQACAFAAAFIgEAJQgEAJgGAFQgGAEgFABIgEABQgIAEgFAAQgDAAAAgFg");
	this.shape_290.setTransform(702.775,204.95);

	this.shape_291 = new cjs.Shape();
	this.shape_291.graphics.f("#232323").s().p("AAZAtQgFgKAAgTQgOASgMAJQgNAJgMAAQgHAAgFgGQgGgGAAgLQAAgZAXgdQAXgdAWAAQAIAAAEAJQABADADAAQAIAAAAAGIgBAJQgGAbAAAMQAAAXAJAFQAFACAAAEQAAADgFAEQgEACgEAAQgHAAgFgKgAgPgPQgRAYAAAQQAAALAHAAQALAAASgWQATgVAAgRQAAgPgJAAQgNAAgQAYg");
	this.shape_291.setTransform(693.275,200.1);

	this.shape_292 = new cjs.Shape();
	this.shape_292.graphics.f("#232323").s().p("AgjBLQgKgNAAgaQAAgeALgeQALgfAQgQQAPgQAQAAQAKAAAGAHQAGAGAAAMQAAAJgIAMQgIANgNALQAWAJAAAhQAAAZgPATQgQATgSAAQgQAAgJgNgAgRAKIgKAHQgBAJAAAKQAAASAFAJQAGAJAJAAQAMAAAJgOQAIgOAAgQQAAgPgFgJQgFgIgHAAQgCAAgTAOgAgEg0QgNATgHAhQAkgcAJgMQAJgNAAgHQAAgLgJAAQgNAAgMATg");
	this.shape_292.setTransform(682.775,197.025);

	this.shape_293 = new cjs.Shape();
	this.shape_293.graphics.f("#232323").s().p("AglAsQgJgKAAgPQABgYARgYQARgZAWAAQAQAAAJAMQAKAMAAARQABAYgVAWQgUAWgVAAQgNAAgJgLgAgRgTQgLATAAARQAAAKAEAGQAEAGAHAAQAOAAAPgQQAOgQAAgSQAAgMgFgIQgHgHgJAAQgOAAgMATg");
	this.shape_293.setTransform(671.55,200.225);

	this.shape_294 = new cjs.Shape();
	this.shape_294.graphics.f("#232323").s().p("Ag3BWQgEgDAAgCQAAgGADgJQARhHAAg3IAAgHQAAgLAEgFQAEgFAFAAQACAAADAEQACADAAAHQAAAKgCANIgDAUQAPgZAPgPQAQgOAOAAQAKAAAHAHQAHAIAAAKQAAAhgZAaQgYAYgWAAQgGAAgDgDQgEgCgDgJQgFATgEAfIgDATQgBADgDAFQgDADgCAAQgDAAgEgDgAgBgqQgUAaAAAOQAAADAEADQAEADAGAAQANAAASgTQASgVAAgUQAAgHgDgEQgCgEgFAAQgOAAgTAag");
	this.shape_294.setTransform(658.925,203.1);

	this.shape_295 = new cjs.Shape();
	this.shape_295.graphics.f("#232323").s().p("AAZAtQgFgKAAgTQgOASgMAJQgNAJgMAAQgHAAgFgGQgGgGAAgLQAAgZAXgdQAXgdAWAAQAIAAAEAJQABADADAAQAIAAAAAGIgBAJQgGAbAAAMQAAAXAJAFQAFACAAAEQAAADgFAEQgEACgEAAQgHAAgFgKgAgPgPQgRAYAAAQQAAALAHAAQALAAASgWQATgVAAgRQAAgPgJAAQgNAAgQAYg");
	this.shape_295.setTransform(647.075,200.1);

	this.shape_296 = new cjs.Shape();
	this.shape_296.graphics.f("#232323").s().p("AgoBMQgHgIAAgMQAAgXAKgQQAJgRANgKQAMgKAUgHIAJgDQABAAABgBQAAAAAAgBQABAAAAgBQAAAAAAgBQgEgQgFgGQgFgFgIgEQgIgDgHAAIgIACIgHADQgFADgCAAQgFAAAAgEQAAgFAHgHQAGgHARAAIADAAQAPAAANAIQAMAJAFAPQAFAPAAAaQAAASgLAZQgLAZgSANQgQANgUAAQgGAAgGgIgAgCAAQgcAZABAfQgBAEACAEQACAEABAAQAHAAAHgDQAFgCAIgJQAJgHAHgNQAHgMADgKIAEgQIAAgKQgXAEgLAKg");
	this.shape_296.setTransform(636.55,197.35);

	this.shape_297 = new cjs.Shape();
	this.shape_297.graphics.f("#232323").s().p("AgfAzQgKgGAAgHQAAgGAHAAIADACQAKAJAPAAQAMAAAKgHQAJgGAAgMQAAgHgGgFQgFgEgHgBQgFAAgMAFIgGAAQgGAAAAgGQAAgDADgBQADgCAIgDQAbgGAAgQQABgFgEgDQgDgDgGAAQgJAAgLAJQgIAFgDAAQgGAAAAgGQAAgHAOgHQAOgIALAAQAOAAAGAHQAIAHAAAGQAAATgWAJQANACAHAGQAHAIAAAKQAAARgOALQgOALgWAAQgNAAgKgGg");
	this.shape_297.setTransform(625.65,200.05);

	this.shape_298 = new cjs.Shape();
	this.shape_298.graphics.f().s("#FFFFFF").ss(3,1,1).p("AlekNQBxioFsgMQCKgFCKgBAkvDiQhIhggUiGQgRhrAZhRADAHIQj1gaiQhm");
	this.shape_298.setTransform(609.4432,214.9);

	this.shape_299 = new cjs.Shape();
	this.shape_299.graphics.f().s("#232323").ss(4,1,1).p("AnigZQAaABAZAAAjcgSQC9AIC7ANQCqANCdAK");
	this.shape_299.setTransform(722.8875,171.9625);

	this.shape_300 = new cjs.Shape();
	this.shape_300.graphics.f("#232323").s().p("AC4HxQgPgBgKgHQgNgHADgMQJBAbI7ggQBugGA7gLQBagRBkguQBKgiBog+IACgBQAtgbAXgTQAkgeAQgiQALgXAEghQADgUABgmQABgvgCgXQgCgogKgdQgJgcgUgdQgQgZgZgaQgqgsgxgiQhwhMizgoQgigIgSgIQgcgMgLgVIuEgJQg9AAghgFQgzgJgjgXQDWAHDZADQEgAFEmgBQAkAAARAEQANADAQAIIAOAHIAOAHQAmASA/ARIBnAdQBVAcBKA1QAtAgAnAoQAXAYAVAbQAcAlAKAbQAJAbACA5QAEBUgIAwQgLBJgmAtQgOASgXARIgrAeQhnBDgyAZQg0AahZAfQhcAgg2AKQgwAIhkAEIgwACQktAKjHAAQktAAj4gUgA0nGAQhZgPgqgKQhHgSg0gcIgzgcQgegPgYgDIgQgCIgZgCQgYgCgNgLQgIgHgMgVQgLgUgKgGQgMgIgWABIglABQgggEgbgeQgTgUgVgpQgRgjgHgTQgLgeAAgaQAAgXAMgsQAPg2AJgaQAQgsAUgfQAWgjA7g6IABgCQAhggAQgOQAdgaAbgOQAXgMAbgKQB1gqCYgRQBmgLCugEQCxgDCxABIA0ABICcABIADAEQABADAAAEQgBAHgFAEQgIAGgQgBQmJgDl8AaQh1AIhEANQhlAThIApQhCAlgyA7QgOAQgLAQQggAugUA0QgKAcgPA6QgKAoAAAUQAAAYALAeQAHATARAgQALAUAGAIQALAPAMAIQARAKAyAEQAQABANADQAUAGAKAMQAFAFAJARQAHAPAHAGQALAJAVABIAjACQASACAVAJIAkASQCTBPCpAOQAFAFgDAIQgCAIgHADQgFADgJAAIgOgBg");
	this.shape_300.setTransform(759.1807,221.1774);

	this.shape_301 = new cjs.Shape();
	this.shape_301.graphics.f("#FFFFFF").s().p("AFPINQp0gcqigrQjQgOiXg0Qj1gaiQhmIAQABQAYADAeAPIAzAcQA0AcBHASQAqAKBZAPQAUADAIgFQAHgDACgIQADgIgFgFQipgOiThPIgkgSQgVgJgSgCIgjgCQgVgBgLgJQgHgGgHgPQgJgRgFgFQgKgMgUgFQhJhhgUiGQgQhrAZhRQALgQAOgQQAyg7BCglQBIgpBlgTQBEgNB1gIQF8gaGJADQAQABAIgGQAFgEABgHQAAgEgBgDQC9AIC8AOQCqANCcAKQh0gKh/gNQlmgklsAHIAzABQixgBixADQiuAEhmALQiYARh1AqQgbAKgXAMQgbAOgdAaQgRAOggAgQByioFtgMQCKgFCJgBIADAAIAIAAQKvgVKhAvQEDASDqAMQjZgDjWgHQAjAXAzAJQAhAFA9AAIOEAJQALAVAcAMQASAIAiAIQCzAoBwBMQAxAiAqAsQAZAaAQAZQALA1gCA+QgFC7hlB2IgCABQhoA+hKAiQhkAuhaARQg7ALhuAGQo7AgpBgbQgDAMANAHQAKAHAPABQD4AUEtAAQDHAAEtgKQkMAfk2AAQiRAAiagHgAcMkiQhKg1hVgcIhngdQg/gRgmgSIgOgHIADAAQFrAHBfDZQgngngtghg");
	this.shape_301.setTransform(761.2905,221.7574);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_253},{t:this.shape_252},{t:this.shape_251}]},822).to({state:[]},33).to({state:[{t:this.shape_301},{t:this.shape_300},{t:this.shape_299},{t:this.shape_298},{t:this.shape_297},{t:this.shape_296},{t:this.shape_295},{t:this.shape_294},{t:this.shape_293},{t:this.shape_292},{t:this.shape_291},{t:this.shape_290},{t:this.shape_289},{t:this.shape_288},{t:this.shape_287},{t:this.shape_286},{t:this.shape_285},{t:this.shape_284},{t:this.shape_283},{t:this.shape_282},{t:this.shape_281},{t:this.shape_280},{t:this.shape_279},{t:this.shape_278},{t:this.shape_277},{t:this.shape_276},{t:this.shape_275},{t:this.shape_274},{t:this.shape_273},{t:this.shape_272},{t:this.shape_271},{t:this.shape_270},{t:this.shape_269},{t:this.shape_268},{t:this.shape_267},{t:this.shape_266},{t:this.shape_265},{t:this.shape_264},{t:this.shape_263},{t:this.shape_262},{t:this.shape_261},{t:this.shape_260},{t:this.shape_259},{t:this.shape_258},{t:this.shape_257},{t:this.shape_256},{t:this.shape_255},{t:this.shape_254}]},50).to({state:[]},19).to({state:[]},347).wait(37));

	// Слой_118___копия
	this.shape_302 = new cjs.Shape();
	this.shape_302.graphics.f("#232323").s().p("AiADsQgKgJAAgPQAAgMAUgNIAHgFQAGgGALAAQAIAAANALQAXAAAAATQAAAQgTAMQgTALgPAAQgOAAgLgJgAhfBgQgCgMAAgGQAAgWAYgwIAEgIQAVgTBAgYIAmgOQASgHAKgTQAJgTAAgRQAAgLgGgZQgGgZgTgIQgTgHgRAAQglAAgRALQgRAKgCANQgDAOgRAFIgSACQgRAAAAgTQgBgZAmgeQAngdAYAAIArgBQAegBASAMQAUAMAQASQAQATAAA1QAAAvgRAbQgQAbgbAOQgbANhTAbQgLAcgGAgQgEAPgJAFQgKAFgUAAQgCAAgCgNg");
	this.shape_302.setTransform(583.3,130.2212);

	this.shape_303 = new cjs.Shape();
	this.shape_303.graphics.f().s("#232323").ss(4,1,1).p("AQHgsQhqFVkiDRQkiDRmYAAQmaAAkijRQkijRAAknQAAkmEijRQEijRGkgEQGjgFGBCnQGBCmhpFWg");
	this.shape_303.setTransform(585.6096,135.9177);

	this.shape_304 = new cjs.Shape();
	this.shape_304.graphics.f("#FFFFFF").s().p("Ar7H6QkijRAAknQAAkmEijRQEijRGkgEQGjgFGBCnQGBCmhpFWQhqFVkiDRQkiDRmYAAQmaAAkijRg");
	this.shape_304.setTransform(585.6096,135.9177);

	this.shape_305 = new cjs.Shape();
	this.shape_305.graphics.f("#232323").s().p("AiSBVIABgQIAEgcQAFgfAEhAIACgaQABgFAGgFQAGgFAHAAQANAAAAALIgFAbQgEAaAAAOQAAAKAHAAQAPAAAjgDQAigDAAgDIABgBIACgDQAPgoAZgVQAZgWAdAAQAdAAASAWQASAWAAAfQAAAuglAoQglAogoAAQgZAAgPgSQgQgTAAgcIgBgHIAAgIQAAgBgBAAQAAAAgBAAQAAgBgBAAQAAAAgBAAIgfAAQgSAAgMADQgNACgCACQgDACgBAIIgEARQgBAGAAAHIAAAPQAAAIgEAJQgEAJgKAAQgPAAAAgTgAAcgnQgUAkAAAfQAAATAHALQAIAMANAAQAaAAAcgeQAbgdAAgjQAAgXgLgNQgKgOgSAAQgdAAgVAjg");
	this.shape_305.setTransform(1418.525,169.825);

	this.shape_306 = new cjs.Shape();
	this.shape_306.graphics.f("#232323").s().p("AAvBTQgJgTAAgkQgaAjgYARQgZAQgUABQgOAAgKgMQgKgMAAgSQAAgwAqg1QArg3AoAAQAQAAAHARQADAGAFgBQAOAAAAAMIgCAPQgJA0AAAXQAAArAQAJQAIAEAAAHQAAAFgHAGQgJAGgHgBQgOABgIgUgAgcgbQggArAAAeQAAAUAOAAQAUAAAignQAjgnAAgiQABgagSAAQgXAAgfAtg");
	this.shape_306.setTransform(1390.5,170.15);

	this.shape_307 = new cjs.Shape();
	this.shape_307.graphics.f("#232323").s().p("AAqAPQAAgGgEAAQgSAAgXACQgYACgLAEQgKADgDACQgDACgCAMQgBALAAANIAAAVQAAAUgSAAQgPAAAAgUQAAgMAEgTQAGgkAFhXQABgMABgDQABgDAGgDQAGgEAFAAQAOAAAAALIgFAbQgEAaAAAOQAAAJAHABQAOgBAjgEQAlgFABgDQACgDAEgqQADghASAAQAPAAAAAOIgCAPQgOA5gBAmQABAqAOANQAHAHAAAEQAAAFgHAEQgIAEgGAAQgcAAAAhXg");
	this.shape_307.setTransform(1369.25,170.15);

	this.shape_308 = new cjs.Shape();
	this.shape_308.graphics.f("#232323").s().p("Ag6BeQgSgKAAgNQAAgLAMAAQACAAAEADQATARAbAAQAYAAARgNQARgNAAgTQAAgOgKgJQgJgJgNAAQgKAAgYAIQgFABgFAAQgLAAAAgNQgBgFAGgDQAFgDARgEQAygMAAgeQAAgJgGgGQgGgFgKgBQgTAAgVARQgMAJgHAAQgKABgBgKQABgOAZgOQAZgOAXgBQAYAAANANQANAMABAOQgBAhgnASQAWAEAOAMQANAOgBAUQAAAegZAUQgaAUgpABQgZAAgSgMg");
	this.shape_308.setTransform(1348.55,170.05);

	this.shape_309 = new cjs.Shape();
	this.shape_309.graphics.f("#232323").s().p("AhDCAQgcgTAAgMQAAgGADgHQACgFAFAAQACAAACADQAYAlAxgBQAfABAPgmQAQgnAEg7QgcAZgbAOQgbAQgOgBQgRAAgKgOQgKgPAAgTQAAgfAMgpQALgqAGgGQAHgGAKABQAFgBADAHQADAGAAAHQAAAFgEAHQgYApAAAsQAAAJAEAJQAEAGAIAAQAKAAAOgFQAOgGASgNQASgOAHgJQAGgIADgLQACgLABgkQABgkARAAQAJgBADAGQADAFAAAOIgDAwIgBAOQgFBggYA2QgXA3gtAAQgjAAgbgSg");
	this.shape_309.setTransform(1328.275,175);

	this.shape_310 = new cjs.Shape();
	this.shape_310.graphics.f("#232323").s().p("AAuBTQgJgTAAgkQgZAjgYARQgYAQgVABQgOAAgKgMQgKgMAAgSQAAgwAqg1QAqg3AqAAQAPAAAHARQADAGAFgBQAOAAAAAMIgCAPQgKA0AAAXQAAArARAJQAIAEAAAHQAAAFgIAGQgHAGgHgBQgPABgJgUgAgcgbQggArAAAeQAAAUAOAAQAUAAAignQAkgnAAgiQAAgagRAAQgZAAgeAtg");
	this.shape_310.setTransform(1292.7,170.15);

	this.shape_311 = new cjs.Shape();
	this.shape_311.graphics.f("#232323").s().p("ABvCAQAAgDAJgaQAIgXAAgIQAAgIgDAAIgIAEIgKADQgJAAgEgGQgEgGAAgRQAAgRALgtIAAgFQgZAogaAZQgaAYgVAAQgLAAgMgOQgMgOAAgdQAAgOADgVQgXAngZAYQgaAWgUAAQgKAAgNgLQgMgMABgVQAAgWABgMIADgWIACgRQAIgngCgLQAEgNANAAQAGAAAFAFQAGAEAAAKQgBARgHAZQgKAhAAAaQAAANACAIQACAIAHAAQAUAAAeglQAegmAVg2QAIgVANAAQAHAAAFAFQAFAFAAAGQgBANgIAXQgQAtAAAfQAAAdAMAAQAGAAAJgEQAIgEAMgLQAMgLAMgRIARgaQAEgKAOgqQAIgWAEgHQAFgHAJAAIAEAAQAGAAAEADQAEACAAAOQAAAIgHAZQgOAxgDA+QAAAFADAAIACAAQAIgFAIAAQANAAACANIAAAMQAAAOgEAMIgHATIgDAFQgLAZgMABIgFABQgFAAAAgFg");
	this.shape_311.setTransform(1265.75,173.875);

	this.shape_312 = new cjs.Shape();
	this.shape_312.graphics.f().s("#232323").ss(4,1,1).p("AYXgVQgJF8mVBOQmWBNoZgZQoYgapBgoQpBgphAmpQhAmpJMgUQJLgTI/AsQJAArGtAJQGsAJgIF9g");
	this.shape_312.setTransform(1341.1145,173.282);

	this.shape_313 = new cjs.Shape();
	this.shape_313.graphics.f("#FFFFFF").s().p("AE9INQtKgcuHgrQuIgshlnIQhlnKOagUQOZgVOGAvQOGAuKgAKQKgAKgOGZQgOGYp7BUQnfA/pVAAQjCAAjPgHgAHKHvQF6AAEwg5IAFgBQGVhOAJl8QgJF8mVBOIgFABQkwA5l6AAIAAAAIAAAAQh6AAiAgGIgGAAQoYgapBgoQpBgphAmpQgGgqAAgmQAAlbISgSIAGAAQCxgGCwAAIABAAIAAAAQFyAAFsAaIALABIACAAIAIAAIAQACIAUABIALABQJAArGtAJQGkAJAAFvIAAAOIAAgOQAAlvmkgJQmtgJpAgrIgLgBIgUgBIgQgCIgIAAIgCAAIgLgBQlsgalyAAIAAAAIgBAAQiwAAixAGIgGAAQoSASAAFbQAAAmAGAqQBAGpJBApQJBAoIYAaIAGAAQCAAGB6AAIAAAAIAAAAg");
	this.shape_313.setTransform(1341.1145,173.2571);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_304},{t:this.shape_303},{t:this.shape_302}]},806).to({state:[]},33).to({state:[{t:this.shape_313},{t:this.shape_312},{t:this.shape_311},{t:this.shape_310},{t:this.shape_309},{t:this.shape_308},{t:this.shape_307},{t:this.shape_306},{t:this.shape_305}]},50).to({state:[]},16).to({state:[]},347).wait(56));

	// Слой_118
	this.shape_314 = new cjs.Shape();
	this.shape_314.graphics.f("#232323").s().p("AiADsQgKgJAAgPQAAgMAUgNIAHgFQAGgGALAAQAIAAANALQAXAAAAATQAAAQgTAMQgTALgPAAQgOAAgLgJgAhfBgQgCgMAAgGQAAgWAYgwIAEgIQAVgTBAgYIAmgOQASgHAKgTQAJgTAAgRQAAgLgGgZQgGgZgTgIQgTgHgRAAQglAAgRALQgRAKgCANQgDAOgRAFIgSACQgRAAAAgTQgBgZAmgeQAngdAYAAIArgBQAegBASAMQAUAMAQASQAQATAAA1QAAAvgRAbQgQAbgbAOQgbANhTAbQgLAcgGAgQgEAPgJAFQgKAFgUAAQgCAAgCgNg");
	this.shape_314.setTransform(583.3,130.2212);

	this.shape_315 = new cjs.Shape();
	this.shape_315.graphics.f().s("#232323").ss(4,1,1).p("AQHgsQhqFVkiDRQkiDRmYAAQmaAAkijRQkijRAAknQAAkmEijRQEijRGkgEQGjgFGBCnQGBCmhpFWg");
	this.shape_315.setTransform(585.6096,135.9177);

	this.shape_316 = new cjs.Shape();
	this.shape_316.graphics.f("#FFFFFF").s().p("Ar7H6QkijRAAknQAAkmEijRQEijRGkgEQGjgFGBCnQGBCmhpFWQhqFVkiDRQkiDRmYAAQmaAAkijRg");
	this.shape_316.setTransform(585.6096,135.9177);

	this.shape_317 = new cjs.Shape();
	this.shape_317.graphics.f("#232323").s().p("Ag/BYQgQgRAAgfQAAgzAjguQAjgvAoAAQANAAAJAJQAJAJAAAMQAAAcgcAZQgbAZgtAZQgJAEAAAIQAAAPAJAJQAIAJARAAQAmAAApgrQAGgGADAAQAFAAAAAKQAAASggAaQghAaghAAQgeAAgPgRgAgPg0QgVAYgIAiQBLgsAAgcQAAgLgJAAQgRAAgUAZg");
	this.shape_317.setTransform(917.925,98.325);

	this.shape_318 = new cjs.Shape();
	this.shape_318.graphics.f("#232323").s().p("AiqAzQAAgbALhEQAFgcAAgNQAAgMALAAQATAAAAAdQAAAOgGAoQgIAsAAAJQALgKAWgkQAfgyAOgOQAPgNAPAAQAMAAAHAPQAHAQACA6QAAAPACAIQACAHAAAAQAJAAAcg5QAQgfAOgQQAOgPARAAQAQAAAGAPQAGAPAEAdQADAdAFAZQAFAZAQAHQAKAFAAAHQAAAGgJAHQgIAGgIAAQgOAAgLgRQgMgSgFg6QgDgYgCgKQgCgJgGAAQgHAAgLAOQgKAOgXAsQgSAigKAMQgJALgIAAQgIAAgFgGQgHgGgBgJQgCgJgBgiQgEg4gGgKQgSABg2BiQgTAhgDADQgDADgIADQgJACgFAAQgMAAAAgvg");
	this.shape_318.setTransform(890.15,98.175);

	this.shape_319 = new cjs.Shape();
	this.shape_319.graphics.f("#232323").s().p("Ag/BYQgQgRAAgfQAAgzAjguQAjgvAoAAQANAAAJAJQAJAJAAAMQAAAcgcAZQgbAZgtAZQgJAEAAAIQAAAPAJAJQAIAJARAAQAmAAApgrQAGgGADAAQAFAAAAAKQAAASggAaQghAaghAAQgeAAgPgRgAgPg0QgVAYgIAiQBLgsAAgcQAAgLgJAAQgRAAgUAZg");
	this.shape_319.setTransform(860.625,98.325);

	this.shape_320 = new cjs.Shape();
	this.shape_320.graphics.f("#232323").s().p("AhaBoQgEgFAAgFQAAgGAFgZQAIgsAJhkQABgKAGgIQAHgHAIgBQAFAAADAGQADAFAAAHQAAAHgCAIQgKAlgDAmQArgGAhgwQAQgWAMgJQAMgJAOAAQAFgBAGAFQAFAFAAAHQAAAJgRAEQgJADgHAHQgIAGgWAZQgRATgMAHIgCABIACACQAMAGAPAVQAVAeALAHQAKAIAOAAIAGAAQAGgBAAAGQAAAHgHAIQgIAHgSAAQgOAAgNgMQgNgMgQgbQgJgPgIgIQgIgIgLAAIgNADQgLAEgBAEQgCACAAAWIgBAgQAAAHgGAGQgHAEgHAAQgIAAgEgDg");
	this.shape_320.setTransform(841.075,98.25);

	this.shape_321 = new cjs.Shape();
	this.shape_321.graphics.f("#232323").s().p("AAvBUQgKgUABgjQgaAhgYARQgZARgUAAQgOAAgKgLQgKgMAAgSQAAgwAqg2QAqg3AqAAQAPAAAHASQACAGAGAAQAOgBAAAMIgCAQQgKAzAAAXQAAArARAJQAIAEAAAHQAAAFgIAGQgHAFgIABQgNgBgJgSgAgcgbQggAsAAAdQAAAVAOAAQAUgBAigoQAkgnAAghQAAgagRAAQgZAAgeAtg");
	this.shape_321.setTransform(818.75,98.45);

	this.shape_322 = new cjs.Shape();
	this.shape_322.graphics.f("#232323").s().p("AhvBHQAAgJADgPQAKg2AAg8QAAgIAGgIQAGgIAFAAQAKAAADAGQAEAGAAARQAAASgKA4IgEAYQAAABAAAAQAAABABAAQAAABAAAAQAAAAAAAAQADAAAXgqQAWgsARgSQAQgSAVAAQAQAAAKAPQAKAOAFAoQAFAsAEALQAEALAJgBQAGAAAIgDIACgBQAIAAAAAJQAAAIgLAIQgKAJgPAAQgQAAgIgMQgIgMgFg1QgFg0gRAAQgJAAgKAMQgLAMgXAqQgeA6gJAIQgJAIgFAAQgWAAAAgVg");
	this.shape_322.setTransform(796.325,98.9);

	this.shape_323 = new cjs.Shape();
	this.shape_323.graphics.f("#232323").s().p("AhDCKQgQgYgBguQAAg5AUg4QAUg6AegdQAcgdAegBQASAAAMAMQAKAMABAWQAAARgPAXQgPAYgYAUQApARAAA9QAAAvgdAiQgdAkghgBQgfAAgRgYgAggATIgSAOQgDAPAAATQAAAgAKASQAKAQARAAQAXAAAQgZQAQgaAAgeIAAgBQAAgagKgRQgKgQgMAAQgEAAgjAbgAgJhhQgXAjgOA+QBFg1AQgWQAQgXAAgNQAAgWgRAAQgYAAgXAkg");
	this.shape_323.setTransform(760.05,92.75);

	this.shape_324 = new cjs.Shape();
	this.shape_324.graphics.f("#232323").s().p("AhvBHQAAgJADgPQAKg2AAg8QAAgIAGgIQAGgIAFAAQAKAAADAGQAEAGAAARQAAASgKA4IgEAYQAAABAAAAQAAABAAAAQABABAAAAQAAAAAAAAQADAAAXgqQAWgsARgSQAQgSAVAAQAQAAAKAPQAKAOAFAoQAFAsAEALQAEALAJgBQAGAAAIgDIACgBQAIAAAAAJQAAAIgLAIQgKAJgPAAQgQAAgIgMQgIgMgFg1QgFg0gRAAQgJAAgKAMQgLAMgXAqQgeA6gJAIQgJAIgFAAQgWAAAAgVg");
	this.shape_324.setTransform(723.225,98.9);

	this.shape_325 = new cjs.Shape();
	this.shape_325.graphics.f("#232323").s().p("AAwBQQgIgUAAgkIAAgGIAAgGQgXAngXAVQgYAWgVgBQgMABgMgOQgNgOAAgdQAAgYAMgtQAJgmAAgQQAGgLALAAQAHAAAFAGQAEAEAAAHQAAAMgJAYQgQAsAAAgQAAAeANAAQASAAAbgeQAagdATg1QAIgVAFgHQAFgGAIAAQAMAAAAAQIgDAOQgLAnAAAiQAAArAOAMQAHAGAAAEQAAAGgHAEQgIAEgGAAQgMAAgIgSg");
	this.shape_325.setTransform(698.825,98.85);

	this.shape_326 = new cjs.Shape();
	this.shape_326.graphics.f("#232323").s().p("AiqAzQAAgbALhEQAFgcAAgNQAAgMAKAAQAVAAgBAdQABAOgHAoQgIAsAAAJQALgKAWgkQAegyAPgOQAOgNAQAAQAMAAAHAPQAHAQACA6QgBAPADAIQABAHABAAQAJAAAdg5QAPgfAOgQQAOgPARAAQAPAAAHAPQAHAPADAdQADAdAFAZQAFAZAQAHQAKAFAAAHQAAAGgJAHQgIAGgIAAQgOAAgLgRQgMgSgFg6QgDgYgDgKQgBgJgGAAQgHAAgLAOQgKAOgXAsQgSAigJAMQgKALgHAAQgJAAgGgGQgFgGgCgJQgCgJgBgiQgDg4gHgKQgSABg2BiQgTAhgDADQgDADgIADQgJACgFAAQgMAAAAgvg");
	this.shape_326.setTransform(669.75,98.175);

	this.shape_327 = new cjs.Shape();
	this.shape_327.graphics.f("#232323").s().p("AAvBUQgJgUAAgjQgaAhgYARQgYARgVAAQgOAAgKgLQgKgMAAgSQAAgwAqg2QAqg3ApAAQAQAAAHASQACAGAGAAQAOgBAAAMIgCAQQgJAzAAAXQAAArAQAJQAIAEAAAHQAAAFgHAGQgIAFgIABQgOgBgIgSgAgcgbQggAsAAAdQAAAVAOAAQAUgBAigoQAjgnAAghQABgagSAAQgXAAgfAtg");
	this.shape_327.setTransform(624.05,98.45);

	this.shape_328 = new cjs.Shape();
	this.shape_328.graphics.f("#232323").s().p("Ag6BfQgSgLAAgOQAAgLAMABQACAAAEADQATARAbAAQAYAAARgMQARgNABgVQAAgNgLgJQgJgJgNAAQgKAAgYAIQgFACgFAAQgLAAAAgOQgBgFAGgDQAFgEARgDQAygMAAgeQABgJgHgGQgGgGgKAAQgTABgVAQQgMAJgHAAQgLAAAAgKQABgNAZgPQAZgNAXAAQAYAAANAMQANAMAAAOQAAAhgnATQAWADAOAMQAMAOAAATQABAfgaAUQgaAVgpAAQgZAAgSgLg");
	this.shape_328.setTransform(603.8,98.35);

	this.shape_329 = new cjs.Shape();
	this.shape_329.graphics.f("#232323").s().p("Ag/BYQgQgRAAgfQAAgzAjguQAjgvAoAAQANAAAJAJQAJAJAAAMQAAAcgcAZQgbAZgtAZQgJAEAAAIQAAAPAJAJQAIAJARAAQAmAAApgrQAGgGADAAQAFAAAAAKQAAASggAaQghAaghAAQgeAAgPgRgAgPg0QgVAYgIAiQBLgsAAgcQAAgLgJAAQgRAAgUAZg");
	this.shape_329.setTransform(571.175,98.325);

	this.shape_330 = new cjs.Shape();
	this.shape_330.graphics.f("#232323").s().p("AAjBcQgBgFACgFQADgGAKhTQgcAXgaAPQgbAOgOAAQgTAAgJgPQgKgOABgUQgBgaAKggQAKgiAWAAQAFAAADAHQADAFAAAIQAAAKgJAQQgNAWAAAPQABAJACAHQAEAJAIAAQATAAAcgTQAegTAHgPQAHgPAAgIIAAgHIgBgHQgBgHAFgJQAEgIAIgBQAKABADAEQAEADgBARIgDAtIAAAPQgCAWgHAsQgGAtgDAFQgEAGgHgBQgSAAABgLg");
	this.shape_330.setTransform(551.65,98.05);

	this.shape_331 = new cjs.Shape();
	this.shape_331.graphics.f().s("#232323").ss(4,1,1).p("EAmLgAXQgNGYp8BUQp7BTtKgbQtJgbuIgsQuIgshlnIQhlnJOagVQOZgVOGAvQOHAvKfAJQKgAKgOGZg");
	this.shape_331.setTransform(734.5911,101.5406);

	this.shape_332 = new cjs.Shape();
	this.shape_332.graphics.f("#FFFFFF").s().p("AE9INQtJgbuIgsQuIgshlnIQhlnJOagVQOZgVOGAvQOHAvKfAJQKgAKgOGZQgNGYp8BUQneA/pUAAQjDAAjQgHg");
	this.shape_332.setTransform(734.5911,101.5406);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_316},{t:this.shape_315},{t:this.shape_314}]},806).to({state:[]},33).to({state:[{t:this.shape_332},{t:this.shape_331},{t:this.shape_330},{t:this.shape_329},{t:this.shape_328},{t:this.shape_327},{t:this.shape_326},{t:this.shape_325},{t:this.shape_324},{t:this.shape_323},{t:this.shape_322},{t:this.shape_321},{t:this.shape_320},{t:this.shape_319},{t:this.shape_318},{t:this.shape_317}]},50).to({state:[]},16).to({state:[]},347).wait(56));

	// БРОВИ
	this.shape_333 = new cjs.Shape();
	this.shape_333.graphics.f("#FFFFFF").s().p("Al3BwIgmgIQgigFgPgGQgSgGgSgQQgPgLgIgNQgNgWABgeQABgtAYgbQALgLATgMQARgKAMgDQAIgCAZAAIAqACQARABAiAHQAwAKAXAJQAaALAGARIAFARQACAFAHAJQANATACATQACAZgQAZQgMAUgZAQQgRAMgRAEQgOADgXAAQgsAAgSgEgAGKBiIgbgDIgagCIgpgBQgXgDgVgIQgYgKgKgPQgKgPABgkQAAgZAFgMQAFgKARgQQAdgcATgIQAOgGAigDIAtgCQAZgBATACQAzAEAdAeQAUAUAGAdQAGAbgHAcQgGARgJAKQgJALgUAJQgmARgqAAIgMAAg");
	this.shape_333.setTransform(854.5,197.65);

	this.shape_334 = new cjs.Shape();
	this.shape_334.graphics.f("#FFFFFF").s().p("AiXCXQgigBgZgHQgUgGgagOIgsgYQglgUgIgFQgYgPgJgUQgEgHgDgNIgGgUIgKgbQgGgRgCgLQgFggARgbQATgcAggGQAMgCAbABIAtgBQAaABATAEQAjAJAqAiQAqAjARAhQAXApgBA4QgBA2gcAVQgTAPgmAAIgGgBgACkCCQgugFgPgWQgIgNgBgYQgBgZAEgaQACgOAFgMQAIgRAPgPQAYgaAjgRQAZgMAZgEQAMgBAmAAQAggBAQACQAcAFAOAQQAGAFAFAKIAJARIAJATQAIASgDAVQgDAVgMASQgUAggrAUIgdANIgdALQgdAJglAAQgVAAgXgDg");
	this.shape_334.setTransform(854.5751,200.7531);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_333}]},806).to({state:[{t:this.shape_334}]},26).to({state:[]},8).wait(468));

	// Слой_79
	this.shape_335 = new cjs.Shape();
	this.shape_335.graphics.f().s("#232323").ss(6,1,1).p("AHdgmQgaC7AFB3QAFB3nBgvQnAgvglhnQglhoBVh3QBVh4CUhOQCUhODgghQDgghAxBLQAxBKgZC8g");
	this.shape_335.setTransform(1152.4753,299.1741);

	this.shape_336 = new cjs.Shape();
	this.shape_336.graphics.f("#232323").s().p("AEkBbIh9grIhrgpQg+gYgugIQgvgJhKABQhkAAgXgBQgSgBgKgFQgQgIgBgOQgBgIAGgIQAFgHAIgDQALgFAXAAIAogBQBFgBAjABQA6ABAtAHQAmAHAZAJIAaALQAPAHAKADQAQAFAgAIIAkAQQAVAKAhAKIBEAUQAeAJAMAKQAJAIADAMQAEAMgFAKQgHANgOABIgCABQgIAAgMgFg");
	this.shape_336.setTransform(1142.1118,310.1583);

	this.shape_337 = new cjs.Shape();
	this.shape_337.graphics.f("#FFFFFF").s().p("AAMFUQnAgvglhnQglhoBVh3QBVh4CUhOQCUhODgghQDgghAxBLQAxBKgZC8QgaC7AFB3QADBVjnAAQhaAAh+gNgAiYBUQAuAIBAAZIBpApIB+ArQAOAFAIgBQAOgBAHgNQAFgKgEgMQgEgMgJgIQgMgKgegJIhEgVQgggKgVgKIglgQQgfgIgPgFQgKgDgQgHIgagLQgYgJgngHQgugHg6gBQgigBhFABIgpABQgXAAgKAFQgIADgGAHQgFAIAAAIQACAOAPAIQAKAFATABQAXABBjAAIAIAAQBFAAAsAIg");
	this.shape_337.setTransform(1152.4753,299.1741);

	this.shape_338 = new cjs.Shape();
	this.shape_338.graphics.f().s("#232323").ss(6,1,1).p("AnaC7QAGgiAOgmQAziJB7hyQB7hxDPhaQDRhaBCA8QBDA7AYC8QAYC7AjBxQAkBym+BHQm9BHg/haQgkg2AChF");
	this.shape_338.setTransform(1155.9729,295.3857);

	this.shape_339 = new cjs.Shape();
	this.shape_339.graphics.f("#232323").s().p("AE/BAIgYgKQgSgHgggFIkfguIgfgDQgLABgXAGIjOA1QgaAHgNgCQgKgCgHgHIgDgDQgFgHAAgHQgBgLAJgJIAGgEQAIgGASgEIABAAIDWg6QAcgHAOgBQANgBAiAEIBqAQQAqAGARAFIAgAHIAYgBQAQgBAKADIAYAKQANAFAdADQAhAEAYAIIATAIQARALAEAMQAEAOgLAMQgLAMgPAAIgCAAQgKAAgNgFg");
	this.shape_339.setTransform(1145.477,312.8678);

	this.shape_340 = new cjs.Shape();
	this.shape_340.graphics.f("#FFFFFF").s().p("Am7FYQgkg2AChFIADADQAHAHAKACQANACAagHIDOg2QAXgGALgBIAfADIEfAvQAgAFASAHIAYAKQAOAGALgBQAPAAALgMQALgMgEgOQgEgMgRgLIgTgIQAFgFABgIQADgLgHgKQgHgLgKgFQgOgGgggCIhHgDQgigBgXgEIgngGIgwAAIgbgDIgdgFQgagCgnAEQguAFg4AOQgiAHhCATIgnAMQgWAGgJAHIgFAFQgSAFgIAGIgGAEQAGgiAOgmQAziJB7hyQB7hxDPhaQDRhaBCA8QBDA7AYC8QAYC7AjBxQAkBym+BHQjDAfh6AAQicAAgjgyg");
	this.shape_340.setTransform(1155.9729,295.3857);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_337},{t:this.shape_336},{t:this.shape_335}]},806).to({state:[{t:this.shape_340},{t:this.shape_339},{t:this.shape_338}]},14).to({state:[]},20).wait(468));

	// Слой_78
	this.instance_11 = new lib.ВКВ22();
	this.instance_11.setTransform(-26,-235,0.7024,0.7024);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(806).to({_off:false},0).to({_off:true},34).wait(468));

	// Слой_117
	this.shape_341 = new cjs.Shape();
	this.shape_341.graphics.f("#232323").s().p("AgtBVQgSgMAAgJQAAgEACgEQACgDADAAQAAAAAAAAQABAAAAAAQAAAAABABQAAAAAAABQARAYAgAAQAUAAAKgZQAKgaAEgnQgTARgSAJQgSAKgJAAQgMAAgGgKQgHgJAAgNQAAgUAIgcQAIgcAEgEQAEgDAHAAQAEAAACAEQACAEAAAFQAAADgDAFQgQAbAAAdQAAAHACAFQADAEAFAAQAHAAAKgDQAIgEAMgJQANgJADgGQAFgGACgHQABgHABgYQAAgYALAAQAHAAACADQACAEAAAJIgCAfIgBAKQgDBAgQAkQgQAkgdAAQgYAAgSgMg");
	this.shape_341.setTransform(1226.95,639.875);

	this.shape_342 = new cjs.Shape();
	this.shape_342.graphics.f("#232323").s().p("AgkCNQgEgEAAgCQAAgGADgMQAIgjAGgiQgWAQgSAAQgQAAgKgJQgJgKAAgRQAAgcAWgfQAWgfATAAQAIAAAFAGQAGAGADAKQAEgsAAgVQAAgKgDgMIgBgDQAAgGAEgEQACgEAFAAQAEAAAFAGQAFAGgBAcIgBAfIgFA5IgCAJQAcg+AoAAQALAAAJAJQAIAJAAAOQAAAtgcAbQgcAbgaAAQgPAAgFgRQgFASgFAtIgDAYQgBAFgDAEQgEAEgDAAQgEAAgFgEgAg2gbQgLANgGAPQgGAQAAALQABAQASAAQAIAAAMgGQALgFAGgHIACgBQAEgdAAgOQgDACgEAAQgEAAgEgOQgCgHgCgBQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAQgGAAgKANgAAwgpQgIAFgLAQQgLAQgNAaQAAAIAEAGQAFAGAIAAQASAAATgYQATgWAAgZQAAgSgNAAQgJAAgIAGg");
	this.shape_342.setTransform(1209.2,636.825);

	this.shape_343 = new cjs.Shape();
	this.shape_343.graphics.f("#232323").s().p("AgxA7QgGgKgBgUQAAgWAGgZQAGgaADgJIACgHQABgFALgCQAAgBABAAQAAAAABAAQAAgBABAAQAAAAABAAQACAAACAJQAAAFgDAIQgIAWAAAJQAAABABAAQAAABAAAAQAAABAAAAQABAAAAAAQAcgbAWAAQAOAAALALQAJALABAKQgBAagcAaQgcAagdAAQgMAAgIgLgAABgRQgIAFgMALIgHAFQgCACgFABQgCANAAAOQAAASAOAAQAQAAATgTQAUgUAAgRQAAgHgEgFQgEgFgHAAQgKAAgIAEg");
	this.shape_343.setTransform(1191.7,636.175);

	this.shape_344 = new cjs.Shape();
	this.shape_344.graphics.f("#232323").s().p("AhxAhQAAgRAIguQADgSAAgIQAAgIAHAAQANAAAAATQAAAJgEAbIgGAjQAIgHAOgYQAVghAKgJQAJgJAKAAQAIAAAFALQAFAKABAmQAAALABAEQABAFABAAQAFAAATglQAKgVAKgKQAJgLAMAAQAKAAAEAKQAFAKACAUQABATAEARQAEAQAKAEQAHAEAAAEQAAAEgGAFQgGAFgEAAQgKAAgIgNQgHgMgEglIgDgXQgCgHgDAAQgFAAgHAKQgHAKgQAcQgMAXgGAIQgGAHgFAAQgFAAgEgDQgEgFgBgGIgCgdQgCglgFgGQgLAAglBCIgOAYQgCACgGACIgJABQgIAAAAggg");
	this.shape_344.setTransform(1172.575,636.5);

	this.shape_345 = new cjs.Shape();
	this.shape_345.graphics.f("#232323").s().p("AhBA+QAAgTApgmIAGgFQgYgjAAgTQAAgRAPAAQAEAAACADQABAEABAMQACAUAPAUQAggcAMgWIAGgJQACgDAEAAQAEAAAEAEQAEADAAAGQAAAMg7A0QAUAaAXANIAFADIABADQAAAFgEAEQgEAFgFAAQgQAAgigvQgcAYgJAYQgDAIgDADQgPAAAAgMg");
	this.shape_345.setTransform(1152.525,636.95);

	this.shape_346 = new cjs.Shape();
	this.shape_346.graphics.f("#232323").s().p("AgrBRQgEgDAAgFQAAgEAHgFIACgCQADgBAEAAQACAAAFADQAIAAAAAHQAAAFgHAEQgGAEgFAAQgGAAgDgDgAggAhIgBgGQAAgIAJgQIABgDQAHgGAVgIIAOgFQAGgDADgGQADgGAAgGQAAgEgCgJQgCgIgGgDQgHgCgGAAQgLAAgHADQgFAEgBAEQgBAFgGACIgHAAQgFAAgBgGQAAgJAOgKQANgKAIAAIAOAAQALgBAGAEQAGAEAGAHQAGAGAAATQAAAQgGAJQgGAJgJAFQgJAFgcAIIgGAVQgBAFgEACQgDABgHAAQAAAAAAAAQAAAAAAgBQgBAAAAgBQAAgBAAgBg");
	this.shape_346.setTransform(747.9,414.1722);

	this.shape_347 = new cjs.Shape();
	this.shape_347.graphics.f("#232323").s().p("AgxA7QgCgFAAgCQAAgDALgJIAFgFQAQgLAQgPIgMAAQgGAAgIgEQgIgFgBgEQgCgGAAgEQAAgQARgNQAQgMAXgFIAJgBIAHgBIAGABIADgBQADAAAEADQAEACAAADQAAADgEAKQgEAIgEAXQgDAXAAAPIABARIAAAJQAAAAAAABQAAAAAAAAQgBABAAAAQgBABgBAAQgDACgDAAQgGAAgCgDQgCgDAAgJIABgjIgWAUIgLAKQgPAMgGAIIgEADIgDABQgFAAgDgEgAgEgkQgTAJAAAOQAAAEAFACQAFADAJAAQAPAAAIgDQADgCACgFIAHgdQAAgBgBAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQgPAAgRAKg");
	this.shape_347.setTransform(735.525,416.375);

	this.shape_348 = new cjs.Shape();
	this.shape_348.graphics.f("#232323").s().p("AgjA2QgJgKAAgQQAAgcAWgfQAWgeATAAQAIgBAHAKQAGAJAAALQAAAGgDAEQgDAFgCAAQgHAAgCgNQgDgNgGAAQgLAAgOAbQgPAZAAATQAAARAUABQAPgBAWgPQAHgEAEAAQADAAAAADQAAAJgTAMQgTANgSAAQgQgBgIgIg");
	this.shape_348.setTransform(724.025,416.45);

	this.shape_349 = new cjs.Shape();
	this.shape_349.graphics.f("#232323").s().p("AhVBCQgCgCAAgDIABgGQAJgLAHgNIASgmQAKgaADgRQABgHAJAAQAGAAABACQACABACAGQACAFAAADIAEAVIAEAUIAFAYQADAOACAAQABAAADgHIAJgVIAGgLIAMgYQAKgVAFgJIAIgLQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAEABAFACQAFACAAACIABAXIACAhIACAbQABALADAHQAFALAAAGQAAAFgEACQgEACgEAAQgHAAgEgMQgFgMgBg4QgBgRgBgEQgJAOgQAgIgHAPIgFAKQgLAagIAAQgGAAgDgBQgDgDgDgGQgDgIgFgbQgGgdgDgGIgNAeQgIAXgIAOQgIAOgEACQgDAEgEAAQgDAAgDgDg");
	this.shape_349.setTransform(708.725,416.3);

	this.shape_350 = new cjs.Shape();
	this.shape_350.graphics.f("#232323").s().p("AglA0QgKgKAAgSQAAgeAVgcQAVgcAYAAQAIABAFAFQAFAFAAAHQAAARgQAQQgRANgaAPQgFADAAAFQAAAJAFAFQAFAFAKAAQAWAAAYgaQAEgDACAAQADAAAAAFQAAAMgTAPQgUAPgTAAQgSABgJgLgAgIgeQgNAOgFAUQAtgaAAgQQAAgHgGAAQgKAAgLAPg");
	this.shape_350.setTransform(693.675,416.4);

	this.shape_351 = new cjs.Shape();
	this.shape_351.graphics.f("#232323").s().p("AhVBCQgCgCAAgDIABgGQAJgLAHgNIASgmQAKgaADgRQABgHAJAAQAGAAABACQACABACAGQACAFAAADIAEAVIAEAUIAFAYQADAOACAAQABAAADgHIAJgVIAGgLIAMgYQAKgVAFgJIAIgLQAAgBABAAQAAgBABAAQAAAAABAAQAAgBABAAQAEABAFACQAFACAAACIABAXIACAhIACAbQABALADAHQAFALAAAGQAAAFgEACQgEACgEAAQgHAAgEgMQgFgMgBg4QgBgRgBgEQgJAOgQAgIgHAPIgFAKQgLAagIAAQgGAAgDgBQgDgDgDgGQgDgIgFgbQgGgdgDgGIgNAeQgIAXgIAOQgIAOgEACQgDAEgEAAQgDAAgDgDg");
	this.shape_351.setTransform(678.075,416.3);

	this.shape_352 = new cjs.Shape();
	this.shape_352.graphics.f("#232323").s().p("AAbBLQgEgMAAgVIAAgEIAAgDQgOAXgNAMQgPANgMAAQgIAAgHgIQgHgJAAgRQAAgOAGgbQAHgWAAgJQADgHAGAAQAFAAADADQACAEAAADQAAAIgFAMQgKAbAAAUQAAARAIAAQALAAAPgRQAPgSAMgfQAEgNADgDQADgEAFAAQAIAAAAAKIgCAHQgHAXAAAVQAAAZAIAHQAFAEgBADQABADgFACQgEADgDAAQgIAAgFgLgAgDgsIgKgEIgJgGIgHgIIgBgDIgBgEIAAgDIgBgCIABgFIACgDIACgBIADgBQADAAACACQABAAAAAAQABABAAAAQAAABAAAAQABABAAAAIACAKQABAEADADQAEADAEACQAFACAHAAIAEAAIAFgBIAEgCIAEgCIAEgEIADgFIADgFIACgFQABgDABgBIAFgCQAEAAABADQADACAAAFIgCAFIgDAHIgFAGIgGAGIgGAEIgIACIgIACIgIABQgGAAgFgCg");
	this.shape_352.setTransform(661.95,413.975);

	this.shape_353 = new cjs.Shape();
	this.shape_353.graphics.f("#232323").s().p("AAcAyQgGgMAAgVQgPAUgNAKQgPALgMAAQgJAAgGgHQgGgHAAgLQAAgdAagfQAZghAYAAQAJAAAEAKQACAEADAAQAIAAAAAHIgBAJQgGAeAAANQAAAaAKAGQAFACAAAEQAAADgFAEQgEADgFAAQgIAAgFgLgAgQgQQgTAaAAARQAAANAIAAQAMAAAUgYQAVgXAAgUQAAgPgKAAQgOAAgSAag");
	this.shape_353.setTransform(648.725,416.475);

	this.shape_354 = new cjs.Shape();
	this.shape_354.graphics.f("#232323").s().p("AgjA4QgKgGAAgIQAAgHAIAAIACACQANALAPAAQAOAAAKgIQALgIAAgMQgBgIgFgFQgGgFgIAAQgGAAgNAEIgHABQgGAAgBgHQABgDADgCIANgEQAegHgBgSQABgFgEgEQgEgDgGAAQgLAAgMAJQgHAGgEAAQgHAAAAgGQAAgIAQgIQAOgJANAAQAOAAAJAIQAHAHAAAIQAAAUgXALQAOACAHAHQAIAIAAALQAAASgPANQgPAMgYAAQgPAAgMgHg");
	this.shape_354.setTransform(636.7,416.425);

	this.shape_355 = new cjs.Shape();
	this.shape_355.graphics.f("#232323").s().p("AgxA7QgCgFAAgCQAAgDALgJIAFgFQAQgLAQgPIgMAAQgGAAgIgEQgIgFgBgEQgCgGAAgEQAAgQARgNQAQgMAXgFIAJgBIAHgBIAGABIADgBQADAAAEADQAEACAAADQAAADgEAKQgEAIgEAXQgDAXAAAPIABARIAAAJQAAAAAAABQAAAAAAAAQgBABAAAAQgBABgBAAQgDACgDAAQgGAAgCgDQgCgDAAgJIABgjIgWAUIgLAKQgPAMgGAIIgEADIgDABQgFAAgDgEgAgEgkQgTAJAAAOQAAAEAFACQAFADAJAAQAPAAAIgDQADgCACgFIAHgdQgBgBAAAAQAAgBAAAAQgBAAAAgBQAAAAgBAAQgPAAgRAKg");
	this.shape_355.setTransform(811.375,376.025);

	this.shape_356 = new cjs.Shape();
	this.shape_356.graphics.f("#232323").s().p("AAZAJQAAgBAAgBQAAAAgBAAQAAgBAAAAQgBAAAAAAIgYABQgPABgGACQgHACAAABQgCACgCAGIgBAOIAAAOQAAALgKAAQgJAAAAgLQAAgIACgMQADgVAEgzIABgIQABgCAEgCQACgDAEAAQAIAAAAAHIgDAQQgCAPAAAIQAAAGAEAAIAdgCQAWgDAAgCIAEgbQACgUALAAQAIAAABAJIgCAIQgJAjABAWQgBAZAJAHQAEAEAAADQAAADgEACQgFADgDAAQgRAAAAg0g");
	this.shape_356.setTransform(799.25,376.125);

	this.shape_357 = new cjs.Shape();
	this.shape_357.graphics.f("#232323").s().p("AgtBTQgHgIAAgNQAAgZALgTQAKgSAOgKQANgNAWgGIALgEQADgBgBgDQgEgRgFgHQgGgHgJgDQgJgEgHAAQgDAAgGADIgIADQgFADgDAAQgEAAAAgFQAAgEAHgIQAHgJARABIAFAAQARAAANAJQANAJAGARQAGARAAAdQAAATgNAbQgMAcgTAPQgSANgWAAQgHAAgHgJgAgDAAQgeAcAAAiQAAAFACAEQACADACAAQAIAAAGgCQAHgDAIgIQAKgKAHgNQAIgNADgMQAEgMAAgGIAAgLQgZAGgMAKg");
	this.shape_357.setTransform(787.475,373.1);

	this.shape_358 = new cjs.Shape();
	this.shape_358.graphics.f("#232323").s().p("AgoAxQgKgLAAgRQAAgaATgbQASgbAZAAQASAAAKANQALANAAASQAAAbgWAYQgWAYgXAAQgPAAgJgLgAgTgVQgMAVAAATQAAAKAFAHQAEAHAIAAQAPAAAQgRQAQgSAAgUQAAgOgGgIQgGgIgLAAQgQAAgNAVg");
	this.shape_358.setTransform(774.825,376.275);

	this.shape_359 = new cjs.Shape();
	this.shape_359.graphics.f("#232323").s().p("AggA2QgJgGgBgLIgBgCQgBgKAIgNQAIgMAegPQAUgKAAgIQAAgEgDgDQgEgCgDAAQgIAAgWALIgCACQgJgBAAgFQAAgLASgHQAQgGANAAQAIAAAJAGQAJAHAAALQAAAIgGAJQgGAHgWAMQgSAKgHAHQgGAGAAAJQAAAGAFACIAJACQATAAAQgIQAFgDADAAQAGAAAAAGQAAAJgQAHQgPAGgWAAQgLAAgKgGg");
	this.shape_359.setTransform(763.3694,376.15);

	this.shape_360 = new cjs.Shape();
	this.shape_360.graphics.f("#232323").s().p("AglA1QgKgLAAgSQAAgeAVgbQAVgcAYAAQAIAAAFAFQAFAFAAAIQAAAQgQAPQgRAPgaAOQgFADAAAFQAAAIAFAGQAFAFAKAAQAWAAAYgZQAEgEACAAQADAAAAAFQAAALgTAQQgUAQgTAAQgSgBgJgJgAgIgfQgNAPgFAUQAtgaAAgRQAAgGgGAAQgKAAgLAOg");
	this.shape_360.setTransform(752.275,376.05);

	this.shape_361 = new cjs.Shape();
	this.shape_361.graphics.f("#232323").s().p("AgjA1QgJgJAAgRQAAgbAWgeQAWgfATgBQAIABAHAIQAGAKAAALQAAAGgDAFQgDAEgCAAQgHAAgCgNQgDgNgGAAQgLAAgOAaQgPAaAAASQAAATAUgBQAPAAAWgOQAHgGAEAAQADAAAAAFQAAAIgTAMQgTAMgSAAQgQAAgIgJg");
	this.shape_361.setTransform(740.825,376.1);

	this.shape_362 = new cjs.Shape();
	this.shape_362.graphics.f("#232323").s().p("AhVBCQgCgDAAgCIABgFQAJgMAHgNIASgmQAKgaADgRQABgHAJAAQAGAAABACQACACACAEQACAFAAAEIAEAUIAEAVIAFAXQADAPACAAQABAAADgHIAJgUIAGgMIAMgYIAPgeIAIgMQAAAAABAAQAAgBABAAQAAAAABAAQAAgBABAAQAEAAAFACQAFADAAADIABAWIACAhIACAbQABALADAHQAFALAAAGQAAAFgEACQgEACgEAAQgHAAgEgMQgFgMgBg4QgBgRgBgEQgJAOgQAgIgHAPIgFAKQgLAagIAAQgGAAgDgCQgDgBgDgIQgDgGgFgbQgGgegDgGIgNAeQgIAWgIAPQgIAOgEACQgDADgEAAQgDAAgDgCg");
	this.shape_362.setTransform(716.725,375.95);

	this.shape_363 = new cjs.Shape();
	this.shape_363.graphics.f("#232323").s().p("AglA1QgKgLAAgSQAAgeAVgbQAVgcAYAAQAIAAAFAFQAFAFAAAIQAAAQgQAPQgRAPgaAOQgFADAAAFQAAAIAFAGQAFAFAKAAQAWAAAYgZQAEgEACAAQADAAAAAFQAAALgTAQQgUAQgTAAQgSgBgJgJgAgIgfQgNAPgFAUQAtgaAAgRQAAgGgGAAQgKAAgLAOg");
	this.shape_363.setTransform(701.675,376.05);

	this.shape_364 = new cjs.Shape();
	this.shape_364.graphics.f("#232323").s().p("AAUA3IABgGQACgEAHgxQgSAOgPAIQgQAJgIAAQgLAAgFgJQgHgJAAgKQAAgQAHgUQAFgTAOAAQACgBACAEQADADAAAFQgBAGgGAKQgHANAAAJQAAAFACAEQACAFAEAAQAMAAAQgKQASgMAFgJQADgJAAgFIAAgEIgBgEQAAgEADgFQADgGAEAAQAGAAACADQACACAAAKIgCAbIAAAJIgFAmQgEAbgCADQgDADgEAAQgKAAAAgGg");
	this.shape_364.setTransform(690.05,375.9);

	this.shape_365 = new cjs.Shape();
	this.shape_365.graphics.f("#232323").s().p("AgKALQgCgCAAgJQAAgHABgCQABgCAEAAIAJgBIACAAQABAAAAAAQABAAAAAAQABABABAAQAAAAABABQADABAAAEQAAAFgDADQgCADgFAEQgEADgCAAQgEAAgDgCg");
	this.shape_365.setTransform(681.125,380.125);

	this.shape_366 = new cjs.Shape();
	this.shape_366.graphics.f("#232323").s().p("AgKALQgCgCAAgJQAAgHABgCQABgCAEAAIAJgBIACAAQABAAAAAAQABAAAAAAQABABABAAQAAAAABABQADABAAAEQAAAFgDADQgCADgFAEQgEADgCAAQgEAAgDgCg");
	this.shape_366.setTransform(675.625,380.125);

	this.shape_367 = new cjs.Shape();
	this.shape_367.graphics.f("#232323").s().p("AAcAvQgEgLAAgWIAAgDIAAgEQgOAXgNANQgPAMgMAAQgHAAgHgIQgIgIAAgRQAAgOAHgbQAGgXAAgJQADgGAGAAQAFAAADADQACADAAADQAAAIgFAOQgKAaAAATQAAASAIAAQALAAAQgSQAPgSALgeQAFgNADgEQADgEAEAAQAIAAAAAKIgCAIQgHAXAAAUQAAAZAIAIQAFAEAAACQAAADgFADQgEACgDAAQgIAAgFgLg");
	this.shape_367.setTransform(666.175,376.375);

	this.shape_368 = new cjs.Shape();
	this.shape_368.graphics.f("#232323").s().p("Ag1A9QgDgCAAgDIADgSQAFgbAFg6QABgGAEgFQAEgFAFAAQADAAABADQACADAAAFIgBAIQgGAXgCAWQAagDATgdQAJgNAIgFQAHgGAIAAQADAAADACQADAEAAADQAAAGgKADQgFABgEAFQgFADgNAPQgKALgHAEIgBABIABABQAHAEAJALQAMASAHAFQAGAFAIgBIAEAAQAEAAAAAEQAAAEgFAEQgFAFgKgBQgJABgHgIQgIgGgKgQQgEgKgFgFQgFgEgGAAIgIABQgHADgBACQgBACAAAMIAAAUQAAAEgEADQgEADgEAAQgFAAgCgDg");
	this.shape_368.setTransform(653.825,376);

	this.shape_369 = new cjs.Shape();
	this.shape_369.graphics.f("#232323").s().p("AAcAyQgGgMAAgVQgPAUgNAKQgPALgMAAQgJAAgGgHQgGgHAAgLQAAgdAagfQAZghAYAAQAJAAAEAKQACAEADAAQAIAAAAAHIgBAJQgGAeAAANQAAAaAKAGQAFACAAAEQAAADgFAEQgEADgFAAQgIAAgFgLgAgQgQQgTAaAAARQAAANAIAAQAMAAAUgYQAVgXAAgUQAAgPgKAAQgOAAgSAag");
	this.shape_369.setTransform(640.475,376.125);

	this.shape_370 = new cjs.Shape();
	this.shape_370.graphics.f("#232323").s().p("AgnBSQgKgOAAgcQAAghALgiQAMgiASgRQAQgRASgBQALABAHAGQAGAHAAANQAAALgIANQgJAOgPAMQAZAKAAAkQAAAcgRAVQgSAVgTAAQgSAAgKgPgAgTALIgLAIQgBAKAAALQAAATAGAKQAFAKALAAQANAAAKgPQAJgPAAgSQAAgRgGgJQgGgJgHAAQgCAAgVAPgAgFg5QgOAUgIAlQAogfAKgOQAKgNAAgIQAAgNgKAAQgOAAgOAWg");
	this.shape_370.setTransform(629.025,372.75);

	this.shape_371 = new cjs.Shape();
	this.shape_371.graphics.f("#232323").s().p("AgoBMQgQgLAAgHQAAgEACgEQABgDADAAQAAAAABAAQAAAAAAAAQABABAAAAQAAABABAAQAOAVAdAAQARAAAKgWQAJgXACgjQgQAPgQAIQgQAKgIgBQgKAAgGgIQgGgJAAgLQAAgTAHgYQAHgZADgDQAEgDAGAAQADAAACADQACAEAAAEQAAADgDAEQgOAYAAAaQAAAHADAEQACADAEABQAGgBAJgCQAIgEALgIQAKgIAEgFQAEgFABgHQACgGABgWQAAgVAKAAQAGAAACADQABADAAAJIgCAcIAAAJQgDA4gOAhQgOAggaAAQgVAAgRgLg");
	this.shape_371.setTransform(615.725,379);

	this.shape_372 = new cjs.Shape();
	this.shape_372.graphics.f("#232323").s().p("AAVA3IAAgGQACgEAHgxQgSAOgPAIQgQAJgJAAQgKAAgFgJQgHgJABgKQgBgQAHgUQAFgTAOAAQACgBACAEQACADABAFQgBAGgFAKQgIANAAAJQAAAFACAEQACAFAEAAQAMAAAQgKQASgMAFgJQADgJAAgFIAAgEIgBgEQABgEACgFQADgGAEAAQAGAAACADQADACgBAKIgCAbIAAAJIgFAmQgEAbgCADQgDADgEAAQgKAAABgGg");
	this.shape_372.setTransform(604,375.9);

	this.shape_373 = new cjs.Shape();
	this.shape_373.graphics.f("#232323").s().p("AgoAyQgIgIAAgIQAAgDADgCIAGgCIAEABIAEAHQAFAIAKAAQAMAAAMgHQAMgHAFgMQAEgMAAgDQAAAAAAgBQAAAAAAAAQgBgBAAAAQgBAAAAAAIgOADQgNACgOAAQgEAAgCgCQgDgCAAgCQAAgFAMgDIADAAIAIgBQAXgDAGgCQgBgNgGgHQgFgHgIAAQgOAAgPAMIgHAGIgEABQgGAAAAgIQgBgLASgIQARgIAPAAQAKAAAKAHQAKAHADANQAEANAAAKQAAAXgRAWQgRAWglAAQgKAAgIgJg");
	this.shape_373.setTransform(583.6,376.275);

	this.shape_374 = new cjs.Shape();
	this.shape_374.graphics.f("#232323").s().p("AgoAyQgIgIAAgIQAAgDADgCIAGgCIAEABIAFAHQAEAIAKAAQAMAAAMgHQAMgHAEgMQAFgMAAgDQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAIgOADQgNACgOAAQgEAAgCgCQgCgCAAgCQAAgFALgDIADAAIAIgBQAYgDAFgCQgBgNgFgHQgGgHgJAAQgNAAgPAMIgHAGIgDABQgIAAAAgIQABgLARgIQARgIAQAAQAJAAAKAHQAKAHADANQAEANAAAKQAAAXgRAWQgSAWgjAAQgLAAgIgJg");
	this.shape_374.setTransform(572.65,376.275);

	this.shape_375 = new cjs.Shape();
	this.shape_375.graphics.f().s("#232323").ss(3,1,1).p("AqyuPQh7G3sEgDQsDgEmbAAQmbAAkji9Qkii9AAkMQAAkNEii9QEji9LPgNQLPgNJLDgQJKDgh7G3gEA6iAXpQhNEUnmgCQnlgDkCAAQkCAAi3h3Qi3h3AAioQAAipC3h3QC3h3HEgIQHDgIFyCNQFxCNhOEUg");
	this.shape_375.setTransform(906.8226,495.5651);

	this.shape_376 = new cjs.Shape();
	this.shape_376.graphics.f("#FFFFFF").s().p("EAxvAb7QnlgDkCAAQkCAAi3h3Qi3h3AAioQAAipC3h3QC3h3HEgIQHDgIFyCNQFxCNhOEUQhNESnfAAIgHAAgA4xnbQsDgEmbAAQmbAAkji9Qkii9AAkMQAAkNEii9QEji9LPgNQLPgNJLDgQJKDgh7G3Qh6G0r5AAIgMAAg");
	this.shape_376.setTransform(906.8226,495.5651);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_376},{t:this.shape_375},{t:this.shape_374},{t:this.shape_373},{t:this.shape_372},{t:this.shape_371},{t:this.shape_370},{t:this.shape_369},{t:this.shape_368},{t:this.shape_367},{t:this.shape_366},{t:this.shape_365},{t:this.shape_364},{t:this.shape_363},{t:this.shape_362},{t:this.shape_361},{t:this.shape_360},{t:this.shape_359},{t:this.shape_358},{t:this.shape_357},{t:this.shape_356},{t:this.shape_355},{t:this.shape_354},{t:this.shape_353},{t:this.shape_352},{t:this.shape_351},{t:this.shape_350},{t:this.shape_349},{t:this.shape_348},{t:this.shape_347},{t:this.shape_346},{t:this.shape_345},{t:this.shape_344},{t:this.shape_343},{t:this.shape_342},{t:this.shape_341}]},753).to({state:[]},52).to({state:[]},447).wait(56));

	// Слой_77
	this.shape_377 = new cjs.Shape();
	this.shape_377.graphics.f("#232323").s().p("EAsZAFeQgKgKAAgNQAAgNAKgKQAJgKAOABQANgBAKAKQAKAKgBANQABANgKAKQgKAKgNAAQgOAAgJgKgA1rj4QgKgKAAgNQAAgOAKgJQAKgKANAAQANAAAKAKQAKAJAAAOQAAANgKAKQgKAJgNAAQgNAAgKgJgAw/j9QgKgKABgNQgBgNAKgKQAKgKANAAQAOAAAJAKQAKAKAAANQAAANgKAKQgJAKgOAAQgNAAgKgKgEgtGgEvQgJgJAAgOQAAgOAJgJQAKgJANAAQAOAAAJAJQAKAJgBAOQABAOgKAJQgJAJgOAAQgNAAgKgJg");
	this.shape_377.setTransform(1067.95,572.25);

	this.shape_378 = new cjs.Shape();
	this.shape_378.graphics.f("#232323").s().p("EAsdAFpQgKgKAAgNQAAgOAKgJQAJgKAOAAQANAAAKAKQAJAJAAAOQAAANgJAKQgKAJgNAAQgOAAgJgJgA1vkDQgKgKAAgNQAAgOAKgJQAKgKANAAQANAAAKAKQAKAJAAAOQAAANgKAKQgKAJgNAAQgNAAgKgJgAxDkIQgKgKABgNQgBgNAKgKQAKgKANAAQAOAAAJAKQAKAKAAANQAAANgKAKQgJAKgOAAQgNAAgKgKgEgtKgE6QgJgJAAgOQAAgOAJgJQAKgJANAAQAOAAAJAJQAKAJgBAOQABAOgKAJQgJAJgOAAQgNAAgKgJg");
	this.shape_378.setTransform(1068.35,573.35);

	this.shape_379 = new cjs.Shape();
	this.shape_379.graphics.f("#232323").s().p("EAsfAFbQgKgKAAgNQAAgOAKgJQAJgKAOAAQANAAAKAKQAJAJAAAOQAAANgJAKQgKAJgNAAQgOAAgJgJgA1BkIQgHgIAAgLQAAgLAHgHQAIgIALAAQALAAAIAIQAIAHAAALQAAALgIAIQgIAIgLAAQgLAAgIgIgAwckNQgHgHAAgKQAAgJAHgHQAHgHAJAAQAKAAAHAHQAHAHAAAJQAAAKgHAHQgHAHgKAAQgJAAgHgHgEgtPgFBQgGgGAAgIQAAgJAGgGQAFgFAJAAQAIAAAGAFQAGAGAAAJQAAAIgGAGQgGAGgIAAQgJAAgFgGg");
	this.shape_379.setTransform(1068.025,573.225);

	this.shape_380 = new cjs.Shape();
	this.shape_380.graphics.f("#232323").s().p("EAsfAFbQgKgKAAgNQAAgOAKgJQAJgKAOAAQANAAAKAKQAJAJAAAOQAAANgJAKQgKAJgNAAQgOAAgJgJgA1qkIQgIgIAAgLQAAgLAIgHQAIgIALAAQALAAAHAIQAIAHAAALQAAALgIAIQgHAIgLAAQgLAAgIgIgAxGkNQgHgHAAgKQAAgJAHgHQAHgHAKAAQAKAAAGAHQAHAHAAAJQAAAKgHAHQgGAHgKAAQgKAAgHgHgEgtPgFBQgGgGAAgIQAAgJAGgGQAFgFAJAAQAIAAAGAFQAGAGAAAJQAAAIgGAGQgGAGgIAAQgJAAgFgGg");
	this.shape_380.setTransform(1068.025,573.225);

	this.shape_381 = new cjs.Shape();
	this.shape_381.graphics.f("#232323").s().p("EAsfAFbQgKgKAAgNQAAgOAKgJQAJgKAOAAQANAAAKAKQAJAJAAAOQAAANgJAKQgKAJgNAAQgOAAgJgJgA07kIQgIgIAAgLQAAgLAIgHQAIgIALAAQALAAAHAIQAIAHAAALQAAALgIAIQgHAIgLAAQgLAAgIgIgAwXkNQgHgHAAgKQAAgJAHgHQAHgHAKAAQAKAAAGAHQAHAHAAAJQAAAKgHAHQgGAHgKAAQgKAAgHgHgEgtPgFBQgGgGAAgIQAAgJAGgGQAFgFAJAAQAIAAAGAFQAGAGAAAJQAAAIgGAGQgGAGgIAAQgJAAgFgGg");
	this.shape_381.setTransform(1068.025,573.225);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_377}]},752).to({state:[{t:this.shape_378}]},1).to({state:[{t:this.shape_379}]},26).to({state:[{t:this.shape_380}]},14).to({state:[{t:this.shape_381}]},12).to({state:[]},1).wait(502));

	// Г
	this.instance_12 = new lib.АСЦАЦ6363();
	this.instance_12.setTransform(536,66,0.6198,0.6198);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(752).to({_off:false},0).to({_off:true},54).wait(502));

	// Слой_76
	this.shape_382 = new cjs.Shape();
	this.shape_382.graphics.f("#232323").s().p("ABPEQQgOgBgGgKQgGgKAAgVIgBiYQAAhJACgjIAGhBQAFgvABgRQACglgFgcIgCgSQAAgKAEgGQAGgIANgEQAOgDAJAFQAQAIABAjQABA4gCAcIgFA0QgFAygCArQgBAYAABSIABB0QABAbgLALQgHAIgMAAIgDAAgAh0DbQgIgKAAgZIAAlqQAAgsAHgVQAFgPAIgGQAIgHAMACQAMABAGAJQAHAJgBAPIgDAbQgDAQAAAgIAAFYQAAAZgHAJQgHAKgOAAQgOAAgIgJg");
	this.shape_382.setTransform(1435.4667,671.045);

	this.shape_383 = new cjs.Shape();
	this.shape_383.graphics.f("#232323").s().p("Ah0EqQgIgKAAgZIAAlpQAAgsAHgVQAFgPAIgGQAIgHAMABQAMACAGAIQAHAKgBAPIgDAbQgDAQAAAgIAAFYQAAAYgHAKQgHAKgOAAQgOAAgIgKgABPDsQgOgBgGgKQgGgKAAgVIgBiYQAAhIACgkIAGhBQAFgvABgRQACglgFgcIgCgSQAAgKAEgGQAGgIANgEQAOgDAJAFQAQAIABAjQABA4gCAcIgFA0QgFAygCAsQgBAYAABRIABB0QABAbgLALQgHAIgMAAIgDAAg");
	this.shape_383.setTransform(1435.4667,663.065);

	this.shape_384 = new cjs.Shape();
	this.shape_384.graphics.f("#232323").s().p("ABCEQQgOgBgHgKQgGgKAAgVIAAiYQAAhJACgjIAFhBQAGgvABgRQACglgFgcIgDgSQAAgKAEgGQAGgIANgEQAPgDAIAFQARAIABAjQABA4gCAcIgFA0QgGAygBArQgBAYAABSIAAB0QABAbgKALQgIAIgMAAIgCAAgAhmDZQgIgKAAgZIAAlpQAAgsAHgVQAEgPAIgGQAIgHAMABQAMACAHAIQAHAKgBAPIgEAbQgCAQAAAgIAAFYQAAAYgIAKQgHAKgOAAQgOAAgHgKg");
	this.shape_384.setTransform(1427.9667,671.3418);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_382}]},752).to({state:[{t:this.shape_383}]},27).to({state:[{t:this.shape_384}]},24).to({state:[]},3).wait(502));

	// Слой_75
	this.shape_385 = new cjs.Shape();
	this.shape_385.graphics.f("#232323").s().p("Ag1CmQgfAAgLgMQgJgKAAgaIAAjmQAAgYAEgLQAEgIAHgGQAIgFAIAAQARACAHASQAEALAAAUIAADcQA6AAA0AEQAhACAGARQAEAJgFAKQgFAJgKAFQgLAGgcAAg");
	this.shape_385.setTransform(921.6971,690.9229);

	this.shape_386 = new cjs.Shape();
	this.shape_386.graphics.f("#232323").s().p("AADBjIgWgBIgZAAQgOgBgIgHQgGgGgGgPQgIgRgegpQgbgigHgYQgGgYAJgOQAIgNAPAAQAPAAAJAMQADAFAGARQAHAUAVAbQAaAgAGAMQADAGACACQACABAGABQARADAVgDIAngJQAbgGAQgCQAWgDAJAEQANAFAFAOQAFAOgIALQgIAMgTADIgfADQgKACgWAGQgVAGgLABIgOABIgJAAg");
	this.shape_386.setTransform(927.3563,680.1333);

	this.shape_387 = new cjs.Shape();
	this.shape_387.graphics.f("#232323").s().p("AhTC+QgdAAgJgLQgHgJAAgXIAAg1IgEhUQgDg0AChpQAAgWAHgKQAHgJAOgBQAOAAAIAJQAKAMgBAdIAAA/QgBAqACAgIAEBBQADAngCAbICeABQAZAAAKAHQALAIgBAPQAAAQgLAHQgJAHgYAAg");
	this.shape_387.setTransform(921.2861,690.6238);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_385}]},752).to({state:[{t:this.shape_386,p:{y:680.1333}}]},14).to({state:[{t:this.shape_386,p:{y:673.5333}}]},13).to({state:[{t:this.shape_386,p:{y:682.0333}}]},11).to({state:[{t:this.shape_387}]},15).to({state:[]},1).wait(502));

	// Слой_72
	this.instance_13 = new lib.фоны_фонстол2copy3();
	this.instance_13.setTransform(0,-171,0.3426,0.3426);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(752).to({_off:false},0).wait(54).to({scaleX:0.6704,scaleY:0.6704,x:-876,y:-993},0).wait(34).to({scaleX:0.8805,scaleY:0.8805,x:-1369,y:-1408},0).to({_off:true},19).wait(11).to({_off:false},0).to({_off:true},11).wait(8).to({_off:false},0).to({_off:true},16).wait(403));

	// ОБЛ
	this.instance_14 = new lib.Анимация51("synched",0);
	this.instance_14.setTransform(989.3,157.3);
	this.instance_14._off = true;

	this.instance_15 = new lib.Анимация52("synched",0);
	this.instance_15.setTransform(672.8,157.3);
	this.instance_15._off = true;

	this.instance_16 = new lib.Анимация53("synched",0);
	this.instance_16.setTransform(1209.8,157.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_14}]},752).to({state:[{t:this.instance_15}]},32).to({state:[{t:this.instance_16}]},21).to({state:[]},1).wait(502));
	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(752).to({_off:false},0).to({_off:true,x:672.8},32).wait(524));
	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(752).to({_off:false},32).to({_off:true,x:1209.8},21).wait(503));

	// Слой_70
	this.instance_17 = new lib._676868();
	this.instance_17.setTransform(641,243,0.5063,0.5063);
	this.instance_17._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(718).to({_off:false},0).to({_off:true},34).wait(556));

	// Каркас_27
	this.shape_388 = new cjs.Shape();
	this.shape_388.graphics.f("#232323").s().p("A0EYcQk/AGk3hIQjShMixiQQjTiSjCirQhHhHg6hUQhFhogsh3Ihuj6QgkhTgfhXQhLjyAfkFQAChQAdhLQAzhTBwgOQCDgcCIAWQCmAWCGBuQAuAwAjA5QAnAzAkAzQAuBMAWBXQBsEyC1ESQA0BLA9BGQBhBwB3BYQBBAsBHAeQCZBCCpANQA0gGAwgKQBPgPBNgbQCgg5COhkIAGgEQBBgrBahCIARgNQgVgwgkgzQgkhHgEhSQgEg3ABg5QgClLA9lHQA8jOB2i1QBOiABXh6QB1isCSiXIAVgSQghgqgQgXQgbgsAHglQAJglAmgRQA5gVA3AyQApAfAZApIATgKQBrgyBzgRQBagOBVAqQB9BniOC+IGSi3QBFggBMgFQBLAJAQBbQBtA2B4hlQBtg3ByA+QBRBviyByQgTAMgGAWQAFAcArgJQDVgdDJhTQB0gvB2AqQBGBKg7B4QBXgRBYANQBUAdgCBrQBagKBVggQBZgRBQA2QAkAmATAxQAcAqAgAlQAqBPhKBSQBRAdgyB/QgEBOAHBNQgXBOhXAgQhKAqg3A8QBCAAA9AcQA3AiAABLQgOBMhaASQhKAfg+AwQAmBXhlBMQhOA2hiAPQjUBFi3CKQjhCGj0BgQiuBEi6AgQh9AQh+gFIoCAAQiuAAitgTQiLgYiGg3QgvA4g3AuQjBCqjdCEQhaA2hfAtQhtAzh2AcQiVAiiaAAQgjAAgjgCg");
	this.shape_388.setTransform(783.4009,530.6029);

	this.shape_389 = new cjs.Shape();
	this.shape_389.graphics.f("#232323").s().p("A90XlQjShJiziNQjWiPjEioQhIhGg7hTQhHhngth2Ihyj5QgmhTgfhWQhPjxAbkGQAAhQAchLQAzhUBwgPQCCgeCIAUQCmAUCIBsQAvAvAkA4IBMBmQAwBLAXBWQBwExC5EPQA1BKA+BFQBiBvB5BWQBBArBIAdQCaBACpAKQA0gGAwgLQBOgQBNgcQCgg8CahjIAGgDQBCgsBahBIARgMQgVgxgjgzQgkhHgDhSQgEg4ABg4QAAlLA/lHQA+jOB4izQBPiABXh5QB2isCTiWIAVgSQghgqgPgXQgcgtAIglQAJgkAmgRQA5gVA3AyQApAhAYAoIATgKQBsgxBzgRQBagNBVArQB8BoiPC9IGTi1QBFgfBNgFQBLAKAPBbQBtA2B4hkQBtg2ByA/QBRBwi0BwQgSAMgHAWQAFAcArgJQDVgbDKhSQB0guB2AqQBGBLg8B4QBWgRBYAOQBUAdgCBrQBagJBVggQBZgRBQA4QAjAlATAyQAcApAgAmQAqBPhLBSQBRAdgzB/QgFBOAHBNQgYBOhXAfQhKAqg4A8QBCgBA9AdQA3AiAABMQgPBLhaASQhKAeg+AwQAlBXhmBMQhOA2hiANQjVBEi3CJQjiCEj1BfQiuBDi7AfQh8APh+gGIoCgDQiugBiugVQiKgYiGg4QgvA3g4AuQjCCpjdCDQhbA0hfAtQhtA0h1AfQi2Asi/gHIhVACQkTAAkPg7g");
	this.shape_389.setTransform(782.1647,530.7373);

	this.shape_390 = new cjs.Shape();
	this.shape_390.graphics.f("#232323").s().p("A9tXvQjThHi1iKQjYiMjGilQhKhFg8hSQhIhmgvh2Ih1j3QgohSgghVQhTjwAYkGQgBhQAbhMQAxhVBwgQQCBggCJARQCmASCKBqQAvAvAlA3IBOBkQAwBLAZBWQB1EvC8EMQA3BKA+BEQBkBtB6BUQBCArBIAcQCcA9CpAIQAzgHAwgLQBOgSBMgdQCfg+CohiIAGgEQBBgqBbhCIASgMQgVgwgjg0QgkhHgChSQgEg4ACg4QAClLBBlHQA/jNB5izQBPh+BZh6QB3irCUiVIAVgRQghgsgPgWQgbgtAIglQAJgkAngRQA5gUA2AyQApAhAYAoIATgJQBsgxBzgQQBbgMBUArQB8BpiRC8IGUiyQBFgfBNgFQBLALAPBbQBsA4B5hkQBug2BxBAQAoA4gpBCQghA8hCAqQgTALgGAWQAEAcArgJQDVgZDLhRQB0gtB2ArQBFBLg8B3QBWgPBYAOQBUAdgDBsQBagKBVgfQBagPBOA3QAkAmASAyQAcAqAgAlQApBPhLBSQBQAegzB/QgFBMAGBPQgZBNhXAfQhKApg4A7QBCABA8AcQA3AkgBBLQgPBLhaARQhLAeg+AwQAkBXhmBLQhOA1hiANQjVBCi5CJQjiCCj2BdQivBCi6AeQh9AOh+gGIoCgHQiugCitgWQiKgaiFg4QgwA3g4AuQjDCnjfCBQhaA1hgAsQhsA0h1AiQi2Aui+gEQhAADhAAAQj+AAj6gyg");
	this.shape_390.setTransform(780.9441,531.0253);

	this.shape_391 = new cjs.Shape();
	this.shape_391.graphics.f("#232323").s().p("A9mX4QjVhDi3iIQjZiJjJiiQhKhEg+hRQhJhlgyh1Ih4j1QgphSgihVQhVjvATkGQgChQAahMQAwhVBvgTQCBghCJAPQCnAPCLBpQAwAuAmA2IBPBkQAxBJAaBWQB5EuDBEJQA3BJBABDQBmBsB7BSQBDAqBIAbQCcA7CpAFQAzgIAwgMQBOgTBMgeQCehAC0hiIAGgEQBCgqBbhAIASgMQgUgxgjgzQgjhIgChSQgEg4ACg4QAFlLBDlHQBAjMB6iyQBRh/BZh4QB4iqCViVIAVgRQghgrgOgXQgbgtAIglQAJgkAngRQA5gTA3AzQAoAgAYApIATgJQBsgwB0gQQBagMBTAsQB8BpiSC8IGViwQBGgeBMgEQBLAKAPBcQBrA5B6hkQBvg0BwBAQAoA5gqBAQghA9hDApQgSAMgHAVQAEAdArgJQDWgYDLhQQB1gtB1AsQBFBMg+B3QBXgPBYAPQBTAegDBrQBagJBVgeQBagPBOA4QAkAmASAyQAcAqAfAlQAoBQhMBRQBRAeg1B/QgGBNAGBOQgYBNhYAeQhLApg4A6QBCABA8AeQA3AjgBBMQgQBLhaARQhLAdg/AvQAkBYhmBKQhPA0hjANQjVBBi5CHQjkCBj2BbQivBBi7AdQh8ANh+gHIoCgKQiugDitgXQiKgaiFg6QgwA3g5AtQjDCnjgB/QhbAzhfAsQhuA1hzAkQi0Ayi/gBQhQAFhQAAQjtAAjrgsg");
	this.shape_391.setTransform(779.7866,531.3006);

	this.shape_392 = new cjs.Shape();
	this.shape_392.graphics.f("#232323").s().p("A9gYBQjWg/i5iGQjbiGjLifQhLhCg/hRQhLhkgzh0Ih8j0QgphRgkhUQhZjuAQkGQgDhQAYhMQAuhWBwgUQCBgkCIAOQCoANCMBlQAwAuAnA2QAqAxAnAxQAyBJAbBVQB+EsDEEHQA5BHBABDQBoBqB8BRQBDAoBJAaQCdA5CpADQAzgJAwgMQBOgUBLggQCdhCDBhhIAGgEQBCgpBchBIASgMQgUgwgjg0QgjhIgBhSQgDg4ADg4QAGlLBFlGQBCjNB7ixQBRh+BZh4QB7ipCViTIAWgRQgggsgPgXQgbgtAJgkQAJglAngQQA6gUA1A0QAoAgAYApIATgJQBsgvB0gOQBagMBUAtQB7BqiTC6IGWitQBGgdBMgEQBLAKAOBcQBrA5B7hiQBug0BxBBQAnA5gqBBQgiA8hDApQgSALgHAVQAEAdArgIQDWgXDLhOQB1gsB1AsQBFBMg/B3QBXgPBYAPQBTAfgEBsQBbgIBVgeQBZgPBOA4QAkAnARAyQAbAqAgAmQAoBPhNBRQBRAfg2B+QgGBOAFBNQgZBOhYAdQhKAog5A6QBCABA8AeQA3AkgCBMQgRBLhaAQQhLAdg/AuQAkBZhoBJQhOA0hjAMQjWBAi6CFQjkCAj3BZQiwBAi7AcQh8AMh+gIIoCgNQiugFitgXQiKgciEg6QgyA3g4AsQjECljhB/QhbAzhgArQhsA0hzAoQi0A0i+ACQhiAHhiAAQjbAAjaglg");
	this.shape_392.setTransform(778.6717,531.6038);

	this.shape_393 = new cjs.Shape();
	this.shape_393.graphics.f("#232323").s().p("A9ZYKQjXg9i6iDQjeiCjNicQhNhCg/hPQhNhjg0hzIiAjyQgqhQglhUQhcjtALkGQgEhQAXhNQAthWBvgWQCBgmCJAMQCnAKCOBkQAxAtAoA2IBSBgQAzBIAcBVQCDErDHEDQA6BHBCBBQBoBpB+BPQBEAnBJAZQCeA3CpAAQAzgJAwgNQBNgWBLggQCchEDOhiIAGgDQBDgpBbhAIASgMQgTgwgjg1QgihIgBhSQgDg3ADg5QAJlLBHlFQBDjMB9ixQBSh9BZh3QB7ipCXiSIAWgRQgggsgPgXQgbgtAKglQAJgkAngQQA6gTA1AzQAoAhAYAqIATgJQBtgvBzgOQBbgLBTAtQB6BsiUC5IGXirQBGgdBNgDQBLAMAMBbQBsA6B7hiQBvgzBwBCQAnA5grBAQgiA9hDAoQgTALgHAVQAEAdArgIQDWgWDMhMQB1gsB1AuQBDBMg+B2QBXgOBXAQQBUAfgGBsQBbgIBWgdQBZgOBOA5QAjAmARAyQAbAqAfAnQAnBQhMBQQBQAfg2B+QgHBNAFBOQgaBOhYAcQhLAog5A5QBCACA8AeQA3AkgDBMQgRBLhaAPQhMAdg/AuQAjBZhnBIQhQAzhjAMQjVA+i7CFQjmB+j3BYQiwA/i7AaQh9AMh+gJIoCgRQiugFisgZQiKgdiEg7QgyA3g4AsQjGCjjhB+QhbAyhhArQhsA0hxArQi0A2i+AFQh2ALh3AAQjGAAjGgfg");
	this.shape_393.setTransform(777.5446,531.9796);

	this.shape_394 = new cjs.Shape();
	this.shape_394.graphics.f("#232323").s().p("A9SYSQjYg5i8iBQjgh/jPiZQhNhAhBhPQhOhig2hyIiEjwQgshQglhTQhgjsAIkGQgFhQAWhNQArhXBvgXQCAgoCJAKQCnAICQBiQAyArAoA2QArAvAoAwQA1BIAdBUQCHEoDLEBQA8BGBCBBQBqBnB/BNQBEAnBKAXQCeA1CpgDQAzgKAwgOQBNgWBKgiQBNgjBwgsQBngrBSgtIAGgEQBCgpBdg/IASgLQgTgxgig0QgihJAAhSQgCg3ACg5QALlLBKlFQBEjMB9ivQBUh9Bah3QB8inCYiSIAVgQQgfgsgPgYQgagtAJgkQAKglAngPQA6gTA1A0QAoAhAXApIATgIQBtgvB0gMQBbgLBSAuQB6BsiWC4IGZioQBGgdBNgCQBKAMANBcQBqA6B8hhQBvgzBwBDQAmA5gqBBQgjA7hDAoQgUAMgGAVQAEAcArgHQDWgVDMhLQB1gqB1AuQBDBMg/B2QBXgNBXAQQBTAggGBrQBbgHBWgdQBZgNBOA5QAiAnARAyQAbArAfAmQAnBRhNBPQBPAgg2B9QgIBOAFBNQgaBOhZAcQhLAng6A5QBCACA8AfQA2AlgDBLQgRBLhaAPQhMAcg/AuQAiBYhoBIQhQAzhiALQjXA9i8CDQjlB9j5BWQiwA+i7AZQh9AKh+gJIoCgUQiugGisgbQiJgdiEg8QgyA3g5ArQjGCijjB8QhbAyhhAqQhsA1hwAuQiyA5i/AHQiIAPiIAAQi0AAi1gag");
	this.shape_394.setTransform(776.4093,532.3622);

	this.shape_395 = new cjs.Shape();
	this.shape_395.graphics.f("#232323").s().p("A9KYbQjZg3i+h9Qjhh8jSiWQhOg/hChOQhQhgg4hyIiGjuQgthQgnhSQhkjqAFkHQgHhPAVhOQAqhYBvgYQB/gqCJAIQCoAGCRBfQAyArApA1IBVBeQA2BHAeBTQCLEnDPD+QA8BFBEA/QBrBmCABLQBFAmBKAXQCfAxCpgEQAzgLAvgPQBOgXBJgjQBNgkB2gtQBrgsBUgsIAGgEQBDgoBcg/IASgLQgSgxgig1QgihIABhSQgCg4ADg5QANlKBMlFQBFjLB/ivQBTh7Bbh3QB+inCZiQIAWgRQgggsgOgYQgagtAJgkQAKglAogPQA6gTA0A1QAnAhAXAqIAUgJQBtgtB0gMQBagLBTAvQB4BtiWC3IGailQBGgdBNgCQBKAMAMBdQBrA6B8hgQBvgxBwBDQAmA5grBAQgjA8hEAnQgTAMgHAVQADAcAsgHQDWgTDNhKQB2gqBzAvQBDBOhAB1QBXgOBXASQBUAggHBrQBbgGBWgcQBYgOBOA7QAjAnAQAyQAbAqAeAnQAnBRhOBPQBPAhg3B8QgIBOAEBNQgbBNhYAcQhMAmg6A5QBCADA8AfQA2AlgEBLQgSBLhaAOQhMAcg/AtQAiBahpBGQhQAzhjAKQjXA8i8CCQjnB7j5BVQixA8i7AYQh9AKh+gKIoBgXQitgIitgbQiKgfiDg9QgyA2g5AsQjIChjjB6QhcAxhhAqQhsA2huAwQiyA7i+AKQibATibAAQiiAAihgUg");
	this.shape_395.setTransform(775.2843,532.7281);

	this.shape_396 = new cjs.Shape();
	this.shape_396.graphics.f("#232323").s().p("A9CYiQjagzjAh7Qjjh4jUiTQhPg+hDhNQhQhfg6hxIiLjsQgthPgphSQhmjpAAkGQgIhQAUhOQAphYBugaQB/gsCJAGQCoADCSBeQAzArAqAzIBWBdQA2BHAhBSQCOElDUD6QA9BFBEA+QBtBlCBBJQBGAlBKAVQCgAwCpgHQAygMAvgPQBNgZBJgkQBMglB8guQBvgsBWgtIAGgDQBEgoBdg+IASgLQgTgyghg0QghhJABhSQgCg4AEg4QAPlLBOlEQBGjKCAiuQBTh8Bdh2QB/imCaiPIAWgRQgggsgOgYQgZgtAJgkQAKglAogPQA6gSA0A1QAnAiAXApIATgJQBvgsBzgLQBbgKBSAvQB4BtiYC3IGbijQBGgcBNgBQBLANALBcQBqA7B9hfQBwgxBuBEQAmA6grA/QgkA8hEAnQgTAKgHAWQADAcAsgHQDWgSDNhIQB2gpB0AwQBDBNhCB1QBXgMBYARQBSAhgHBrQBagFBXgcQBagMBMA6QAjAnAQAzQAaArAeAmQAmBRhOBPQBPAhg4B8QgIBOADBNQgbBNhZAbQhMAmg6A5QBCACA7AgQA2AmgEBLQgSBKhaAOQhMAbhAAtQAgBahoBGQhRAyhjAJQjXA6i9CBQjoB6j5BTQixA8i8AWQh8AJh+gLIoCgaQitgJitgcQiJggiDg9QgzA2g4ArQjJCgjkB4QhdAxhgApQhsA2htAzQixA9i+AOQitAXiuAAQiPAAiPgQg");
	this.shape_396.setTransform(774.1315,533.1634);

	this.shape_397 = new cjs.Shape();
	this.shape_397.graphics.f("#232323").s().p("A87YqQjagxjCh3Qjkh2jXiPQhPg+hFhLQhRhfg8hvIiOjqQgvhOgphSQhqjngEkGQgJhQAThOQAohZBugcQB+gtCJAEQCoABCTBbQA0AqAqAzIBYBcQA3BFAiBSQCTEjDXD3QA9BEBGA9QBuBjCCBHQBGAkBLAUQCgAuCpgKQAzgMAvgQQBMgaBIglQBMgmCCgvQB0gtBYgsIAGgDQBDgoBdg9IATgLQgTgyghg1QgghIAChSQgCg4AEg5QASlKBPlEQBIjKCBitQBUh7Beh1QB/ilCbiPIAWgQQgfgsgOgYQgZguAKgkQAKglAogPQA6gRA0A1QAnAiAWApIAUgIQBtgsB1gKQBbgJBRAvQB4BuiZC2IGbigQBHgcBNgBQBKANALBdQBpA8B+hfQBwgwBuBFQAmA6gsA/QgkA7hEAnQgUALgGAVQACAdAsgHQDWgRDOhHQB2goB0AwQBCBOhCB1QBXgMBXASQBTAhgIBsQBbgFBWgcQBZgMBNA8QAiAnAQAzQAaArAeAmQAlBRhPBPQBQAhg6B8QgJBOADBNQgbBNhZAaQhMAlg7A5QBCADA7AgQA2AmgFBLQgSBLhbANQhMAahAAtQAgBahpBFQhRAyhjAIQjYA5i+CAQjnB5j7BRQixA6i8AVQh9AJh9gMIoCgeQitgJisgeQiJggiDg/QgzA2g5AqQjKCfjkB3QhdAwhhAoIjYBsQiwBCi9APQjAAdjBAAQh8AAh9gMg");
	this.shape_397.setTransform(773.0339,533.6253);

	this.shape_398 = new cjs.Shape();
	this.shape_398.graphics.f("#232323").s().p("A8zYxQjbgtjDh1QjmhyjZiNQhRg8hFhKQhThdg9hvIiRjoQgwhNgrhRQhtjmgIkGQgKhQAShOQAnhaBtgdQB9gvCJACQCogCCVBZQA0AqArAyIBZBbQA5BEAiBRQCYEhDaD0QA/BDBGA9QBwBhCDBFQBGAiBLAUQCiArCogMQAzgNAugRQBLgbBJglQBLgoCIgwQB4gtBagsIAGgEQBDgnBeg8IATgLQgSgyghg1QgghJAChSQgBg4AFg4QATlLBSlCQBJjLCCisQBVh6Beh1QCBikCciOIAWgQQgfgtgOgXQgZguAKgkQALgkAogPQA6gRAzA1QAnAiAWAqIAUgIQBugsB0gJQBbgIBRAvQB3BviaC1IGdieQBGgbBNAAQBLANAKBdQBpA9B+heQBwgwBuBGQAlA6gsA/QgkA7hEAmQgUALgHAVQADAdArgHQDXgPDOhGQB2gnBzAxQBCBPhDB0QBXgMBYATQBSAigJBrQBbgFBXgaQBZgLBMA7QAiAoAQAyQAZAsAeAnQAlBRhPBOQBPAig6B7QgKBOADBNQgcBNhZAZQhNAlg7A4QBCAEA7AhQA1AlgFBMQgTBKhaANQhNAahAAsQAfBahpBFQhRAxhjAIQjYA3i/B/QjpB2j6BQQizA5i7AVQh9AHh+gMIoBghQitgLisgfQiJghiChAQgzA2g6AqQjLCdjlB2QhdAwhiAnIjVBvQiwBEi9ASQjRAjjSAAQhrAAhrgJg");
	this.shape_398.setTransform(771.9441,534.088);

	this.shape_399 = new cjs.Shape();
	this.shape_399.graphics.f("#232323").s().p("A8rY3QjbgqjGhxQjnhwjbiJQhRg6hHhKQhUhcg/huIiVjmQgxhLgshSQhwjkgMkFQgLhQARhPQAlhaBtgeQB8gyCKAAQCngECXBXQA0ApAsAxIBbBaQA5BEAkBRQCbEdDeDyQBABCBHA7QBxBgCEBDQBIAhBLATQChApCpgPQAygOAugRQBLgcBIgnQBLgpCNgwQB9guBcgsIAGgEQBDgmBfg8IASgLQgRgxghg2QgfhJAChSQAAg4AEg4QAWlLBUlCQBKjJCEisQBVh6Bfh0QCCikCdiMIAWgQQgfgtgOgYQgYguAKgkQALgkAogPQA6gQA0A1QAmAjAWAqIATgIQBvgrB0gJQBbgHBRAwQB2BvibC0IGeiaQBGgbBNAAQBLAOAJBdQBpA9B/hdQBwgvBuBHQAlA6gtA+QglA8hEAlQgUAKgHAWQACAcAsgGQDWgNDPhFQB3gnByAyQBCBPhEB0QBXgLBYATQBSAjgKBrQBbgEBXgbQBZgKBMA8QAhAoAQAzQAZArAeAnQAkBShQBNQBPAig7B7QgJBOABBNQgcBNhZAYQhNAlg7A4QBBAEA7AhQA2AmgGBMQgUBKhaAMQhNAahBArQAgBahrBFQhRAwhjAHQjYA2jAB+QjqB0j7BPQiyA5i8ASQh9AHh+gNIoAglQitgMitggQiIgiiChAQgzA1g6AqQjMCcjmB0QhdAvhiAnQhrA3hpA7QiuBGi9AVQjkApjnAAQhWAAhYgGg");
	this.shape_399.setTransform(770.866,534.6);

	this.shape_400 = new cjs.Shape();
	this.shape_400.graphics.f("#232323").s().p("A8jY+QjcgnjHhvQjqhrjciGQhSg6hIhJQhVhahBhuIiXjjQgzhMgthPQh0jjgPkHQgMhOAPhPQAkhaBsghQB8gyCKgDQCngGCYBVQA1AnAtAxQAuAsAtAsQA7BDAlBQQCgEdDhDtQBABCBIA6QBzBeCFBBQBIAhBLARQCjAmCogRQAxgPAugSQBLgdBHgnQBKgqCUgyQCBgvBdgrIAGgDQBFgmBeg8IASgLQgRgxggg2QgfhKADhRQAAg4AFg5QAYlKBWlCQBMjJCEiqQBWh6BghzQCDiiCdiMIAXgQQgfgtgNgYQgYguAKgkQAMgkAngOQA7gRAzA2QAlAjAWAqIAUgIQBvgqB0gIQBbgIBRAyQB1BwicCyIGeiYQBIgaBMABQBLAOAIBdQBpA+B/hcQBxguBtBHQAlA6guA/QglA7hFAlQgTAKgIAVQADAdArgGQDXgMDPhEQB3gmByAzQBCBPhFB0QBYgLBWAUQBSAjgKBrQBagDBYgaQBZgKBMA9QAhAoAPAzQAZArAdAnQAkBShQBNQBPAjg8B7QgLBNACBOQgdBLhaAZQhMAkg8A4QBCAEA6AhQA1AngGBLQgUBLhaALQhNAZhBArQAfBahrBEQhSAwhjAHQjZA0jAB8QjrB0j7BNQizA3i8ARQh9AGh9gOIoBgnQiugOirghQiIgiiBhBQg1A0g7AqQjLCajnBzQheAuhiAnQhqA3hoA+QitBIi9AYQj1Awj5AAQhFAAhFgDg");
	this.shape_400.setTransform(769.8272,535.132);

	this.shape_401 = new cjs.Shape();
	this.shape_401.graphics.f("#232323").s().p("A8FZSQjdgijKhqQjshljfiBQhUg4hJhHQhZhYhChsIiejgQg0hKgvhPQh5jegWkHQgOhOAOhPQAhhcBsgjQB6g2CKgFQCmgLCaBRQA3AmAtAwIBeBWQA8BBAnBQQCnEYDnDoQBDBABIA4QB1BbCHA+QBIAfBMAQQCjAiCogVQAygQAtgTQBLgfBFgqQBJgsCYgzQCFgyBegsIAGgDQBDgnBfg8IASgLQgSgyggg1QgfhKAChRQAAg4AEg4QAVlLBUlCQBLjJCCisQBXh6Bfh0QCCikCciMIAWgQQgfgtgNgYQgZguAKgkQALgkAogPQA6gRA0A2QAmAiAWAqIAUgIQBugqB0gJQBbgIBRAwQB2BvibC0IGeibQBHgaBMAAQBLAOAJBcQBpA+B/hdQBwgvBuBGQAlA6gtA/QglA7hEAmQgUAKgHAVQADAeArgHQDXgODOhEQB3gnBzAxQBBBQhDBzQBXgLBXATQBSAjgJBrQBbgEBWgaQBagLBMA8QAhAoAPAzQAaArAdAnQAlBShQBNQBPAig7B8QgKBNACBOQgdBMhZAZQhMAkg8A4QBCAEA7AhQA1AngFBLQgUBKhaAMQhNAahBAsQAgBZhrBFQhRAxhjAHQjYA2jAB9QjqB1j6BPQizA4i8ATQh9AHh9gNIoBgkQiugNirgfQiJgiiChAQgzA1g7AqQjLCcjmB0QhdAvhiAnQhpA6hmBBQirBMi8AdQkUA9kaAAIhJgBg");
	this.shape_401.setTransform(768.1787,536.7234);

	this.shape_402 = new cjs.Shape();
	this.shape_402.graphics.f("#232323").s().p("A7nZlQjdgcjNhmQjvhfjih7QhVg2hLhFQhahXhGhpIijjcQg2hJgxhOQh+jcgckGQgRhOAMhPQAfhcBrgmQB5g4CJgKQCogOCbBNQA3AkAvAwIBgBTQA9A/ApBQQCuEUDsDiQBFA+BKA3QB3BYCIA7QBJAcBMAOQClAeCngZQAxgRAtgUQBJggBFgsQBIguCcg2QCIg0BfgtIAGgEQBDgnBeg8IASgMQgSgxggg1QgghKAChRQgCg4AFg4QATlLBRlDQBKjKCAisQBWh7Beh1QCBikCbiOIAWgQQgegtgOgXQgZguAKgkQAKglAogOQA6gRA0A1QAnAiAWAqIATgJQBvgrB0gKQBbgJBRAxQB3BuiaC1IGcieQBIgbBMgBQBLAPAJBbQBqA9B+heQBwgvBuBFQAlA6gsA/QgkA7hEAmQgUAMgHAUQADAeArgIQDXgPDOhGQB2gnBzAwQBCBPhCB0QBXgMBXATQBSAigIBrQBbgEBWgbQBagLBMA7QAiAoAPAyQAaArAeAnQAlBShQBOQBQAhg6B8QgKBNADBOQgcBMhZAbQhNAlg7A4QBCADA7AhQA2AlgFBMQgUBKhaANQhMAahBAsQAhBahqBFQhSAxhiAIQjYA4i/B+QjpB4j6BQQiyA5i8AUQh9AJh+gNIoBghQitgLisgeQiJghiCg/QgzA1g7AqQjKCejlB2QhdAvhhAoQhoA6hlBFQioBRi8AhQkyBMk7AAIgIAAg");
	this.shape_402.setTransform(766.5599,538.3942);

	this.shape_403 = new cjs.Shape();
	this.shape_403.graphics.f("#232323").s().p("Egh2AYAQjwhajmh1QhWg0hNhDQhchUhIhoIipjYQg3hHgzhNQiEjZgjkFQgShOAKhQQAdhcBqgpQB3g7CJgMQCngTCdBJQA5AkAvAuIBiBQQA/A+ArBPQC0EPDyDdQBGA8BMA1QB5BVCKA3QBJAbBNAMQCkAbCngeQAxgSAsgVQBJgjBDgtQBHgvChg6QCKg2BgguIAGgEQBDgnBeg+IASgLQgSgxgig1QgghJABhSQgBg4AEg4QAQlLBQlDQBIjLB/itQBVh7Beh2QB/ilCbiPIAWgQQgggtgOgXQgZguAKgkQAKgkAogPQA6gSA0A1QAnAiAWApIAUgIQBugsB0gLQBbgJBRAvQB4BviZC1IGcihQBGgbBNgBQBLANAKBcQBqA8B+heQBwgxBuBFQAmA6gsA/QgkA7hEAnQgUALgHAVQADAcAsgHQDWgQDOhIQB2goBzAwQBDBOhCB1QBXgMBXASQBTAhgIBrQBagFBXgbQBagNBMA8QAiAnAQAyQAbArAdAnQAmBRhPBPQBQAhg6B8QgIBNADBOQgcBNhZAbQhMAmg6A3QBCADA7AgQA2AmgFBLQgTBLhaANQhMAbhAAtQAgBYhpBHQhRAxhiAJQjYA5i+CAQjoB5j6BSQixA6i8AWQh9AJh+gMIoBgdQiugJisgeQiJggiCg+QgzA2g6AqQjJCfjkB4QhdAwhhAoQhnA8hiBJQinBVi7AlQk0BUk/AHQjegXjPhgg");
	this.shape_403.setTransform(765.0171,540.0968);

	this.shape_404 = new cjs.Shape();
	this.shape_404.graphics.f("#232323").s().p("EghbAYdQjzhUjohwQhXgyhPhBQhehRhLhnIitjUQg6hFg0hMQiJjVgpkFQgUhOAHhPQAbhdBpgrQB2g/CJgPQCmgXCfBFQA5AjAxAsQAzAmAxAoQBAA9AtBNQC7ELD3DXQBHA6BNAzQB7BTCLAzQBLAaBMAKQCmAWCmghQAwgUAsgWQBIglBCguQBGgxCkg9QCOg5BggvIAGgEQBEgnBcg/IASgLQgSgxgig1QghhJABhRQgCg4AEg5QAOlLBOlEQBGjKB+ivQBUh7Bdh2QB+inCaiQIAWgQQgggtgOgXQgagtAKglQAKgkAogPQA6gSA0A0QAnAhAXAqIATgIQBugtB0gMQBbgJBSAuQB4BtiXC3IGaijQBGgcBNgCQBLANALBcQBqA7B9hfQBvgyBvBEQAnA6gsBAQgjA7hEAnQgTALgHAVQADAdArgHQDXgSDNhJQB2gpBzAvQBDBOhBB1QBXgOBYASQBSAhgHBrQBbgGBWgcQBagMBNA6QAiAnAQAzQAbArAeAmQAmBRhOBPQBPAgg4B9QgIBNAEBOQgcBNhYAbQhMAng6A5QBCADA7AeQA2AmgEBLQgSBKhaAPQhMAbhAAtQAhBZhoBHQhRAxhjAKQjXA7i9CBQjnB7j5BTQixA8i8AXQh9AKh9gMIoCgZQiugJisgcQiJgeiDg+QgzA2g6ArQjICgjjB6QhcAxhhAoQhmA/hgBLQilBZi5AqQkyBck/AOQjfgRjRhbg");
	this.shape_404.setTransform(763.5562,541.7952);

	this.shape_405 = new cjs.Shape();
	this.shape_405.graphics.f("#232323").s().p("Egg/AY5Qj1hOjrhqQhZgvhQg/QhghQhNhlIiyjPQg7hFg3hJQiPjTgvkDQgVhNAFhQQAYhfBogtQB1hACIgTQClgbChBBQA6AhAyArQA0AlAyAnQBCA6AvBNQDBEHD8DQQBJA5BOAxQB+BPCMAxQBKAXBNAIQCmASClglQAwgUArgYQBHgmBCgwQBEgzCphAQCQg8BhgwIAGgEQBDgoBdg/IASgLQgUgyghg0QgihIABhSQgCg4ADg4QAMlLBLlFQBEjMB+iuQBTh9Bch2QB9inCYiRIAWgRQgggsgOgXQgaguAJgkQAKgkAogQQA6gTA0A1QAnAhAYApIATgIQBuguBzgMQBbgLBSAuQB5BsiVC5IGYinQBHgcBMgDQBLANAMBcQBqA6B9hgQBvgyBvBDQAnA5grBAQgjA8hEAoQgSALgHAVQADAdArgIQDWgTDNhLQB1gqB1AvQBDBNhAB1QBXgNBXARQBTAggGBrQBbgGBWgdQBZgNBNA6QAjAnARAyQAaArAfAmQAnBRhOBPQBQAgg4B9QgHBOAEBNQgbBNhYAcQhMAng6A6QBCACA8AfQA2AkgDBLQgSBLhaAPQhMAbg/AuQAiBZhpBHQhQAzhiAKQjXA8i8CDQjnB8j4BVQixA9i7AYQh9ALh+gKIoCgWQitgHitgbQiKgeiDg9QgyA2g6AsQjGCijjB7QhcAxhgAqQhlA/heBPQiiBdi5AvQkvBjk/AWQjfgLjThXg");
	this.shape_405.setTransform(762.169,543.459);

	this.shape_406 = new cjs.Shape();
	this.shape_406.graphics.f("#232323").s().p("EggjAZWQj2hIjuhlQhagthRg9QhihNhQhjIi4jLQg8hDg5hIQiTjPg2kCQgYhNAEhQQAWhfBngwQBzhDCIgWQCkgfCjA8QA6AgAzAqQA1AkAzAmQBDA5AxBLQDHECECDKQBKA3BPAvQCABNCNAtQBLAVBNAGQCnAPCkgqQAvgWArgYQBGgoBAgyQBDg0CshEQCTg+BjgyIAGgDQBDgpBbg/IASgMQgTgxgig0QgihJAAhRQgDg4ADg5QAKlKBIlGQBEjMB8ivQBSh9Bbh4QB8ioCYiSIAVgQQgggsgOgXQgaguAIgkQAKgkAngQQA6gUA1A1QAoAgAXAqIAUgJQBtguBzgOQBbgKBTAtQB5BsiUC4IGYipQBGgdBMgDQBLAMANBcQBqA6B8hhQBvgzBwBCQAnA5grBBQgiA8hEAoQgSALgHAVQAEAdAqgIQDXgVDMhMQB1grB0AuQBEBNg/B2QBXgOBXAQQBUAfgGBsQBbgIBVgdQBagNBNA5QAkAnAQAyQAbAqAfAmQAnBRhNBQQBRAfg3B+QgIBNAFBOQgaBNhYAdQhLAng6A6QBCACA8AfQA2AkgCBLQgRBKhaAQQhMAcg/AuQAiBYhoBJQhPAzhjALQjWA9i8CEQjlB+j4BXQiwA+i7AaQh9ALh+gJIoCgTQiugGisgZQiKgdiEg8QgyA3g5AsQjFCjjiB8QhcAyhgAqQhkBBhbBSQihBhi3AzQksBrk+AeQjggGjVhRg");
	this.shape_406.setTransform(760.827,545.1359);

	this.shape_407 = new cjs.Shape();
	this.shape_407.graphics.f("#232323").s().p("EggHAZyQj4hCjwhfQhbgqhTg8QhkhLhShgIi8jHQg/hCg6hGQiZjLg7kBQgahMAChQQAUhfBlgzQByhHCHgaQCjgiCkA5QA8AeA0ApIBpBHQBFA3AyBKQDPD9EGDEQBLA1BQAtQCBBKCPApQBMAUBNAEQCmAKCjgtQAwgXApgaQBFgpA/gzQBCg3CwhHQCWhBBjgzIAGgDQBCgpBchAIASgMQgUgxgig0QgjhIAAhSQgEg4ADg4QAHlLBHlGQBCjMB7ixQBSh+Bah3QB6ipCXiTIAVgRQgggsgPgXQgagtAJgkQAJglAngQQA5gTA2AzQAoAhAYApIATgJQBtgvBzgOQBagLBUAsQB6BriTC6IGXisQBGgdBMgEQBLALANBcQBsA5B6hiQBvgzBwBBQAoA5grBBQgiA8hDAoQgSAMgHAVQAEAcArgIQDWgWDLhNQB1gsB1AtQBEBMg+B3QBXgPBXAQQBUAfgFBrQBbgIBVgeQBZgOBOA5QAkAmARAyQAcAqAeAmQAoBRhNBQQBRAfg2B+QgGBNAFBOQgaBNhYAdQhLApg5A6QBCABA8AfQA3AkgCBKQgRBLhaAQQhMAdg+AuQAiBYhnBJQhPA0hiAMQjXA/i6CFQjkB/j4BZQivBAi7AaQh9AMh+gIIoCgPQiugFitgYQiKgciEg7QgyA3g4AtQjFCjjgB/QhcAyhgArQhiBChZBWQieBli2A4QkqBxk9AmQjgAAjXhMg");
	this.shape_407.setTransform(759.5765,546.8288);

	this.shape_408 = new cjs.Shape();
	this.shape_408.graphics.f("#232323").s().p("A/qaOQj6g7jyhaQhcgohUg5QhmhJhUheIjCjCQhAhAg7hGQiejHhCj/QgchLAAhRQAShgBkg1QBvhKCHgcQCjgnClA1QA8AdA1AnIBrBFQBGA2A0BJQDVD3ELC+QBMAzBSArQCCBGCQAmQBMASBOACQCmAHCigyQAugYAqgbQBDgqA+g2QBBg3C0hLQCYhFBlgzIAFgEQBCgqBchAIARgMQgTgwgkg0QgihIgChSQgDg4ACg4QAFlLBElGQBBjOB5ixQBRh+BZh4QB6iqCViUIAWgRQghgsgPgXQgbgtAJgkQAJglAngQQA6gUA2AzQAoAhAYApIATgJQBsgwB0gPQBagMBTAsQB7BpiRC8IGVivQBFgeBNgEQBLALAOBcQBsA4B6hjQBug0BxBAQAoA5gqBBQgiA8hCApQgUAMgGAVQAEAdArgJQDWgYDLhOQB1gtB1AsQBFBMg+B3QBXgPBYAPQBTAfgEBrQBagJBWgeQBZgPBPA4QAjAnASAxQAcAqAfAmQAoBQhMBRQBRAeg1B+QgGBOAFBNQgYBOhZAeQhKAog5A7QBCABA9AeQA3AkgCBLQgRBKhZARQhMAdg+AvQAkBYhnBKQhPA0hjAMQjVBBi6CGQjjCBj3BaQivBBi7AcQh9ANh+gHIoCgLQiugEitgXQiKgbiEg6QgyA3g4AtQjECmjfB/QhbA0hgArQhhBEhWBYQicBpi1A8QkmB5k9AtIggABQjPAAjJhCg");
	this.shape_408.setTransform(758.3676,548.4751);

	this.shape_409 = new cjs.Shape();
	this.shape_409.graphics.f("#232323").s().p("A/NapQj7g2j1hSQhdgmhWg4QhnhFhXhdIjGi9QhBg/g+hEQiijDhIj9QgdhLgDhQQAPhgBjg4QBuhNCGggQChgqCnAxQA9AbA2AmIBtBCQBHA1A2BHQDaDzEQC2QBNAxBTAqQCFBDCQAiQBMAQBOAAQCmADChg2QAtgZApgcQBDgtA9g2QA/g5C4hPQCbhHBlg1IAGgEQBBgqBbhBIASgMQgUgxgkgzQgkhIgBhSQgFg3ADg5QAClLBClHQA/jMB5izQBQh/BYh5QB5irCUiVIAVgRQghgrgPgXQgbgsAJglQAIglAngRQA6gUA2AzQAoAgAYApIAUgJQBsgxBzgPQBagOBUAtQB8BoiRC8IGUixQBGgfBNgEQBKAKAPBcQBsA3B6hjQBtg1ByA/QAoA5gqBBQghA9hCApQgTAMgGAVQAEAdArgJQDWgaDKhQQB1gtB1ArQBFBMg9B3QBXgQBYAPQBUAdgEBsQBagJBWgfQBZgQBPA4QAjAmATAyQAcApAfAmQApBPhMBSQBRAeg0B/QgGBNAHBOQgZBNhXAfQhKApg5A7QBCAAA9AeQA3AjgBBMQgQBKhaARQhLAeg+AvQAkBYhmBKQhOA2hjAMQjVBCi4CIQjjCCj2BcQiwBCi6AeQh9ANh+gGIoCgIQiugCitgWQiKgaiFg5QgxA3g4AuQjCCmjfCCQhbA0hfAsQhgBFhUBcQiZBsizBBQkjCAk8A1Ig7ABQjAAAi+g4g");
	this.shape_409.setTransform(757.2665,550.185);

	this.shape_410 = new cjs.Shape();
	this.shape_410.graphics.f("#232323").s().p("A/TadQj7g7jyhXQhdgnhUg5QhnhHhVhfIjCjAQhBhAg8hFQifjGhEj/QgbhLgBhQQAQhgBkg2QBvhKCGgeQCjgpCmA1QA8AcA1AnIBsBEQBGA2A1BIQDVD2ENC8QBNAzBSAqQCDBFCQAlQBMASBOACQCmAECigyQAugZApgaQBEgsA9g1QBAg4CxhMQCVhGBjg1IAGgEQBBgrBahCIARgNQgUgwgkgzQgkhIgDhRQgEg4ABg4QgBlLA/lHQA9jOB3i0QBOh/BYh6QB2isCTiXIAWgRQgigrgPgXQgbgsAHglQAJgkAngSQA5gUA2AyQApAgAZAoIATgJQBrgyBzgRQBbgNBUArQB9BniPC+IGSi2QBFgfBNgFQBLAKAQBbQBsA3B5hmQBtg2ByA/QAoA4goBCQghA8hCArQgSAMgHAVQAFAdArgKQDVgbDKhSQB0gvB1AqQBHBLg8B4QBXgRBYAOQBTAdgCBrQBagKBWgfQBYgRBQA3QAkAlASAyQAdAqAgAlQApBPhKBSQBRAegzB+QgFBOAHBNQgXBOhYAgQhKAqg3A7QBCAAA8AdQA4AjgBBLQgPBMhZARQhLAeg9AwQAlBXhmBMQhOA2hiANQjUBFi4CJQjhCEj1BfQivBEi6AfQh8APh+gFIoDgDQiuAAitgVQiKgYiGg4QgwA4g4AuQjBCpjdCDQhaA1hfAtQhhBFhWBYQiaBqi1A9QkmB7k8AwIgkABQjNAAjHg/g");
	this.shape_410.setTransform(758.0852,549.5364);

	this.shape_411 = new cjs.Shape();
	this.shape_411.graphics.f("#232323").s().p("A/ZaPQj5g+jyhcQhbgphUg6QhlhKhThfIi/jEQhAhBg7hGQicjJg+kAQgbhLABhRQAShgBlgzQBwhJCHgbQCjgmClA4QA8AdA0AoIBrBGQBFA3AzBJQDSD6EJDAQBMA0BRAsQCCBICPAnQBMATBNADQCnAICigwQAvgYAqgZQBDgrA/g0QBBg3CphKQCQhEBhg1IAFgEQBBgsBZhDIASgMQgVgwglgzQgkhHgEhSQgFg3ABg5QgElLA7lIQA8jOB1i1QBMiABXh7QB1itCRiYIAVgRIgxhCQgcgsAIglQAHgkAngSQA5gVA3AyQAqAfAYAoIATgJQBsgzBygSQBagPBVArQB+BmiNC/IGRi6QBFgfBMgGQBLAIAQBcQBuA1B3hmQBtg3ByA9QBTBvizBzQgTAMgFAWQAEAcArgKQDVgdDJhUQBzgwB3ApQBGBKg6B4QBWgRBZANQBUAcgBBrQBagLBUggQBZgRBQA1QAkAmAUAxQAcAqAgAkQArBPhKBTQBRAcgxCAQgEBNAIBOQgXBOhXAgQhKArg3A8QBCgBA9AdQA5AigBBLQgOBMhZATQhLAeg9AwQAnBXhlBNQhOA3hiAOQjUBGi2CMQjgCGj0BiQitBFi7AhQh8AQh+gEIoCADQiuABiugTQiKgXiHg3QgvA5g4AuQi/CrjcCFQhZA2hfAuQhhBFhYBVQicBoi2A6QkoB2k9AqIgPAAQjYAAjQhHg");
	this.shape_411.setTransform(758.9467,548.9164);

	this.shape_412 = new cjs.Shape();
	this.shape_412.graphics.f("#232323").s().p("A/faCQj4hCjwhgQhagshTg7QhkhLhShhIi7jHQg+hCg6hIQiYjLg7kBQgZhMAChQQAUhfBmgzQBxhHCIgZQCjghCkA6QA8AdAzAqQA2AjAzAkQBFA5AyBKQDND9EGDFQBKA1BRAuQCBBJCOArQBMAUBNAEQCmALCkgtQAugXArgZQBFgpA/gzQBCg2CihIQCKhCBeg2IAFgEQBBgsBZhEIARgNQgWgvglgzQglhGgEhSQgGg3AAg5QgHlLA4lIQA5jPB1i2QBLiBBUh8QB0iuCQiZIAUgSIgyhBQgbgsAGglQAIgkAmgSQA5gWA4AxQApAfAZAoIATgKQBrgzBzgUQBagPBVApQB/BmiLDAIGOi+QBFghBMgGQBLAIASBbQBtA1B3hoQBsg4BzA8QBUBviyB0QgSAMgGAWQAFAcArgKQDUggDJhWQBzgwB2AnQBIBKg6B5QBXgTBYAMQBVAbgBBsQBagMBVghQBYgTBRA2QAlAlATAxQAdApAhAlQArBOhJBTQBSAcgxCAQgDBOAJBNQgWBOhXAhQhJAsg3A9QBCgCA+AcQA3AiACBLQgOBMhZATQhKAfg9AxQAnBXhkBNQhNA4hiAPQjTBJi0CNQjfCJjzBjQitBHi6AjQh8ASh+gDIoCAHQiuADiugRQiLgViHg2QgvA5g3AvQi8CtjcCHQhZA3heAvQhhBFhbBSQieBki2A3QkrBxk9AkQjfgBjXhNg");
	this.shape_412.setTransform(759.819,548.2948);

	this.shape_413 = new cjs.Shape();
	this.shape_413.graphics.f("#232323").s().p("A/kZ0Qj4hHjthkQhagshSg9QhjhNhPhjIi4jKQg+hDg4hIQiUjPg2kCQgYhMADhQQAWhfBngxQByhFCIgWQClgeCiA8QA7AfAzAqIBoBJQBEA6AwBLQDJEBECDKQBKA2BPAvQCABMCNAtQBLAVBOAGQCmANCkgpQAwgXAqgYQBFgoBBgyQBDg0CahGQCFhBBbg2IAGgEQBAgtBYhEIARgNQgWgvglgzQgnhGgFhSQgGg3AAg5QgLlLA1lIQA3jQBzi3QBJiCBUh8QByiwCOiaIAVgSQgjgqgQgXQgdgrAHglQAHglAngSQA4gXA4AxQAqAeAaAoIASgKQBrg0BygVQBagQBVApQCABkiJDBIGNjBQBEgiBMgHQBMAHASBbQBuAzB2hoQBrg5B0A7QBVBtixB2QgSANgGAWQAGAcAqgLQDVghDHhYQBygyB3AmQBIBJg4B5QBXgSBYAKQBVAbABBrQBZgMBUgjQBZgTBRA1QAlAlAUAwQAeApAgAkQAtBOhJBUQBSAbgvCBQgDBNAKBOQgVBOhXAiQhIAsg2A9QBCgCA9AbQA5AhACBMQgNBMhZAUQhKAhg8AxQAoBWhkBOQhMA5hiAQQjSBLizCOQjdCMjzBlQisBJi5AlQh8ATh+gCIoCANQiuAEiugPQiMgUiHg0QguA5g2AwQi8CujZCKQhZA3heAwQhiBFhcBPQigBhi3A0QktBrk+AfQjfgGjVhQg");
	this.shape_413.setTransform(760.7339,547.671);

	this.shape_414 = new cjs.Shape();
	this.shape_414.graphics.f("#232323").s().p("A/qZmQj1hLjshoQhZgvhRg+QhhhOhOhkIi1jOQg8hEg3hJQiQjRgykDQgXhNAFhQQAYhfBnguQB0hCCIgUQClgdCiBAQA6AfAyAsQA0AlAzAmQBDA6AvBMQDEEFD+DOQBJA4BPAwQB+BOCNAvQBKAYBOAGQCmARCkgnQAwgVArgYQBGgmBBgxQBFg0CShEQB/g/BZg2IAGgEQA/gtBYhGIARgNQgXgvgmgyQgnhGgGhRQgGg4gBg4QgOlLAylKQA1jPBwi5QBJiCBSh+QBwiwCNicIAUgSQgjgpgQgXQgdgrAGglQAHglAmgTQA5gXA4AwQAqAeAaAoIATgKQBqg2BygVQBagRBVAnQCBBjiHDDIGLjGQBEghBMgJQBLAGATBcQBvAxB1hpQBqg6B1A6QBVBsivB4QgSANgFAVQAFAdArgLQDUgkDGhaQBygzB4AlQBJBIg3B6QBVgUBZAKQBVAbACBrQBagOBUgjQBYgUBRA0QAmAkAUAxQAeAoAhAkQAtBOhHBVQBSAZguCBQgBBOAKBNQgVBPhWAjQhIAtg1A9QBCgDA+AbQA4AhADBLQgMBMhZAWQhJAhg8AxQAoBWhiBPQhMA5hhASQjSBMiyCRQjbCOjyBoQirBKi5AmQh8AVh+gBIoCASQiuAGiugOQiLgSiIgzQguA6g2AwQi5CwjZCMQhYA5hdAwQhjBFheBLQiiBfi4AxQkuBmk/AZQjegKjVhUg");
	this.shape_414.setTransform(761.6811,547.0525);

	this.shape_415 = new cjs.Shape();
	this.shape_415.graphics.f("#232323").s().p("A/vZZQj0hQjqhsQhZgwhPhAQhfhQhNhmIixjQQg7hGg1hKQiNjTgtkEQgWhNAHhQQAZheBogtQB1hACIgRQCmgaCgBDQA6AgAyAsQAzAmAyAnQBCA8AtBMQDAEID7DTQBHA5BOAyQB9BQCMAyQBKAYBNAIQCmAUClgkQAwgUAsgYQBHglBCgwQBFgyCLhCQB5g9BWg2IAGgFQA/gtBXhHIARgNQgXgvgngyQgnhFgHhRQgHg4gCg4QgRlLAvlKQAzjRBvi5QBHiDBRh+QBuiyCLidIAUgSQgjgpgQgXQgegqAGgmQAHglAmgTQA3gXA6AvQAqAeAaAnIATgKQBpg3BygWQBagTBWAnQCCBhiGDFIGJjJQBEgjBMgJQBLAGAUBaQBvAyB0hrQBqg7B1A4QBXBsiuB6QgSANgFAVQAGAcAqgLQDUgmDFhcQByg0B3AkQBKBIg2B6QBWgVBZAJQBVAZADBsQBagPBTgkQBYgVBSAzQAmAkAVAxQAeAoAiAkQAtBMhGBWQBSAZgsCCQgBBNALBNQgUBPhWAkQhHAug1A+QBCgEA+AaQA5AhADBLQgLBMhYAWQhKAig7AzQAqBVhiBQQhLA6hiASQjRBOiwCTQjbCQjwBqQirBMi4ApQh7AVh/ABIoBAWQiuAJiugNQiMgRiIgxQgtA6g2AxQi4CyjXCOQhXA5hdAyQhjBDhgBJQikBdi5AsQkvBhk/AUQjggOjShXg");
	this.shape_415.setTransform(762.6542,546.4471);

	this.shape_416 = new cjs.Shape();
	this.shape_416.graphics.f("#232323").s().p("A/zZKQjzhUjohwQhXgyhPhBQhehRhKhnIiujUQg5hHg1hLQiJjVgokFQgUhOAIhPQAaheBpgqQB2g+CJgQQCmgWCfBFQA5AiAxAsQAzAnAxAoQBBA9AsBNQC7ELD3DYQBHA6BNAzQB7BSCLA1QBKAZBNAKQClAWCmghQAwgTAsgXQBIgkBDguQBGgxCDhAQB0g9BUg2IAFgEQA/guBWhIIAQgNQgXgvgngxQgohFgIhRQgIg4gCg4QgUlLArlKQAxjRBti6QBHiEBPh/QBtizCJieIAUgTQgkgpgQgWQgegqAFgmQAGgkAmgUQA4gYA6AvQAqAdAbAnIASgKQBpg4BygYQBZgTBXAmQCCBgiDDGIGHjNQBDgjBMgKQBMAEAVBbQBwAwByhsQBqg8B1A4QBYBqitB8QgSANgFAVQAGAdArgMQDTgoDEheQByg1B3AjQBLBGg1B7QBWgVBYAIQBWAYAEBrQBagPBTglQBXgVBTAyQAmAjAVAxQAfAnAiAkQAuBMhFBXQBSAYgrCCQAABNAMBNQgTBPhWAlQhHAug0A/QBCgEA+AZQA6AgAEBLQgLBMhYAXQhIAjg7A0QAqBUhhBRQhLA6hhAUQjQBQivCUQjZCSjvBtQiqBOi4AqQh7AXh/ACIoBAcQiuAJiugKQiMgRiIgvQgtA6g1AyQi2C0jWCQQhXA6hcAzQhjBDhjBGQilBZi6AqQkxBbk/AOQjfgSjRhbg");
	this.shape_416.setTransform(763.6474,545.8194);

	this.shape_417 = new cjs.Shape();
	this.shape_417.graphics.f("#232323").s().p("A/3Y9QjyhZjmh0QhXgzhNhDQhdhThIhoIipjXQg5hHgzhMQiFjZgkkFQgThOAJhPQAdhdBpgpQB4g8CJgNQCmgUCeBJQA5AjAwAtIBiBQQBAA+ArBOQC1EPD0DbQBGA8BMA0QB5BVCKA2QBKAbBNALQClAaCmgeQAxgTAsgWQBIgiBEguQBGgvB8g+QBug7BSg3IAFgEQA/gwBVhHIAQgOQgYgugngxQgphEgIhSQgJg3gCg5QgYlKAolLQAvjRBri8QBFiEBOiAQBri0CIigIAUgSQglgpgQgWQgfgqAGglQAFgmAmgTQA3gZA7AvQAqAcAcAnIASgKQBog5BygZQBYgUBYAlQCDBfiBDHIGFjRQBDgkBMgKQBLAEAWBaQBwAvBxhtQBpg+B2A3QBaBpisB+QgSANgFAWQAGAcArgMQDTgqDDhgQBxg2B4AhQBLBGgzB8QBVgXBZAIQBVAXAGBrQBZgQBTgmQBXgWBTAxQAnAjAWAwQAfAoAiAjQAwBMhFBXQBSAYgpCCQAABNANBNQgTBQhVAlQhHAvgzA/QBCgFA/AZQA6AfAEBLQgJBMhYAYQhJAkg6A0QArBUhgBSQhKA7hhAVQjQBSitCWQjYCUjuBvQipBPi4AtQh7AXh+AEIoBAhQiuAKiugIQiMgPiJguQgsA7g1AyQi0C1jUCTQhWA7hcAzQhjBEhlBCQinBWi6AnQk0BVk/AJQjegVjPhfg");
	this.shape_417.setTransform(764.6722,545.1385);

	this.shape_418 = new cjs.Shape();
	this.shape_418.graphics.f("#232323").s().p("A/8YwQjwhcjkh5QhVg0hMhEQhchVhGhpIimjaQg3hJgyhMQiBjbggkGQgRhOALhPQAehcBqgoQB4g5CKgLQCmgRCdBLQA4AkAvAvIBhBRQA/A/ApBPQCxESDwDgQBEA8BMA2QB4BXCJA5QBJAcBMAMQClAdCngcQAxgSAtgUQBJgiBEgsQBHguB0g8QBog6BPg2IAGgFQA9gwBVhIIAQgOQgYgvgogwQgqhEgJhRQgJg4gDg4QgblKAllLQAtjSBpi8QBFiGBNiAQBoi1CGihIAUgTQglgogRgWQgegqAEglQAGgmAlgUQA4gYA6AtQAqAdAdAmIASgLQBng6BygaQBYgVBYAlQCFBeiADHIGDjUQBDglBLgLQBMAEAXBZQBwAvBwhvQBpg/B2A2QBaBpiqB/QgSANgEAWQAHAcAqgNQDSgsDDhhQBwg4B4AhQBMBFgyB8QBVgXBZAGQBVAWAHBsQBZgRBSgnQBXgYBUAxQAnAjAXAwQAfAnAjAjQAvBLhDBYQBSAXgoCCQABBOAOBNQgSBPhVAmQhGAwgzBAQBCgFA/AXQA6AfAGBLQgKBMhXAZQhIAkg6A1QAsBThfBUQhKA7hhAWQjOBVisCXQjWCWjtByQioBRi4AtQh7Aah+AEIoAAmQitANivgHQiMgNiKgtQgrA7g0AyQizC4jSCUQhWA8hbA1QhlBDhmA/QioBSi7AkQk2BRk+ACQjegYjOhkg");
	this.shape_418.setTransform(765.7995,544.2665);
	this.shape_418._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_388}]},718).to({state:[{t:this.shape_389}]},1).to({state:[{t:this.shape_390}]},1).to({state:[{t:this.shape_391}]},1).to({state:[{t:this.shape_392}]},1).to({state:[{t:this.shape_393}]},1).to({state:[{t:this.shape_394}]},1).to({state:[{t:this.shape_395}]},1).to({state:[{t:this.shape_396}]},1).to({state:[{t:this.shape_397}]},1).to({state:[{t:this.shape_398}]},1).to({state:[{t:this.shape_399}]},1).to({state:[{t:this.shape_400}]},1).to({state:[{t:this.shape_401}]},1).to({state:[{t:this.shape_402}]},1).to({state:[{t:this.shape_403}]},1).to({state:[{t:this.shape_404}]},1).to({state:[{t:this.shape_405}]},1).to({state:[{t:this.shape_406}]},1).to({state:[{t:this.shape_407}]},1).to({state:[{t:this.shape_408}]},1).to({state:[{t:this.shape_409}]},1).to({state:[{t:this.shape_410}]},1).to({state:[{t:this.shape_411}]},1).to({state:[{t:this.shape_412}]},1).to({state:[{t:this.shape_413}]},1).to({state:[{t:this.shape_414}]},1).to({state:[{t:this.shape_415}]},1).to({state:[{t:this.shape_416}]},1).to({state:[{t:this.shape_417}]},1).to({state:[{t:this.shape_418}]},1).to({state:[{t:this.shape_418}]},1).to({state:[{t:this.shape_418}]},1).to({state:[{t:this.shape_418}]},1).to({state:[]},1).wait(556));
	this.timeline.addTween(cjs.Tween.get(this.shape_418).wait(748).to({_off:false},0).wait(3).to({_off:true},1).wait(556));

	// Слой_69
	this.shape_419 = new cjs.Shape();
	this.shape_419.graphics.f("#232323").s().p("EhZ2AaRQgggDgYgJQgQgGgcgQQgegRgNgGQgcgMgkgFQgWgEgtgDIi9gMQkjgTiWAAQj1AAjBAkQgfAGgOABQgZADgTgCQgYgDgTgLQgWgMgKgTQgNgaAKgfQAJgeAZgUQAVgSAfgLQAWgIAlgHQDGgnD8gBQCagBEsATIC4ALQA/AEAgAGQA1AJAkAVIAnAZQAWAPASAFQAXAIArAAIEXADQAjAAAQACQAdADAUAJQAZALAQAUQARAWAAAYQgBAYgRAVQgQAUgZAKQgVAJgbACQgSACggAAIkUABQgmAAgTgBgAuoLmQhQgKhugZQhEgPiUglQgqgKgYgOQghgTgIgeQgGgaAPgZQANgYAZgNQAngVBCAGQBIAFCqAvQCZArBZgCIBCgCQAmgBAaAHQAiAJAXAZQAYAbgDAfQgCAVgPATQgOARgVAKQgeAPg5ADIgkABQhJAAhTgMgEhjMAELQgrgFgggPQgYgKghgXIg3gmIhAghQgngTgUgUQgpgngNhAQgNg+AVgsQAYgzBOgjQBGgfBegQQA7gKBwgKQAigDASAAQAdAAAXAHQAaAJASATQAUAUACAZQACAYgPAWQgOAVgXANQgTALgbAGQgRAEggAFIkTAnIACAVQBoBSCDAQIA0AFQAeAEAUAHQAaAJASATQATAUACAZQACAZgQAXQgPAWgZAMQgVAKgdADQgUADghAAQgxAAgdgDgEBHCgEiQjSghhpgOQgpgGgWgIQghgMgPgYQgTghAUgoQAUgnAmgPQAhgNAtACQAaABA1AJQD1ArD1AMQAnACAQADQAfAEAVALQAaANAPAYQAQAZgEAaQgHAjgnATQgfAQgvAEQgsAEgxAAQhkAAh7gQgEApmgGWQgUgEhCgUQjXhGjkAEQg9ABgYgDQgwgGgdgXQgqghgJhDQgGgvALhMQgmgThMAjQhRAmgmgLQgkgLgQgnQgPgnANglQANgiAggZQAegXAngLQAggJArgDIBNgBQA9gBAfAGQAyAKAaAfQAaAhAABBIABBtQCRgKCyAiQBsAVDRA7QAdAJAOAGQAXALAMAQQAZAjgZAtQgXArgtALQgTAFgWAAQgVAAgZgFgA61zMQxzg6uVjBQgagFgNgFQgUgIgLgOQgXgbAPgnQAOglAigQQAegOApAAQAaABAvAIQPYCnR0A5QOuAwSugXQKIgMXcg7QVog2L8gJQJKgHBsgDQGJgLEqgkQBMgJFLgvQD6gkCfgMQA+gFAxAWQA5AZgGAwQgGA/hxAVQmVBLoBAmQk2AWpnAXQ6FA9shAZQ1gArxIAPQmFAGlaAAQsTAAorgdg");
	this.shape_419.setTransform(920.0864,582.8528);
	this.shape_419._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_419).wait(718).to({_off:false},0).to({_off:true},34).wait(556));

	// Слой_68
	this.shape_420 = new cjs.Shape();
	this.shape_420.graphics.f().s("#FFFFFF").ss(4,1,1).p("ABblPQA1AaAtAsQBnBnAACSQAACRhnBnQhnBniRAAQiGAAhihX");
	this.shape_420.setTransform(786.7,577.65);

	this.shape_421 = new cjs.Shape();
	this.shape_421.graphics.f("#232323").s().p("AGrD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAs6E/Qg1gZgtgtQhnhnAAiSQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAQhSAAhFghg");
	this.shape_421.setTransform(840.225,570.6);

	this.shape_422 = new cjs.Shape();
	this.shape_422.graphics.f("#232323").s().p("AGqD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAq0FgQhIgDg9geQg1gZgsgsIgBgBQhmhngBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_422.setTransform(841.825,570.6);

	this.shape_423 = new cjs.Shape();
	this.shape_423.graphics.f("#232323").s().p("AGpD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqzFgQhIgDg9geQg1gZgsgsIgBgBQhmhngBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_423.setTransform(843.425,570.6);

	this.shape_424 = new cjs.Shape();
	this.shape_424.graphics.f("#232323").s().p("AGoD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqyFgQhIgDg9geIgBAAQg0gZgsgsIgBgBQhmhngBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_424.setTransform(845.025,570.6);

	this.shape_425 = new cjs.Shape();
	this.shape_425.graphics.f("#232323").s().p("AGnD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqxFgQhIgDg9geIgBAAQg0gZgsgsIgBgBQhmhngBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_425.setTransform(846.625,570.6);

	this.shape_426 = new cjs.Shape();
	this.shape_426.graphics.f("#232323").s().p("AGmD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqwFgQhIgDg9geIgBAAQg0gZgsgtIgBgBQhnhmAAiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_426.setTransform(848.225,570.6);

	this.shape_427 = new cjs.Shape();
	this.shape_427.graphics.f("#232323").s().p("AGlD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqvFgQhIgDg9geIgBAAQg0gZgsgtIgBgBQhnhmAAiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_427.setTransform(849.825,570.6);

	this.shape_428 = new cjs.Shape();
	this.shape_428.graphics.f("#232323").s().p("AGkD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAquFgQhIgDg9geIgBAAQg0gZgsgtIgBgBQhnhmAAiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_428.setTransform(851.425,570.6);

	this.shape_429 = new cjs.Shape();
	this.shape_429.graphics.f("#232323").s().p("AGjD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqtFgQhIgDg9geIgBAAQg0gZgsgtIgBgBQhnhmAAiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_429.setTransform(853.025,570.6);

	this.shape_430 = new cjs.Shape();
	this.shape_430.graphics.f("#232323").s().p("AGiD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqsFgQhIgDg9geIgBAAQg0gagsgsIgBgBQhmhmgBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_430.setTransform(854.575,570.6);

	this.shape_431 = new cjs.Shape();
	this.shape_431.graphics.f("#232323").s().p("AGhD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqrFgQhIgDg9geIgBAAQg0gagsgsIgBgBQhmhmgBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_431.setTransform(856.175,570.6);

	this.shape_432 = new cjs.Shape();
	this.shape_432.graphics.f("#232323").s().p("AGgD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqqFgQhIgDg9geIgBAAQg0gagsgsIgBgBQhmhmgBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_432.setTransform(857.775,570.6);

	this.shape_433 = new cjs.Shape();
	this.shape_433.graphics.f("#232323").s().p("AGfD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqpFgQhIgDg9geIgBAAQg0gagsgsIgBgBQhmhmgBiRIAAgBQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_433.setTransform(859.375,570.6);

	this.shape_434 = new cjs.Shape();
	this.shape_434.graphics.f("#232323").s().p("AGeD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqoFgQhIgDg9geIgBAAQg0gagsgsIgBgBQhnhmAAiSQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_434.setTransform(860.975,570.6);

	this.shape_435 = new cjs.Shape();
	this.shape_435.graphics.f("#232323").s().p("AGdD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqnFgQhIgDg9geIgBAAQg0gagsgsIgBgBQhnhmAAiSQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_435.setTransform(862.575,570.6);

	this.shape_436 = new cjs.Shape();
	this.shape_436.graphics.f("#232323").s().p("AGcD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqmFgQhIgDg9geIgBAAQg1gagsgsIgBgBQhmhmAAiSQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_436.setTransform(864.175,570.6);

	this.shape_437 = new cjs.Shape();
	this.shape_437.graphics.f("#232323").s().p("AGbD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqlFgQhIgDg9geIgBAAQg1gagsgsIgBgBQhmhmAAiSQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_437.setTransform(865.775,570.6);

	this.shape_438 = new cjs.Shape();
	this.shape_438.graphics.f("#232323").s().p("AGaD5QhnhnAAiSQAAiRBnhnQBnhnCSAAQCSAABnBnQBnBnAACRQAACShnBnQhnBniSAAQiSAAhnhngAqkFgQhIgEg9gdQg1gZgtgtQhnhnAAiSQAAiRBnhnQBnhnCSAAQCGAABiBXIARAQQBnBnAACRQAACShnBnQhnBniSAAIgSAAg");
	this.shape_438.setTransform(867.375,570.6);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_421},{t:this.shape_420}]},692).to({state:[{t:this.shape_422}]},1).to({state:[{t:this.shape_423}]},1).to({state:[{t:this.shape_424}]},1).to({state:[{t:this.shape_425}]},1).to({state:[{t:this.shape_426}]},1).to({state:[{t:this.shape_427}]},1).to({state:[{t:this.shape_428}]},1).to({state:[{t:this.shape_429}]},1).to({state:[{t:this.shape_430}]},1).to({state:[{t:this.shape_431}]},1).to({state:[{t:this.shape_432}]},1).to({state:[{t:this.shape_433}]},1).to({state:[{t:this.shape_434}]},1).to({state:[{t:this.shape_435}]},1).to({state:[{t:this.shape_436}]},1).to({state:[{t:this.shape_437}]},1).to({state:[{t:this.shape_438}]},1).to({state:[]},9).wait(590));

	// Слой_67
	this.shape_439 = new cjs.Shape();
	this.shape_439.graphics.f().s("#232323").ss(4,1,1).p("AH0AAQAADPiSCTQiTCSjPAAQjOAAiTiSQiSiTAAjPQAAjOCSiTQCTiSDOAAQDPAACTCSQCSCTAADOg");
	this.shape_439.setTransform(780.15,576.9);

	this.shape_440 = new cjs.Shape();
	this.shape_440.graphics.f("#FFFFFF").s().p("AFSFiQiTiTAAjPQAAjOCTiTQCTiSDPAAQDOAACTCSQCTCTAADOQAADPiTCTQiTCSjOAAQjPAAiTiSgAwUFiQiSiTAAjPQAAjOCSiTQCSiSDPAAQDQAACSCSQCTCTAADOQAADPiTCTQiSCSjQAAQjPAAiSiSg");
	this.shape_440.setTransform(849.3,576.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_440},{t:this.shape_439}]},692).to({state:[]},26).wait(590));

	// Слой_66
	this.instance_18 = new lib.ЫИЫВПМ67();
	this.instance_18.setTransform(1294.7,279,0.7457,0.7457,0,0,180);

	this.shape_441 = new cjs.Shape();
	this.shape_441.graphics.f().s("#232323").ss(4,1,1).p("AIUAAQAADcicCcQicCcjcAAQjbAAicicQibicAAjcQAAjbCbicQCcibDbAAQDcAACcCbQCcCcAADbg");
	this.shape_441.setTransform(794.8,558.05);

	this.shape_442 = new cjs.Shape();
	this.shape_442.graphics.f("#FFFFFF").s().p("Al3F4QibicAAjcQAAjbCbicQCcicDbAAQDcAACbCcQCdCcAADbQAADcidCcQibCbjcAAQjbAAicibg");
	this.shape_442.setTransform(794.8,558.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_442},{t:this.shape_441},{t:this.instance_18}]},692).to({state:[]},26).wait(590));

	// Слой_65
	this.instance_19 = new lib.фоны_фонстол2copy5();
	this.instance_19.setTransform(-25,-234,0.3583,0.3583);
	this.instance_19._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_19).wait(692).to({_off:false},0).to({_off:true},26).wait(590));

	// Слой_116
	this.shape_443 = new cjs.Shape();
	this.shape_443.graphics.f("#232323").s().p("AiaCQQAAgrBhhYIANgNQg4hTAAguQAAgoAiAAQAKAAAEAIQAEAIADAeQAEAtAjAyQBNhDAcg2QAJgRAFgEQAFgFAJAAQAKAAAJAIQAJAIAAAMQAAAdiKB+QAvA8A2AeIAMAIQACADAAAFQAAAMgJAKQgJAJgNAAQgmAAhShtQhAA3gVA5QgIASgIAKQgigCAAgeg");
	this.shape_443.setTransform(507.325,240.625);

	this.shape_444 = new cjs.Shape();
	this.shape_444.graphics.f("#232323").s().p("AihD5QgMgJAAgFQABgQAGgcQA1jPAAifIAAgYQgBgeALgOQALgOAPAAQAHAAAGAKQAGALAAAUQAAAbgFAnIgIA5QAqhKAvgpQAvgqAoAAQAdAAAUAWQATAVAAAgQAABchHBMQhGBKhCAAQgRAAgKgJQgJgIgLgWQgOAzgMBcIgIA1QgCALgIAMQgJALgHAAQgJAAgLgJgAgEh8Qg7BKAAAqQAAAJAMAKQALAKASgBQAoABA0g8QA1g7AAg7QAAgUgJgLQgIgMgNABQgngBg6BMg");
	this.shape_444.setTransform(471.8,248.7);

	this.shape_445 = new cjs.Shape();
	this.shape_445.graphics.f("#232323").s().p("AhrDJQgrgeAAgUQAAgJAFgJQAEgJAGAAQAEAAAEAFQAlA5BNAAQAwAAAZg8QAYg8AGhdQgqAogrAXQgrAXgXAAQgaAAgPgXQgRgWABggQAAgwAShBQAShCAKgIQAJgJARAAQAHAAAFAKQAGAKAAAKQgBAHgGAMQglBAAABFQAAAPAGANQAFALANAAQAPAAAXgJQAWgJAdgWQAcgVAKgOQAKgNAFgRQAEgRABg5QABg4AaAAQAQAAAEAIQAFAIAAAWQAAARgGA5IgBAYQgICWglBWQglBVhGAAQg3AAgsgcg");
	this.shape_445.setTransform(435.75,247.525);

	this.shape_446 = new cjs.Shape();
	this.shape_446.graphics.f("#232323").s().p("ACsB8QgNgdAAg6IAAgJIABgJQglA8gmAiQgmAiggAAQgSAAgTgXQgUgVAAgtQAAgYAFgcQgbA2gqAmQgqAmghAAQgQAAgTgTQgTgSAAggQAAgkADgTIAFghIAEgbQALg9gDgSQAGgTAWAAQAIgBAIAIQAIAGAAAQQAAAagLAnQgQA0AAAoQAAAWADANQAEALALABQAlAAAvhDQAvhBAbhIQANghARABQAMgBAHAJQAHAIAAAJQAAAUgOAlQgaBFAAAxQAAAvAVgBQAKABAOgIQAOgHAVgUQAUgVAUgeQAUgeAFgNIAVhCQAJggAJgMQAIgMAOAAQATAAAAAZQAAADgGASQgIAcgFApQgFApAAAbQAABCAVAUQAMAKAAAHQAAAIgMAHQgLAGgJAAQgUAAgMgeg");
	this.shape_446.setTransform(393.575,240.55);

	this.shape_447 = new cjs.Shape();
	this.shape_447.graphics.f("#232323").s().p("AgbAeQgFgGgBgYQAAgVADgEQACgFAKgCQAKgCAQAAIAGAAQAGAAAGAFQAIAEAAAJQAAAQgHAIQgFAIgOAJQgMAKgFAAQgMAAgGgFg");
	this.shape_447.setTransform(359.7,250.475);

	this.shape_448 = new cjs.Shape();
	this.shape_448.graphics.f("#232323").s().p("AgbAeQgFgGAAgYQgBgVADgEQADgFAJgCQAKgCAQAAIAGAAQAGAAAGAFQAIAEgBAJQAAAQgFAIQgHAIgNAJQgMAKgFAAQgMAAgGgFg");
	this.shape_448.setTransform(345.15,250.475);

	this.shape_449 = new cjs.Shape();
	this.shape_449.graphics.f("#232323").s().p("AiaCQQAAgrBhhYIANgNQg4hTAAguQAAgoAiAAQAKAAAEAIQAEAIADAeQAEAtAjAyQBNhDAcg2QAJgRAFgEQAFgFAJAAQAKAAAJAIQAJAIAAAMQAAAdiKB+QAvA8A2AeIAMAIQACADAAAFQAAAMgJAKQgJAJgNAAQgmAAhShtQhAA3gVA5QgIASgIAKQgigCAAgeg");
	this.shape_449.setTransform(322.325,240.625);

	this.shape_450 = new cjs.Shape();
	this.shape_450.graphics.f("#232323").s().p("AihD5QgLgJAAgFQgBgQAIgcQA0jPgBifIAAgYQgBgeAMgOQAMgOAOAAQAHAAAGAKQAHALAAAUQgBAbgFAnIgIA5QAqhKAugpQAwgqApAAQAcAAATAWQAVAVgBAgQAABchGBMQhIBKhCAAQgQAAgKgJQgKgIgKgWQgOAzgMBcIgIA1QgCALgJAMQgIALgHAAQgJAAgLgJgAgEh8Qg7BKAAAqQAAAJALAKQAMAKASgBQAoABA0g8QA1g7AAg7QAAgUgIgLQgJgMgMABQgogBg6BMg");
	this.shape_450.setTransform(286.8,248.7);

	this.shape_451 = new cjs.Shape();
	this.shape_451.graphics.f("#232323").s().p("AhqDJQgsgeAAgUQAAgJAEgJQAFgJAHAAQADAAAEAFQAlA5BNAAQAwAAAYg8QAZg8AHhdQgsAogrAXQgqAXgWAAQgbAAgQgXQgQgWAAggQABgwAShBQAShCAKgIQAKgJAPAAQAIAAAGAKQAEAKAAAKQABAHgHAMQglBAAABFQAAAPAFANQAHALAMAAQAQAAAWgJQAWgJAcgWQAdgVAKgOQAKgNAFgRQADgRACg5QABg4AbAAQAPAAAEAIQAFAIAAAWQAAARgFA5IgBAYQgJCWglBWQglBVhGAAQg3AAgrgcg");
	this.shape_451.setTransform(250.75,247.525);

	this.shape_452 = new cjs.Shape();
	this.shape_452.graphics.f("#232323").s().p("ACsB8QgNgdAAg6IAAgJIABgJQglA8gmAiQgmAiggAAQgSAAgTgXQgUgVAAgtQAAgYAFgcQgbA2gqAmQgqAmghAAQgQAAgTgTQgTgSAAggQAAgkADgTIAFghIAEgbQALg9gDgSQAGgTAWAAQAIgBAIAIQAIAGAAAQQAAAagLAnQgQA0AAAoQAAAWADANQAEALALABQAlAAAvhDQAvhBAbhIQANghARABQAMgBAHAJQAHAIAAAJQAAAUgOAlQgaBFAAAxQAAAvAVgBQAKABAOgIQAOgHAVgUQAUgVAUgeQAUgeAFgNIAVhCQAJggAJgMQAIgMAOAAQATAAAAAZQAAADgGASQgIAcgFApQgFApAAAbQAABCAVAUQAMAKAAAHQAAAIgMAHQgLAGgJAAQgUAAgMgeg");
	this.shape_452.setTransform(208.575,240.55);

	this.shape_453 = new cjs.Shape();
	this.shape_453.graphics.f().s("#232323").ss(4,1,1).p("EAlQgApQAAHzp7FhQp6Fhu7A6Qu6A6s0ioQs1inA4rMQA3rLLrlyQLslxPLgKQPNgLJ6FhQJ7FhAAHzg");
	this.shape_453.setTransform(368.063,230.1017);

	this.shape_454 = new cjs.Shape();
	this.shape_454.graphics.f("#FFFFFF").s().p("A5ORYQs1inA4rMQA3rLLrlyQLslxPLgKQPNgLJ6FhQJ7FhAAHzQAAHzp7FhQp6Fhu7A6Qj0APjtAAQqsAAphh9g");
	this.shape_454.setTransform(368.063,230.1017);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_454},{t:this.shape_453},{t:this.shape_452},{t:this.shape_451},{t:this.shape_450},{t:this.shape_449},{t:this.shape_448},{t:this.shape_447},{t:this.shape_446},{t:this.shape_445},{t:this.shape_444},{t:this.shape_443}]},718).to({state:[]},34).to({state:[]},500).wait(56));

	// Слой_115
	this.shape_455 = new cjs.Shape();
	this.shape_455.graphics.f("#232323").s().p("AiQEKQgMgKAAgRQAAgNAXgPIAIgGQAHgGANAAQAIAAAQAMQAZAAAAAVQAAASgWANQgVANgQAAQgRAAgMgKgAhrBtQgDgPAAgGQAAgZAcg2IAEgIQAZgXBHgaIArgQQAUgJALgVQALgVAAgTQAAgMgHgcQgHgdgVgIQgVgIgUAAQgpAAgUALQgTAMgCAOQgDARgUAFQgKACgKAAQgUAAAAgVQAAgdArggQArghAcAAIAvgCQAigBAVAOQAWANASAVQATAUAAA9QAAA0gTAfQgTAegeAQQgeAPheAeQgMAggHAjQgEARgLAGQgMAGgVAAQgDAAgCgOg");
	this.shape_455.setTransform(618.125,321.8427);

	this.shape_456 = new cjs.Shape();
	this.shape_456.graphics.f().s("#232323").ss(2,1,1).p("APiAAQAAE4kjDdQkkDcmbAAQmaAAkkjcQkjjdAAk4QAAk3EjjdQEkjcGaAAQGbAAEkDcQEjDdAAE3g");
	this.shape_456.setTransform(608.4,331.3);

	this.shape_457 = new cjs.Shape();
	this.shape_457.graphics.f("#FFFFFF").s().p("Aq+IVQkjjdAAk4QAAk3EjjdQEjjcGbAAQGbAAEkDcQEjDdAAE3QAAE4kjDdQkkDcmbAAQmbAAkjjcg");
	this.shape_457.setTransform(608.4,331.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_457},{t:this.shape_456},{t:this.shape_455}]},686).to({state:[]},6).to({state:[]},560).wait(56));

	// ПАКЕТ
	this.instance_20 = new lib.Анимация37("synched",0);
	this.instance_20.setTransform(1731,379.7);
	this.instance_20._off = true;

	this.instance_21 = new lib.Анимация38("synched",0);
	this.instance_21.setTransform(1294,444.7);
	this.instance_21._off = true;

	this.instance_22 = new lib.Анимация39("synched",0);
	this.instance_22.setTransform(1012,316.7);
	this.instance_22._off = true;

	this.instance_23 = new lib.Анимация40("synched",0);
	this.instance_23.setTransform(322.55,249.55);
	this.instance_23._off = true;

	this.instance_24 = new lib.Анимация41("synched",0);
	this.instance_24.setTransform(648.95,40.6);
	this.instance_24._off = true;

	this.instance_25 = new lib.Анимация42("synched",0);
	this.instance_25.setTransform(1233.55,154.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_20}]},678).to({state:[{t:this.instance_21}]},7).to({state:[{t:this.instance_22}]},6).to({state:[{t:this.instance_23}]},1).to({state:[{t:this.instance_24}]},9).to({state:[{t:this.instance_25}]},8).to({state:[]},9).wait(590));
	this.timeline.addTween(cjs.Tween.get(this.instance_20).wait(678).to({_off:false},0).to({_off:true,x:1294,y:444.7},7).wait(623));
	this.timeline.addTween(cjs.Tween.get(this.instance_21).wait(678).to({_off:false},7).to({_off:true,x:1012,y:316.7},6).wait(617));
	this.timeline.addTween(cjs.Tween.get(this.instance_22).wait(685).to({_off:false},6).to({_off:true,x:322.55,y:249.55},1).wait(616));
	this.timeline.addTween(cjs.Tween.get(this.instance_23).wait(691).to({_off:false},1).to({_off:true,x:648.95,y:40.6},9).wait(607));
	this.timeline.addTween(cjs.Tween.get(this.instance_24).wait(692).to({_off:false},9).to({_off:true,x:1233.55,y:154.2},8).wait(599));

	// Каркас_23
	this.shape_458 = new cjs.Shape();
	this.shape_458.graphics.f("#232323").s().p("ApUFZQhKgeg5g5Qg3hOAOhpQgDhgAvhZQBPhaCHBeQAzA4gJBUQgEAWAJAUQAPATAggHQAxADAvAXQELBYDzjiQBThdA5hwQAuhBA5g2IAJgIQA0gwBBgdQBBgXBHAaQA8AfAPBKQAKBEgvA5QglArgzAdQgwAogiA4QhiCRhuCJQhAA3hNAjQhEAihGAaQggALggAIQhlAahnAAQjJAAjLhkg");
	this.shape_458.setTransform(960.2447,586.0742);

	this.shape_459 = new cjs.Shape();
	this.shape_459.graphics.f("#232323").s().p("ApYFWQhKgeg5g5Qg4hNAPhpQgChhAthYQBPhcCHBfQAzA4gJBUQgDAVAIAVQAQATAfgHQAzACAuAYQELBYD3jjQBUhcA8hvQAuhAA6g0IAKgJQA0gtBCgdQBCgXBGAcQA8AgANBLQAJBDgwA5QgmAqgzAcQgxAngjA3QhkCPhxCIQhBA2hNAhQhDAihFAaIhAATQhmAahnAAQjJAAjKhjg");
	this.shape_459.setTransform(960.6463,586.3764);

	this.shape_460 = new cjs.Shape();
	this.shape_460.graphics.f("#232323").s().p("ApcFTQhKgeg5g5Qg4hMAOhqQgChgAthZQBPhbCIBeQAyA4gIBUQgDAVAIAVQAQATAfgHQAyABAvAYQELBXD7jiQBWhbA9htQAwg/A7g0IAJgIQA2gtBBgbQBEgWBFAeQA7AfAMBMQAIBDgxA4QgnAqgzAbQgyAmgkA3QhnCNhzCGQhBA0hNAgQhEAghDAbIg/AUQhnAahoAAQjIAAjKhig");
	this.shape_460.setTransform(961.0473,586.684);

	this.shape_461 = new cjs.Shape();
	this.shape_461.graphics.f("#232323").s().p("ApgFRQhKgfg5g4Qg4hNAOhpQgDhhAthYQBPhcCHBeQAzA4gIBUQgDAVAIAVQAQATAfgIQAzADAuAXQELBXEAjjQBXhZA/htQAxg+A8gyIAJgIQA2gsBDgaQBDgUBFAeQA6AiALBLQAHBDgyA3QgoApg0AaQgyAmglA1QhpCMh2CDQhCAzhMAfQhEAfhBAcIg/AUQhoAahoAAQjIAAjJhgg");
	this.shape_461.setTransform(961.4776,586.996);

	this.shape_462 = new cjs.Shape();
	this.shape_462.graphics.f("#232323").s().p("ApkFNQhKgeg5g4Qg4hNANhpQgDhhAthYQBPhcCIBeQAyA3gIBUQgDAVAJAVQAQATAfgHQAyABAvAYQELBWEDjiQBahYBBhrQAxg+A9gxIAKgIQA3grBCgZQBEgTBEAgQA6AiAKBMQAGBDg0A3QgoAog0AZQg0AlglA1QhsCKh4CBQhDAxhLAdIiDA7Ig/AUQhpAchqAAQjGAAjJhhg");
	this.shape_462.setTransform(961.8749,587.3055);

	this.shape_463 = new cjs.Shape();
	this.shape_463.graphics.f("#232323").s().p("ApoFKQhJgeg6g4Qg4hNANhpQgDhhAshYQBPhcCIBdQAzA4gIBUQgCAVAHAVQARASAfgHQAyACAvAXQELBWEHjjQBbhWBDhqQAzg8A9gwIAKgIQA4gqBDgYQBEgSBEAhQA5AkAIBLQAFBEg1A1QgpAng0AZQg1AkgmA0QhuCIh6B/QhEAxhKAaIiCA8QgfALggAIQhqAdhrAAQjFAAjIhgg");
	this.shape_463.setTransform(962.2703,587.6535);

	this.shape_464 = new cjs.Shape();
	this.shape_464.graphics.f("#232323").s().p("AprFHQhKgeg6g4Qg5hMAOhqQgEhgAthZQBOhcCIBdQAzA4gHBUQgDAVAIAVQAQASAfgHQAzABAvAYQELBVELjiQBchVBFhpQAzg7A/gvIAKgIQA5gpBDgWQBFgRBDAiQA4AkAHBMQADBEg1A0QgqAng0AXQg1AjgnA0QhxCGh9B8QhFAwhIAZQhFAfg8AcQgfAMgfAIQhrAdhsAAQjEAAjHhfg");
	this.shape_464.setTransform(962.6538,587.9718);

	this.shape_465 = new cjs.Shape();
	this.shape_465.graphics.f("#232323").s().p("ApvFEQhJgdg6g5Qg5hMANhpQgEhhAthZQBOhcCIBdQAzA3gHBUQgDAVAIAVQAQATAfgIQAzACAvAXQEMBVEOjjQBehSBHhoQA0g7BAguIAKgHQA6goBDgVQBFgQBCAkQA4AlAFBMQADBEg3AzQgqAmg1AWQg1AigpAzQhzCEh/B7QhFAuhIAXQhFAeg6AeIg+AUQhsAdhsAAQjEAAjHheg");
	this.shape_465.setTransform(963.0098,588.3096);

	this.shape_466 = new cjs.Shape();
	this.shape_466.graphics.f("#232323").s().p("ApyFBQhKgeg6g4Qg5hLANhqQgFhhAthZQBOhcCIBcQAzA4gHBTQgDAWAJAUQAQATAfgHQAzABAvAXQELBUETjiQBfhRBJhmQA1g6BBgtIAKgHQA6gnBEgUQBFgPBCAlQA3AnAEBMQABBDg3AzQgrAlg2AVQg2AhgpAzQh1CBiBB5QhHAthGAVQhFAeg5AeQgeAMggAIQhsAehuAAQjCAAjGhdg");
	this.shape_466.setTransform(963.4052,588.6615);

	this.shape_467 = new cjs.Shape();
	this.shape_467.graphics.f("#232323").s().p("Ap2E9QhJgdg7g4Qg5hLANhqQgFhhAthZQBNhdCJBdQAzA3gHBUQgCAVAIAVQAQATAfgIQAzABAvAXQEMBUEWjiQBhhPBKhlQA3g5BBgsIAKgGQA7gnBFgSQBEgOBCAmQA3AnACBNQAABDg4AyQgsAkg2AUQg2AhgqAxQh4CAiDB2QhIAshFATQhFAeg3AeIg+AVQhtAehuAAQjCAAjGhdg");
	this.shape_467.setTransform(963.7626,589.0074);

	this.shape_468 = new cjs.Shape();
	this.shape_468.graphics.f("#232323").s().p("Ap4E6QhKgdg7g4Qg5hLAMhqQgDhhArhZQBOhdCIBcQA0A4gHBTQgCAVAIAVQAQATAfgIQAzACAvAWQCGAqCagxQCRgqB1hdQBihOBMhjQA4g4BCgqIAKgHQA8glBEgSQBFgMBBAnQA2ApABBMQgBBDg5AxQgtAkg2ATQg2AfgrAxQh7B+iFBzQhIAqhEATQhGAcg0AfQggAMgfAJQhuAehwAAQjAAAjEhbg");
	this.shape_468.setTransform(964.0957,589.3662);

	this.shape_469 = new cjs.Shape();
	this.shape_469.graphics.f("#232323").s().p("ApxFBQhKgdg6g4Qg5hNANhpQgDhgAshZQBOhcCJBcQAzA4gIBUQgDAVAJAUQAQATAfgHQAyABAvAXQEMBVERjiQBehRBIhnQA2g6BAgtIAKgIQA6gnBEgVQBEgPBCAlQA4AlAFBNQABBDg3AzQgqAmg2AVQg1AigpAyQh1CDiAB5QhGAuhHAWQhGAdg5AeIg+AUQhrAdhtAAQjDAAjHheg");
	this.shape_469.setTransform(963.2563,588.5767);

	this.shape_470 = new cjs.Shape();
	this.shape_470.graphics.f("#232323").s().p("AppFIQhKgeg5g5Qg4hMANhqQgDhgAthZQBPhcCIBeQAzA4gJBUQgCAVAIAVQAQATAfgIQAyADAvAWQELBXEIjiQBbhWBDhqQAzg8A+gwIAKgHQA4gqBDgYQBEgRBEAhQA5AkAIBMQAEBDg1A1QgpAng0AYQg1AkgmA0QhvCIh7B+QhEAxhKAaIiCA7Ig+AUQhpAbhqAAQjGAAjJhgg");
	this.shape_470.setTransform(962.3615,587.8607);

	this.shape_471 = new cjs.Shape();
	this.shape_471.graphics.f("#232323").s().p("ApgFPQhKgfg5g5Qg3hNAOhpQgChhAthYQBPhbCHBfQAzA3gJBUQgDAVAIAVQAQATAfgHQAzADAuAXQELBYD+jhQBXhaA/htQAxg+A8gyIAJgIQA2gtBCgaQBEgVBEAfQA7AhALBMQAHBDgyA3QgoApgzAaQgyAmglA2QhpCMh1CDQhDA0hLAeQhEAhhCAaIhAAUQhlAZhnAAQjKAAjKhig");
	this.shape_471.setTransform(961.4266,587.1457);

	this.shape_472 = new cjs.Shape();
	this.shape_472.graphics.f("#232323").s().p("ApXFUQhJgfg5g5Qg3hNAPhqQgChgAuhYQBRhbCGBfQAxA5gJBUQgDAVAIAVQAQATAfgHQAzADAuAXQEKBaD1jhQBThdA7hvQAthBA6g1IAJgIQA0gvBBgdQBCgXBHAcQA7AeAPBLQAKBDgwA5QgmArgyAcQgxAogiA3QhjCRhwCIQg/A2hPAjQhDAhhHAaIg/ATQhjAZhlAAQjLAAjNhmg");
	this.shape_472.setTransform(960.4339,586.5152);

	this.shape_473 = new cjs.Shape();
	this.shape_473.graphics.f("#232323").s().p("ApNFaQhKggg4g5Qg2hOAPhpQAAhhAuhXQBRhaCFBgQAyA5gKBTQgDAVAIAVQAQAUAfgHQAxADAvAYQEJBcDsjhQBPhgA2hyQArhCA3g3IAJgJQAygxBAggQBBgaBHAZQA9AcASBKQANBCguA8QgkAsgxAeQgvAqgfA5QhdCVhqCMQg+A5hQAnQhCAjhLAYQggAMggAHQhhAXhiAAQjOAAjOhog");
	this.shape_473.setTransform(959.3978,585.8904);

	this.shape_474 = new cjs.Shape();
	this.shape_474.graphics.f("#232323").s().p("ApEFfQhIggg4g6Qg2hOAQhpQAAhhAvhXQBRhaCFBhQAxA5gKBUQgDAVAHAVQAPATAggGQAyADAuAZQEJBdDijfQBLhkAxh0QAohDA1g6IAIgJQAwgzA/gjQBAgcBIAVQA+AZAVBKQAQBCgrA9QgjAugvAgQgtAsgeA6QhWCZhkCQQg7A8hRArQhDAkhPAYIhAASQheAWhgAAQjRAAjQhrg");
	this.shape_474.setTransform(958.3341,585.3257);

	this.shape_475 = new cjs.Shape();
	this.shape_475.graphics.f("#232323").s().p("Ao5FkQhJghg4g6Qg1hPARhpQABhgAvhXQBShaCEBjQAxA6gLBTQgDAVAHAVQAPATAggGQAyADAuAaQEIBeDZjeQBGhmAsh2QAmhFAyg8IAIgJQAug1A9glQA+ggBJASQBAAYAXBIQATBBgpA/QgfAvgvAiQgrAugbA7QhQCchdCWQg4A9hUAwQhCAlhTAXIhAASQhcAVhcAAQjUAAjShug");
	this.shape_475.setTransform(957.23,584.7964);

	this.shape_476 = new cjs.Shape();
	this.shape_476.graphics.f("#232323").s().p("AovFnQhIghg3g6Qg1hPARhpQAChgAwhXQBShZCEBjQAxA6gMBUQgEAVAIAVQAPATAfgGQAzAEAtAZQEIBhDPjcQBDhpAmh4QAihHAwg+IAIgKQArg2A7goQA+giBJAPQBBAUAaBIQAVBAglBBQgeAwgtAkQgqAwgXA8QhKCfhWCZQg3BBhUA0QhBAmhYAWQggAKggAHQhZAUhaAAQjWAAjVhxg");
	this.shape_476.setTransform(956.0597,584.3089);

	this.shape_477 = new cjs.Shape();
	this.shape_477.graphics.f("#232323").s().p("AojFrQhJghg2g7Qg1hPAThpQABhhAxhWQBThYCDBkQAwA6gMBTQgDAVAHAWQAPATAfgGQAyAFAuAZQEGBjDGjbQA/hrAhh5QAfhIAthBIAHgKQAqg4A5gqQA8glBKAMQBBASAeBGQAYA/gjBCQgcAygrAmQgoAxgVA+QhCCihRCcQgzBDhWA5Qg/AnhdAWQggAKghAGQhXAThXAAQjYAAjWh0g");
	this.shape_477.setTransform(954.8971,583.8924);

	this.shape_478 = new cjs.Shape();
	this.shape_478.graphics.f("#232323").s().p("AoYFvQhIgjg3g7QgzhPAThpQABhgAyhWQBUhYCCBlQAwA6gNBUQgDAVAHAVQAOATAggFQAyAEAuAaQEFBlC9jYQA5huAdh6QAchKAqhCIAHgKQAng7A3gsQA6gnBLAJQBCAPAhBEQAaA/ggBDQgaAzgpAoQgmA0gSA9Qg8ClhJCgQgxBFhWA9QhAAohhAVQgfAKghAHQhUARhUAAQjcAAjYh2g");
	this.shape_478.setTransform(953.6942,583.4982);

	this.shape_479 = new cjs.Shape();
	this.shape_479.graphics.f("#232323").s().p("Ao1FDQhFgmg0g+QgwhSAZhnQAGhhA2hTQBZhUB9BsQAsA9gQBSQgFAVAFAWQAOAUAggEQAyAHAsAcQEAByDMjNQBBhqAkh4QAihHAvhAIAHgJQArg4A6goQA+gjBJAOQBAATAdBHQAWBAglBBQgdAxgsAlQgpAxgXA8QhICghUCaQg1BChZA2QhCAkhgARQggAIgiAFQg/AJhAAAQjxAAjmiNg");
	this.shape_479.setTransform(955.9497,587.347);

	this.shape_480 = new cjs.Shape();
	this.shape_480.graphics.f("#232323").s().p("ApPEUQhEgpgwhBQgshUAehlQAMhhA6hQQBdhPB3ByQApA/gVBSQgGAUAFAWQANAUAggCQAxAKArAeQD6B/DajDQBIhlAth1QAmhFA0g7IAIgJQAug1A9gkQA/geBJATQA/AXAXBJQASBCgpA+QghAugvAiQgsAugbA6QhTCbhfCUQg5A+hcAwQhDAghgALQggAHghADQgrAEgrAAQkIAAjxing");
	this.shape_480.setTransform(958.0495,591.4054);

	this.shape_481 = new cjs.Shape();
	this.shape_481.graphics.f("#232323").s().p("ApoDkQhCgtgshDQgnhWAjhkQAQhgA/hNQBghKBxB4QAnBCgaBRQgHATAEAXQALAVAggBQAxAMApAhQDzCLDoi3QBPhfA2hyQArhCA3g4IAJgJQAxgxBAgfQBCgaBHAYQA9AcASBKQANBDguA7QgkAsgxAeQgvAqgfA5QhdCVhqCNQg9A5heApQhFAchfAHQggAFghABIgpABQkhAAj8jCg");
	this.shape_481.setTransform(959.9667,595.6494);

	this.shape_482 = new cjs.Shape();
	this.shape_482.graphics.f("#232323").s().p("Ap9CyQhAgwgphFQgjhYAphiQAWhfBChKQBkhFBrB+QAiBDgdBPQgIAUACAWQALAXAgABQAwAOAnAiQDsCYD1irQBWhZA9huQAvg/A7g0IAKgIQA1gtBCgbQBDgWBFAeQA7AfAMBMQAJBDgyA4QgnAqgzAbQgyAngjA1QhnCOhzCGQhBA0hfAjQhHAYhdACIhCADQk4gBkDjeg");
	this.shape_482.setTransform(961.6438,600.0468);

	this.shape_483 = new cjs.Shape();
	this.shape_483.graphics.f("#232323").s().p("AhiF6Qk4gRj4jsQg8gzgmhHQgehZAthgQAbheBGhHQBng/BlCDQAfBFgiBOQgJATABAWQAKAXAgADQAvARAlAkQDkCkECicQBbhVBFhpQA0g7A/gwIAJgHQA5gpBDgXQBFgRBDAiQA4AkAHBMQAEBEg1A0QgqAng1AXQg1AkgnAyQhwCHh8B9QhFAwhgAcQhIAThbgCIgcABIgmgBg");
	this.shape_483.setTransform(963.1639,604.6376);

	this.shape_484 = new cjs.Shape();
	this.shape_484.graphics.f("#232323").s().p("Ag/GCIhCgEQk3ghjqj4Qg7g2ghhIQgahcAzheQAfhbBKhDQBqg7BdCIQAcBHgmBMQgJATAAAWQAIAXAfAFQAvATAjAnQDbCuEOiOQBhhNBMhkQA4g4BBgqIALgHQA7gmBFgRQBFgMBBAnQA2AoABBMQgBBDg5AxQgsAkg2ATQg3AfgrAwQh6CAiEBzQhIArhhAWQg0AKg7AAQgZAAgagCg");
	this.shape_484.setTransform(964.4472,606.383);

	this.shape_485 = new cjs.Shape();
	this.shape_485.graphics.f("#232323").s().p("AhdGNQghgCghgFQk0gyjekDQg4g5gehKQgUhdA3haQAlhbBMg/QBtg0BXCMQAXBIgpBKQgLASgBAXQAHAXAfAGQAtAWAiAoQDSC6EYh/QBnhGBTheQA7g0BEgmIALgGQA+ghBGgNQBGgGA+AqQAyAtgDBLQgGBEg8AsQgvAgg3APQg6AcgtAuQiDB2iMBqQhLAlhgAPQglAFgoAAQgoAAgsgFg");
	this.shape_485.setTransform(965.5179,607.6984);

	this.shape_486 = new cjs.Shape();
	this.shape_486.graphics.f("#232323").s().p("Ah7GXIhBgLQkxhBjRkPQgzg8gbhLQgPheA7hYQAqhYBPg7QBwgvBPCRQAUBJgtBIQgMARgCAXQAFAXAfAIQAtAYAfAqQDHDFEjhvQBrg+BZhZQA/gwBHggIAMgGQBAgcBGgIQBGgCA7AvQAwAvgJBMQgLBCg/AoQgxAdg4AMQg7AXgxArQiLBsiTBgQhNAhhgAIQgXABgWAAQg3AAg8gJg");
	this.shape_486.setTransform(966.3859,609.0882);

	this.shape_487 = new cjs.Shape();
	this.shape_487.graphics.f("#232323").s().p("AiXGeIhBgOQkthQjCkaQgxg9gWhOQgLheBAhVQAuhWBSg3QBygpBICVQAQBJgxBGQgNARgDAWQAFAYAeAKQArAaAdAsQC9DOEsheQBvg3BfhRQBCgrBKgcIALgFQBCgYBHgDQBGADA3A0QAtAygPBKQgPBChCAjQgzAag5AIQg8ATg0AnQiSBjiZBVQhQAbheACIgHAAQhIAAhPgRg");
	this.shape_487.setTransform(967.0225,610.5342);

	this.shape_488 = new cjs.Shape();
	this.shape_488.graphics.f("#232323").s().p("AgWG8QhLgDhRgVIhAgSQkphgizkjQguhAgShOQgGhfBFhRQAxhUBWgyQB0gjBACYQAMBKg0BDQgOAQgEAWQADAZAeALQApAcAbAtQCyDXE0hLQBzgwBlhKQBFgmBLgXIALgDQBEgUBHACQBGAIAzA3QAoA1gTBJQgUBBhEAfQg0AWg6AEQg+AOg2AkQiYBYigBKQhEAShMAAIgdgBg");
	this.shape_488.setTransform(967.4177,612.0795);

	this.shape_489 = new cjs.Shape();
	this.shape_489.graphics.f("#232323").s().p("AgzHHQhLgIhOgYIg/gVQkjhvilkrQgqhDgOhPQAAhfBIhOQA2hRBYguQB2gdA3CbQAJBLg4BAQgOAQgGAWQACAYAdANQAoAeAZAvQCmDgE7g5QB2goBqhEQBHggBNgRIAMgDQBEgOBHAGQBFANAvA5QAlA5gZBIQgYA/hGAaQg1ASg7AAQg+AKg5AgQieBNikA/QgyAJg0AAQgiAAglgEg");
	this.shape_489.setTransform(967.6039,613.7215);
	this.shape_489._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_458}]},643).to({state:[{t:this.shape_459}]},1).to({state:[{t:this.shape_460}]},1).to({state:[{t:this.shape_461}]},1).to({state:[{t:this.shape_462}]},1).to({state:[{t:this.shape_463}]},1).to({state:[{t:this.shape_464}]},1).to({state:[{t:this.shape_465}]},1).to({state:[{t:this.shape_466}]},1).to({state:[{t:this.shape_467}]},1).to({state:[{t:this.shape_468}]},1).to({state:[{t:this.shape_469}]},1).to({state:[{t:this.shape_470}]},1).to({state:[{t:this.shape_471}]},1).to({state:[{t:this.shape_472}]},1).to({state:[{t:this.shape_473}]},1).to({state:[{t:this.shape_474}]},1).to({state:[{t:this.shape_475}]},1).to({state:[{t:this.shape_476}]},1).to({state:[{t:this.shape_477}]},1).to({state:[{t:this.shape_478}]},1).to({state:[{t:this.shape_479}]},1).to({state:[{t:this.shape_480}]},1).to({state:[{t:this.shape_481}]},1).to({state:[{t:this.shape_482}]},1).to({state:[{t:this.shape_483}]},1).to({state:[{t:this.shape_484}]},1).to({state:[{t:this.shape_485}]},1).to({state:[{t:this.shape_486}]},1).to({state:[{t:this.shape_487}]},1).to({state:[{t:this.shape_488}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[{t:this.shape_489}]},1).to({state:[]},1).wait(616));
	this.timeline.addTween(cjs.Tween.get(this.shape_489).wait(674).to({_off:false},0).wait(17).to({_off:true},1).wait(616));

	// К
	this.instance_26 = new lib.городскиежильцыперсонажи64();
	this.instance_26.setTransform(764,377,0.8229,0.8229);
	this.instance_26._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_26).wait(643).to({_off:false},0).to({_off:true},49).wait(616));

	// Слой_56
	this.instance_27 = new lib.фоны_фонстол2copy4();
	this.instance_27.setTransform(-37,-93,0.3476,0.3476);
	this.instance_27._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_27).wait(643).to({_off:false},0).to({_off:true},49).wait(616));

	// Слой_62
	this.instance_28 = new lib.Анимация47("synched",0);
	this.instance_28.setTransform(835.6,265.45);
	this.instance_28._off = true;

	this.instance_29 = new lib.Анимация48("synched",0);
	this.instance_29.setTransform(387.6,265.45);
	this.instance_29._off = true;

	this.instance_30 = new lib.Анимация49("synched",0);
	this.instance_30.setTransform(298.6,265.45);
	this.instance_30._off = true;

	this.instance_31 = new lib.Анимация50("synched",0);
	this.instance_31.setTransform(598.6,265.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_28}]},643).to({state:[{t:this.instance_29}]},20).to({state:[{t:this.instance_30}]},15).to({state:[{t:this.instance_31}]},8).to({state:[]},6).wait(616));
	this.timeline.addTween(cjs.Tween.get(this.instance_28).wait(643).to({_off:false},0).to({_off:true,x:387.6},20).wait(645));
	this.timeline.addTween(cjs.Tween.get(this.instance_29).wait(643).to({_off:false},20).to({_off:true,x:298.6},15).wait(630));
	this.timeline.addTween(cjs.Tween.get(this.instance_30).wait(663).to({_off:false},15).to({_off:true,x:598.6},8).wait(622));

	// ОБЛАКА
	this.instance_32 = new lib.Анимация43("synched",0);
	this.instance_32.setTransform(1470,118.9);
	this.instance_32._off = true;

	this.instance_33 = new lib.Анимация44("synched",0);
	this.instance_33.setTransform(1209,118.9);
	this.instance_33._off = true;

	this.instance_34 = new lib.Анимация45("synched",0);
	this.instance_34.setTransform(876,118.9);
	this.instance_34._off = true;

	this.instance_35 = new lib.Анимация46("synched",0);
	this.instance_35.setTransform(1209,118.9);
	this.instance_35._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_32).wait(643).to({_off:false},0).to({_off:true,x:1209},20).wait(645));
	this.timeline.addTween(cjs.Tween.get(this.instance_33).wait(643).to({_off:false},20).to({_off:true,x:876},15).wait(630));
	this.timeline.addTween(cjs.Tween.get(this.instance_34).wait(663).to({_off:false},15).to({_off:true,x:1209},8).wait(622));
	this.timeline.addTween(cjs.Tween.get(this.instance_35).wait(678).to({_off:false},8).to({x:1491.7},5).to({_off:true},1).wait(616));

	// бзз
	this.shape_490 = new cjs.Shape();
	this.shape_490.graphics.f("#232323").s().p("AhzC4QgjgVAAgZQAAgWAZABQADAAAHAFQAnAiA1AAQAuAAAhgZQAjgZgBgnQAAgagTgRQgTgSgaAAQgSAAgwAPQgKADgLAAQgUAAAAgbQgBgJAKgHQAKgGAigHQBigXABg6QgBgSgLgLQgNgMgUAAQgjAAgqAgQgZATgMAAQgWAAABgTQAAgbAxgbQAygcAtAAQAugBAaAZQAaAYAAAbQAAA/hOAlQAuAHAZAZQAZAaAAAmQAAA7gyAoQgyAnhRAAQgxAAgkgVg");
	this.shape_490.setTransform(1476.05,430.75);

	this.shape_491 = new cjs.Shape();
	this.shape_491.graphics.f("#232323").s().p("AhzC4QgjgVAAgZQAAgWAYABQAEAAAHAFQAnAiA1AAQAuAAAhgZQAjgZgBgnQAAgagTgRQgTgSgaAAQgSAAgwAPQgKADgLAAQgUAAAAgbQgBgJALgHQAJgGAigHQBigXABg6QgBgSgLgLQgNgMgUAAQgjAAgqAgQgYATgNAAQgWAAABgTQAAgbAxgbQAygcAtAAQAtgBAbAZQAaAYAAAbQAAA/hOAlQAtAHAaAZQAZAaAAAmQAAA7gyAoQgyAnhRAAQgxAAgkgVg");
	this.shape_491.setTransform(1441.4,430.75);

	this.shape_492 = new cjs.Shape();
	this.shape_492.graphics.f("#232323").s().p("AhzC4QgjgVAAgZQAAgWAYABQAEAAAHAFQAnAiA1AAQAuAAAhgZQAjgZgBgnQAAgagSgRQgUgSgZAAQgTAAgwAPQgKADgLAAQgUAAAAgbQgBgJAKgHQAKgGAigHQBigXABg6QgBgSgMgLQgNgMgTAAQgjAAgqAgQgYATgNAAQgVAAAAgTQAAgbAxgbQAygcAtAAQAtgBAbAZQAaAYAAAbQAAA/hOAlQAuAHAZAZQAZAaAAAmQAAA7gyAoQgyAnhSAAQgwAAgkgVg");
	this.shape_492.setTransform(1406.75,430.75);

	this.shape_493 = new cjs.Shape();
	this.shape_493.graphics.f("#232323").s().p("AhzC4QgjgVAAgZQAAgWAYABQAEAAAHAFQAnAiA1AAQAuAAAhgZQAjgZgBgnQAAgagSgRQgUgSgZAAQgUAAgvAPQgKADgLAAQgUAAAAgbQgBgJAKgHQAKgGAigHQBigXABg6QgBgSgMgLQgMgMgUAAQgjAAgqAgQgYATgNAAQgWAAABgTQAAgbAxgbQAygcAtAAQAtgBAbAZQAaAYAAAbQAAA/hOAlQAuAHAZAZQAZAaAAAmQAAA7gyAoQgyAnhSAAQgwAAgkgVg");
	this.shape_493.setTransform(1372.1,430.75);

	this.shape_494 = new cjs.Shape();
	this.shape_494.graphics.f("#232323").s().p("AifEVQgXgsAAg0QAAhcA5hRQA4hRBAAAQAHAAANALQAMAKAFgCQgOglgvgqQgtgnAAgcQAAgXAOgOQAPgOAogKQAxgPA0gRQA0gRAKgFQAHgEAGAAQAMAAAAAWQAAALgcAUQgcAUhIARQgsALgLAGQgIAFgBAGQAAANAbAXQBnBbABCIQAAA6ggBEQgfBCgzAhQgyAhgygBQgsAAgXgqgAhLAqQguBMABBAQAAAnAKAXQALAVAQAAQAXAAAmgbQAlgcAYg3QAXg2AAgvQAAgngLgYQgLgZgJAAQg+AAgsBMg");
	this.shape_494.setTransform(1340.8,418.35);

	this.shape_495 = new cjs.Shape();
	this.shape_495.graphics.f().s("#232323").ss(6,1,1).p("AV4AAQAAHBmaE+QmaE+pEAAQpDAAmak+Qmak+AAnBQAAnAGak+QGak+JDAAQJEAAGaE+QGaE+AAHAg");
	this.shape_495.setTransform(1405,424.65);

	this.shape_496 = new cjs.Shape();
	this.shape_496.graphics.f("#FFFFFF").s().p("AveL+Qmak9AAnBQAAnAGak+QGbk9JDgBQJEABGaE9QGbE+gBHAQABHBmbE9QmaE/pEgBQpDABmbk/g");
	this.shape_496.setTransform(1405,424.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_496},{t:this.shape_495},{t:this.shape_494},{t:this.shape_493},{t:this.shape_492},{t:this.shape_491},{t:this.shape_490}]},623).to({state:[]},20).to({state:[]},609).wait(56));

	// Слой_55
	this.shape_497 = new cjs.Shape();
	this.shape_497.graphics.f("#232323").s().p("AlRD+QgogogHg2QgBgMAAgMQAAhFAwgxQAxgvBFAAQBFAAAwAvQAyAxAABFIgCAYQgHA2gpAoQgwAxhFAAQhFAAgxgxgABmgSQgogogHg1IgBgYQAAhFAwgxQAxgxBFAAQBFAAAwAxQAyAxAABFQAAAMgCAMQgHA1gpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_497.setTransform(759.7,529.075);

	this.shape_498 = new cjs.Shape();
	this.shape_498.graphics.f("#232323").s().p("AlRD9QgogogHg2QgCgMABgMQgBhFAxgxQAxgvBFAAQBFAAAwAvQAyAxAABFIgCAYQgHA2gpAoQgwAxhFAAQhFAAgxgxgABmgRQgogogHg1IgBgYQAAhFAwgxQAxgxBFAAQBFAAAwAxQAyAxAABFQgJBNgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_498.setTransform(759.35,528.725);

	this.shape_499 = new cjs.Shape();
	this.shape_499.graphics.f("#232323").s().p("AlRD7QgogogHg1QgCgMABgMQgBhFAxgxQAxgvBFgBQBFABAwAvQAyAxAABFIgCAYQgHA1gpAoQgwAyhFgBQhFABgxgygABmgQQgogogHg1IgBgYQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_499.setTransform(759,528.35);

	this.shape_500 = new cjs.Shape();
	this.shape_500.graphics.f("#232323").s().p("AlRD7QgogogHg2IgBgYQAAhFAwgxQAxgvBFAAQBFAAAwAvQAyAxAABFQAAAMgCAMQgHA2gpAoQgwAxhFAAQhFAAgxgxgABmgPQgogogHg1QgCgMAAgMQABhFAwgxQAxgxBFAAQBFAAAxAxQAxAxgBBFQgIBNgoAoQgxAwhFAAQhFAAgxgwg");
	this.shape_500.setTransform(758.7,527.975);

	this.shape_501 = new cjs.Shape();
	this.shape_501.graphics.f("#232323").s().p("AlRD5QgogogHg1IgBgYQAAhFAwgxQAxgwBFABQBFgBAwAwQAyAxAABFQAAAMgCAMQgHA1gpAoQgwAyhFAAQhFAAgxgygABmgOQgogogHg1IgBgYQAAhFAwgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_501.setTransform(758.35,527.6);

	this.shape_502 = new cjs.Shape();
	this.shape_502.graphics.f("#232323").s().p("AlRD4QgogogHg1QgCgMABgMQgBhFAxgxQAxgwBFABQBFgBAwAwQAyAxAABFQgBAMgBAMQgHA1gpAoQgwAyhFAAQhFAAgxgygABmgNQgogogHg1QgBgMAAgMQAAhFAwgxQAxgxBFABQBFgBAwAxQAyAxAABFQgJBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_502.setTransform(758,527.25);

	this.shape_503 = new cjs.Shape();
	this.shape_503.graphics.f("#232323").s().p("AlRD3QgogogHg1QgCgMABgMQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgBAMgBAMQgHA1gpAoQgwAxhFAAQhFAAgxgxgABmgLQgogogHg2QgCgMABgMQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBOgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_503.setTransform(757.65,526.875);

	this.shape_504 = new cjs.Shape();
	this.shape_504.graphics.f("#232323").s().p("AlRD3QgogogHg2QgBgMgBgMQAAhFAxgxQAxgvBFgBQBFABAxAvQAwAxABBFQgBAMgBAMQgHA2goAoQgxAxhFgBQhFABgxgxgABmgLQgogogHg1QgCgMABgMQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_504.setTransform(757.3,526.5);

	this.shape_505 = new cjs.Shape();
	this.shape_505.graphics.f("#232323").s().p("AlRD2QgogogHg2QgBgMAAgMQAAhFAwgxQAxgvBFgBQBFABAwAvQAyAxAABFIgCAYQgHA2gpAoQgwAxhFgBQhFABgxgxgABmgKQgogogHg1QgBgMAAgMQAAhFAwgxQAxgxBFABQBFgBAwAxQAyAxAABFQgJBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_505.setTransform(757,526.15);

	this.shape_506 = new cjs.Shape();
	this.shape_506.graphics.f("#232323").s().p("AlRD0QgogogHg1QgCgMABgMQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgBAMgBAMQgHA1gpAoQgwAxhFAAQhFAAgxgxgABmgIQgogogHg2IgBgYQAAhFAwgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBOgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_506.setTransform(756.65,525.775);

	this.shape_507 = new cjs.Shape();
	this.shape_507.graphics.f("#232323").s().p("AlRDzQgogogHg1QgCgMABgMQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgBAMgBAMQgHA1gpAoQgwAxhFAAQhFAAgxgxgABmgHQgogogHg2IgBgYQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBOgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_507.setTransform(756.3,525.425);

	this.shape_508 = new cjs.Shape();
	this.shape_508.graphics.f("#232323").s().p("AlRDyQgogogHg1QgBgMgBgMQAAhFAxgxQAxgwBFAAQBFAAAxAwQAwAxAABFIgBAYQgHA1goAoQgxAxhFAAQhFAAgxgxgABmgGQgogogHg2QgCgMABgMQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBOgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_508.setTransform(755.95,525.025);

	this.shape_509 = new cjs.Shape();
	this.shape_509.graphics.f("#232323").s().p("AlRDxQgogogHg1IgCgYQAAhFAxgxQAxgwBFAAQBFAAAxAwQAwAxAABFQABAMgCAMQgHA1goAoQgxAxhFAAQhFAAgxgxgABmgFQgogogHg2IgBgYQgBhFAxgxQAxgwBFAAQBFAAAxAwQAwAxAABFQgIBOgoAoQgxAwhFAAQhFAAgxgwg");
	this.shape_509.setTransform(755.6,524.675);

	this.shape_510 = new cjs.Shape();
	this.shape_510.graphics.f("#232323").s().p("AlRDwQgogogHg2QgBgLgBgMQABhGAwgwQAxgwBFAAQBFAAAxAwQAwAwAABGIgBAXQgHA2goAoQgxAxhFAAQhFAAgxgxgABmgEQgogogHg2IgCgYQAAhFAxgxQAxgwBFAAQBFAAAxAwQAwAxAABFQgIBOgoAoQgxAwhFAAQhFAAgxgwg");
	this.shape_510.setTransform(755.25,524.3);

	this.shape_511 = new cjs.Shape();
	this.shape_511.graphics.f("#232323").s().p("AlRDvQgogogHg2QgCgMABgLQgBhGAxgwQAxgwBFAAQBFAAAwAwQAyAwAABGQgBALgBAMQgHA2gpAoQgwAxhFAAQhFAAgxgxgABmgDQgogogHg2IgBgXQgBhFAxgxQAxgxBFAAQBFAAAwAxQAyAxAABFQgJBNgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_511.setTransform(754.95,523.95);

	this.shape_512 = new cjs.Shape();
	this.shape_512.graphics.f("#232323").s().p("AlRDuQgogogHg1IgBgZQgBhEAxgyQAxgvBFAAQBFAAAxAvQAwAyAABEQAAANgBAMQgHA1goAoQgxAxhFAAQhFAAgxgxgABmgCQgogogHg2QgCgMABgMQgBhEAxgyQAxgwBFAAQBFAAAwAwQAyAyAABEQgJBOgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_512.setTransform(754.6,523.55);

	this.shape_513 = new cjs.Shape();
	this.shape_513.graphics.f("#232323").s().p("AlRDtQgogogHg1IgCgZQAAhEAxgyQAxgvBFAAQBFAAAxAvQAwAyAABEQABANgCAMQgHA1goAoQgxAxhFAAQhFAAgxgxgABmgBQgogogHg2IgCgXQAAhGAxgxQAxgwBFAAQBFAAAxAwQAwAxAABGIgBAXQgHA2goAoQgxAwhFAAQhFAAgxgwg");
	this.shape_513.setTransform(754.25,523.2);

	this.shape_514 = new cjs.Shape();
	this.shape_514.graphics.f("#232323").s().p("AlSDvQgogpgHg1QgBgMAAgMQAAhFAwgxQAxgvBFgBQBFABAxAvQAxAxAABFIgCAYQgHA1goApQgxAxhFgBQhFABgxgxgABngDQgogogHg1IgCgYQAAhFAxgxQAxgwBFAAQBFAAAwAwQAxAxAABFQgIBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_514.setTransform(753.375,523.35);

	this.shape_515 = new cjs.Shape();
	this.shape_515.graphics.f("#232323").s().p("AlSDwQgogogHg2QgCgLAAgMQAAhGAxgwQAxgwBFAAQBFAAAwAwQAxAwAABGQAAAMgBALQgHA2gpAoQgwAxhFAAQhFAAgxgxgABngEQgogogHg2IgBgXQAAhGAwgxQAxgwBFAAQBFAAAxAwQAxAxAABGQgJBNgoAoQgxAwhFAAQhFAAgxgwg");
	this.shape_515.setTransform(752.475,523.5);

	this.shape_516 = new cjs.Shape();
	this.shape_516.graphics.f("#232323").s().p("AlTDyQgogogHg2QgCgMAAgMQABhFAwgxQAxgwBFAAQBFAAAwAwQAyAxgBBFIgBAYQgHA2gpAoQgwAwhFAAQhFAAgxgwgABogGQgogogHg1IgBgYQgBhFAxgxQAxgwBFAAQBFAAAwAwQAyAxAABFQgJBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_516.setTransform(751.6,523.65);

	this.shape_517 = new cjs.Shape();
	this.shape_517.graphics.f("#232323").s().p("AlUDzQgogogHg2QgBgMAAgMQAAhFAwgxQAxgvBFAAQBFAAAxAvQAxAxAABFQAAAMgCAMQgHA2goAoQgxAxhFAAQhFAAgxgxgABpgHQgogogHg2QgCgMAAgLQAAhGAxgxQAxgwBFAAQBFAAAwAwQAxAxAABGQgIBNgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_517.setTransform(750.725,523.8);

	this.shape_518 = new cjs.Shape();
	this.shape_518.graphics.f("#232323").s().p("AlUD0QgogogHg1QgCgMAAgMQAAhFAxgxQAxgwBFABQBFgBAwAwQAxAxAABFQAAAMgBAMQgHA1gpAoQgwAyhFAAQhFAAgxgygABpgJQgogogHg1IgBgYQAAhFAwgxQAxgwBFAAQBFAAAxAwQAxAxAABFQgJBNgoAoQgxAxhFAAQhFAAgxgxg");
	this.shape_518.setTransform(749.875,523.95);

	this.shape_519 = new cjs.Shape();
	this.shape_519.graphics.f("#232323").s().p("AlVD2QgogogHg1IgBgZQAAhEAwgyQAxgvBFAAQBFAAAxAvQAxAyAABEQAAANgCAMQgHA1goAoQgxAxhFAAQhFAAgxgxgABqgKQgogogHg2IgCgXQAAhGAxgxQAxgwBFAAQBFAAAwAwQAxAxAABGQgIBNgpAoQgwAwhFAAQhFAAgxgwg");
	this.shape_519.setTransform(748.975,524.1);

	this.shape_520 = new cjs.Shape();
	this.shape_520.graphics.f("#232323").s().p("AlVD4QgogpgIg1QgBgMAAgMQAAhFAxgxQAwgvBGgBQBFABAwAvQAxAxAABFIgCAYQgGA1gpApQgwAxhFgBQhGABgwgxgABrgMQgogogIg1IgBgYQAAhFAxgxQAwgwBGAAQBFAAAwAwQAxAxAABFQgJBNgoAoQgwAxhFAAQhGAAgwgxg");
	this.shape_520.setTransform(748.1,524.25);

	this.shape_521 = new cjs.Shape();
	this.shape_521.graphics.f("#232323").s().p("AlWD5QgogogHg2QgCgLAAgMQAAhGAxgwQAxgwBFAAQBFAAAwAwQAxAwAABGQAAAMgBALQgHA2gpAoQgwAxhFAAQhFAAgxgxgABrgNQgogogHg2IgBgXQAAhGAwgxQAxgwBFAAQBFAAAxAwQAxAxAABGQgJBNgoAoQgxAwhFAAQhFAAgxgwg");
	this.shape_521.setTransform(747.225,524.4);

	this.shape_522 = new cjs.Shape();
	this.shape_522.graphics.f("#232323").s().p("AlXD7QgogogHg2QgBgMAAgMQAAhFAwgxQAxgwBFAAQBFAAAxAwQAxAxAABFIgCAYQgHA2goAoQgxAwhFAAQhFAAgxgwgABsgPQgogogHg1IgCgYQAAhFAxgxQAxgwBFAAQBFAAAwAwQAxAxAABFQgIBNgpAoQgwAxhFAAQhFAAgxgxg");
	this.shape_522.setTransform(746.325,524.55);

	this.shape_523 = new cjs.Shape();
	this.shape_523.graphics.f("#232323").s().p("AlYD8QgogogGg2IgCgYQAAhFAwgxQAygvBEAAQBFAAAxAvQAxAxAABFQAAAMgCAMQgGA2gpAoQgxAxhFAAQhEAAgygxgABsgQQgngogIg2IgBgXQAAhGAwgxQAxgwBFAAQBGAAAwAwQAxAxAABGIgBAXQgIA2goAoQgwAwhGAAQhFAAgxgwg");
	this.shape_523.setTransform(745.45,524.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_497}]},616).to({state:[{t:this.shape_498}]},1).to({state:[{t:this.shape_499}]},1).to({state:[{t:this.shape_500}]},1).to({state:[{t:this.shape_501}]},1).to({state:[{t:this.shape_502}]},1).to({state:[{t:this.shape_503}]},1).to({state:[{t:this.shape_504}]},1).to({state:[{t:this.shape_505}]},1).to({state:[{t:this.shape_506}]},1).to({state:[{t:this.shape_507}]},1).to({state:[{t:this.shape_508}]},1).to({state:[{t:this.shape_509}]},1).to({state:[{t:this.shape_510}]},1).to({state:[{t:this.shape_511}]},1).to({state:[{t:this.shape_512}]},1).to({state:[{t:this.shape_513}]},1).to({state:[{t:this.shape_514}]},1).to({state:[{t:this.shape_515}]},1).to({state:[{t:this.shape_516}]},1).to({state:[{t:this.shape_517}]},1).to({state:[{t:this.shape_518}]},1).to({state:[{t:this.shape_519}]},1).to({state:[{t:this.shape_520}]},1).to({state:[{t:this.shape_521}]},1).to({state:[{t:this.shape_522}]},1).to({state:[{t:this.shape_523}]},1).to({state:[]},1).wait(665));

	// Каркас_15___копия
	this.shape_524 = new cjs.Shape();
	this.shape_524.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EJQAKgSADgUQAJgaAMgYIACgEQAEgMgBgRQALAPAFASQAHAVgCAWQgFAcgUAXQgMAOgTAKQgSALgZAEgAiHEpQgegFgdgNIAWgLQATgLARgMIAUgMQAHgHAFgJQAJgLALgJIAPgcIASgaQAFgMgCgNQAEgRAIgPQAEgQgEgUIADgSIAIgPIABAAIA/AYQAbAMAWAQIgGALIgLAYIghA4QgHAJgEALIgEAKQgIANgHAKQgMAOgOAKIgfAXQgYAPgYATIgEAGgAlfCqQgYgWgPgfQgKgfATggQADgFAJgHIADgDIAFAFQAKAJAMABQAXABAPgZQAFgLgDgMQgCgLgJgHIAHgDQAogNApgGQAYgEAXACIgbBGQgKAbgPAaQgRAUgXAPIg5AtQgJAHgGAGgABSgXIgZgNIAEgUQAGg+AChBQAOgwAvgeQArgYA3AKIAVBLQAEAWgLAUIgVAlQgIAbAbAUQAhATApgaQAbgJAcgEQAPgBAKALQADAPgUAIIhxA3IhMAaIgUAKQgkgcgygZgAhdhlIgBhuQgBgRADgQQADgSAKgPIAQgeQAVgIATAVIAaAeIAKAIQgOAhgHAhQgMA7AEA8QgugVgfgJg");
	this.shape_524.setTransform(1207.7334,169.1647);

	this.shape_525 = new cjs.Shape();
	this.shape_525.graphics.f("#232323").s().p("AggGEQgsgDgtgIQgogFgmgNQgpgNglgXQhXgzhGhLIgHgIQgMgNgJgQQgLgYAAgbQgDggAGggQANgtAngfQAWgYAbgUQAhgXAngIQA+gPA9ACIAAhzQABgXADgWIAKgXIAXgtQAJgRAMgPQAVgRAfAEQAXgBAZAFQAdALAUAcQAPAOAQAQIABACIBGgmQAggIAgACQAdAAAbAIQAgAMAPAjQAJAQAGARQAPAwgFAxQA9gDA5AaQArAkgTBBQgVAugzAUQg7AjhCAaIgtARIABABQAVAkAIAqQAEAhgFAhQgLA9gxAtQgtAohAAHQgcAEgcAAQgfAAgggGgACcCqIgCAFQgMAXgJAaQgDAUgKASIgnAtQAZgEASgKQATgKAMgPQAUgXAFgcQACgWgHgVQgFgRgLgQQABARgEAMgAgiAdIgDASQAEAUgEARQgIAOgEARQACANgFANIgSAZIgPAdQgLAJgJAKQgFAJgHAHIgUAMQgRANgTALIgWAKQAdANAeAFIAiADIAEgFQAYgUAYgOIAfgYQAOgJAMgPQAHgKAIgNIAEgKQAEgLAHgIIAhg4IALgYIAGgLQgWgRgbgLIg/gZIgBAAgAlyAnQgJAIgDAEQgTAgAKAfQAPAgAYAVIAMALQAGgGAJgHIA5gsQAXgPARgVQAPgaAKgaIAbhHQgXgCgYAEQgpAGgoANIgHADQAJAHACALQADAMgFALQgPAagXgCQgMgBgKgJIgFgFIgDADgACBkHQgvAdgOAxQgCBAgGA+IgEAUIAZANQAyAaAkAbIAUgKIBMgaIBxg3QAUgIgDgOQgKgMgPABQgcAEgbAJQgpAaghgTQgbgUAIgbIAVglQALgUgEgWIgVhLQgQgDgPAAQgkAAgfASgAhAk1IgQAdQgKAPgDATQgDAQABAQIABBuQAfAJAuAVQgEg7AMg8QAHghAOghIgKgIIgageQgNgPgPAAQgGAAgGADg");
	this.shape_525.setTransform(1207.8132,169.4501);

	this.shape_526 = new cjs.Shape();
	this.shape_526.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAVgCAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDAKIgFAKQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIhIA5gABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3QgVAIgXAHIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_526.setTransform(1175.5458,197.1415);

	this.shape_527 = new cjs.Shape();
	this.shape_527.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHAqQAFAhgGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgWgHgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgKQADgKAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALIBIg5QAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLQAXgGAVgJIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_527.setTransform(1175.6268,197.4058);

	this.shape_528 = new cjs.Shape();
	this.shape_528.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAVgCAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgEAKIgEAKQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIidBGIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_528.setTransform(1143.3958,225.0915);

	this.shape_529 = new cjs.Shape();
	this.shape_529.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgWgHgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgKQAEgKAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLICdhGQAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_529.setTransform(1143.4768,225.3558);

	this.shape_530 = new cjs.Shape();
	this.shape_530.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EKQAKgSADgVQAJgaAMgYIACgDQAEgNgBgRQALAQAFARQAHAVgCAWQgFAcgUAXQgMAPgTAKQgSAKgZAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAFgJQAJgLALgIIAPgdIASgaQAFgMgCgNQAEgQAIgPQAEgRgEgUIADgSIAIgPIABAAIA/AYQAbAMAWAQIgGALIgLAYIgRAfQgHAOgJAMQgHAJgEAKIgEAKIgPAXIgaAZQgPAMgQAKQgYAQgYASIgEAGgAlfCqQgYgWgPgfQgKgfATggIAPgOIAFAEQAKAJAMABQAXACAPgaQAFgLgDgMQgCgKgJgIIAHgCQAogOApgGQAYgDAXABIgbBHQgKAbgPAZQgRAVgXAPIhIA5gABSgXIgZgNIAEgUQAGg/ACg/QAOgwAvgeQArgaA3ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAhASApgZQAbgJAcgDQAPgCAKAMQADAOgUAIIg5AdIg4AaQgVAIgWAHIghALIgUAKQgkgcgygZgAhdhlIgBhuQgBgQADgQQADgSAKgQIAQgeQAVgIATAWIAaAdIAKAIQgOAhgHAhQgMA7AEA9QgugVgfgKg");
	this.shape_530.setTransform(1111.2334,253.0415);

	this.shape_531 = new cjs.Shape();
	this.shape_531.graphics.f("#232323").s().p("AggGFIhZgMQgogGgmgLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgLgYAAgbQgDggAGggQANgtAngfQAWgYAbgUQAhgXAngHQA+gQA9ACIAAhzQABgWADgWQAEgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAXgBAZAFQAdAMAUAbIAfAeIABACIBGgmQAggJAgADQAdAAAbAIQAgANAPAiQAJAQAGARQAPAvgFAyQA9gDA5AbQArAjgTBBQgVAugzAUQg7AjhCAaIgtARIABABQAVAkAIArQAEAggFAhQgLA9gxAtQgtAohAAGQgcAFgeAAQgeAAgfgFgACcCrIgCADQgMAYgJAaQgDAVgKASIgnAsQAZgEASgKQATgKAMgPQAUgXAFgcQACgWgHgVQgFgRgLgQQABARgEANgAgaAOIgIAPIgDASQAEAUgEARQgIAPgEAQQACANgFAMIgSAaIgPAdQgLAIgJALQgFAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAYgSAYgQQAQgKAPgMIAagZIAPgXIAEgKQAEgKAHgJQAJgMAHgOIARgfIALgYIAGgLQgWgQgbgMIg/gYgAl+AzQgTAgAKAfQAPAfAYAWIAMALIBIg5QAXgPARgVQAPgZAKgbIAbhHQgXgBgYADQgpAGgoAOIgHACQAJAIACAKQADAMgFALQgPAagXgCQgMgBgKgJIgFgEgACBkHQgvAegOAwQgCA/gGA/IgEAUIAZANQAyAaAkAbIAUgKIAhgLQAWgGAVgJIA4gaIA5gdQAUgIgDgOQgKgMgPACQgcADgbAJQgpAZghgSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgRgDgPAAQgkAAgeASgAhAk2IgQAeQgKAQgDASQgDAQABAQIABBuQAfAKAuAVQgEg9AMg7QAHghAOghIgKgIIgagdQgNgQgPAAQgGAAgGACg");
	this.shape_531.setTransform(1111.3132,253.3058);

	this.shape_532 = new cjs.Shape();
	this.shape_532.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAVgCAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDALIgFAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIhIA5gABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3QgVAIgXAHIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_532.setTransform(1079.0458,280.9915);

	this.shape_533 = new cjs.Shape();
	this.shape_533.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgWgHgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgJQADgLAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALIBIg5QAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLQAXgGAVgJIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_533.setTransform(1079.1268,281.2558);

	this.shape_534 = new cjs.Shape();
	this.shape_534.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EKQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAWgCAVQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgEALIgEAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3IhNAaIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_534.setTransform(1046.8958,308.9415);

	this.shape_535 = new cjs.Shape();
	this.shape_535.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASIgnAsQAagEARgKQASgKAOgPQAUgXAEgcQACgVgHgWQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgJQAEgLAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIBNgaIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_535.setTransform(1046.9768,309.2058);

	this.shape_536 = new cjs.Shape();
	this.shape_536.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EKQAKgSADgVQAJgaAMgYIACgDQAEgNgBgRQALAQAFARQAHAWgCAVQgFAcgUAXQgMAPgTAKQgSAKgZAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAFgJQAJgLALgIIAPgdIASgaQAFgMgCgNQAEgQAIgPQAEgRgEgUIADgSIAIgPIABAAIA/AYQAbAMAWAQIgGALIgLAYIgRAfQgHAOgJAMQgHAJgEALIgEAJIgPAXIgaAZQgPAMgQAKQgYAQgYASIgEAGgAlfCqQgYgWgPgfQgKgfATggIAPgOIAFAEQAKAJAMABQAXACAPgaQAFgLgDgMQgCgKgJgIIAHgCQAogOApgGQAYgDAXABIgbBHQgKAbgPAZQgRAVgXAPIhIA5gABSgXIgZgNIAEgUQAGg/ACg/QAOgwAvgeQArgaA3ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAhASApgZQAbgJAcgDQAPgCAKAMQADAOgUAIIg5AdIg4AaQgVAIgWAHIghALIgUAKQgkgcgygZgAhdhlIgBhuQgBgQADgQQADgSAKgQIAQgeQAVgIATAWIAaAdIAKAIQgOAhgHAhQgMA7AEA9QgugVgfgKg");
	this.shape_536.setTransform(1014.7334,336.8915);

	this.shape_537 = new cjs.Shape();
	this.shape_537.graphics.f("#232323").s().p("AggGFIhZgMQgogGgmgLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgLgYAAgbQgDggAGggQANgtAngfQAWgYAbgUQAhgXAngHQA+gQA9ACIAAhzQABgWADgWQAEgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAXgBAZAFQAdAMAUAbIAfAeIABACIBGgmQAggJAgADQAdAAAbAIQAgANAPAiQAJAQAGARQAPAvgFAyQA9gDA5AbQArAjgTBBQgVAugzAUQg7AjhCAaIgtARIABABQAVAkAIArQAEAggFAhQgLA9gxAtQgtAohAAGQgcAFgeAAQgeAAgfgFgACcCrIgCADQgMAYgJAaQgDAVgKASIgnAsQAZgEASgKQATgKAMgPQAUgXAFgcQACgVgHgWQgFgRgLgQQABARgEANgAgaAOIgIAPIgDASQAEAUgEARQgIAPgEAQQACANgFAMIgSAaIgPAdQgLAIgJALQgFAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAYgSAYgQQAQgKAPgMIAagZIAPgXIAEgJQAEgLAHgJQAJgMAHgOIARgfIALgYIAGgLQgWgQgbgMIg/gYgAl+AzQgTAgAKAfQAPAfAYAWIAMALIBIg5QAXgPARgVQAPgZAKgbIAbhHQgXgBgYADQgpAGgoAOIgHACQAJAIACAKQADAMgFALQgPAagXgCQgMgBgKgJIgFgEgACBkHQgvAegOAwQgCA/gGA/IgEAUIAZANQAyAaAkAbIAUgKIAhgLQAWgGAVgJIA4gaIA5gdQAUgIgDgOQgKgMgPACQgcADgbAJQgpAZghgSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgRgDgPAAQgkAAgeASgAhAk2IgQAeQgKAQgDASQgDAQABAQIABBuQAfAKAuAVQgEg9AMg7QAHghAOghIgKgIIgagdQgNgQgPAAQgGAAgGACg");
	this.shape_537.setTransform(1014.8132,337.1558);

	this.shape_538 = new cjs.Shape();
	this.shape_538.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EKQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAWgCAVQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDALIgFAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIg6AdIg3AaQgVAIgXAHIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_538.setTransform(982.5458,364.8415);

	this.shape_539 = new cjs.Shape();
	this.shape_539.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASIgnAsQAagEARgKQASgKAOgPQAUgXAEgcQACgVgHgWQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgJQADgLAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLQAXgGAVgJIA3gaIA6gdQAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_539.setTransform(982.6268,365.1058);

	this.shape_540 = new cjs.Shape();
	this.shape_540.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAWgCAVQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgEALIgEAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3IhNAaIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_540.setTransform(950.3958,392.7915);

	this.shape_541 = new cjs.Shape();
	this.shape_541.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgVgHgWQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgJQAEgLAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIBNgaIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_541.setTransform(950.4768,393.0558);

	this.shape_542 = new cjs.Shape();
	this.shape_542.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EJQAKgSADgUQAJgaAMgYIACgEQAEgMgBgRQALAPAFASQAHAVgCAWQgFAcgUAXQgMAOgTAKQgSALgZAEgAiHEpQgegFgdgNIAWgLQATgLARgMIAUgMQAHgHAFgJQAJgLALgJIAPgcIASgaQAFgMgCgNQAEgRAIgPQAEgQgEgUIADgSIAIgPIABAAIA/AYQAbAMAWAQIgGALIgLAYIgRAfQgHANgJAMQgHAJgEALIgEAKQgIANgHAKQgMAOgOAKIgfAXQgYAPgYATIgEAGgAlfCqQgYgWgPgfQgKgfATggQADgFAJgHIADgDIAFAFQAKAJAMABQAXABAPgZQAFgLgDgMQgCgLgJgHIAHgDQAogNApgGQAYgEAXACIgbBGQgKAbgPAaQgRAUgXAPIg5AtQgJAHgGAGgABSgXIgZgNIAEgUQAGg+AChBQAOgwAvgeQArgYA3AKIAVBLQAEAWgLAUIgVAlQgIAbAbAUQAhATApgaQAbgJAcgEQAPgBAKALQADAPgUAIIhxA3IhMAaIgUAKQgkgcgygZgAhdhlIgBhuQgBgRADgQQADgSAKgPIAQgeQAVgIATAVIAaAeIAKAIQgOAhgHAhQgMA7AEA8QgugVgfgJg");
	this.shape_542.setTransform(918.2334,420.7647);

	this.shape_543 = new cjs.Shape();
	this.shape_543.graphics.f("#232323").s().p("AggGEQgsgDgtgIQgogFgmgMQgpgOglgXQhXg0hGhJIgHgIQgMgOgJgQQgLgYAAgbQgDgfAGghQANgtAngfQAWgYAbgUQAhgXAngIQA+gPA9ACIAAhzQABgXADgVIAKgYIAXguQAJgQAMgPQAVgRAfAEQAXgCAZAHQAdAKAUAcQAPANAQARIABABIBGglQAggIAgADQAdgBAbAJQAgALAPAjQAJAQAGARQAPAvgFAxQA9gBA5AaQArAjgTBBQgVAvgzASQg7AkhCAaIgtARIABABQAVAkAIArQAEAggFAgQgLA+gxAtQgtAohAAGQgcAFgcAAQgfAAgggGgACcCrIgCADQgMAYgJAaQgDAVgKARIgnAtQAZgEASgLQATgJAMgPQAUgWAFgdQACgWgHgVQgFgSgLgOQABAQgEANgAgiAdIgDASQAEAUgEAQQgIAPgEARQACANgFAMIgSAaIgPAcQgLAJgJALQgFAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAYgSAYgQIAfgWQAOgLAMgOQAHgKAIgNIAEgJQAEgLAHgKQAJgMAHgNIARgfIALgYIAGgLQgWgQgbgMIg/gYIgBAAgAlyAnQgJAHgDAGQgTAgAKAeQAPAfAYAWIAMAMQAGgHAJgHIA5gtQAXgPARgUQAPgaAKgbIAbhGQgXgBgYADQgpAGgoAOIgHACQAJAHACALQADANgFAKQgPAZgXgBQgMgBgKgJIgFgEIgDACgACBkIQgvAfgOAvQgCBBgGA+IgEAUIAZANQAyAaAkAbIAUgKIBMgZIBxg4QAUgHgDgQQgKgLgPABQgcAEgbAJQgpAaghgTQgbgUAIgbIAVglQALgUgEgWIgVhLQgQgDgPAAQgkAAgfARgAhAk2IgQAeQgKAPgDASQgDARABAQIABBuQAfAJAuAWQgEg9AMg7QAHghAOghIgKgIIgagdQgNgQgPAAQgGAAgGACg");
	this.shape_543.setTransform(918.3132,421.0501);

	this.shape_544 = new cjs.Shape();
	this.shape_544.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAEAggFAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgVgHgWQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgJQAEgLAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIBNgaIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_544.setTransform(882.7768,391.4558);

	this.shape_545 = new cjs.Shape();
	this.shape_545.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAWgCAVQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPQgHAOgJAMQgHAJgEALIgEAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3IhNAaIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_545.setTransform(847.1458,361.6415);

	this.shape_546 = new cjs.Shape();
	this.shape_546.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAEAggFAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgVgHgWQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgJQAEgLAHgJQAJgMAHgOIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIBNgaIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_546.setTransform(847.2268,361.9058);

	this.shape_547 = new cjs.Shape();
	this.shape_547.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EKQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAWgCAVQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPQgHAOgJAMQgHAJgEALIgEAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3QgVAIgXAHIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_547.setTransform(776.0458,302.5415);

	this.shape_548 = new cjs.Shape();
	this.shape_548.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgHQgMgOgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASIgnAsQAagEARgKQASgKAOgPQAUgXAEgcQACgVgHgWQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgJQAEgLAHgJQAJgMAHgOIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLQAXgGAVgJIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_548.setTransform(776.1268,302.8058);

	this.shape_549 = new cjs.Shape();
	this.shape_549.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAVgCAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDALIgFAJQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3IhNAaIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_549.setTransform(704.9458,243.4415);

	this.shape_550 = new cjs.Shape();
	this.shape_550.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgWgHgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgJQADgLAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIBNgaIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_550.setTransform(705.0268,243.7058);

	this.shape_551 = new cjs.Shape();
	this.shape_551.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAHAVgCAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDAKIgFAKQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIg6AdIg3AaIhNAaIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_551.setTransform(669.3958,213.8915);

	this.shape_552 = new cjs.Shape();
	this.shape_552.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQACgWgHgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgKQADgKAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIBNgaIA3gaIA6gdQAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_552.setTransform(669.4768,214.1558);

	this.shape_553 = new cjs.Shape();
	this.shape_553.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgJQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAIAVgDAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDAKIgFAKQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIhxA3QgVAIgXAHIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_553.setTransform(633.8458,184.3415);

	this.shape_554 = new cjs.Shape();
	this.shape_554.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHArQAFAggGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASQgHAJgIAJIgYAaQAagEARgKQASgKAOgPQAUgXAEgcQADgWgIgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgKQADgKAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLQAXgGAVgJIBxg3QAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_554.setTransform(633.9268,184.6058);

	this.shape_555 = new cjs.Shape();
	this.shape_555.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EKQAKgSAEgVQAIgaANgYIABgDQAEgNAAgRQAKAQAFARQAIAVgDAWQgEAcgUAXQgOAPgSAKQgRAKgaAEgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAPgdIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgSAjIgKAQIgHAPIgQAaQgHAJgDAKIgFAKQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgaBHQgLAbgPAZQgRAVgWAPIhIA5gABTgXIgZgNIADgUQAHg/ABg/QAPgwAugeQAsgaA2ALIAVBLQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEAOgUAIIidBGIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_555.setTransform(598.2958,154.7915);

	this.shape_556 = new cjs.Shape();
	this.shape_556.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgGgIQgNgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAdAAAcAIQAfANAQAiQAJAQAFARQAQAvgGAyQA+gDA4AbQArAjgTBBQgUAug0AUQg7AjhBAaIguARIABABQAWAkAHAqQAFAhgGAhQgLA9gwAtQguAohAAGQgcAFgeAAQgdAAgggFgACcCrIgBADQgNAYgIAaQgEAVgKASIgnAsQAagEARgKQASgKAOgPQAUgXAEgcQADgWgIgVQgFgRgKgQQAAARgEANgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgPAdQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAFgKQADgKAHgJIAQgaIAHgPIAKgQIASgjQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALIBIg5QAWgPARgVQAPgZALgbIAahHQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACBkHQguAegPAwQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgLICdhGQAUgIgEgOQgKgMgPACQgcADgaAJQgpAZgigSQgbgUAIgaIAVgmQALgUgEgWIgVhLQgQgDgQAAQgjAAgfASgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_556.setTransform(598.3768,155.0558);

	this.shape_557 = new cjs.Shape();
	this.shape_557.graphics.f("rgba(255,255,255,0.067)").s().p("AB5EJQAKgSADgUQAJgaAMgYIACgEQAEgMgBgRQALAPAFASQAHAVgCAWQgFAcgUAXQgMAOgTAKQgSALgZAEgAiHEpQgegFgdgNIAWgLQATgLARgMIAUgMQAHgHAFgJQAJgLALgJIAPgcIASgaQAFgMgCgNQAEgRAIgPQAEgQgEgUIADgSIAIgPIABAAIA/AYQAbAMAWAQIgGALIgLAYIgRAfIgQAZQgHAJgEALIgEAKQgIANgHAKQgMAOgOAKIgfAXQgYAPgYATIgEAGgAlfCqQgYgWgPgfQgKgfATggQADgFAJgHIADgDIAFAFQAKAJAMABQAXABAPgZQAFgLgDgMQgCgLgJgHIAHgDQAogNApgGQAYgEAXACIgbBGQgKAbgPAaQgRAUgXAPIg5AtQgJAHgGAGgABSgXIgZgNIAEgUQAGg+AChBQAOgwAvgeQArgYA3AKIAVBLQAEAWgLAUIgVAlQgIAbAbAUQAhATApgaQAbgJAcgEQAPgBAKALQADAPgUAIIhxA3IhMAaIgUAKQgkgcgygZgAhdhlIgBhuQgBgRADgQQADgSAKgPIAQgeQAVgIATAVIAaAeIAKAIQgOAhgHAhQgMA7AEA8QgugVgfgJg");
	this.shape_557.setTransform(562.7834,125.2147);

	this.shape_558 = new cjs.Shape();
	this.shape_558.graphics.f("#232323").s().p("AggGEQgsgDgtgIQgogFgmgMQgpgOglgXQhXgzhGhKIgHgJQgMgNgJgQQgLgYAAgbQgDgfAGghQANgtAngfQAWgYAbgUQAhgXAngIQA+gPA9ACIAAhzQABgWADgWIAKgYIAXguQAJgQAMgPQAVgRAfAEQAXgCAZAHQAdAKAUAcQAPAOAQAQIABACIBGgmQAggIAgADQAdgBAbAJQAgAMAPAiQAJAQAGARQAPAwgFAwQA9gCA5AbQArAkgTBAQgVAugzATQg7AkhCAaIgtARIABABQAVAkAIAqQAEAhgFAgQgLA9gxAuQgtAohAAGQgcAFgcAAQgfAAgggGgACcCrIgCADQgMAYgJAaQgDAVgKARIgnAtQAZgEASgLQATgJAMgPQAUgWAFgdQACgWgHgVQgFgSgLgOQABAQgEANgAgiAdIgDASQAEAUgEAQQgIAPgEARQACANgFANIgSAZIgPAdQgLAIgJALQgFAKgHAGIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAYgSAYgPIAfgYQAOgKAMgOQAHgKAIgNIAEgJQAEgMAHgJIAQgZIARgfIALgXIAGgMQgWgQgbgMIg/gYIgBAAgAlyAnQgJAHgDAGQgTAfAKAfQAPAfAYAWIAMAMQAGgHAJgHIA5gtQAXgPARgUQAPgZAKgbIAbhHQgXgCgYAEQgpAGgoANIgHADQAJAHACALQADANgFAKQgPAZgXgBQgMgBgKgJIgFgFIgDADgACBkHQgvAegOAvQgCBBgGA+IgEAUIAZANQAyAaAkAbIAUgKIBMgZIBxg4QAUgHgDgQQgKgLgPABQgcAEgbAJQgpAaghgTQgbgUAIgbIAVglQALgUgEgWIgVhLQgQgDgPAAQgkAAgfASgAhAk2IgQAeQgKAPgDASQgDAQABARIABBuQAfAJAuAWQgEg9AMg7QAHghAOghIgKgIIgagdQgNgQgPAAQgGAAgGACg");
	this.shape_558.setTransform(562.8632,125.5001);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_525},{t:this.shape_524}]},623).to({state:[{t:this.shape_527},{t:this.shape_526}]},1).to({state:[{t:this.shape_529},{t:this.shape_528}]},1).to({state:[{t:this.shape_531},{t:this.shape_530}]},1).to({state:[{t:this.shape_533},{t:this.shape_532}]},1).to({state:[{t:this.shape_535,p:{x:1046.9768,y:309.2058}},{t:this.shape_534,p:{x:1046.8958,y:308.9415}}]},1).to({state:[{t:this.shape_537},{t:this.shape_536}]},1).to({state:[{t:this.shape_539},{t:this.shape_538}]},1).to({state:[{t:this.shape_541},{t:this.shape_540,p:{x:950.3958,y:392.7915}}]},1).to({state:[{t:this.shape_543},{t:this.shape_542}]},1).to({state:[{t:this.shape_544},{t:this.shape_540,p:{x:882.6958,y:391.1915}}]},1).to({state:[{t:this.shape_546},{t:this.shape_545}]},1).to({state:[{t:this.shape_535,p:{x:811.6768,y:332.3558}},{t:this.shape_534,p:{x:811.5958,y:332.0915}}]},1).to({state:[{t:this.shape_548},{t:this.shape_547}]},1).to({state:[{t:this.shape_535,p:{x:740.5768,y:273.2558}},{t:this.shape_534,p:{x:740.4958,y:272.9915}}]},1).to({state:[{t:this.shape_550},{t:this.shape_549}]},1).to({state:[{t:this.shape_552},{t:this.shape_551}]},1).to({state:[{t:this.shape_554},{t:this.shape_553}]},1).to({state:[{t:this.shape_556},{t:this.shape_555}]},1).to({state:[{t:this.shape_558},{t:this.shape_557}]},1).to({state:[]},1).wait(665));

	// ОКНО
	this.instance_36 = new lib.фоны_фонокно();
	this.instance_36.setTransform(129,-30,0.2901,0.2901);

	this.shape_559 = new cjs.Shape();
	this.shape_559.graphics.f("#0B88F0").s().p("EBYxBMgMAAAiZAMAt9AAAMAAACZAgEiGtBMgMAAAiZAMAt9AAAMAAACZAg");
	this.shape_559.setTransform(807.375,447.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_559},{t:this.instance_36}]},616).to({state:[]},27).wait(665));

	// КОТИКС
	this.instance_37 = new lib.городскиежильцыперсонажи63();
	this.instance_37.setTransform(282,152,0.4254,0.4254);
	this.instance_37._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_37).wait(616).to({_off:false},0).to({_off:true},27).wait(665));

	// Слой_52
	this.shape_560 = new cjs.Shape();
	this.shape_560.graphics.f("#0B88F0").s().p("AIrGnQiQAAhmgoQhmgoAAg5QAAg4BmgpQBmgoCQAAQCRAAB+AvQB/AuAQA8QAQA9iPAeQiOAeiRAAIAAAAgAtki9QhmgoAAg4QAAg5BmgoQBmgoCRAAQCQAABmAoQBmAoBEAyQBDAyhKAlQhKAljwAKQguACgqAAQisAAhSghg");
	this.shape_560.setTransform(888.2813,637.025);
	this.shape_560._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_560).wait(589).to({_off:false},0).to({_off:true},27).wait(692));

	// ТЕКСТ___копия
	this.shape_561 = new cjs.Shape();
	this.shape_561.graphics.f("#232323").s().p("AiQEKQgMgKAAgRQAAgNAXgPIAIgGQAHgGANAAQAIAAAQAMQAZAAAAAVQAAASgWANQgVANgQAAQgRAAgMgKgAhrBtQgDgPAAgGQAAgZAcg2IAEgIQAZgXBHgaIArgQQAUgJALgVQALgVAAgTQAAgMgHgcQgHgdgVgIQgVgIgUAAQgpAAgUALQgTAMgCAOQgDARgUAFQgKACgKAAQgUAAAAgVQAAgdArggQArghAcAAIAvgCQAigBAVAOQAWANASAVQATAUAAA9QAAA0gTAfQgTAegeAQQgeAPheAeQgMAggHAjQgEARgLAGQgMAGgVAAQgDAAgCgOg");
	this.shape_561.setTransform(604.025,169.9927);

	this.shape_562 = new cjs.Shape();
	this.shape_562.graphics.f("#232323").s().p("AhDDgQAAgNAMgTQANgSANAAQAJAAANAIQAMAHAAAGQAAAigQAPQgSAOgMAAQgaAAAAgigAgSBXQgQgCgFgFQgFglAWhnQAShUAAghQAAgvAQgRQASgQALAAQAJAAAJAHQAJAIAAAJQAAAHgmCrQgRBGAAAmQgBAZgHAMQgIAAgPgDg");
	this.shape_562.setTransform(601.375,169.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_561}]},589).to({state:[{t:this.shape_562}]},26).to({state:[]},1).wait(692));

	// ВОПРОС___копия___копия
	this.shape_563 = new cjs.Shape();
	this.shape_563.graphics.f().s("#232323").ss(4,1,1).p("AUZgSQAAGHlXEVQlXEVokAkQoiAlmxkAQmwkBAooZQAoobHxi/QHwjAG7AFQG7AEFXEVQFXEVAAGHg");
	this.shape_563.setTransform(598.5307,171.9031);

	this.shape_564 = new cjs.Shape();
	this.shape_564.graphics.f("#FFFFFF").s().p("AuMLoQmwkBAooZQAoobHxi/QHwjAG7AFQG7AEFXEVQFXEVAAGHQAAGHlXEVQlXEVokAkQhFAFhCAAQnRAAl7jgg");
	this.shape_564.setTransform(598.5307,171.9031);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_564},{t:this.shape_563}]},589).to({state:[]},27).wait(692));

	// Слой_50
	this.shape_565 = new cjs.Shape();
	this.shape_565.graphics.f("#232323").s().p("AnqFGQhXghgzhZQgzhYAPhcQAPhcBIgpQBJgqBXAhQBXAhAzBXQAzBZgPBcQgPBchIAqQgoAXguAAQgjAAgngOgAGiB3QhXghgzhXQgzhYAPhdQAPhcBIgqQBJgqBXAhQBXAiAzBYQAzBYgPBcQgPBbhIAqQgoAYguAAQgjAAgngPg");
	this.shape_565.setTransform(954.2602,325.8127);

	this.shape_566 = new cjs.Shape();
	this.shape_566.graphics.f("#232323").s().p("AnsFFQhXghgzhZQgzhYAPhcQAPhcBIgpQBJgqBXAhQBXAhAzBXQAzBZgPBcQgPBchIAqQgpAXgtAAQgkAAgmgOgAGkB4QhXghgzhXQgzhYAPhdQAQhcBIgqQBIgqBXAhQBYAiAzBYQAzBYgQBcQgOBbhJAqQgoAYguAAQgjAAgngPg");
	this.shape_566.setTransform(952.2852,326.5127);

	this.shape_567 = new cjs.Shape();
	this.shape_567.graphics.f("#232323").s().p("AnvFEQhXghgzhYQgzhYAPhdQAQhbBIgqQBIgqBXAhQBYAiAzBXQAzBYgQBcQgOBchJAqQgoAXguAAQgjAAgngOgAGnB5QhXghgzhYQgzhXAPhdQAPhcBIgqQBJgqBXAhQBXAiAzBYQAzBYgPBcQgPBbhIAqQgpAXgtAAQgkAAgmgOg");
	this.shape_567.setTransform(950.2852,327.2377);

	this.shape_568 = new cjs.Shape();
	this.shape_568.graphics.f("#232323").s().p("AnxFDQhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBXQAzBYgPBcQgPBchIAqQgoAXguAAQgjAAgngOgAGpB6QhXghgzhYQgzhXAPhdQAPhcBIgqQBJgqBXAhQBXAiAzBYQAzBYgPBcQgPBbhIAqQgoAXguAAQgjAAgngOg");
	this.shape_568.setTransform(948.3102,327.9377);

	this.shape_569 = new cjs.Shape();
	this.shape_569.graphics.f("#232323").s().p("AnzFCQhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgpAXgtAAQgkAAgmgOgAGrB7QhXghgzhYQgzhXAPhdQAQhcBIgqQBIgqBXAhQBYAiAzBYQAzBYgQBcQgOBbhJAqQgoAXguAAQgjAAgngOg");
	this.shape_569.setTransform(946.2852,328.6377);

	this.shape_570 = new cjs.Shape();
	this.shape_570.graphics.f("#232323").s().p("An2FBQhXghgzhYQgzhYAPhdQAQhbBIgqQBIgqBXAhQBYAiAzBYQAzBXgQBcQgOBchJAqQgoAXgtAAQgkAAgngOgAGtB8QhXghgzhYQgzhXAPhdQAQhcBIgqQBIgqBXAhQBYAiAzBYQAzBYgQBcQgOBbhJAqQgoAXgtAAQgkAAgngOg");
	this.shape_570.setTransform(944.3102,329.3377);

	this.shape_571 = new cjs.Shape();
	this.shape_571.graphics.f("#232323").s().p("An4FAQhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgoAYguAAQgjAAgngPgAGwB9QhXghgzhZQgzhXAPhcQAPhdBIgpQBJgqBXAhQBXAhAzBYQAzBZgPBcQgPBbhIAqQgoAXguAAQgjAAgngOg");
	this.shape_571.setTransform(942.3102,330.0627);

	this.shape_572 = new cjs.Shape();
	this.shape_572.graphics.f("#232323").s().p("An6E/QhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgpAYgtAAQgkAAgmgPgAGyB+QhXghgzhZQgzhXAPhcQAQhdBIgpQBIgqBXAhQBYAhAzBYQAzBZgQBcQgOBbhJAqQgoAXguAAQgjAAgngOg");
	this.shape_572.setTransform(940.3352,330.7627);

	this.shape_573 = new cjs.Shape();
	this.shape_573.graphics.f("#232323").s().p("An6E/QhXghgzhZQgzhYAPhcQAPhcBIgpQBJgqBXAhQBXAhAzBYQAzBYgPBcQgPBchIAqQgoAXguAAQgjAAgngOgAGyB+QhXghgzhYQgzhXAPhdQAPhcBIgqQBJgqBXAhQBXAiAzBYQAzBYgPBcQgPBbhIAqQgoAYguAAQgjAAgngPg");
	this.shape_573.setTransform(942.9102,329.7127);

	this.shape_574 = new cjs.Shape();
	this.shape_574.graphics.f("#232323").s().p("An5E/QhXghgzhZQgzhYAPhcQAPhcBIgpQBJgqBXAhQBXAhAzBYQAzBYgPBcQgPBchIAqQgpAXgtAAQgkAAgmgOgAGxB/QhXghgzhZQgzhXAPhcQAQhdBIgpQBIgqBXAhQBYAhAzBYQAzBZgQBcQgOBbhJAqQgoAXguAAQgjAAgngOg");
	this.shape_574.setTransform(945.4852,328.6877);

	this.shape_575 = new cjs.Shape();
	this.shape_575.graphics.f("#232323").s().p("An5E+QhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgoAXguAAQgjAAgngOgAGxB/QhXghgzhYQgzhXAPhdQAPhcBIgqQBJgqBXAhQBXAiAzBYQAzBYgPBcQgPBbhIAqQgoAXguAAQgjAAgngOg");
	this.shape_575.setTransform(948.0602,327.6377);

	this.shape_576 = new cjs.Shape();
	this.shape_576.graphics.f("#232323").s().p("An5E+QhXghgzhZQgzhYAPhcQAQhcBIgpQBIgqBXAhQBYAhAzBYQAzBYgQBcQgOBchJAqQgoAXgtAAQgkAAgngOgAGwCAQhXghgzhZQgzhXAPhcQAQhdBIgpQBIgqBXAhQBYAhAzBYQAzBZgQBcQgOBbhJAqQgoAXgtAAQgkAAgngOg");
	this.shape_576.setTransform(950.6102,326.5877);

	this.shape_577 = new cjs.Shape();
	this.shape_577.graphics.f("#232323").s().p("An4E9QhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgoAXguAAQgjAAgngOgAGwCAQhXghgzhYQgzhXAPhdQAPhcBIgqQBJgqBXAhQBXAiAzBYQAzBYgPBcQgPBbhIAqQgoAXguAAQgjAAgngOg");
	this.shape_577.setTransform(953.2102,325.5877);

	this.shape_578 = new cjs.Shape();
	this.shape_578.graphics.f("#232323").s().p("An4E9QhXghgzhZQgzhYAPhcQAQhcBIgpQBIgqBXAhQBYAhAzBYQAzBYgQBcQgOBchJAqQgoAXgtAAQgkAAgngOgAGvCBQhXghgzhZQgzhXAPhcQAQhdBIgpQBIgqBXAhQBYAhAzBYQAzBZgQBcQgOBbhJAqQgoAXgtAAQgkAAgngOg");
	this.shape_578.setTransform(955.7602,324.5377);

	this.shape_579 = new cjs.Shape();
	this.shape_579.graphics.f("#232323").s().p("An3E8QhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgpAXgtAAQgkAAgmgOgAGvCBQhXghgzhYQgzhXAPhdQAQhcBIgqQBIgqBXAhQBYAiAzBYQAzBYgQBcQgOBbhJAqQgoAXguAAQgjAAgngOg");
	this.shape_579.setTransform(958.3352,323.4877);

	this.shape_580 = new cjs.Shape();
	this.shape_580.graphics.f("#232323").s().p("An3E8QhXghgzhZQgzhYAPhcQAQhcBIgpQBIgqBXAhQBYAhAzBYQAzBYgQBcQgOBchJAqQgoAXgtAAQgkAAgngOgAGuCBQhXghgzhYQgzhXAPhdQAQhcBIgqQBIgqBXAhQBYAiAzBYQAzBYgQBcQgOBbhJAqQgoAYgtAAQgkAAgngPg");
	this.shape_580.setTransform(960.9102,322.4627);

	this.shape_581 = new cjs.Shape();
	this.shape_581.graphics.f("#232323").s().p("An2E7QhXghgzhYQgzhYAPhdQAPhbBIgqQBJgqBXAhQBXAiAzBYQAzBXgPBcQgPBchIAqQgpAYgtAAQgkAAgmgPgAGuCCQhXghgzhZQgzhXAPhcQAQhdBIgpQBIgqBXAhQBYAhAzBYQAzBZgQBcQgOBbhJAqQgoAXguAAQgjAAgngOg");
	this.shape_581.setTransform(963.4852,321.4127);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_565}]},589).to({state:[{t:this.shape_566}]},1).to({state:[{t:this.shape_567}]},1).to({state:[{t:this.shape_568}]},1).to({state:[{t:this.shape_569}]},1).to({state:[{t:this.shape_570}]},1).to({state:[{t:this.shape_571}]},1).to({state:[{t:this.shape_572}]},1).to({state:[{t:this.shape_573}]},1).to({state:[{t:this.shape_574}]},1).to({state:[{t:this.shape_575}]},1).to({state:[{t:this.shape_576}]},1).to({state:[{t:this.shape_577}]},1).to({state:[{t:this.shape_578}]},1).to({state:[{t:this.shape_579}]},1).to({state:[{t:this.shape_580}]},1).to({state:[{t:this.shape_581}]},1).to({state:[]},11).wait(692));

	// Слой_48
	this.instance_38 = new lib.городскиежильцыперсонажи62();
	this.instance_38.setTransform(138.9,494.45,0.5089,0.5089,-44.9976);

	this.instance_39 = new lib.городскиежильцыперсонажи60();
	this.instance_39.setTransform(729,51,0.4304,0.4304);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_39},{t:this.instance_38}]},589).to({state:[]},27).wait(692));

	// Слой_49
	this.shape_582 = new cjs.Shape();
	this.shape_582.graphics.f().s("#FFFFFF").ss(4,1,1).p("AflgrQhUEenuDVQpSEBtJAAQtHAApTkBQpSkAAAlqQAAk7HAjr");
	this.shape_582.setTransform(325.0625,651.0625);

	this.shape_583 = new cjs.Shape();
	this.shape_583.graphics.f("#0B88F0").s().p("A1xIDQpSkBAAlqQAAg9ARg7QBTkeOUjCQOUjCBnFxQBpFxNbhSQNbhTBjEMQBkELnADrQhEAkhPAiQpSEBtIAAQtIAApSkBg");
	this.shape_583.setTransform(364.8802,602.1792);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_583},{t:this.shape_582}]},589).to({state:[{t:this.shape_583}]},26).to({state:[]},1).wait(692));

	// Слой_47
	this.shape_584 = new cjs.Shape();
	this.shape_584.graphics.f("#232323").s().p("EArIAjpQgWggg4h3QgthggtguQgxgyhegpQAHAbgEAdQgKBShcAoQhVAlhbgVQg5gNhrgyQhqgxg5gNQhIgQheAHQgnADiBASQj2Aik4AFQi4AEl5gIQAJBAgyAzQgzA0g/gHQhAgHgmg9Qgmg9AWg9QhhgZhlAGQhmAGhdAmQg4AZgcALQgxASgngBQgvgBgkghQgmgkALgqQotA5orgSQAGBMhGA1QhGA1hIgaQgsgRgjgrQgUAIgUgKQgegRAEg9QACgfgBgWIgHgWIgLgkQg1hLgfhYQgMgigdhxQgXhdgZg0IgXgvQgOgcgHgUQgJgagHg1QgIg3gJgZQgMgmgcgnQgUgdgkgoQh2iCiIhrQhPg/gMgKQgygrgdgpQg5hRgQh6QgKhSAGiNQAHiRALhOQAHg2AUhpIAeieQAaiEAOg/QAahrAehTQAEgnAIgaQAGgSALgaIAUgsQAPgkAOg6QALgxAKg/IAPhyQASiPAKg3QAIgtAUhaIA2jzQAZhxATg2IATg0QALgdAFgWIAJg2QAHggAKgUQATgjAqgTIAUgbQAtg1A7gfQA+ghBCgCQBEgCA9AgQBAAiAfA6QALAUAMAlQARATAQAXQDCENBtGCQAZBWAOAjQAcBBAqAkQAxApBHAKQA1AHBVgJIBUgKQBIgjAdgTQAwghAvg2QAXgZAiguICDosQAahyAdg9QArhdBGgpQBRgwBpAYQBhAWBKBIQA/A9AxBiQAeA9AuB5ICpG/QAyCFAdBAQAwBrA0BOQAWAgAvA/QAoA5ASAtQAXA1AIBJQAFArADBYQAFDOAQB+QAXC1A3CKQAeBOAzBbQAgA6BABnIFOIcQAwBNAcApQA/AZAZAoQALATAKAlQA7AyBdAsQAPAHCdBCQCuBJDPB0QB7BFDzCUQBmA/AzAkQBRA7A1A9QAjApAjA4QAYAnAkBCQAZAwgBAvQgBA3gqAHIgJAAQglAAgjg0gAOJMDQAWAlAUAfIAaAkQAQAXAQARIALANQhciHg9heIAqBIg");
	this.shape_584.setTransform(1034.9276,615.8816);

	this.shape_585 = new cjs.Shape();
	this.shape_585.graphics.f("#FFFFFF").s().p("AC+CgQALhggzhIQgyhJhdgXQhcgYhPAoQglASgdAeQgdAdgRAkQgNAcgGAdQgJgoAAgwQgBh2AuhGQAuhDBZgYQBTgXBVAWQBaAYBFBCQBGBCAXBYQAXBZghBaQgjBdhNAvQgVAMgXAJQAzg4AJhSg");
	this.shape_585.setTransform(580.7834,195.8812);

	this.shape_586 = new cjs.Shape();
	this.shape_586.graphics.f("#232323").s().p("EgZTAuvQhOgQgpgvQgngtgIhKQgFgxAJhWQAJhTAKgpQAShEAjgrQAUgZAggXQAWgQAlgXIA4ggQACgcAHgjIAQhfIAHhKQAEgtAHgcQAFgSAMghQAMghAEgRQALgnAGhSQAWkkAIlRQAHkVgClhQgBiDgLhGQgFgegKgoIgRhGIgHgZIiSgBQg0AAgcgCQgsgDgigLQgjgLg/gjQh5hDg7grQhehHgvhRQgJgPgeg/QgXgxgVgbIgtgzQgcgegKgZQgEgJgDgMQgagjgagoQgagog4heQgjg3gVgpQgMgYgRgoIgdg/IgghBQgSgmgHgeQgLgpgBg6IAChlIgBhtQAAhAAJgsQANhJArhRQAagzA9hbQAeguAWgXIAFgFIgIhFIgWgsQgcg4gmhSQgbg8gKgbQgQgugShKQgchxgIg6QgKhOADhfQAChHANgtQAQgzAkgnIAQgRQgDgXAFgXQAKgvAmglQAlgjAxgMQAjgJA3ACIBdADIBCgDQAmgBAaAIQAYAIAaASQANAJAUASQBtAmBjA+QBtBDBYBbIBSBaQAyA4AlAfQApAkBpBFIA3AmIAGAAIDQABQBLABAlAEQA9AGAuAUIAOAHIAaAAQBLAAAyAKQBxAVBjBNQBIA4A3BNQAhAJAfAPQB7A6BaCXQAQAZAZAuIAmBIIAkA5QAUAiALAaQAZA5AOBiQAkDygJD2QgDA+gGAlQgIA2gTAoQgVAsgvA1IgjAoIAAAjIAAALQAeAmAbAlQBQA2BOBmQA4BJBNCFQASAPARASQBCBCBEBpQB/DEBQDXQA1CKAgCQQAaBAAMArQAXBTAFBzQABAXAACiIALBlQARCXALByQATDMAECfQACBYgCBTQA+gKA1gMQEXg/C5iKQCVhwB8i9QBbiKBojiQBejOBTjWQAwh6AUhOQAchxgFhfQgHhvg4haQg8hhhfgiQgogPg1gEQgggCg/AAIlCADQgiAAgSACQgeADgWAIQgbALglAfQgvAmgOAJQhHAshagSQhZgRg3hCQg1g/gKhZQgJhWAjhQQAghLBDg7QA+g4BRggQB0gtCpAAQBiAADFAOQC6AIAZADQB3ANBQAoQBHAkBFBGQArAsBIBcQBJBbAiAzQA3BSAcBKQAeBPALBpQAHBEABB6QADDpgKCTQgPDQgwCkQghBzg9CIQgmBThQCfQhCCAgkA/Qg9Bog9BLQhHBWhmBTQhSBDh0BLQjLCFisBJQlACJmnAeQktAWnXggQkTgSolgxIglgEIgVACIgWACQgKARgOAQQgaAfgnAeQgaAUgvAeQhUA3g3ARQgnANgzAFQgdAChAACIgWAAQhLAAgugKgA+8wNQBdAXAyBJQAzBJgLBgQgJBSgzA4QAXgJAVgMQBNgvAjhdQAhhagXhaQgXhYhGhCQhFhChagYQhWgWhTAXQhZAYguBDQguBGABB2QAAAxAJAoQAGgdANgcQARglAdgdQAdgeAlgSQAxgZA3AAQAhAAAjAJg");
	this.shape_586.setTransform(779.5896,289.1908);

	this.shape_587 = new cjs.Shape();
	this.shape_587.graphics.f("#232323").s().p("EgZTAuvQhOgQgpgvQgngtgIhKQgFgxAJhWQAJhTAKgpQAShEAjgrQAUgZAggXQAWgQAlgXIA4ggQACgcAHgjIAQhfIAHhKQAEgtAHgcQAFgSAMghQAMghAEgRQALgnAGhSQAUkDAIkmQggASgaALQhbAnh7AKQhMAHiSgEQhWgCgsgIQhHgMgugjQgmgbgYgsQgYgpgIgxQgPhUAehqQAhhxBCg/QAYgYAjgYQAUgNAugaICFhMQCjhdBRgnQBZgrARgJQA7ghAlgjIAIgJIgLgyIgRhGIgHgZIiSgBQg0AAgcgCQgsgDgigLQgjgLg/gjQh5hDg7grQhehHgvhRQgJgPgeg/QgXgxgVgbIgtgzQgcgegKgZQgEgJgDgMQgagjgagoQgagog4heQgjg3gVgpQgMgYgRgoIgdg/IgghBQgSgmgHgeQgLgpgBg6IAChlIgBhtQAAhAAJgsQANhJArhRQAagzA9hbQAeguAWgXIAFgFIgIhFIgWgsQgcg4gmhSQgbg8gKgbQgQgugShKQgchxgIg6QgKhOADhfQAChHANgtQAQgzAkgnIAQgRQgDgXAFgXQAKgvAmglQAlgjAxgMQAjgJA3ACIBdADIBCgDQAmgBAaAIQAYAIAaASQANAJAUASQBtAmBjA+QBtBDBYBbIBSBaQAyA4AlAfQApAkBpBFIA3AmIAGAAIDQABQBLABAlAEQA9AGAuAUIAOAHIAaAAQBLAAAyAKQBxAVBjBNQBIA4A3BNQAhAJAfAPQB7A6BaCXQAQAZAZAuIAmBIIAkA5QAUAiALAaQAZA5AOBiQAkDygJD2QgDA+gGAlQgIA2gTAoQgVAsgvA1IgjAoIAAAjIAAALQAeAmAbAlQBQA2BOBmQA4BJBNCFQASAPARASQBCBCBEBpQB/DEBQDXQA1CKAgCQQAaBAAMArQAXBTAFBzQABAXAACiIALBlQARCXALByQATDMAECfQACBYgCBTQA+gKA1gMQEXg/C5iKQCVhwB8i9QBbiKBojiQBejOBTjWQAwh6AUhOQAchxgFhfQgHhvg4haQg8hhhfgiQgogPg1gEQgggCg/AAIlCADQgiAAgSACQgeADgWAIQgbALglAfQgvAmgOAJQhHAshagSQhZgRg3hCQg1g/gKhZQgJhWAjhQQAghLBDg7QA+g4BRggQB0gtCpAAQBiAADFAOQC6AIAZADQB3ANBQAoQBHAkBFBGQArAsBIBcQBJBbAiAzQA3BSAcBKQAeBPALBpQAHBEABB6QADDpgKCTQgPDQgwCkQghBzg9CIQgmBThQCfQhCCAgkA/Qg9Bog9BLQhHBWhmBTQhSBDh0BLQjLCFisBJQlACJmnAeQktAWnXggQkTgSolgxIglgEIgVACIgWACQgKARgOAQQgaAfgnAeQgaAUgvAeQhUA3g3ARQgnANgzAFQgdAChAACIgWAAQhLAAgugKgA+8wNQBdAXAyBJQAzBJgLBgQgJBSgzA4QAXgJAVgMQBNgvAjhdQAhhagXhaQgXhYhGhCQhFhChagYQhWgWhTAXQhZAYguBDQguBGABB2QAAAxAJAoQAGgdANgcQARglAdgdQAdgeAlgSQAxgZA3AAQAhAAAjAJg");
	this.shape_587.setTransform(779.5896,289.1908);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_584}]},560).to({state:[{t:this.shape_586},{t:this.shape_585}]},10).to({state:[{t:this.shape_587},{t:this.shape_585}]},9).to({state:[]},10).wait(719));

	// КОТИЧЕК
	this.instance_40 = new lib.городскиежильцыперсонажи61();
	this.instance_40.setTransform(151,177,0.5453,0.5453);

	this.shape_588 = new cjs.Shape();
	this.shape_588.graphics.f().s("#FFFFFF").ss(4,1,1).p("AdEAAQAAFRohDvQogDusDAAQsCAAohjuQogjvAAlRQAAlRIgjuQIhjvMCAAQMDAAIgDvQIhDuAAFRg");
	this.shape_588.setTransform(259.8,597.9);

	this.shape_589 = new cjs.Shape();
	this.shape_589.graphics.f("#0B88F0").s().p("A0jJAQogjuAAlSQAAlRIgjuQIhjuMCgBQMCABIhDuQIhDuAAFRQAAFSohDuQohDusCAAQsCAAohjug");
	this.shape_589.setTransform(259.8,597.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_40,p:{rotation:0,x:151,y:177}}]},560).to({state:[{t:this.shape_589},{t:this.shape_588},{t:this.instance_40,p:{rotation:-45,x:45.65,y:521.85}}]},28).to({state:[]},1).wait(719));

	// Слой_96
	this.shape_590 = new cjs.Shape();
	this.shape_590.graphics.f("#0B88F0").s().p("AyvIBICCkPItg6tIHUpzISBL2IB9kFIZynHIudWpIAANYIV0lwIAAWiMgk1AMAgA5d0iIKyUEIHlvxIuiq4g");
	this.shape_590.setTransform(515.175,328.8);
	this.shape_590._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_590).wait(985).to({_off:false},0).to({_off:true},18).wait(305));

	// Слой_97
	this.shape_591 = new cjs.Shape();
	this.shape_591.graphics.f("#0B88F0").s().p("AKrW2QgagGgQgUQgPgSgIgbQgFgSgFgfQgNhMgVipQgUiggPhVQgWiAhlmZQhRlMgTjQQgVjwAgkLQAKhWABgXQAFg+gHgwQgIg6gbguQgdgzgugaIgRgIIgHABQgOACgYAAImmAAQiQAAhIgGQhKgFgzgPQhCgUgpgoQgcgbgMggQgJgbACguQADhDAfgYQAPgLAWgEQAQgDAaAAIDYABQAaAAAOACQAXAEAOALQAYARAAAhQAAAggXASQgTAPgqAEQghADhDABQhDAAghADQAeAVA1AKQAkAHAuACQAbACA3AAIHKADQAVgdA4AEQBMAFBEAyQBAAwAmBJQA/B4gIC7QgCA5gMBlQgMBugDAvQgREABTFuQAPBBA9D0QAwC+AWB3QAVBpAeDYIApEpQAFAhgDAVQgEAegTAOQgOALgRAAQgHAAgJgDg");
	this.shape_591.setTransform(808.2139,708.9006);

	this.shape_592 = new cjs.Shape();
	this.shape_592.graphics.f("#0B88F0").s().p("AKnXyQgagGgRgUQgOgSgIgbQgGgSgFgfQgMhMgWipIgMhgIihlYQgxhqgXg1QglhbgThLQgmiSAEi+QAChzAZjgIA+o0QADgeAAgQQgBgagKgSQgRgig8gZQh4gwiBAFIg3ADQgggBgWgIQgbgKgQgWIhjAAQiRAAhIgGQhJgFgzgPQhCgUgpgoQgdgbgLggQgKgbACguQADhDAfgYQAPgLAXgEQAPgDAbAAIDXABQAaAAAPACQAWAEAPALQAXARAAAhQABAggXASQgTAPgrAEQghADhDABQhCAAgiADQAeAVA1AKQAkAHAuACQAcACA3AAIF3ADIgBgBQgPgIgKgPQgKgQgBgRQgBgSAJgQQAIgRAOgJQAJgFAOgFIAYgHQAggLAjghQAlgkAHgFIAjgWIAigYQAVgPAPgGQAZgLAzgEQBWgHAqAAQA8gBAXAaQAQAQAFAgQAIAvgOAmQgQAtgmATQgLAGgTAFIggAJIggAOQgUAKgLADQgoAOgbgOQgVgLgKgaQgIgXACgbQgJALgVAKQgcANgFADQgLAHgNAOIgWAWQgMALgNAJIASABQBNAFBDAyQBAAwAmBJQBAB4gIC7QgCA5gMBlQgNBugDAvQgREABUFuQAOBBA9D0IAGAYQBwD5A0FSQAFAdAAAQQABAagGAUQgHAXgRAPIgJAHIAaC0QAFAhgDAVQgFAegTAOQgNAKgRAAQgIAAgIgCg");
	this.shape_592.setTransform(808.6847,702.9487);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_591}]},994).to({state:[{t:this.shape_592}]},8).to({state:[]},1).wait(305));

	// Слой_95
	this.shape_593 = new cjs.Shape();
	this.shape_593.graphics.f().s("#232323").ss(6,1,1).p("AnFHCQhuiRAAi/QAAjpClimQClilDpAAQDqAAClClQCmCmAADpQAACchKB9");
	this.shape_593.setTransform(795.1,519);

	this.shape_594 = new cjs.Shape();
	this.shape_594.graphics.f("#FFFFFF").s().p("AmKHGIgmgGIgVgCQhuiRgBi/QAAjpCmimQClilDpAAQDqAAClClQCmCmAADpQAACchKB9QAIhFgNhDQgVhnhFhWQhFhUhggrQhhgrhtAHQhtAGhbA3QhaA1g5BeQg6BdgIBpQgDArAEAjQADAiAJAhg");
	this.shape_594.setTransform(795.1,519.4);

	this.shape_595 = new cjs.Shape();
	this.shape_595.graphics.f("#0B88F0").s().p("AmECBQgigBgbgGQhGgOgigxQgSgagBggQgBghASgYQAbgjA5gFQAMgBAOABIAVACIAmAGIATAAICfAAQAbAAAOACQAWAEAOAKIACACQBFgBBwgEQAxgCAegGQAQgDAbgJIArgNQAmgKAygEIBZgFQAhgCARABQAcACAVAJQAmASAZAtQAaAwgNAmQgPAxhIAWQgnALgyAEQgdACg/AAQkygClAAKIgzABIgMAAg");
	this.shape_595.setTransform(794.2863,573.7396);

	this.shape_596 = new cjs.Shape();
	this.shape_596.graphics.f("#232323").s().p("EgufA4TQhkgLhYg3QhYg3g1hVQg1hVgMhnQgMhnAghfQAsiBCTiPQCtibBKhWQBVhjBMiSQAthZBMi1QA9iSAchKQAvh8AchmQAHgZANg0QA0oYDTpTQCzn4FUqYQBWinA5hcQBWiLBbhgQAngqBShSQAngpAZgoIgCgIQgPhAgEhhIgFhzQgEhBgKgwQgFgXgNgyQgNgvgFgZQgMg7gChwIgQqnQgDhnAEg2QAFhXAWhCQAghkBNhOQAogpAvgeQAfglAsgXQANgHANgFQBYg+ClAZQEtAuEkDaQDpCuDyEoQBGBWCHCwQCHCwBGBWQD1EtDeClQAxAkCUBiQB8BSBFA4QCpCLCWDcQBrCcCKEIQEbIdC/HhQDdIpB1IHQBJFBBdKAQBeKIBGE5QARBPABArQACBEgdAtQgwBIhlgFQhigFg/hEQg2g6gehgQgSg8gSh0Iguk3QhOA2hpAYQhjAXh0gEQhYgEh/gUQiOgahHgLQiJgUitgJQhogGjQgEQvRgUniAEQssAGqFA9Qi9AShcgEQh0gGhZgjQjEFOj1DiQkHD0jwAAQgaAAgZgDgAI4BsQg5AFgbAjQgSAYABAiQACAgASAaQAhAxBGAOQAbAGAjABQAVABApgCQFBgKEzACQA/AAAcgCQAzgEAngLQBHgWAQgxQANgngbgwQgYgtgngSQgUgJgcgCQgSgBggACIhZAFQgzAEglAKIgrANQgbAJgRADQgdAGgxACQhyAEhEABIgCgCQgPgKgWgEQgOgCgaAAIifAAQgJghgEgjQgDgjACgpQAJhqA5hdQA6hdBag2QBbg3BugHQBtgGBhAqQBgArBFBVQBFBWAVBoQANBDgIBDQBJh8AAibQAAjqilimQililjqAAQjqAAimClQilCmAADqQAAC/BvCQIgOAAIgNAAg");
	this.shape_596.setTransform(690.2196,553.2302);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_596},{t:this.shape_595},{t:this.shape_594},{t:this.shape_593}]},985).to({state:[]},18).wait(305));

	// Слой_108
	this.shape_597 = new cjs.Shape();
	this.shape_597.graphics.f("#FFFFFF").s().p("AhxBsQgUgPgMgWQgNgWgCgYQgDgbAOgpQASgzAdgVQAXgQAigCQAWgBAnAEQAoAFATAFQAgAIAUARQASAPAJAXQAJAXgCAXQgHA8hMAvQg2AjgtADIgMAAQgtAAgjgag");
	this.shape_597.setTransform(1517.1582,524.4798);

	this.shape_598 = new cjs.Shape();
	this.shape_598.graphics.f("#232323").s().p("AWGByQgTgGgOgPQgNgOgEgUQgFgUAGgTQAHgYAXgQQAXgQAaACQAaABAVATQAUASAEAaQAEAdgSAaQgTAbgdAFIgOACQgMAAgNgFgAq0gHQgRgHgIgRQgJgRADgSQADgQAOgMQANgMAQgBQAFAAABgBQAPABAMAIQANAHAHANQAGANgBAPQgBAPgIAMQgLAOgSAFQgIACgHAAQgKAAgKgEgA3GgPQgSgFgKgPQgKgPABgTQACgUAMgNQAJgIALgEQAGgCAJAAQABAAAAAAQABAAAAgBQABAAAAAAQABAAAAgBQASABAPAMQAOANAEARQADASgJARQgJARgRAHQgJAEgKAAQgHAAgJgDg");
	this.shape_598.setTransform(1369.8092,561.6727);

	this.shape_599 = new cjs.Shape();
	this.shape_599.graphics.f("#FFFFFF").s().p("AgMCIQg/gNgigfQgogigHgxQgDgYAGgYQAGgZAQgSQASgWAngTQAxgXAiAFQAbAFAaAXQAQAOAZAgQAaAgAJAQQARAcACAaQACAXgJAXQgKAXgSAPQgfAYgwAAQgaAAgdgHg");
	this.shape_599.setTransform(1549.8529,523.2457);

	this.shape_600 = new cjs.Shape();
	this.shape_600.graphics.f("#232323").s().p("AUSBZQgOgEgJgKQgJgKgDgOQgDgOAEgNQAFgRAQgKQAPgLASACQASABAOAMQAPAMACASQADAVgNARQgMATgUAEIgJABQgJAAgJgEgAtFAXQgRgHgIgQQgJgSADgRQADgQAOgMQANgMAQgBQAFAAABgCQAPABAMAIQANAIAHANQAGANgBAPQgBAPgIAKQgLAPgSAFQgIACgHAAQgLAAgJgEgA0xAKQgTgFgKgOQgKgPACgTQABgUANgNQAJgIALgEQAGgCAIAAQABAAABAAQAAAAABgBQAAAAABAAQAAAAAAgBQASABAPAMQAPANADARQAEASgKARQgJAQgQAHQgKAEgJAAQgIAAgIgDg");
	this.shape_600.setTransform(1382.2773,561.9167);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_598},{t:this.shape_597}]},1120).to({state:[{t:this.shape_600},{t:this.shape_599}]},12).to({state:[]},19).to({state:[]},1).wait(156));

	// Слой_107
	this.instance_41 = new lib.городскиежильцыперсонажи43();
	this.instance_41.setTransform(339,-16,0.5383,0.5383);
	this.instance_41._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_41).wait(1120).to({_off:false},0).to({_off:true},31).wait(157));

	// клюв
	this.shape_601 = new cjs.Shape();
	this.shape_601.graphics.f("#232323").s().p("AmtEXQgHiDAehrQAehqBDgvQBDgvBagBQBagCAlgIQAjgICdhCQA0gWBzg7QBbgnAGApQAHAojTDLQgnAkhQAtQhaAzghAbQgaAVhDBKQg6A/hHAwQhaA8gwAAQgzAAgDhCg");
	this.shape_601.setTransform(387.5935,333.8452);
	this.shape_601._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_601).wait(1055).to({_off:false},0).wait(11).to({x:326.1935,y:349.3452},0).wait(11).to({x:388.0935,y:338.3952},0).to({_off:true},43).wait(188));

	// Слой_89
	this.instance_42 = new lib.фоны_фонстол2copy4();
	this.instance_42.setTransform(-847,-396,0.5243,0.5243);
	this.instance_42._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_42).wait(905).to({_off:false},0).wait(23).to({scaleX:0.6796,scaleY:0.6796,x:-1550,y:-723},0).wait(32).to({scaleX:0.955,scaleY:0.955,x:-1672,y:-1135},0).wait(25).to({scaleX:0.9483,scaleY:0.9483,x:-1209,y:-1345},0).to({_off:true},18).wait(52).to({_off:false,scaleX:0.4758,scaleY:0.4758,x:-612,y:-349},0).wait(65).to({scaleX:0.6384,scaleY:0.6384,x:-994,y:-718},0).to({_off:true},32).wait(156));

	// Слой_109
	this.shape_602 = new cjs.Shape();
	this.shape_602.graphics.f("#232323").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_602.setTransform(1454.575,499.925);

	this.shape_603 = new cjs.Shape();
	this.shape_603.graphics.f("#232323").s().p("ABSAdQAAgLgJAAQghAAguAEQgwAEgVAGQgUAGgFAFQgFAFgDAWQgEAWAAAXIAAArQAAAmgjAAQgdAAAAgmQAAgYAHgmQALhGAMipQABgWADgGQACgGALgHQAKgHAMAAQAaAAAAAUIgIA1QgJAyAAAbQAAATAOAAQAaAABGgIQBHgKADgFQAEgHAIhRQAGhBAjAAQAdAAAAAdQAAAGgFAVQgbBwAABLQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQg3AAAAiqg");
	this.shape_603.setTransform(1412.525,499.125);

	this.shape_604 = new cjs.Shape();
	this.shape_604.graphics.f("#232323").s().p("AhyC4QgkgVAAgaQAAgUAZAAQADAAAIAFQAmAiA1AAQAuAAAigZQAhgYABgoQgBgagSgRQgUgRgZAAQgUAAgvAOQgJADgLABQgWAAABgcQAAgKAKgFQAJgHAhgIQBkgWAAg7QAAgRgNgLQgMgMgUAAQgkAAgpAgQgYAUgNgBQgVABgBgVQAAgaAygcQAygcAtABQAtgBAbAZQAaAYAAAbQAABAhOAkQAuAHAZAZQAZAaAAAmQAAA7gyAoQgyAohSAAQgwgBgjgVg");
	this.shape_604.setTransform(1372.25,498.9);

	this.shape_605 = new cjs.Shape();
	this.shape_605.graphics.f("#232323").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_605.setTransform(1333.725,499.925);

	this.shape_606 = new cjs.Shape();
	this.shape_606.graphics.f("#232323").s().p("AkUDQQgNgJAAgKQAAgVApgrQApgsAxgeQA9glAWgWQgKgPgdgQQgegTgagVIgIgHQgugegOgPQgPgPAAgSQAAgMAIgKQAJgJAJAAQAFAAAOAGQANAFAGAGIARAQQBbBaA2AYQACAAAFgGQADgNAAgaQAAgZgFgeIgDgVQAAgQANgLQAMgKAPAAQARAAAGAIQAHAGAAASIgFBvIAAAHIAAAIQANAAANgJQAOgKAagdQB0h4ASAAQAKAAAIAJQAJAIAAALQAAAGgmAqQgnAqgpAjQg0AtAAACQAAADArAgQAvAlASAQIAHAFQA0AfANAQQANAQAAALQAAAKgIALQgJAKgJAAQgfAAhyhoQgygwgLgCIgHgCQgDgBgKABQgJAAAAACQgFBQgLBLQgFAPgUAAQgfAAAAgfQAAgOAHgjQAFgfABgLIACgYQABgNgCgJQgSADg3AoQg3ApgoAnQgCACgNAYQgTAmgWAAQgLAAgMgJg");
	this.shape_606.setTransform(1281.025,498.65);

	this.shape_607 = new cjs.Shape();
	this.shape_607.graphics.f("#232323").s().p("AhyC4QgkgVAAgaQAAgUAYAAQAEAAAIAFQAmAiA1AAQAuAAAigZQAhgYABgoQAAgagTgRQgUgRgZAAQgUAAgvAOQgJADgLABQgWAAAAgcQAAgKALgFQAJgHAhgIQBkgWgBg7QAAgRgMgLQgNgMgTAAQgkAAgpAgQgZAUgMgBQgVABgBgVQAAgaAzgcQAxgcAtABQAtgBAbAZQAaAYAAAbQAABAhOAkQAuAHAZAZQAZAaAAAmQAAA7gyAoQgzAohRAAQgwgBgjgVg");
	this.shape_607.setTransform(1202.5,498.9);

	this.shape_608 = new cjs.Shape();
	this.shape_608.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_608.setTransform(1164.975,499.125);

	this.shape_609 = new cjs.Shape();
	this.shape_609.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAJgiQBAkDAAjEIgBgeQAAgmAOgRQAOgRASAAQAJAAAIANQAHANABAYQAAAigIAxQgJA9AAAJQA0hbA6gzQA6g0AzAAQAjAAAZAbQAYAaAAAoQAAByhXBeQhZBchSAAQgUAAgNgKQgMgLgNgcQgRBAgPByIgKBCQgCAPgLAOQgLANgJAAQgLAAgNgLgAgGibQhIBdgBA0QAAALAPAMQAOAMAXAAQAxAABChJQBAhKABhIQgBgagJgNQgLgPgPAAQgyAAhJBdg");
	this.shape_609.setTransform(1119,509.975);

	this.shape_610 = new cjs.Shape();
	this.shape_610.graphics.f("#232323").s().p("AifEVQgXgsAAg0QAAhcA5hRQA4hRBAAAQAIgBAMALQAMALAFgCQgOglgvgqQgtgnAAgcQAAgWAOgOQAPgOAogLQAxgOA0gSQAzgRALgFQAHgDAGAAQAMgBAAAWQAAALgcAUQgcAUhIASQgsAKgLAGQgJAFAAAGQABANAaAYQBnBaABCIQAAA6ggBEQgfBCgzAhQgyAhgyAAQgsAAgXgrgAhLAqQguBMABBAQgBAnALAWQALAXARAAQAWAAAmgcQAlgcAYg3QAXg2AAgvQAAgogKgXQgMgYgKgBQg9ABgsBLg");
	this.shape_610.setTransform(1082.4,486.5);

	this.shape_611 = new cjs.Shape();
	this.shape_611.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_611.setTransform(1040.125,499.575);

	this.shape_612 = new cjs.Shape();
	this.shape_612.graphics.f("#232323").s().p("ABZD0QgPglAAhHIAAgMIAAgLQgsBLgvApQgvAqgoAAQgYAAgYgbQgYgbABg5QgBguAWhZQAThKAAgeQALgVAVAAQAPAAAJAKQAIAKAAAMQABAZgSAsQggBYAAA/QAAA6AbAAQAhAAA1g6QA0g6AlhnQAPgqAKgMQAJgMAQAAQAXAAAAAgQABADgHAWQgVBMAABFQAABSAbAYQAOANAAAJQAAAJgOAIQgOAJgMAAQgZgBgPgkgAgKiSQgTgFgQgIQgQgJgMgMQgNgMgIgPIgFgKIgEgLIgCgKIgCgHQABgJACgGQACgGAEgEQAEgEAEgBIAJgBQALgBAHAFQAHAEABAIQABAQAGAPQAFAOAJAKQALAJAQAHQARAGAXAAIANAAIAPgDIAPgGQAIgDAEgDQAJgGAHgHQAFgIAFgJIAHgRIAFgPQAEgKAGgFQAHgFAHAAQANAAAHAIQAHAIAAAQQgBAGgDALQgEAJgHAMQgGALgKAMQgKAKgLAJQgJAFgLAGQgMAFgNAEIgbAFIgaACQgUAAgRgFg");
	this.shape_612.setTransform(969,490.95);

	this.shape_613 = new cjs.Shape();
	this.shape_613.graphics.f("#232323").s().p("AjTCtQgVgfAAg7QAAg+AQhMQAQhMAJgaIAHgWQAEgOAfgHQAFgDAFAAQAJAAAGAYQAAAPgIAXQgYBDAAAaQAAAHAEABQBRhOBFAAQAqAAAcAgQAdAgAAAbQAABRhTBLQhSBLhUAAQgmAAgVgfgAhBgzQgbAOghAfIgUARQgIAHgMACQgHAnAAAnQAAA1ApAAQAvAAA7g4QA5g5AAg0QAAgVgLgPQgMgPgTAAQgcAAgbAOgAB+CHQAAg+AbiSQAKg1AAgLQAAgWAIgQQAIgQAPAAQASAAAKAJQALAIAAALQAAALgFASQgcBkgGAnQgGApAAA3QAAAaAHAiIABAKQAAAHgLAKQgMAKgNAAQgiAAAAg/g");
	this.shape_613.setTransform(921.325,497.725);

	this.shape_614 = new cjs.Shape();
	this.shape_614.graphics.f("#232323").s().p("ABSAdQAAgLgJAAQghAAguAEQgwAEgVAGQgUAGgFAFQgFAFgDAWQgEAWAAAXIAAArQAAAmgjAAQgdAAAAgmQAAgYAHgmQALhGAMipQABgWADgGQACgGALgHQAKgHAMAAQAaAAAAAUIgIA1QgJAyAAAbQAAATAOAAQAaAABGgIQBHgKADgFQAEgHAIhRQAGhBAjAAQAdAAAAAdQAAAGgFAVQgbBwAABLQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQg3AAAAiqg");
	this.shape_614.setTransform(873.125,499.125);

	this.shape_615 = new cjs.Shape();
	this.shape_615.graphics.f("#232323").s().p("ABDC0QAAgLADgJQAFgMAVijQg3Awg0AcQg2AcgagBQgkAAgSgcQgSgdAAgmQAAg0AShAQASg/AtgBQAJAAAHAMQAGALAAAQQAAATgTAgQgYAqAAAdQgBASAHAPQAFARAQAAQAmAAA5glQA6gnANgdQANgdAAgQIgBgNQgCgGAAgIQAAgMAJgSQAJgRAPAAQARgBAIAJQAGAIAAAgQAAAUgFBEIgCAcQgDAsgMBXQgNBVgIALQgHALgOAAQghgBAAgVg");
	this.shape_615.setTransform(832.2,498.3);

	this.shape_616 = new cjs.Shape();
	this.shape_616.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_616.setTransform(793.975,498.875);

	this.shape_617 = new cjs.Shape();
	this.shape_617.graphics.f("#232323").s().p("AjZCLQAAgRAGgfQAThpAAh2QAAgNAMgRQALgQAKAAQATAAAHAMQAIAKAAAjQAAAjgVBuQgHAlAAAJQAAAGADAAQAFAAAshTQAshWAhgiQAggjAnAAQAgAAAUAdQAUAcAJBNQAKBVAIAWQAIAVARABQALgBAQgHIAFgCQAPAAAAASQAAAPgVASQgVARgdAAQgeAAgQgXQgRgYgJhoQgKhmggAAQgSAAgUAYQgWAYgsBTQg7BvgRAQQgRAPgLAAQgqAAAAgog");
	this.shape_617.setTransform(752.425,499.95);

	this.shape_618 = new cjs.Shape();
	this.shape_618.graphics.f("#232323").s().p("Ah2CvQgdgfAAg2QAAhaBJhnQBJhlA9AAQAdAAAUAfQAVAeAAAjQAAAUgJAQQgJAOgJAAQgVAAgIgpQgKgsgRAAQglAAgxBXQgyBVAAA9QAAA7BEAAQAzAABGgxQAYgQAMgBQAMAAAAAOQAAAbg/AoQg/Apg8AAQg0AAgcgeg");
	this.shape_618.setTransform(708.825,499);

	this.shape_619 = new cjs.Shape();
	this.shape_619.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_619.setTransform(672.425,498.875);

	this.shape_620 = new cjs.Shape();
	this.shape_620.graphics.f("#232323").s().p("AifEVQgXgsAAg0QAAhcA5hRQA4hRBAAAQAHgBANALQAMALAFgCQgOglgvgqQgtgnAAgcQAAgWAOgOQAPgOAogLQAxgOA0gSQA0gRAKgFQAHgDAGAAQAMgBAAAWQAAALgcAUQgcAUhIASQgsAKgLAGQgIAFgBAGQABANAaAYQBnBaABCIQAAA6ggBEQgfBCgzAhQgyAhgyAAQgsAAgXgrgAhLAqQguBMABBAQAAAnAKAWQALAXARAAQAWAAAmgcQAlgcAYg3QAXg2AAgvQAAgogKgXQgMgYgJgBQg+ABgsBLg");
	this.shape_620.setTransform(638.35,486.5);

	this.shape_621 = new cjs.Shape();
	this.shape_621.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAJgiQBAkDAAjEIAAgeQgBgmAOgRQAOgRATAAQAIAAAIANQAHANAAAYQAAAigGAxQgKA9AAAJQA0hbA6gzQA7g0AyAAQAjAAAZAbQAYAaAAAoQAAByhXBeQhZBchSAAQgUAAgNgKQgMgLgNgcQgRBAgPByIgKBCQgDAPgKAOQgKANgJAAQgLAAgOgLgAgFibQhKBdABA0QAAALAOAMQAPAMAVAAQAyAABBhJQBBhKAAhIQAAgagKgNQgKgPgQAAQgxAAhIBdg");
	this.shape_621.setTransform(562.5,509.975);

	this.shape_622 = new cjs.Shape();
	this.shape_622.graphics.f("#232323").s().p("AiED5Qg2gkAAgZQAAgMAFgLQAGgLAIAAQAEAAAFAGQAuBHBgAAQA8AAAehKQAehLAIhzQg1Axg2AcQg0AdgcAAQghAAgUgcQgTgcAAgoQAAg7AXhRQAWhRAMgLQAMgLAUAAQAKAAAGANQAGAMAAANQAAAJgIAOQguBQAABVQAAATAHAPQAIAOAPAAQATAAAdgKQAbgMAjgbQAkgbAMgQQANgRAFgVQAFgVAChGQAChHAgAAQATAAAGALQAFAJAAAdQAAAVgGBGIgCAdQgKC7guBqQguBrhXAAQhFAAg1gkg");
	this.shape_622.setTransform(517.725,508.525);

	this.shape_623 = new cjs.Shape();
	this.shape_623.graphics.f("#232323").s().p("ABDC0QAAgLADgJQAFgMAVijQg2Awg1AcQg2AcgbgBQgiAAgTgcQgTgdAAgmQABg0AShAQASg/AsgBQALAAAFAMQAHALAAAQQAAATgTAgQgZAqAAAdQABASAGAPQAFARAQAAQAmAAA5glQA5gnAOgdQANgdAAgQIgBgNQgCgGABgIQAAgMAIgSQAJgRAOAAQATgBAGAJQAIAIAAAgQAAAUgHBEIgCAcQgCAsgNBXQgNBVgHALQgHALgNAAQgigBAAgVg");
	this.shape_623.setTransform(479.35,498.3);

	this.shape_624 = new cjs.Shape();
	this.shape_624.graphics.f("#232323").s().p("AhyC4QgkgVAAgaQAAgUAZAAQADAAAIAFQAmAiA1AAQAuAAAigZQAhgYABgoQAAgagTgRQgUgRgZAAQgUAAgvAOQgJADgLABQgWAAAAgcQAAgKALgFQAJgHAhgIQBkgWgBg7QAAgRgMgLQgNgMgTAAQgkAAgpAgQgYAUgNgBQgVABgBgVQAAgaAzgcQAxgcAtABQAtgBAbAZQAaAYAAAbQAABAhOAkQAuAHAZAZQAZAaAAAmQAAA7gyAoQgyAohSAAQgwgBgjgVg");
	this.shape_624.setTransform(441.1,498.9);

	this.shape_625 = new cjs.Shape();
	this.shape_625.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_625.setTransform(406.475,498.875);

	this.shape_626 = new cjs.Shape();
	this.shape_626.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAJgiQBAkDAAjEIAAgeQgBgmAOgRQAOgRASAAQAJAAAIANQAHANABAYQgBAigGAxQgKA9AAAJQA0hbA6gzQA6g0AzAAQAkAAAYAbQAYAaAAAoQAAByhXBeQhYBchTAAQgUAAgNgKQgMgLgNgcQgRBAgPByIgKBCQgCAPgLAOQgKANgKAAQgLAAgNgLgAgGibQhIBdAAA0QAAALAOAMQAOAMAXAAQAxAABBhJQBChKAAhIQgBgagJgNQgLgPgPAAQgyAAhJBdg");
	this.shape_626.setTransform(362.45,509.975);

	this.shape_627 = new cjs.Shape();
	this.shape_627.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_627.setTransform(322.525,498.875);

	this.shape_628 = new cjs.Shape();
	this.shape_628.graphics.f("#232323").s().p("ABDC0QAAgLADgJQAFgMAVijQg3Awg0AcQg2AcgagBQgkAAgRgcQgUgdABgmQAAg0AShAQASg/AtgBQAKAAAGAMQAGALAAAQQAAATgTAgQgZAqAAAdQAAASAHAPQAFARAQAAQAmAAA5glQA6gnANgdQANgdAAgQIgBgNQgBgGgBgIQAAgMAJgSQAJgRAPAAQARgBAIAJQAGAIAAAgQAAAUgFBEIgDAcQgCAsgMBXQgNBVgIALQgIALgNAAQghgBAAgVg");
	this.shape_628.setTransform(284.45,498.3);

	this.shape_629 = new cjs.Shape();
	this.shape_629.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_629.setTransform(215.575,499.575);

	this.shape_630 = new cjs.Shape();
	this.shape_630.graphics.f("#232323").s().p("AhrCwQgfgUgDgiIgBgHQgDgjAZgnQAagoBlgyQBCghAAgbQAAgOgMgIQgMgIgJAAQgaAAhKAlIgHAEQgdgBAAgUQAAghA5gWQA4gWAqAAQAaAAAdAVQAdAVAAAjQAAAdgTAaQgSAbhLApQg8AigVAVQgWAWAAAcQAAATASAHQATAGAKAAQBBAAA0gcQASgIAIgBQATAAAAAVQAAAfgyAUQgyAVhMAAQgkAAgggVg");
	this.shape_630.setTransform(178.1789,499.15);

	this.shape_631 = new cjs.Shape();
	this.shape_631.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_631.setTransform(141.825,498.875);

	this.shape_632 = new cjs.Shape();
	this.shape_632.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_632.setTransform(1442.425,371.675);

	this.shape_633 = new cjs.Shape();
	this.shape_633.graphics.f("#232323").s().p("AhzC4QgjgVAAgaQAAgVAZABQADAAAHAFQAnAiA1AAQAuAAAhgZQAjgYgBgoQAAgagSgRQgUgRgZgBQgUAAgvAPQgKADgLAAQgUAAAAgbQgBgKALgFQAJgGAigIQBjgXAAg6QAAgSgNgLQgNgMgTAAQgjAAgqAgQgZAUgMgBQgVAAAAgTQgBgbAygcQAygbAtAAQAugBAaAZQAaAYAAAbQAAA/hOAlQAtAHAaAZQAZAaAAAmQAAA7gyAoQgyAohSAAQgwgBgkgVg");
	this.shape_633.setTransform(1403.05,371.45);

	this.shape_634 = new cjs.Shape();
	this.shape_634.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_634.setTransform(1336.725,371.675);

	this.shape_635 = new cjs.Shape();
	this.shape_635.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAJg2AAgYQAAgXAVAAQAnAAAAA4QAAAagNBNQgPBXgBATQAXgVAphGQA8hiAdgaQAcgaAeAAQAXAAANAeQAOAfADByQABAdAEAOQAEAOACAAQAQAAA4hvQAdg8AcgfQAcgfAiAAQAcAAANAeQANAdAGA6QAFA5AMAxQALAwAdAOQAUAJAAANQAAAMgRANQgQANgOAAQgdAAgWgiQgWgjgMhxQgEgugFgUQgEgTgKAAQgPAAgUAcQgUAcgtBVQgkBEgRAWQgTAWgPAAQgPAAgMgMQgNgMgDgRQgDgRgEhDQgEhugPgSQghAAhqDAQglBBgGAGQgGAGgPAFQgRAEgKAAQgYAAAAhcg");
	this.shape_635.setTransform(1280.75,371.175);

	this.shape_636 = new cjs.Shape();
	this.shape_636.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_636.setTransform(1221.525,372.125);

	this.shape_637 = new cjs.Shape();
	this.shape_637.graphics.f("#232323").s().p("AkkD/QAAgWAEgiQAJhcAGidIAFihIAAgPQAAhAApAAQAOAAAIANQAJAMAAALQAABagNBcQgDAuAAAYQAAAEABACIAEAIQAogXBThQQBUhSAfgYIAPgMQAogpASAAQALAAAQALQAQALAAAHQAAABAAABQgBAAAAABQAAAAAAABQgBAAAAAAQgmAshOBAQhWBIhBBAQA+AdBeAfIAFADQAUAKAIACQASAFANAGQAtAVAsANQArANAJAAQADAAAFgEQAEgDAEAAQAPAAALAQQAMAQAAAJQAAARgMALQgMAKgQAAQgZAAhFgYQhEgZgkgRQgXgKhigmQhjglgPAAQgaAAgMALQACAGAAAMQAAAPgIA+QgGA0AAAOQAAAOgPAMQgOAMgSAAQgPAAAAgkg");
	this.shape_637.setTransform(1170.375,362.975);

	this.shape_638 = new cjs.Shape();
	this.shape_638.graphics.f("#232323").s().p("AjACwQAAgYAhgpQAignA1hcQA2heAhhKQAGgNANAAQAFAAANAFQAOAEAEAGQAEAFANA8QAsDXAvAoQALAKACADQADADAAAGQgBALgGAJQgIAJgGACQgHADgVAAQgHAAgbgkQgbglgkihQgJgsgGgOQgJgBgIARQhICQgkA0IgIAOQgsBOgVAAQgbAAAAgag");
	this.shape_638.setTransform(1081.05,371.725);

	this.shape_639 = new cjs.Shape();
	this.shape_639.graphics.f("#232323").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_639.setTransform(1037.775,372.475);

	this.shape_640 = new cjs.Shape();
	this.shape_640.graphics.f("#232323").s().p("AiWESQgWgeAAgrQAAhQAkg8QAig9ArgmQAsgmBMgXQAZgHAJgEQAJgFgBgKQgNg3gSgWQgTgWgfgMQgegMgYAAQgKAAgSAIQgSAHgKAGQgOAIgMAAQgNAAAAgOQAAgQAXgaQAXgbA5AAIAQAAQA4AAAsAeQAsAeATA4QASA4AABeQAAA/goBbQgpBbg/AvQg9AvhGAAQgZAAgXgdgAgLgBQhiBaAAByQAAAPAFANQAGANAHAAQAZAAAWgJQAVgJAegdQAfgdAagrQAZgrALgoQALgnABgVIAAgkQhRARgqAkg");
	this.shape_640.setTransform(999.3,361.775);

	this.shape_641 = new cjs.Shape();
	this.shape_641.graphics.f("#232323").s().p("AjTCtQgVgfAAg7QAAg+AQhMQAQhMAJgaIAHgWQAEgOAfgHQAFgDAFAAQAJAAAGAYQAAAPgIAXQgYBDAAAaQAAAHAEABQBRhOBFAAQAqAAAcAgQAdAgAAAbQAABRhTBLQhSBLhUAAQgmAAgVgfgAhBgzQgbAOghAfIgUARQgIAHgMACQgHAnAAAnQAAA1ApAAQAvAAA7g4QA5g5AAg0QAAgVgLgPQgMgPgTAAQgcAAgbAOgAB+CHQAAg+AbiSQAKg1AAgLQAAgWAIgQQAIgQAPAAQASAAAKAJQALAIAAALQAAALgFASQgcBkgGAnQgGApAAA3QAAAaAHAiIABAKQAAAHgLAKQgMAKgNAAQgiAAAAg/g");
	this.shape_641.setTransform(952.525,370.275);

	this.shape_642 = new cjs.Shape();
	this.shape_642.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAKg2AAgYQAAgXAUAAQAnAAAAA4QAAAagNBNQgPBXgBATQAXgVAphGQA8hiAdgaQAcgaAeAAQAXAAAOAeQANAfADByQAAAdAFAOQAEAOACAAQAQAAA4hvQAdg8AcgfQAcgfAiAAQAdAAANAeQANAdAFA6QAFA5AMAxQALAwAdAOQAUAJAAANQAAAMgRANQgQANgOAAQgdAAgWgiQgWgjgLhxQgFgugFgUQgEgTgKAAQgPAAgUAcQgVAcgsBVQgkBEgRAWQgSAWgQAAQgPAAgNgMQgMgMgDgRQgDgRgDhDQgGhugOgSQghAAhqDAQglBBgGAGQgGAGgPAFQgRAEgKAAQgYAAAAhcg");
	this.shape_642.setTransform(889.8,371.175);

	this.shape_643 = new cjs.Shape();
	this.shape_643.graphics.f("#232323").s().p("Ah2CvQgdgeAAg3QAAhaBJhnQBJhlA9AAQAdAAAUAeQAVAgAAAiQAAAUgJAQQgJAOgJAAQgVAAgIgpQgKgsgRAAQglAAgxBXQgyBVAAA9QAAA7BEAAQAzAABGgwQAYgRAMgBQAMAAAAAOQAAAbg/AoQg/Apg8AAQg0AAgcgeg");
	this.shape_643.setTransform(832.375,371.55);

	this.shape_644 = new cjs.Shape();
	this.shape_644.graphics.f("#232323").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_644.setTransform(792.075,372.475);

	this.shape_645 = new cjs.Shape();
	this.shape_645.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAJgiQBAkDAAjEIgBgeQAAgmAOgRQAOgRASAAQAJAAAIANQAHANABAYQgBAigHAxQgJA9AAAJQA0hbA6gzQA6g0AzAAQAkAAAYAbQAYAaAAAoQAAByhXBeQhZBchSAAQgUAAgNgKQgMgLgNgcQgRBAgPByIgKBCQgCAPgLAOQgKANgKAAQgLAAgNgLgAgGibQhIBdgBA0QAAALAPAMQAOAMAXAAQAxAABChJQBAhKABhIQgBgagJgNQgLgPgPAAQgyAAhJBdg");
	this.shape_645.setTransform(745.5,382.525);

	this.shape_646 = new cjs.Shape();
	this.shape_646.graphics.f("#232323").s().p("AjZCLQAAgRAGgfQAThpAAh2QAAgNAMgRQALgQAKAAQATAAAHAMQAIALAAAiQAAAjgVBuQgHAkAAAKQAAAGADAAQAFAAAshTQAshVAhgjQAggjAnAAQAgAAAUAdQAUAcAJBNQAKBVAIAWQAIAVARABQALgBAQgHIAFgCQAPAAAAARQAAAQgVASQgVARgdAAQgeAAgQgYQgRgXgJhoQgKhmggAAQgSAAgUAYQgWAYgsBSQg7BwgRAQQgRAPgLAAQgqAAAAgog");
	this.shape_646.setTransform(701.425,372.5);

	this.shape_647 = new cjs.Shape();
	this.shape_647.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_647.setTransform(629.075,371.425);

	this.shape_648 = new cjs.Shape();
	this.shape_648.graphics.f("#232323").s().p("AkUDQQgNgJAAgKQAAgVApgrQApgsAxgeQA9glAWgWQgKgOgdgSQgegSgagVIgIgHQgugegOgPQgPgQAAgRQAAgMAIgKQAJgJAJAAQAFAAAOAGQANAFAGAGIARARQBbBZA2AYQACAAAFgGQADgMAAgbQAAgZgFgeIgDgVQAAgQANgLQAMgKAPAAQARAAAGAIQAHAGAAARIgFBwIAAAHIAAAIQANAAANgKQAOgJAagdQB0h4ASAAQAKAAAIAJQAJAIAAAMQAAAFgmAqQgnAqgpAjQg0AtAAACQAAADArAgIBBA1IAHAEQA0AhANAPQANAQAAALQAAAKgIALQgJAKgJAAQgfAAhyhoQgygwgLgCIgHgCQgDgBgKABQgJAAAAACQgFBQgLBLQgFAPgUAAQgfAAAAggQAAgNAHgjQAFgfABgLIACgYQABgNgCgJQgSADg3AoQg3ApgoAnQgCACgNAZQgTAlgWAAQgLAAgMgJg");
	this.shape_648.setTransform(578.925,371.2);

	this.shape_649 = new cjs.Shape();
	this.shape_649.graphics.f("#232323").s().p("AiwDJQgJgJAAgJQAAgMAKgwQARhWARjEQABgTANgPQANgPARAAQAJgBAGALQAGAKAAAPQAAAMgEAQQgUBJgFBKQBTgNBBhdQAfgrAYgSQAXgSAaAAQALgBAKAKQALAKAAAMQAAASghAJQgRAGgPAMQgPANgqAwQghAmgaAOIgCACQAAAAAAABQAAAAABAAQAAABAAAAQABAAABAAQAZAOAcAoQAqA5AUAPQAVAPAbAAIALAAQANgBAAALQAAAOgPAOQgQAPgiAAQgbgBgZgWQgZgYghgzQgRgegRgQQgQgRgTABQgFgBgVAIQgWAHgDAGQgCAHgCAoIgBBBQAAANgMAKQgNAKgOAAQgPABgIgJg");
	this.shape_649.setTransform(528.625,371.3);

	this.shape_650 = new cjs.Shape();
	this.shape_650.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_650.setTransform(485.025,371.675);

	this.shape_651 = new cjs.Shape();
	this.shape_651.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAJg2AAgYQAAgXAVAAQAnAAAAA4QAAAagNBNQgPBXAAATQAVgVArhGQA7hiAdgaQAcgaAeAAQAXAAANAeQAOAfADByQAAAdAFAOQAEAOACAAQAQAAA3hvQAeg8AcgfQAcgfAiAAQAcAAANAeQANAdAGA6QAFA5AMAxQAKAwAeAOQAUAJAAANQAAAMgQANQgSANgOAAQgcAAgWgiQgWgjgMhxQgEgugFgUQgFgTgJAAQgPAAgUAcQgUAcguBVQgiBEgTAWQgRAWgQAAQgQAAgLgMQgMgMgEgRQgDgRgEhDQgEhugPgSQghAAhrDAQgkBBgGAGQgGAGgQAFQgQAEgLAAQgXAAAAhcg");
	this.shape_651.setTransform(429.05,371.175);

	this.shape_652 = new cjs.Shape();
	this.shape_652.graphics.f("#232323").s().p("ABSAdQAAgLgJAAQghAAguAEQgwAEgVAGQgUAGgFAFQgFAFgDAWQgEAWAAAXIAAArQAAAmgjAAQgdAAAAgmQAAgYAHgmQALhGAMipQABgWADgGQACgGALgHQAKgHAMAAQAaAAAAAUIgIA1QgJAyAAAbQAAATAOAAQAaAABGgIQBHgKADgFQAEgHAIhRQAGhBAjAAQAdAAAAAdQAAAGgFAVQgbBwAABLQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQg3AAAAiqg");
	this.shape_652.setTransform(340.775,371.675);

	this.shape_653 = new cjs.Shape();
	this.shape_653.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_653.setTransform(298.675,372.125);

	this.shape_654 = new cjs.Shape();
	this.shape_654.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAIgiQBBkDAAjEIAAgeQgBgmAOgRQAOgRATAAQAIAAAHANQAIANAAAYQAAAigGAxQgKA9AAAJQA0hbA6gzQA7g0AyAAQAjAAAZAbQAYAaAAAoQAAByhXBeQhZBchSAAQgVAAgLgKQgNgLgNgcQgRBAgPByIgKBCQgCAPgLAOQgLANgIAAQgLAAgOgLgAgFibQhKBdABA0QAAALAOAMQAPAMAVAAQAyAABBhJQBBhKAAhIQAAgagKgNQgKgPgQAAQgxAAhIBdg");
	this.shape_654.setTransform(253.25,382.525);

	this.shape_655 = new cjs.Shape();
	this.shape_655.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_655.setTransform(211.475,372.125);

	this.shape_656 = new cjs.Shape();
	this.shape_656.graphics.f("#232323").s().p("AhQETQgXgGAAgJQAAgsA/AAIAmAAQARgBAegMQAcgLAagVQAagVALgUQALgTAAgTQABgggcgZQgbgZgvAAQgHAAgaALQgZAMgJgBQgbAAgGgGQgIgIABgRQAAgMA6gXQA6gWAugwQAugvAAgcQABgTgUgPQgTgOgiAAQgsAAg4AMQg6AMgFAKQgGAMgYCgQgZCfABAZQgBANACAMIABAYQAAAwgvAAQgNAAgIgSQgJgTABgPQAAgHALgvQAOhAAOhvQAOhvAAgIQAAgOgEgHQgEgHgPAAIgKAAQgGABgFgIQgGgGAAgLQAAgbBcgfQBdggB+AAQAvAAAkAgQAlAgAAAgQgBAYgfAtQggArgyAiQAAAFAdANQAfAPAPAMQAPANAJAXQAKAVAAAfQAAAdgmAwQglAwg9AhQg8Agg/AAQgNAAgVgIg");
	this.shape_656.setTransform(165,364.35);

	this.shape_657 = new cjs.Shape();
	this.shape_657.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAIgiQBBkDAAjEIAAgeQgBgmAOgRQAOgRATAAQAIAAAHANQAIANAAAYQAAAigGAxQgKA9AAAJQA0hbA6gzQA7g0AyAAQAjAAAZAbQAYAaAAAoQAAByhXBeQhZBchSAAQgVAAgMgKQgMgLgNgcQgRBAgPByIgKBCQgDAPgKAOQgLANgIAAQgLAAgOgLgAgFibQhKBdABA0QAAALAOAMQAPAMAVAAQAyAABBhJQBBhKAAhIQAAgagKgNQgKgPgQAAQgxAAhIBdg");
	this.shape_657.setTransform(1260,527.825);

	this.shape_658 = new cjs.Shape();
	this.shape_658.graphics.f("#232323").s().p("AhQEUQgXgIAAgIQAAgsA/AAIAmgBQARgBAegLQAcgMAagUQAagVALgTQALgVAAgSQAAgggbgZQgbgZgvAAQgGAAgbALQgaAMgIAAQgbAAgGgIQgIgGAAgTQAAgKA8gYQA4gWAvgwQAugvAAgcQABgTgUgOQgUgPghAAQgsAAg5AMQg5AMgGALQgFALgYCgQgZCeABAZQgBAOACAMIABAYQAAAwgvAAQgNAAgIgTQgIgSAAgQQAAgGALgwQAOg/AOhuQAOhwAAgHQAAgPgEgHQgEgHgPAAIgLABQgFgBgFgGQgGgIAAgJQAAgcBcggQBcgfB/AAQAvAAAkAfQAlAhgBAhQAAAXgfAsQggAsgyAiQAAAGAdANQAfAPAPAMQAOANAKAWQAKAWAAAeQAAAcgmAxQglAwg8AgQg9Ahg/AAQgNAAgVgHg");
	this.shape_658.setTransform(1171.75,509.65);

	this.shape_659 = new cjs.Shape();
	this.shape_659.graphics.f("#232323").s().p("AiwDJQgJgJAAgJQAAgNAKgvQARhWARjEQABgTANgPQANgQARAAQAJABAGAJQAGALAAAOQAAANgEAQQgUBIgFBMQBTgOBBhdQAfgrAYgSQAXgTAaAAQALAAAKAKQALAJAAAOQAAARghAKQgRAFgPANQgPAMgqAwQghAmgaANIgCADQAAAAAAABQAAAAAAAAQABABAAAAQABAAABABQAZANAcAoQAqA5AUAPQAVAPAbAAIALgBQANAAAAALQAAAOgPAPQgQAOgigBQgbABgZgXQgZgYghgzQgRgegRgRQgQgQgTAAQgFABgVAGQgWAIgDAHQgCAGgCAoIgBBBQAAANgMAKQgNALgOAAQgPAAgIgJg");
	this.shape_659.setTransform(1094.925,516.6);

	this.shape_660 = new cjs.Shape();
	this.shape_660.graphics.f("#232323").s().p("AiwDJQgJgJAAgJQAAgNAKgvQARhWARjEQABgTANgPQANgQARAAQAJABAGAJQAGALAAAOQAAANgEAQQgUBIgFBMQBTgOBBhdQAfgrAYgSQAXgTAaAAQALAAAKAKQALAJAAAOQAAARghAKQgRAFgPANQgPAMgqAwQghAmgaANIgCADQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABQAZANAcAoQAqA5AUAPQAVAPAbAAIALgBQANAAAAALQAAAOgPAPQgQAOgigBQgbABgZgXQgZgYghgzQgRgegRgRQgQgQgTAAQgFABgVAGQgWAIgDAHQgCAGgCAoIgBBBQAAANgMAKQgNALgOAAQgPAAgIgJg");
	this.shape_660.setTransform(1011.375,516.6);

	this.shape_661 = new cjs.Shape();
	this.shape_661.graphics.f("#232323").s().p("AhQBUQAAgFACgDQBBgQASgeQASgeAAgMQAAgjgJgPQgFgHAAgGQAAgGAFgJQAEgKAFAAQAIAAAQAFQAQAGACAEQADAEAHAWQAGAWABAQQAAAGgOAfQgNAegXASQgXARgTAEIgPAEQgcAMgRAAQgKAAAAgRg");
	this.shape_661.setTransform(948.8,534.45);

	this.shape_662 = new cjs.Shape();
	this.shape_662.graphics.f("#232323").s().p("AkXDYQgJgJAAgIQACgOADgEQAfglAWgrQAWgqAjhUQAhhWAKg2QAEgXAeAAQASAAAGAFQAGAFAGAQQAHARABAMIALBDIAMBFQAFAdANAvQALAwAHAAQAFAAAJgWIAehEIAQgkIAphSQAhhEASgfQARgfAHgGQAGgGAIAAQANAAAQAHQARAHABAJIADBJIAFBuQACAzAEAlQAEAlAKAWQARAkAAAUQAAARgNAGQgOAGgMAAQgZAAgNgnQgNgngHi6QgCg4gEgMQgdAtgzBsQgMAZgMAXIgPAhQgkBVgcAAQgVAAgJgFQgLgFgJgYQgJgXgShXQgUhigIgXQgYA2gSAxQgdBJgaAvQgbAugLAJQgLAJgLAAQgLAAgJgIg");
	this.shape_662.setTransform(903.55,516.375);

	this.shape_663 = new cjs.Shape();
	this.shape_663.graphics.f("#232323").s().p("AjBCwQABgYAhgpQAignA2hcQA2heAfhKQAHgNANAAQAFAAAOAFQANAEAEAGQAEAFANA8QAsDXAvAoQAMAKABADQACADAAAGQAAALgGAJQgIAJgGACQgHADgVAAQgHAAgbgkQgbglgkihQgJgsgGgOQgJgBgHARQhJCQglA0IgHAOQgtBOgUAAQgcAAAAgag");
	this.shape_663.setTransform(797.25,517.025);

	this.shape_664 = new cjs.Shape();
	this.shape_664.graphics.f("#232323").s().p("AkXDYQgJgJAAgIQADgOACgEQAfglAWgrQAWgqAjhUQAhhWAKg2QAFgXAdAAQARAAAHAFQAGAFAHAQQAFARABAMIANBDIALBFQAFAdANAvQALAwAHAAQAFAAAJgWIAehEIARgkIAohSQAhhEASgfQASgfAGgGQAGgGAIAAQANAAAQAHQARAHABAJIADBJIAEBuQACAzAFAlQAEAlALAWQAQAkAAAUQAAARgNAGQgOAGgMAAQgZAAgNgnQgOgngFi6QgDg4gEgMQgdAtg0BsQgLAZgMAXIgOAhQgmBVgbAAQgVAAgKgFQgKgFgJgYQgJgXgShXQgUhigIgXQgYA2gTAxQgcBJgaAvQgaAugMAJQgMAJgLAAQgKAAgJgIg");
	this.shape_664.setTransform(706.75,516.375);

	this.shape_665 = new cjs.Shape();
	this.shape_665.graphics.f("#232323").s().p("Ah2CvQgdgeAAg3QAAhbBJhlQBJhmA9AAQAdAAAUAfQAVAfAAAhQAAAWgJAOQgJAPgJABQgVAAgIgqQgKgsgRAAQglAAgxBXQgyBWAAA7QAAA8BEAAQAzAABGgxQAYgQAMAAQAMAAAAANQAAAbg/ApQg/Aog8AAQg0AAgcgeg");
	this.shape_665.setTransform(657.475,516.85);

	this.shape_666 = new cjs.Shape();
	this.shape_666.graphics.f("#232323").s().p("AkXDYQgJgJAAgIQACgOADgEQAfglAWgrQAWgqAihUQAjhWAJg2QAEgXAeAAQARAAAHAFQAGAFAHAQQAFARACAMIAMBDIALBFQAFAdAMAvQAMAwAHAAQAFAAAJgWIAdhEIARgkIAphSQAhhEASgfQARgfAHgGQAGgGAIAAQANAAARAHQAQAHABAJIADBJIAFBuQABAzAFAlQAEAlALAWQAQAkAAAUQAAARgOAGQgOAGgMAAQgYAAgNgnQgOgngGi6QgCg4gEgMQgcAtg1BsQgLAZgMAXIgPAhQglBVgbAAQgVAAgKgFQgKgFgJgYQgJgXgShXQgVhigHgXQgYA2gTAxQgcBJgaAvQgaAugMAJQgMAJgKAAQgLAAgJgIg");
	this.shape_666.setTransform(505.9,516.375);

	this.shape_667 = new cjs.Shape();
	this.shape_667.graphics.f("#232323").s().p("AjIE1QgOgLAAgHQAAgTAIgiQBBkDAAjEIgBgeQAAgmAOgRQAOgRASAAQAJAAAHANQAJANgBAYQABAigIAxQgJA9AAAJQA0hbA6gzQA6g0AzAAQAkAAAYAbQAYAaAAAoQAAByhYBeQhXBchTAAQgUAAgMgKQgNgLgNgcQgRBAgPByIgKBCQgDAPgKAOQgLANgIAAQgMAAgNgLgAgGibQhJBdAAA0QAAALAPAMQAPAMAVAAQAyAABChJQBBhKgBhIQABgagKgNQgLgPgQAAQgxAAhJBdg");
	this.shape_667.setTransform(396.6,527.825);

	this.shape_668 = new cjs.Shape();
	this.shape_668.graphics.f("#232323").s().p("AiWESQgWgeAAgrQAAhQAkg8QAig9ArgmQAsgmBMgXQAZgHAJgEQAJgFgBgKQgNg3gSgWQgTgWgfgMQgdgMgZAAQgJAAgTAIQgTAHgJAGQgOAIgMAAQgNAAAAgOQAAgQAXgaQAXgbA5AAIAQAAQA4AAAsAeQAsAeASA4QATA4AABeQAAA/goBbQgpBbg/AvQg9AvhGAAQgZAAgXgdgAgLgBQhiBaAAByQAAAPAFANQAGANAHAAQAaAAAVgJQAVgJAegdQAfgdAagrQAZgrALgoQALgnABgVIAAgkQhRARgqAkg");
	this.shape_668.setTransform(358.15,507.075);

	this.shape_669 = new cjs.Shape();
	this.shape_669.graphics.f("#232323").s().p("AkXDYQgJgJAAgIQACgOADgEQAfglAWgrQAWgqAihUQAjhWAJg2QAEgXAeAAQASAAAGAFQAGAFAHAQQAFARACAMIALBDIAMBFQAFAdAMAvQAMAwAHAAQAFAAAJgWIAdhEIARgkIAphSQAhhEASgfQASgfAGgGQAGgGAIAAQANAAARAHQAQAHABAJIADBJIAFBuQABAzAFAlQAEAlALAWQAQAkAAAUQAAARgOAGQgOAGgMAAQgYAAgNgnQgOgngGi6QgCg4gEgMQgcAtg1BsQgLAZgMAXIgPAhQglBVgbAAQgVAAgKgFQgKgFgJgYQgJgXgShXQgVhigHgXQgYA2gTAxQgcBJgaAvQgaAugMAJQgMAJgKAAQgLAAgJgIg");
	this.shape_669.setTransform(262.45,516.375);

	this.shape_670 = new cjs.Shape();
	this.shape_670.graphics.f("#232323").s().p("AkUDQQgNgKAAgJQAAgVApgrQApgsAxgeQA9glAWgWQgKgOgdgRQgegTgagVIgIgGQgugfgOgPQgPgPAAgSQAAgMAIgJQAJgKAJAAQAFAAAOAFQANAGAGAGIARAQQBbBaA2AYQACAAAFgHQADgMAAgaQAAgYgFgfIgDgVQAAgRANgKQAMgJAPgBQARABAGAGQAHAIAAARIgFBvIAAAHIAAAIQANAAANgJQAOgKAagdQB0h4ASAAQAKAAAIAIQAJAJAAALQAAAGgmAqQgnAqgpAjQg0AtAAACQAAADArAgIBBA1IAHAFQA0AfANAQQANAQAAALQAAAKgIALQgJALgJAAQgfAAhyhpQgygwgLgCIgHgCQgDgBgKAAQgJABAAACQgFBPgLBNQgFAOgUAAQgfAAAAgfQAAgNAHgkQAFgfABgLIACgZQABgNgCgHQgSACg3AoQg3ApgoAnQgCACgNAYQgTAmgWAAQgLAAgMgJg");
	this.shape_670.setTransform(1397.325,389.05);

	this.shape_671 = new cjs.Shape();
	this.shape_671.graphics.f("#232323").s().p("AkXDYQgJgJAAgIQACgOADgEQAfglAWgrQAWgqAihUQAjhWAJg2QAEgXAeAAQASAAAGAFQAGAFAHAQQAFARACAMIALBDIAMBFQAFAdAMAvQAMAwAHAAQAFAAAJgWIAdhEIARgkIAphSQAhhEASgfQASgfAGgGQAGgGAIAAQANAAARAHQAQAHABAJIADBJIAFBuQABAzAFAlQAEAlALAWQAQAkAAAUQAAARgOAGQgOAGgMAAQgYAAgNgnQgOgngGi6QgCg4gEgMQgcAtg1BsQgLAZgMAXIgPAhQglBVgbAAQgVAAgKgFQgKgFgJgYQgJgXgShXQgVhigHgXQgYA2gTAxQgcBJgaAvQgbAugLAJQgMAJgKAAQgLAAgJgIg");
	this.shape_671.setTransform(1305.1,388.925);

	this.shape_672 = new cjs.Shape();
	this.shape_672.graphics.f("#232323").s().p("AiwDJQgJgJAAgJQAAgNAKgvQARhWARjEQABgTANgPQANgQARAAQAJAAAGAKQAGALAAAOQAAANgEAQQgUBIgFBMQBTgOBBhdQAfgrAYgSQAXgSAaAAQALAAAKAJQALAJAAANQAAASghAJQgRAGgPAMQgPANgqAwQghAlgaAOIgCADQAAAAAAABQAAAAAAAAQABABAAAAQABAAABABQAZAOAcAnQAqA5AUAPQAVAPAbAAIALgBQANAAAAALQAAAOgPAOQgQAOgiABQgbAAgZgXQgZgYghgzQgRgfgRgPQgQgQgTgBQgFAAgVAHQgWAIgDAHQgCAGgCAoIgBBBQAAANgMAKQgNALgOAAQgPAAgIgJg");
	this.shape_672.setTransform(1211.425,389.15);

	this.shape_673 = new cjs.Shape();
	this.shape_673.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAKg2AAgYQgBgXAVAAQAnAAAAA4QAAAagNBNQgPBXgBATQAWgVAqhGQA9hiAcgaQAcgaAeAAQAXAAAOAeQANAfADByQAAAdAFAOQAEAOACAAQARAAA3hvQAdg8AcgfQAcgfAiAAQAdAAANAeQANAdAFA6QAGA5ALAxQAKAwAeAOQAUAJAAANQAAAMgQANQgSANgOAAQgbAAgXgiQgWgjgLhxQgFgugFgUQgFgTgJAAQgPAAgUAcQgVAcgtBVQgjBEgSAWQgSAWgQAAQgPAAgMgMQgMgMgDgRQgDgRgDhDQgGhugOgSQggAAhsDAQgkBBgGAGQgGAGgQAFQgQAEgKAAQgYAAAAhcg");
	this.shape_673.setTransform(1111.85,389.025);

	this.shape_674 = new cjs.Shape();
	this.shape_674.graphics.f("#232323").s().p("AiPCtQgVgfAAg7QAAg+AQhMQAPhMAKgaIAHgWQADgOAggHQAEgDAGAAQAJAAAGAYQAAAPgJAXQgXBDAAAaQAAAHAEABQBRhOBEAAQAqAAAdAgQAdAgAAAbQAABRhTBLQhSBLhUAAQgnAAgUgfgAACgzQgaAOghAfIgUARQgIAHgNACQgGAnAAAnQAAA1ApAAQAvAAA6g4QA6g5AAg0QAAgVgMgPQgMgPgTAAQgdAAgaAOg");
	this.shape_674.setTransform(1025.35,388.125);

	this.shape_675 = new cjs.Shape();
	this.shape_675.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAJg2AAgYQAAgXAVAAQAnAAAAA4QAAAagNBNQgPBXAAATQAVgVArhGQA7hiAdgaQAcgaAeAAQAXAAANAeQAOAfADByQABAdAEAOQAEAOACAAQARAAA2hvQAeg8AcgfQAcgfAiAAQAcAAANAeQANAdAGA6QAGA5ALAxQALAwAdAOQAUAJAAANQAAAMgQANQgRANgPAAQgcAAgWgiQgWgjgMhxQgEgugFgUQgEgTgKAAQgPAAgUAcQgUAcguBVQgiBEgTAWQgRAWgRAAQgPAAgMgMQgLgMgEgRQgDgRgDhDQgFhugPgSQggAAhsDAQgkBBgGAGQgGAGgQAFQgQAEgLAAQgXAAAAhcg");
	this.shape_675.setTransform(969.4,389.025);

	this.shape_676 = new cjs.Shape();
	this.shape_676.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAKg2gBgYQABgXAUAAQAnAAAAA4QAAAagNBNQgPBXAAATQAVgVAqhGQA8hiAdgaQAcgaAeAAQAXAAANAeQAOAfADByQABAdAEAOQAEAOACAAQAQAAA3hvQAeg8AcgfQAcgfAiAAQAcAAANAeQANAdAGA6QAFA5AMAxQALAwAdAOQAUAJAAANQAAAMgRANQgQANgOAAQgdAAgWgiQgWgjgMhxQgEgugFgUQgFgTgJAAQgPAAgUAcQgUAcgtBVQgkBEgRAWQgTAWgPAAQgPAAgMgMQgMgMgEgRQgDgRgEhDQgEhugPgSQghAAhqDAQglBBgGAGQgGAGgPAFQgRAEgKAAQgYAAAAhcg");
	this.shape_676.setTransform(853.15,389.025);

	this.shape_677 = new cjs.Shape();
	this.shape_677.graphics.f("#232323").s().p("Ah2CvQgdgeAAg3QAAhbBJhlQBJhmA9AAQAdAAAUAfQAVAeAAAiQAAAWgJAOQgJAQgJAAQgVAAgIgqQgKgsgRAAQglAAgxBXQgyBWAAA7QAAA8BEAAQAzAABGgxQAYgRAMAAQAMAAAAAOQAAAbg/AoQg/Apg8AAQg0AAgcgeg");
	this.shape_677.setTransform(795.725,389.4);

	this.shape_678 = new cjs.Shape();
	this.shape_678.graphics.f("#232323").s().p("AiPCtQgVgfAAg7QAAg+APhMQAQhMAKgaIAHgWQAEgOAfgHQAFgDAFAAQAJAAAGAYQAAAPgIAXQgYBDAAAaQAAAHAEABQBRhOBEAAQAqAAAdAgQAdAgAAAbQAABRhTBLQhSBLhVAAQglAAgVgfgAACgzQgaAOgiAfIgUARQgHAHgMACQgIAnAAAnQAAA1AqAAQAvAAA5g4QA7g5AAg0QAAgVgLgPQgMgPgVAAQgbAAgbAOg");
	this.shape_678.setTransform(730.2,388.125);

	this.shape_679 = new cjs.Shape();
	this.shape_679.graphics.f("#232323").s().p("Ah2CvQgdgeAAg3QAAhbBJhlQBJhmA9AAQAdAAAUAfQAVAeAAAiQAAAWgJAOQgJAQgJAAQgVAAgIgqQgKgsgRAAQglAAgxBXQgyBWAAA7QAAA8BEAAQAzAABGgxQAYgRAMAAQAMAAAAAOQAAAbg/AoQg/Apg8AAQg0AAgcgeg");
	this.shape_679.setTransform(690.825,389.4);

	this.shape_680 = new cjs.Shape();
	this.shape_680.graphics.f("#232323").s().p("AjBCwQABgYAhgpQAignA2hcQA1heAhhKQAGgNANAAQAFAAAOAFQANAEAEAGQAEAFANA8QAsDXAvAoQALAKACADQACADAAAGQAAALgGAJQgIAJgGACQgHADgVAAQgHAAgbgkQgbglgkihQgJgsgGgOQgJgBgHARQhJCQgkA0IgIAOQgtBOgUAAQgcAAAAgag");
	this.shape_680.setTransform(610.15,389.575);

	this.shape_681 = new cjs.Shape();
	this.shape_681.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAKg2AAgYQAAgXAUAAQAnAAAAA4QAAAagNBNQgPBXgBATQAXgVAphGQA8hiAdgaQAcgaAeAAQAXAAAOAeQANAfADByQABAdAEAOQAEAOACAAQAQAAA4hvQAdg8AcgfQAcgfAiAAQAdAAANAeQAMAdAGA6QAGA5ALAxQALAwAdAOQAUAJAAANQAAAMgRANQgQANgOAAQgdAAgWgiQgWgjgLhxQgFgugFgUQgEgTgKAAQgPAAgUAcQgVAcgsBVQgkBEgRAWQgSAWgQAAQgPAAgNgMQgMgMgDgRQgDgRgDhDQgGhugOgSQghAAhqDAQglBBgGAGQgGAGgPAFQgRAEgKAAQgYAAAAhcg");
	this.shape_681.setTransform(516.75,389.025);

	this.shape_682 = new cjs.Shape();
	this.shape_682.graphics.f("#232323").s().p("Ai/CzQAAg2B4htIARgQQhGhoAAg4QAAgyAqAAQAMAAAFAKQAGAKADAkQAEA4AsA/QBghUAihCQAMgVAGgGQAHgFAKAAQANAAALAKQALAKAAAPQAAAjirCcQA7BMBCAlIAQAKQABADAAAHQAAAPgLAMQgLAMgPAAQgwAAhmiJQhQBFgZBGQgKAYgKALQgqgCAAglg");
	this.shape_682.setTransform(417.425,390.375);

	this.shape_683 = new cjs.Shape();
	this.shape_683.graphics.f("#232323").s().p("AhzC4QgjgVAAgaQAAgUAYgBQAEAAAHAHQAnAhA1AAQAuAAAhgZQAjgZgBgnQABgagUgRQgTgRgaAAQgSgBgwAPQgKAEgLAAQgUgBgBgbQAAgKAKgFQAKgHAigIQBigWAAg7QABgRgMgMQgNgLgUAAQgjAAgqAgQgYAUgNAAQgWAAABgVQAAgaAxgcQAygcAtAAQAuABAaAYQAaAYAAAbQAABAhOAkQAtAHAaAZQAZAaAAAmQAAA7gyAoQgzAohQAAQgxAAgkgWg");
	this.shape_683.setTransform(337.65,389.3);

	this.shape_684 = new cjs.Shape();
	this.shape_684.graphics.f("#232323").s().p("AiED5Qg2gkAAgZQAAgMAFgLQAGgLAIAAQAEAAAFAGQAuBHBgAAQA8AAAehKQAehLAIhzQg1Axg2AcQg0AdgcAAQghAAgUgcQgTgcAAgoQAAg7AXhRQAWhRAMgLQAMgLAUAAQAKAAAGANQAGAMAAANQAAAJgIAOQguBQAABVQAAATAHAPQAIAOAPAAQATAAAdgKQAbgMAjgbQAkgbAMgQQANgRAFgVQAFgVAChGQAChHAgAAQATAAAGALQAFAJAAAdQAAAVgGBGIgCAdQgKC7guBqQguBrhXAAQhFAAg1gkg");
	this.shape_684.setTransform(269.375,398.925);

	this.shape_685 = new cjs.Shape();
	this.shape_685.graphics.f("#232323").s().p("AkXDYQgJgJAAgIQADgOACgEQAfglAWgrQAWgqAjhUQAhhWAKg2QAEgXAeAAQARAAAHAFQAGAFAGAQQAHARAAAMIANBDIALBFQAFAdANAvQALAwAHAAQAFAAAJgWIAehEIARgkIAohSQAhhEASgfQASgfAGgGQAGgGAIAAQANAAAQAHQARAHABAJIADBJIAEBuQACAzAFAlQAEAlAKAWQARAkAAAUQAAARgNAGQgOAGgMAAQgZAAgNgnQgOgngFi6QgDg4gEgMQgcAtg0BsQgMAZgMAXIgOAhQgmBVgbAAQgVAAgKgFQgKgFgJgYQgJgXgShXQgUhigIgXQgYA2gTAxQgcBJgaAvQgbAugLAJQgMAJgLAAQgKAAgJgIg");
	this.shape_685.setTransform(217.95,388.925);

	this.shape_686 = new cjs.Shape();
	this.shape_686.graphics.f("#232323").s().p("Ai5EMQgXgCAAgtQAAgUAMgxIAfitIAIgmQAWhmAAgZQAAgLgHgJQgOgSAAgIQAAgIAHgJQAGgHALAAQAFAAACACQAJAHATABQAqgBCkgSIAqgEQAlAAAKAIQALAHAAAUIAAAAQAAALgMAKQgMALgLgBQgNAAgMgCQgMgCgMABQgRgBgTADQgUAEgQAAQgMAAgOACIgdADQgpAFgOAGQgNAGgDAQQgDAVgJAhQgTBFAAASQAsAAA/gUQAtgNAjAAQALAAAKAJQALAKAAAUQAAATgWAIIgpAGQhFAIgxANQgxANgEAIQgFAHgIAwQgIAvAAAQQAAATAUAAQAQAAAYgFIBjgSQBpgUAOAAQANAAASAHQASAIAAAWQAAAOgMAKQgMAIgcAGQgcAFg1AAQhCAAhDATQgXAHgiADQgIABgIADQgJADgKAAIgOgCg");
	this.shape_686.setTransform(161.075,384.35);

	this.shape_687 = new cjs.Shape();
	this.shape_687.graphics.f("#232323").s().p("AhDDgQAAgNAMgTQANgSANAAQAJAAANAIQAMAHAAAGQAAAigQAPQgSAOgMAAQgaAAAAgigAgSBXQgQgCgFgFQgFglAWhnQAShUAAghQAAgvAQgRQASgQALAAQAJAAAJAHQAJAIAAAJQAAAHgmCrQgRBGAAAmQgBAZgHAMQgIAAgPgDg");
	this.shape_687.setTransform(882.575,431.275);

	this.shape_688 = new cjs.Shape();
	this.shape_688.graphics.f("#232323").s().p("ABhD2QAAgIAPgwQAPgvAAgQQAAgNgFABIgPAHQgPAGgFAAQgSAAgIgMQgHgKAAgjQAAghAUhZIABgJQgxBPgyAwQgzAwgnAAQgYAAgYgbQgYgcAAg4QAAgtAWhaQAThKAAgeQAKgWAWAAQAPAAAJALQAIAKAAAMQAAAYgRAuQghBXAABAQAAA4AbABQAiAAA1g5QA0g7AlhnQAPgoAJgNQAJgNAPgBIAEAAQAQAAAFAIQAGAHAAAWQAAAPgIAkQgYBmgEBlQACAJAFABIAEgBQAPgLAQAAQAaAAABAbIADAWQAAAjgXA6QgWA7gjAAQgKAAAAgMg");
	this.shape_688.setTransform(851.575,446.9);

	this.shape_689 = new cjs.Shape();
	this.shape_689.graphics.f("#232323").s().p("AkkD/QAAgWAEgiQAJhcAGidIAFihIAAgPQAAhAApAAQAOAAAIANQAJAMAAALQAABagNBcQgDAuAAAYQAAAEABACIAEAIQAogXBThQQBUhSAfgYIAPgMQAogpASAAQALAAAQALQAQALAAAHQAAABAAABQAAAAgBABQAAAAAAABQgBAAAAAAQgmAshOBAQhWBIhBBAQA+AdBeAfIAFADQAUAKAIACQASAFANAGQAtAVAsANQArANAJAAQADAAAFgEQAEgDAEAAQAPAAALAQQAMAQAAAJQAAARgMALQgMAKgQAAQgZAAhFgYQhEgZgkgRQgXgKhigmQhjglgPAAQgaAAgMALQACAGAAAMQAAAPgIA+QgGA0AAAOQAAAOgPAMQgOAMgSAAQgPAAAAgkg");
	this.shape_689.setTransform(677.475,430.725);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_656},{t:this.shape_655},{t:this.shape_654},{t:this.shape_653,p:{x:298.675,y:372.125}},{t:this.shape_652},{t:this.shape_651},{t:this.shape_650,p:{x:485.025,y:371.675}},{t:this.shape_649},{t:this.shape_648},{t:this.shape_647},{t:this.shape_646},{t:this.shape_645},{t:this.shape_644},{t:this.shape_643},{t:this.shape_642},{t:this.shape_641,p:{x:952.525,y:370.275}},{t:this.shape_640},{t:this.shape_639},{t:this.shape_638},{t:this.shape_637},{t:this.shape_636,p:{x:1221.525,y:372.125}},{t:this.shape_635},{t:this.shape_634,p:{x:1336.725,y:371.675}},{t:this.shape_633},{t:this.shape_632,p:{x:1442.425,y:371.675}},{t:this.shape_631},{t:this.shape_630},{t:this.shape_629,p:{x:215.575,y:499.575}},{t:this.shape_628},{t:this.shape_627},{t:this.shape_626},{t:this.shape_625,p:{x:406.475,y:498.875}},{t:this.shape_624},{t:this.shape_623},{t:this.shape_622,p:{x:517.725,y:508.525}},{t:this.shape_621},{t:this.shape_620},{t:this.shape_619,p:{x:672.425,y:498.875}},{t:this.shape_618},{t:this.shape_617},{t:this.shape_616,p:{x:793.975,y:498.875}},{t:this.shape_615},{t:this.shape_614},{t:this.shape_613,p:{x:921.325,y:497.725}},{t:this.shape_612},{t:this.shape_611,p:{x:1040.125,y:499.575}},{t:this.shape_610},{t:this.shape_609},{t:this.shape_608,p:{x:1164.975,y:499.125}},{t:this.shape_607},{t:this.shape_606},{t:this.shape_605,p:{x:1333.725,y:499.925}},{t:this.shape_604},{t:this.shape_603,p:{x:1412.525,y:499.125}},{t:this.shape_602,p:{x:1454.575,y:499.925}}]},1153).to({state:[{t:this.shape_686},{t:this.shape_685},{t:this.shape_684},{t:this.shape_683},{t:this.shape_650,p:{x:377.025,y:389.525}},{t:this.shape_682},{t:this.shape_653,p:{x:457.525,y:389.975}},{t:this.shape_681},{t:this.shape_625,p:{x:570.775,y:389.275}},{t:this.shape_680},{t:this.shape_636,p:{x:652.575,y:389.975}},{t:this.shape_679},{t:this.shape_678},{t:this.shape_677},{t:this.shape_676},{t:this.shape_634,p:{x:909.125,y:389.525}},{t:this.shape_675},{t:this.shape_674},{t:this.shape_673},{t:this.shape_632,p:{x:1167.825,y:389.525}},{t:this.shape_672},{t:this.shape_605,p:{x:1251.975,y:390.325}},{t:this.shape_671},{t:this.shape_670},{t:this.shape_619,p:{x:1447.475,y:389.275}},{t:this.shape_669},{t:this.shape_622,p:{x:313.875,y:526.375}},{t:this.shape_668},{t:this.shape_667},{t:this.shape_641,p:{x:449.325,y:515.575}},{t:this.shape_666},{t:this.shape_602,p:{x:588.375,y:517.775}},{t:this.shape_665},{t:this.shape_664},{t:this.shape_616,p:{x:757.875,y:516.725}},{t:this.shape_663},{t:this.shape_613,p:{x:846.975,y:515.575}},{t:this.shape_662},{t:this.shape_661},{t:this.shape_660},{t:this.shape_608,p:{x:1051.325,y:516.975}},{t:this.shape_659},{t:this.shape_658},{t:this.shape_629,p:{x:1218.225,y:517.425}},{t:this.shape_657},{t:this.shape_611,p:{x:1305.425,y:517.425}},{t:this.shape_603,p:{x:1347.525,y:516.975}}]},21).to({state:[]},27).to({state:[{t:this.shape_689},{t:this.shape_611,p:{x:728.625,y:439.875}},{t:this.shape_603,p:{x:770.725,y:439.425}},{t:this.shape_616,p:{x:810.225,y:439.175}},{t:this.shape_688},{t:this.shape_687}]},51).wait(56));

	// Слой_112
	this.shape_690 = new cjs.Shape();
	this.shape_690.graphics.f("#FFFFFF").s().p("AmMBPQgWgIgPgUQgPgUgCgXQgDgfATgaQANgRAVgJQAVgJAWACQAYACAUARQAUAQAIAXQAHAXgHAXQgGAYgRAQQgSAQgYAFQgIACgIAAQgQAAgOgGgAFlBTQgbgDgUgSQgVgTgFgbQgFgXAJgYQAKgYAUgOQARgLAVgDQAVgDATAHQATAHAOAQQAOAQAFAUQAGATgFAUQgFAUgOAQQgNAPgUAIQgPAGgPAAIgKgBg");
	this.shape_690.setTransform(1069.0045,327.07);
	this.shape_690._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_690).wait(1221).to({_off:false},0).to({_off:true},45).wait(42));

	// Слой_111
	this.shape_691 = new cjs.Shape();
	this.shape_691.graphics.f("#0B88F0").s().p("EBpzAimQhih0hhhDQg+grhgguIilhPQjHhhhUhwQgTgZAJgQQAHgOAfAAIMUgXQg3hShNhBIgpgiQgWgWgLgUQgNgZADgbQAEgeAVgOQATgNArABILWAGQATgzgNg7QgMg4gkgvQgfgogygmQgggZg+gnQjliOjsh0Qg2gbgcgYQgpgjgEgqQgJhaCZhFIK2k4QAQgogSgtQgRgsgmgcQgggYgwgPQgggKg5gKQmCg5i/glQlKhBjYh2QgmgUgUgUQgcgcgDgfQgBgcATgeQANgVAdgaQD3jtE0i3QBKgsAjgjQA0g0AAg6QgBhBhAgzQgygnhSgaQmIh/mcANQgxACgUgBQgmgDgbgMQghgPgSgeQgTghAKgfQAHgRAQgRQALgMAXgQQEHjICvkVQAZgDABAhQAAAegSAYQjOESj5DsQHXgUHECFQBHAUArAUQA8AbAnAlQAuArASA6QAUA+gXA1QgOAhgiAgQgWAVgtAfQjUCNhnBKQiyCAh0ByQgnAoAHAcQAFAVAiAUQDKB+FtA9QBkAQDKAfQCzAcB4AiQA2APAiAQQAuATAfAcQAlAgAQAsQATAugMAqQgOAzg2AlQglAahGAcIl1CWQifA/hPAsQg5AfgBAmQAAAVAUAUQAOAOAbARIHCEAQCJBOBEBCQBkBhAIBuQADApgOAlQgPAnghATQgTAMgcADQgQACgiABQlNAClNgTQAGAsAtAnIBVA9QAuAhATAwQAWA3ghAiQgQAQgcAHQgTADghABIqjATQBfBKDyB8QDiB0BoBaQBhBWBbCHQA3BRBeCqQAZAtAEAnQAFAyghAUQhlkLi6jZgEhwjAgyQgZgCgQgEQgWgGgLgPQgRgXANghQAKgaAbgdQDqj/EMjMIB4hcQBCg2AqgyQA0g+AahDQAdhMgIhIInPgKQhJgDgJglQgKgnA/gkQIFkqIlj4IsblcQjUhbhsgoQi0hDiXgbQhNgOgpgUQg9gegLgzQgMg5A2g0QArgoBKgeQMJk4MljrQAygOAbgRQAngYAJgkQAOg2g+hAQiCiIkUg9IjsgsQiPgahYgeQhvgkgQhDQgIglAUgmQATgiAjgXQAbgSArgPIBLgXQA2gSBjguQBmgxAzgRQBvgnCUgLQBZgGCxACQBkABA0AGQBUAKA+AbQgYiUhDiIQhDiJhnhtQgvgygRggQgcgyATgpQCICABiCgQBiChA0CzQAaBbANBZQkih+lrAwQk8AqlJCmQgkASgTAYQgZAdALAcQANAfA6AMQB6AcD4AsQDbAtCMA8QCHA7A6BQQAkA0AEA+QAFBBghAvQgcAng2AZQgjAQhDARQr1DMrXEvQhEAcgnAkQgyAuAIA2QCBALCaAzQBfAfCxBLIPiGiQAiAPANAOQATAVgEAhQgEAggVAXQgSAUgeAPQgRAKgmAPQn1DBnIEdIGXAJQAgABAPACQAaAFAQAMQAZATAIAjQAHAfgGAlQgSB6huB0Qg6A+ihB8QkiDfjwEUQERAACIAGQDjAJCzAgQkQAbkQAAQh6AAh6gFg");
	this.shape_691.setTransform(812.9945,440.95);
	this.shape_691._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_691).wait(1203).to({_off:false},0).to({_off:true},18).wait(87));

	// Слой_110
	this.instance_43 = new lib.городскиежильцыперсонажи45();
	this.instance_43.setTransform(161,-14,0.5694,0.5694);
	this.instance_43._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_43).wait(1203).to({_off:false},0).wait(18).to({_off:true},30).wait(57));

	// Слой_45
	this.shape_692 = new cjs.Shape();
	this.shape_692.graphics.f("#FFFFFF").s().p("EiAOBDPMAAAiGdMEAdAAAMAAABFwIhEABMijbAANQiFAAgVBFMCm5AAJMAAAA/Rg");
	this.shape_692.setTransform(796.175,405.75);

	this.shape_693 = new cjs.Shape();
	this.shape_693.graphics.f("#232323").s().p("EBRVABBMim6gAJQAWhECFAAMCjagAOIBFAAQA+gCAlgDQBdgIBGgZQAfAyg+ApQg5AmhIAAg");
	this.shape_693.setTransform(1096.4,424.675);

	this.shape_694 = new cjs.Shape();
	this.shape_694.graphics.f("#FFFFFF").s().p("EiAOBDPMAAAiGdMEAdAAAMAAABFwIhEABQ0BA81LAdMAqQAACMAAAA/RgEgmqAD1MAo/AACQy6gZzrguQiFAAgVBFg");
	this.shape_694.setTransform(796.175,405.75);

	this.shape_695 = new cjs.Shape();
	this.shape_695.graphics.f("#FFFFFF").s().p("EiAOBDQMAAAiGfMEAdAAAMAAABFxIhEAAQ0BA91LAdMAqQAACMAAAA/SgEgmqAD2MAo/AACQy6gazrguQiFABgVBFg");
	this.shape_695.setTransform(796.575,394.1);

	this.shape_696 = new cjs.Shape();
	this.shape_696.graphics.f("#FFFFFF").s().p("EiAOBDQMAAAiGeMEAdAAAMAAABFwIhEABQ0BA81LAdMAqQAACMAAAA/SgEgmqAD1MAo/AACQy6gYzrgvQiFAAgVBFg");
	this.shape_696.setTransform(793.825,378.65);

	this.shape_697 = new cjs.Shape();
	this.shape_697.graphics.f("#232323").s().p("EhALAVFQlHgjmZhAQjsglnwhWQgWgEgMgEQgQgFgKgKIgCgDIgFgGQgOgVAMgeQAMggAfgOQAagLAjACQAXACApAJQBlAWBlAVQCmAhClAcQOaCeOsAFQHTABF1gmQEJgbH2hWQIGhYD4gcIBWgJQBAi8CuiFQDKiaDsAKQgQhpBAhnQA7hgBng1QBagvB4gQQBcgMCDAEQHsAPC1D4QBBiICUhQQCLhKCjgDQCPgDCjAyQB+AnCkBPQAoiOCKhTQCKhRCQAhQAfAHA9ASQA2AOAngHQA1gIA2gyQAggdA5hBQBahcB8gwQB7gwCBAHQAZguAYhKQAZhVANgpQAxiVBVg1QBMgvCaAIIB8AHQBHABAygOQgRh+Awh8QAvh8BhhTQBhhSCCgbQBMgPBKAGQA0AEAyAQQBBATAIApQAEAZgVAWQgTAVgdAFQgWAEgfgEIg2gJIgDgBQiagViEBxQiFByAACeIABBoQgFA6ghAcQgVASghAGQgWAFgpAAImeAHIiVGnQgKAcgHANQgMAVgQALQgXAQgngEIhDgMQhzgUhwBHQhpBCg4BxIgXAwQgPAagRAOQgkAeg7gDQgogChAgVQhVgagwgKQhLgPg+AHQhHAHg6AoQg9ArgSBAQgKAngMBaQgRBIgyAIQgmAHgmglIg+hHQg3g+hgghQhFgXhxgOQhigMhAAAQhZgBhHASQhTAVg/AyQhEA2gaBJQgFAMgLAuQgKAkgKAUQgPAdgaAQQgcASgbgIQgcgHgUghQgFgJgYg0QgkhRhPg7QhIg2hegcQhPgXhmgHQhAgEh6AAQhZAAgwAFQhLAHg5AVQhEAaguAxQgzA1gKBBQgDAcAAA5QgCAygVAcQgZAig6AJQgSADhUABQibADiEBhQhuBSgzB2QDXgRD4gHQDrgHHMAAMBECgAGIIMgBQAbAAAQAEQAXAFAMAOQAgAng0AnQgxAjg8AAMgh7AAGQ26AD27AAQmIAAjIAHQi1AGigANIgJALQgUAVgdAEQgeADgRgUIgGgJQhHAHhCAJQi4AXkpA6QlzBIhsASQpdBlqhAAQoOAAo3g+g");
	this.shape_697.setTransform(1110.9637,292.8146);

	this.shape_698 = new cjs.Shape();
	this.shape_698.graphics.f("#FFFFFF").s().p("EiAOBDQMAAAiGeMEAdAAAIAAf0QhJgHhMAQQiCAahhBTQhhBTgwB8QgvB8ARB+QgzANhGgBIh8gGQiagIhNAvQhVA1gwCVQgOApgZBVQgXBKgaAuQiBgIh7AwQh8AxhZBcQg6BBgfAcQg3Ayg1AJQgmAGg2gNQg9gTgfgGQiRgiiKBTQiKBSgoCPQikhQh+gnQiigxiPACQikAEiKBKQiVBQhACIQi2j5nsgPQiCgDhcAMQh4AQhaAuQhnA2g8BgQhABnARBpQjtgKjLCaQiuCEg/C8IhWAJQj4AboHBZQn2BVkJAcQl1AmnSgCQusgEuZieIeAABQxRgWx6gpQhmgUhlgXQgpgIgWgCQgkgCgaALQgeANgNAhQgLAdANAVIgDAJIAKAAQAKAKAQAGQAMAEAWAEQHwBVDtAlQGYBAFIAkQUMCMQ1izQBsgSF0hIQEog6C4gXQBDgJBHgHIAGAJQAQAUAfgEQAdgDATgWIAJgKQChgNC1gGQDJgHGHAAQW7AAW7gDQnzAPn8ALMAqQAACMAAAA/SgEAsogBNQCEhhCbgDQBVgCASgCQA5gJAagiQAUgcADgyQgBg6AEgbQAJhBAzg2QAvgwBDgaQA6gWBLgHQAwgEBZAAQB6AAA/AEQBmAHBPAXQBeAbBJA2QBPA8AkBRQAXA0AGAJQAUAhAbAHQAcAHAcgRQAagRAOgcQALgVAJgjQAMguAEgMQAahKBEg2QA/gxBTgWQBHgSBZABQBAABBiAMQByAOBEAXQBhAhA2A+IA+BHQAnAlAmgHQAygIAQhIQAMhaALgoQARg/A+grQA5goBIgIQA9gGBLAOQAwALBVAaQBAAUApADQA7ADAjgeQARgPAPgaIAXgvQA4hyBqhCQBwhHBzAUIBDAMQAmADAYgPQAQgLAMgVQAHgNAKgcICVmnIGegHQAoAAAWgFQAigGAVgTQAggcAFg5IAAhpQAAieCFhxQCDhxCaAVMAAAAigMhEBAAGQnMAAjtAHQj4AHjXAQQAzh1BvhRg");
	this.shape_698.setTransform(793.825,378.65);

	this.shape_699 = new cjs.Shape();
	this.shape_699.graphics.f().s("#232323").ss(6,1,1).p("EiCdhJCMEE7AAAMAAABEkIAACIMAAABLZMkE7AAAg");
	this.shape_699.setTransform(808.05,415.8);

	this.shape_700 = new cjs.Shape();
	this.shape_700.graphics.f("#FFFFFF").s().p("EiCdBJDMAAAiSFMEE7AAAMAAABEkIAACIMAAABLZg");
	this.shape_700.setTransform(808.05,415.8);

	this.shape_701 = new cjs.Shape();
	this.shape_701.graphics.f("#232323").s().p("AikhDIDuAAQAbgBAQAEQAYAFAMAPQAgAng1AlQgwAkg9AAIi7AAg");
	this.shape_701.setTransform(1659.5059,393.8722);

	this.shape_702 = new cjs.Shape();
	this.shape_702.graphics.f().s("#232323").ss(6,1,1).p("EiGpgAZMAAAhIpMEE6AAAMAAABEkIAACIUAQyAlsgQyAltI8/AAEiGpADCIAAidEiGpAblIAAh/EiGpAYfIAA0KEBgRBJDMjm6AAAMAAAgsW");
	this.shape_702.setTransform(834.8915,415.8);

	this.shape_703 = new cjs.Shape();
	this.shape_703.graphics.f("#0B88F0").s().p("EBrgBCbIAOiFQAhlWgGjFQgKl1h8kPQhTi0gOgzQgniHA0hbQGrEWF3FdICTgEQAmidgliiQgmiihnh8Qhihpgog4QhGhhANhWQAOhaBdg5QBQgxBsgKQBAgGCDgEQBzgIBHgkQkJjIlChTQA7g2BpABQAvAACMAYQBoARBVgbQBkghARhSQAOhGg5hGQgqgzhTg1Innk9Qiyh1AahvQAOg6A+ggQA4gdBFABQAeABBgANQBOALAvgGQBDgHAwguQA0gxgLg8QgHgngkgiQgagYgwgbQlCizltg8QhjgPgVgFQhDgOgvgWQg6gdgjgxQgng1ADg6QAEhYBeg+QBEgtB4giQGFhtFxiaQA6gYAhgfQArgogHguI1vgMQgtgBgYgEQgmgIgXgUQgjgfACg2QABgyAegoQAagiAtgeQAZgQA8geQDBhjDciZQCQhkD1i7QBmhPAygvQBOhMAphNQAwhcgEhkQgGhrhDhCQgygzhXgXQg6gPhlgHQnBgfnBAcQnCAdm4BWQgdg8AehQQASgyA3hUQDHkuCSmsQBZkGCDoKQgoHJibG1QiaG0kAF9QMWiOMjAXQB2ADBHAKQBnAOBOAiQBbAoA+BHQBCBNAKBaQALBshIByQg2BThtBlQnNGlorEnQgpAWgWAZQgcAgALAgQAQAwBfABIUaAKQAvAAAbAHQAoAKAUAaQAnAzgzBCQgqA3hMAiQldCbluBgQhWAXgfALQhCAXgrAeQg1AmgcA2QgfA7AMA5QIHBlHeDdQBPAlAsAkQA7AzAKA+QAOBYhSBEQhLA+hmAJQgnAEiWgHQh0gFhGAUQAkDAEJCQQBEAlCMBFQB4BBBFBFQA8A8AaBIQAdBRgXBGQgXBChCAsQg8AphNAIQhAAIhQgNIgngIQA6ASA3AbQBoAyBWBLQAdAaANAZQARAggKAcQgLAaghANQgXAJgoAEIkHAXQh2AKhMAnQhjAygEBWQgDA3ArA8QAQAWBGBLQCMCYA0DRQA0DQg0DIQiFAHiFhMQhdg1iKh/QizikgygnQiHhoh8ghQAWBOA0B2QBECbAOAlQBfD9AMFTQAHDEgaFoIgEA3QgDAlgWAcQgQAUgQAAQgJAAgJgHgEhraAZbQglhEhDgtQg5gmhRgaQgygPhjgWIpriEIh9gbQgngIgXgMQgfgQgJgbQgOgmAjgmQAcgeAxgVQA+gcBDgZQDghXEKg8QEQg9F0gsQCBgPA5gNQBngXBGgsQBTg0AohYQArheghhUQgZg9hDgyQgsghhYgqQkDh9iMg2QjhhajAghIjyghQiRgThdghQg/gVgrgfQgngagYghQgfgrgEg2QgDg4AegnQARgWAegSIAYgMIAggPQFfiVF1hVQF1hVF9gRQAjgBATgGQAdgJANgUQAQgagPgjQgLgcgcgdQjPjYmCh/QiCgrjWg1QkbhGg/gRQgogLgXgKQghgPgTgXQgXgZAAgkQAAglAZgSQFsgVC7ABQExABDxAuIDbAsQB/AWBegHQnPldm7lmQBfhCCUAaQBUAPCuBDQEhBwE3AnQE3AnE0glQgyiphciZQhciZh+h8Ih6h0QhJhHgqg1Qh2iUARiLQEagUEWBBQEXBBD0CPQgTiogNhTQgWiLgghrQhQjigchyQgvjFA6iIIEOTTQAEATAAALQAAARgJAKQgJAMgSgEQgSgEADgPQjoigkThSQkShSkaAHQgCBkBRBoQAlAvB/B5QCJCCBtCbQBuCbBMCsQAQAjADAYQAFAigPAWQgLARgWALQgQAHgcAHQjOAwkIgiQikgUkyhNIqEiiIL9JWQAzAoAYAjQAiAwgMAsQhcAYiBgdQiUgqhJgTQjSg2lbAQQi8ALhfAEQijAGh3gHQCOA6DjA+QFMBaArANQDSBCCXBSQC5BkB2CHQAnAtAQArQATA1gWAoQgUAmg1AQQgjAKg/ADQmKAPmDBcQlxBYlZCaIgfAOQgTA3AfA6QAIAQALAOQAaAhAoAWQAtAYBDAMQAbAEBdAKQDrAYEMBVQDNBBEXB3QByAxA8AkQBdA2A5BBQBCBNASBhQATBogwBPQgkA7hKApQg3AehZAaQihAvjxAoQkRAqiHAXQjqApihA1QhuAjhfAvQhUAphJAxICdAmIL+C4QBeAWAxAUQBMAeAuAvQA2A3AEBPQAFBUg4ArQAMhJgohJg");
	this.shape_703.setTransform(761.6331,471.4673);

	this.shape_704 = new cjs.Shape();
	this.shape_704.graphics.f("#FFFFFF").s().p("EBhSBJDQAalpgHjDQgLlThfj9QgOglhFibQgzh3gWhOQB7AiCHBoQAzAnCyCjQCLB/BdA1QCFBNCEgHQA1jIg0jRQg0jQiNiYQhGhLgQgXQgqg7ACg3QAEhXBjgxQBNgnB1gLIEHgWQAogEAYgJQAhgNAKgaQALgcgRggQgOgZgdgaQhVhMhogxQg4gbg5gSIAmAHQBRANBAgHQBMgIA9gpQBCgsAWhCQAYhGgehRQgahJg8g7QhEhFh4hCQiMhEhFgmQkIiPgkjAQBFgUB0AFQCXAGAmgDQBmgJBLg+QBThEgOhZQgKg9g8gzQgsgkhOglQnfjeoHhlQgLg6Aeg6QAcg2A1gmQAsgeBBgXQAfgLBXgXQFthhFeiaQBLghArg4QAyhBgng0QgTgagpgKQgagGgwgBI0agJQhegBgRgwQgLggAdggQAVgaAqgVQIrkoHMmlQBuhkA1hTQBJhzgMhrQgJhbhDhNQg9hGhcgoQhOgjhngNQhGgKh3gEQsigWsXCNQEAl8Cbm0QCbm2AnnIQiCIKhaEGQiSGsjGEuQg3BTgTAzQgdBQAcA8QG4hWHDgdQHBgcHAAfQBmAGA6AQQBWAXAzAyQBDBCAFBsQAFBkgwBcQgpBMhPBNQgxAuhnBQQj0C7iRBkQjcCZjABjQg8AegZAQQguAegZAiQgfAogBAyQgBA2AiAeQAXAVAmAHQAZAFAtAAIVvANQAHAugrAoQghAfg6AYQlyCYmEBuQh5AihEAsQheA/gEBYQgDA5AnA1QAkAyA5AdQAvAXBEAOQAVAEBiAQQFuA7FBC0QAwAbAaAYQAkAiAIAnQAKA7gzAxQgxAuhCAIQgwAFhOgKQhfgOgfAAQhFgBg3AcQg/AhgOA6QgZBuCyB2IHnE9QBTA1ApAzQA5BGgOBGQgQBShkAhQhVAbhogRQiNgYgugBQhqAAg6A2QFCBTEIDIQhHAkhyAIQiDADhBAHQhsAJhQAyQhcA5gOBZQgOBXBGBhQApA4BhBpQBnB7AmCiQAmCjgmCdIiUAEQl3lemqkVQg1BbAnCHQAPAzBTC0QB8EOAKF2QAFDFghFWMjm6AAAMAAAgsWIJrCFQBkAVAyAQQBRAaA4AmQBDAtAlBEQAoBJgMBIQA5grgFhTQgFhQg1g3QguguhMgeQgxgUhegXIr/i4IAAiAQBgguBtgkQCig0DqgpQCHgXERgqQDxgoChgvQBZgaA2geQBKgpAkg7QAxhPgThpQgShhhDhMQg4hBhdg2Qg9gkhygxQkXh4jMhBQkMhWjrgXQhegKgagFQhDgLgugZQgogVgagiIAAicQFZiZFyhYQGDhcGKgPQA/gDAjgLQA0gPAVgmQAWgogUg2QgPgqgngtQh3iIi5hkQiXhRjShCQgqgNlMhbQjkg9iNg6QB2AHCkgGQBegEC9gLQFagQDSA2QBKATCUAqQCAAdBdgYQALgtghgvQgYgkgzgnIr+pWIKFCiQEyBNCkAUQEHAiDPgxQAbgGAQgHQAXgLALgRQAPgXgFghQgEgYgPgjQhNithtiaQhuiciIiBQh/h5glgwQhRhnABhlQEagGETBSQESBRDoChQgCAOASAFQARAEAKgMQAIgKAAgRQAAgLgEgUIkOzTQg6CJAwDEQAbBzBQDhQAgBsAWCLQANBSATCpQjziPkXhBQkXhBkZATQgRCMB2CUQAqA1BJBHIB6B0QB9B8BcCYQBcCaAyCoQk0Amk2gnQk3gnkhhwQivhDhTgPQiUgahfBCQG6FlHQFdQheAIh/gXIjcgrQjwgukygBQi6gBlsAVQgaASAAAlQABAkAWAZQAUAXAhAPQAXAJAoALQA/ASEaBGQDWA0CCArQGDCADODXQAcAeAMAcQAOAjgQAaQgMAUgdAJQgUAFgiACQl9ARl1BVQl2BUleCWIghAPMAAAhIpMEE6AAAMAAABEkIAACIUAQyAlsgQyAltgEiGpAEVQAsAeA/AWQBcAhCRATIDzAgQC/AiDiBZQCLA4EEB9QBXAqAtAgQBDAzAZA9QAhBTgrBfQgoBXhUA1QhGAshmAXQg5ANiBAPQl0AskRA9QkJA8jhBWg");
	this.shape_704.setTransform(834.8915,415.8);

	this.shape_705 = new cjs.Shape();
	this.shape_705.graphics.f().s("#232323").ss(6,1,1).p("ECGRA8SIAAQMMkP/AAAMAAAiY7MEP/AAAMAAABJBIAABBIAAOSQG7YOm7YNgECGRAL3MAAAAwb");
	this.shape_705.setTransform(815.2164,411.15);

	this.shape_706 = new cjs.Shape();
	this.shape_706.graphics.f("#232323").s().p("AgGgfIACACQAZAegbAfg");
	this.shape_706.setTransform(1675.2809,392.3);

	this.shape_707 = new cjs.Shape();
	this.shape_707.graphics.f("#FFFFFF").s().p("EiJuBMeMAAAiY7MEP/AAAMAAABJBIAABBIAAOSMAAAAwbIAAQMgECGRA8SgECGRAL3QG7YOm7YNg");
	this.shape_707.setTransform(815.2164,411.15);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_693},{t:this.shape_692}]},560).to({state:[{t:this.shape_692},{t:this.shape_693}]},28).to({state:[{t:this.shape_692},{t:this.shape_693}]},28).to({state:[{t:this.shape_694}]},27).to({state:[{t:this.shape_695}]},109).to({state:[{t:this.shape_696}]},27).to({state:[{t:this.shape_696}]},80).to({state:[{t:this.shape_698},{t:this.shape_697}]},144).to({state:[{t:this.shape_701},{t:this.shape_700},{t:this.shape_699}]},30).to({state:[{t:this.shape_701},{t:this.shape_700},{t:this.shape_699}]},20).to({state:[{t:this.shape_701},{t:this.shape_704},{t:this.shape_703},{t:this.shape_702}]},168).to({state:[{t:this.shape_707},{t:this.shape_706},{t:this.shape_705}]},31).wait(56));

	// ТЕКСТ
	this.shape_708 = new cjs.Shape();
	this.shape_708.graphics.f("#232323").s().p("AjyDkQAAgkAGgcQAKgvAHgrIAKg8QAWh+AAg2QAAgSgRgCQghgEAAgYQAAgPAJgKQAHgKANgBQAigBAQgKQAOgHAHAAQAOAAALAHQAMAHA3AAIBKgCIBRgEQAIgBAJgFQARgHAKAAIAcAFIAggCQAdAAgBAYQAAARgKALQgKALgOABQgKAAgHAHQgGAGgMAvQgMAvgKB2QgMB3AABfIAAANQAAAHgJAIQgJAIgIABQgSAAgKgRQgKgSAAgyQAAhWApkdQACgMgLgDQgLgChRAAQhuAAgPANQgRANgJBoQgEAqgQBcQgVBwAAAvIACAWQgBAggeAAQgjAAgBgug");
	this.shape_708.setTransform(1010.4,335.125);

	this.shape_709 = new cjs.Shape();
	this.shape_709.graphics.f("#232323").s().p("AiMEXQg3AAgrg9Qgrg9AAg4QAAhUArhXQAqhZBDg4QBCg4BAAAIAggDQAhgEAYAAQApAAAdAOQAeAPAeAfQAfAgAPApQAQAqAAAqQAAA7g9BSQg8BUhVA5QhUA6hEAAgAA0jfQgXAFgKABQgiAFgyAdQgzAdg2BaQg2BYAABOQAAA2AhAjQAiAkAtAAQBDAABKguQBKgvA3hBQA2hBABgdIAAgRQAFhkgxgqQgwgqgogCIgCAAQgIAAgTAFg");
	this.shape_709.setTransform(947.25,334.925);

	this.shape_710 = new cjs.Shape();
	this.shape_710.graphics.f("#232323").s().p("ADfEcQgFgDgNgOQgOgNgKgSQgLgSgMgkIgghcIgRgwIgqiGQgWhIgFgFIAAAAQgPAAgNAeIgoBGQghA2gLAWQgwBYg4BYIgIAOQgwBRgZAAQghAAAAgiQAAgcAqgxQAhgmBcibQBcidAthYQAIgPAOAAQANAAAOAFQANAGAFAHQAEAGAHAUQAHATARA/QArCWAfBSQAfBSANAbQANAbATALQAZAPAAARQAAAJgKAOQgKANgjAAQgJAAgEgDg");
	this.shape_710.setTransform(882.175,336.325);

	this.shape_711 = new cjs.Shape();
	this.shape_711.graphics.f("#232323").s().p("AkDEBQAAgzDFjHQAcgbAAgEQAAgFgXgfQh7iiAAgRQAAgQAJgOQAJgPAJAAQAWAAAVApQAmBOBSBjQB7iJApgoQAogoALAAQAKAAAMALQANALAAALQAAAIgiAeQgsAohFBIQhFBIAAAKQAAACAJAPQAKAOAlAsQAkArASAQQARARAZAOQARAKANASQAOASAAAFQAAAJgIAKQgIAIgLAAQgfAAgkggQgjghhQhnIgegmIgZAbQiECHgOAnQgNAngMANQgLANgaAAQgbAAAAgcg");
	this.shape_711.setTransform(826.075,336.525);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_711},{t:this.shape_710},{t:this.shape_709},{t:this.shape_708}]},545).to({state:[]},721).wait(42));

	// ВОПРОС___копия
	this.shape_712 = new cjs.Shape();
	this.shape_712.graphics.f().s("#232323").ss(4,1,1).p("AZqgXQAAHsmwFcQmwFdqwAuQqwAvoglDQohlDAzqlQAyqmJxjwQJxjwItAFQItAFGwFcQGwFdAAHsg");
	this.shape_712.setTransform(915.036,329.6124);

	this.shape_713 = new cjs.Shape();
	this.shape_713.graphics.f("#FFFFFF").s().p("Ax2OoQohlDAzqlQAyqmJxjwQJxjwItAFQItAFGwFcQGwFdAAHsQAAHsmwFcQmwFdqwAuQhXAGhUAAQpKAAnbkag");
	this.shape_713.setTransform(915.036,329.6124);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_713},{t:this.shape_712}]},545).to({state:[]},721).wait(42));

	// Слой_42
	this.shape_714 = new cjs.Shape();
	this.shape_714.graphics.f("#232323").s().p("ADbClQgSgMgRgQQg4g5AAhQQAAhPA4g6QA6g4BQAAQBQAAA5A4IALAMQAuA2AABHQAABQg5A5Qg5A5hQAAQg6AAgtgdgAmoClQgSgMgRgQQg4g5AAhQQAAhPA4g6QA6g4BQAAQBQAAA5A4IALAMQAuA2AABHQAABQg5A5Qg5A5hQAAQg6AAgtgdg");
	this.shape_714.setTransform(548.425,468.825);
	this.shape_714._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_714).wait(545).to({_off:false},0).to({_off:true},16).wait(747));

	// Слой_41
	this.instance_44 = new lib.Анимация33("synched",0);
	this.instance_44.setTransform(1068,270.4);
	this.instance_44._off = true;

	this.instance_45 = new lib.Анимация34("synched",0);
	this.instance_45.setTransform(1227.4,237.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_44}]},485).to({state:[{t:this.instance_45,p:{skewY:0,x:1227.4}}]},14).to({state:[{t:this.instance_45,p:{skewY:180,x:1257.15}}]},2).to({state:[{t:this.instance_45,p:{skewY:180,x:1257.15}}]},44).to({state:[]},1).wait(762));
	this.timeline.addTween(cjs.Tween.get(this.instance_44).wait(485).to({_off:false},0).to({_off:true,x:1227.4,y:237.65},14).wait(809));

	// зрачки
	this.instance_46 = new lib.Анимация29("synched",0);
	this.instance_46.setTransform(554.2,480.8);
	this.instance_46._off = true;

	this.instance_47 = new lib.Анимация30("synched",0);
	this.instance_47.setTransform(550.25,469.05,0.9974,1);
	this.instance_47._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_46).wait(485).to({_off:false},0).to({_off:true,scaleX:0.9974,x:550.25,y:469.05},37).wait(786));
	this.timeline.addTween(cjs.Tween.get(this.instance_47).wait(485).to({_off:false},37).to({x:559.5},22).to({_off:true},1).wait(763));

	// Слой_37
	this.shape_715 = new cjs.Shape();
	this.shape_715.graphics.f().s("#232323").ss(0.1,1,1).p("AEkAAQAABwhWBOQhVBPh5AAQh3AAhWhPQhVhOAAhwQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABug");
	this.shape_715.setTransform(519.8,477.15);

	this.shape_716 = new cjs.Shape();
	this.shape_716.graphics.f("#232323").s().p("ACDC+QhWhPABhvQgBhvBWhOQBWhPB4AAQB4AABWBPQBWBOgBBvQABBvhWBPQhWBPh4AAQh4AAhWhPgAoeC+QhWhPABhvQgBhvBWhOQBWhPB4AAQB4AABWBPQBWBOgBBvQABBvhWBPQhWBPh4AAQh4AAhWhPg");
	this.shape_716.setTransform(553.5,477.15);

	this.shape_717 = new cjs.Shape();
	this.shape_717.graphics.f().s("#232323").ss(0.1,1,1).p("AkiALQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhWBDQhVBDh4ABQh4AAhWhEQhVhDAAhwg");
	this.shape_717.setTransform(519.8,476.0252);

	this.shape_718 = new cjs.Shape();
	this.shape_718.graphics.f("#232323").s().p("AoeC+QhWhDABhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQABBwhWBDQhVBDh5ABIgBAAQh4AAhVhEgAFSEBQh5AAhWhEQhVhCAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhUBDQhUBDh3AAIgDAAg");
	this.shape_718.setTransform(553.5,476.0252);

	this.shape_719 = new cjs.Shape();
	this.shape_719.graphics.f().s("#232323").ss(0.1,1,1).p("AkiAWQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhVA3QhVA4h5ABQh3ABhWg5QhWg4AAhwg");
	this.shape_719.setTransform(519.8,474.9009);

	this.shape_720 = new cjs.Shape();
	this.shape_720.graphics.f("#232323").s().p("AoeC+QhVg4AAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhUA3QhVA4h5ABIgEABQh2AAhVg5gAFTD2Qh5gChWg3QhXg3ABhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQABBwhVA4QhSA4hzAAIgIAAg");
	this.shape_720.setTransform(553.5,474.9009);

	this.shape_721 = new cjs.Shape();
	this.shape_721.graphics.f().s("#232323").ss(0.1,1,1).p("AkiAiQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhVAsQhVAth4ABQh4AChWguQhWguAAhvg");
	this.shape_721.setTransform(519.8,473.7774);

	this.shape_722 = new cjs.Shape();
	this.shape_722.graphics.f("#232323").s().p("AoeC/QhVguAAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhUAsQhVAth5ABIgHAAQh0AAhUgsgAFUDqQh4gChYgsQhWgrAAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhTAuQhPArhvAAIgPAAg");
	this.shape_722.setTransform(553.5,473.7774);

	this.shape_723 = new cjs.Shape();
	this.shape_723.graphics.f().s("#232323").ss(0.1,1,1).p("AkiAtQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhVAhQhUAhh5ACQh3AChXgjQhWgjAAhvg");
	this.shape_723.setTransform(519.8,472.6554);

	this.shape_724 = new cjs.Shape();
	this.shape_724.graphics.f("#232323").s().p("AodC/QhXgjABhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhUAhQhVAhh4ACIgNAAQhwAAhSghgAFVDfQh4gEhYggQhYgfABhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhTAjQhLAghpAAIgYAAg");
	this.shape_724.setTransform(553.5,472.6554);

	this.shape_725 = new cjs.Shape();
	this.shape_725.graphics.f().s("#232323").ss(0.1,1,1).p("AkiA4QAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhVAWQhUAVh5ADQh3AChXgYQhWgYAAhvg");
	this.shape_725.setTransform(519.8,471.5577);

	this.shape_726 = new cjs.Shape();
	this.shape_726.graphics.f("#232323").s().p("AodC/QhXgYABhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhUAWQhVAVh4ADIgSAAQhtAAhQgWgAFWDTQh4gFhYgTQhZgUABhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhTAYQhGAVhgAAIglgBg");
	this.shape_726.setTransform(553.5,471.5577);

	this.shape_727 = new cjs.Shape();
	this.shape_727.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBDQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhUAKQhVAKh4ADQh4AChWgNQhXgMAAhwg");
	this.shape_727.setTransform(519.8,470.4452);

	this.shape_728 = new cjs.Shape();
	this.shape_728.graphics.f("#232323").s().p("AodC/QhWgMAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhUAKQhUAKh5ADIglAAQhhAAhJgLgAFXDIQh4gGhZgIQhYgHAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhSANQg7AJhNAAQggAAgjgBg");
	this.shape_728.setTransform(553.5,470.4452);

	this.shape_729 = new cjs.Shape();
	this.shape_729.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBOQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhUgBQhUgCh5AEQh3ADhXgCQhXgCAAhvg");
	this.shape_729.setTransform(519.8,469.39);

	this.shape_730 = new cjs.Shape();
	this.shape_730.graphics.f("#232323").s().p("AFYC7Qh4gHhZAEQhaAFABhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhSACIgwABQhDAAhXgFgAodC+QhWgBAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhUgCQhTgBh5ADQhIACg9AAIhLgBg");
	this.shape_730.setTransform(553.5,469.4347);

	this.shape_731 = new cjs.Shape();
	this.shape_731.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBTQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhUgNQhUgNh4AEQh4ADhXAJQhXAKAAhwg");
	this.shape_731.setTransform(519.8,468.8373);

	this.shape_732 = new cjs.Shape();
	this.shape_732.graphics.f("#232323").s().p("AIjC6QhRgJh5gHQh4gIhZAQQhaAQAAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABnhGAAIgLAAgApzBTQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhTgNQhUgNh5AEQh4AEhXAJIgNAAQhLAAABhmg");
	this.shape_732.setTransform(553.5,468.8801);

	this.shape_733 = new cjs.Shape();
	this.shape_733.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBXQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhUgZQhTgYh5AEQh3AFhYAUQhXAUAAhwg");
	this.shape_733.setTransform(519.8,468.4271);

	this.shape_734 = new cjs.Shape();
	this.shape_734.graphics.f("#232323").s().p("AIjCzQhRgTh4gIQh3gJhbAcQhbAcABhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABfg6AAQgKAAgNgDgApzBXQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhTgZQhUgYh4AEQh5AFhXAUQgNADgMAAQg/AAABhfg");
	this.shape_734.setTransform(553.5,468.4451);

	this.shape_735 = new cjs.Shape();
	this.shape_735.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBbQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhUgkQhTgjh4AEQh4AFhYAfQhXAfAAhvg");
	this.shape_735.setTransform(519.8,468.0622);

	this.shape_736 = new cjs.Shape();
	this.shape_736.graphics.f("#232323").s().p("AIkCsQhRgeh4gKQh4gJhaAnQhbAoAAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABXgxAAQgOAAgRgGgApzBbQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhTgkQhTgjh4AEQh5AFhYAfQgTAHgPAAQg2AAABhXg");
	this.shape_736.setTransform(553.5,468.0776);

	this.shape_737 = new cjs.Shape();
	this.shape_737.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBeQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhTgwQhTgvh5AFQh3AGhYAqQhYAqAAhwg");
	this.shape_737.setTransform(519.8,467.7496);

	this.shape_738 = new cjs.Shape();
	this.shape_738.graphics.f("#232323").s().p("AIkCkQhQgph4gLQh4gKhbA0QhcAzABhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABRgqAAQgQAAgWgLgApzBeQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhTgvQhTgvh4AFQh4AFhZAqQgYAMgRAAQgvAAABhRg");
	this.shape_738.setTransform(553.5,467.7628);

	this.shape_739 = new cjs.Shape();
	this.shape_739.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBhQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhTg7QhTg6h4AFQh4AGhYA1QhYA1AAhvg");
	this.shape_739.setTransform(519.8,467.4788);

	this.shape_740 = new cjs.Shape();
	this.shape_740.graphics.f("#232323").s().p("AIlCcQhQg0h4gMQh4gLhbA/QhcBAAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABNgkAAQgSAAgZgRgApzBgQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhTg7QhSg7h4AGQh5AGhZA1QgcARgTAAQgoAAAAhMg");
	this.shape_740.setTransform(553.5,467.5019);

	this.shape_741 = new cjs.Shape();
	this.shape_741.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBjQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhThHQhShGh5AGQh3AHhZBAQhYBAAAhwg");
	this.shape_741.setTransform(519.8,467.242);

	this.shape_742 = new cjs.Shape();
	this.shape_742.graphics.f("#232323").s().p("AImCTQhQg/h4gMQh3gMhdBLQhdBLABhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABHggAAQgSAAgcgXgApzBjQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhShGQhShGh5AGQh4AGhZBAQggAYgVAAQgjAAAAhHg");
	this.shape_742.setTransform(553.5,467.2622);

	this.shape_743 = new cjs.Shape();
	this.shape_743.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBlQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhThSQhShSh5AHQh3AHhZBLQhYBLAAhwg");
	this.shape_743.setTransform(519.8,467.033);

	this.shape_744 = new cjs.Shape();
	this.shape_744.graphics.f("#232323").s().p("AImCKQhPhKh3gNQh4gNhdBXQhdBXAAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABDgcAAQgTAAgfgegApzBlQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhShRQhShSh5AHQh4AGhZBLQgkAfgVAAQggAAABhDg");
	this.shape_744.setTransform(553.5,467.051);

	this.shape_745 = new cjs.Shape();
	this.shape_745.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBnQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhShdQhThdh4AHQh4AHhYBWQhZBWAAhwg");
	this.shape_745.setTransform(519.8,466.8474);

	this.shape_746 = new cjs.Shape();
	this.shape_746.graphics.f("#232323").s().p("AInCBQhPhUh3gOQh4gPhdBjQheBjAAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAAA/gZAAQgTAAghglgApzBnQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhShdQhShdh4AHQh5AHhYBWQgnAmgWAAQgcAAAAg/g");
	this.shape_746.setTransform(553.5,466.8634);

	this.shape_747 = new cjs.Shape();
	this.shape_747.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBpQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvQAABvhShoQhShph5AIQh3AHhZBhQhZBhAAhvg");
	this.shape_747.setTransform(519.8,466.6814);

	this.shape_748 = new cjs.Shape();
	this.shape_748.graphics.f("#232323").s().p("AInB4QhOhgh3gPQh4gOheBuQheBvAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAAA9gWAAQgTAAgkgtgApzBoQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhShpQhShoh4AHQh5AIhYBhQgqAtgWAAQgZAAAAg8g");
	this.shape_748.setTransform(553.5,466.703);

	this.shape_749 = new cjs.Shape();
	this.shape_749.graphics.f().s("#232323").ss(0.1,1,1).p("AkiBqQAAhuBVhPQBWhPB3AAQB5AABVBPQBWBPAABuQAABwhSh0QhShzh4AIQh4AHhZBsQhZBsAAhwg");
	this.shape_749.setTransform(519.8,466.5319);

	this.shape_750 = new cjs.Shape();
	this.shape_750.graphics.f("#232323").s().p("AIoBvQhOhrh3gPQh4gQhfB6QheB6AAhvQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAAA5gUAAQgTAAglg0gApzBqQgBhvBWhPQBWhOB4AAQB4AABWBOQBWBPgBBvQAABvhRh0QhShzh4AIQh5AHhZBsQgsA2gWAAQgXAAAAg5g");
	this.shape_750.setTransform(553.5,466.5514);

	this.shape_751 = new cjs.Shape();
	this.shape_751.graphics.f().s("#232323").ss(0.1,1,1).p("AEkBsQgBBvhRh/QhRh/h5AJQh4AIhZB2QhZB3AAhvQAAhvBVhPQBWhOB3AAQB5AABVBOQBWBPAABvg");
	this.shape_751.setTransform(519.8,466.3971);

	this.shape_752 = new cjs.Shape();
	this.shape_752.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBrQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAABwhRiAQhRh+h5AIQh5AJhZB2QguA9gXAAQgUAAAAg2g");
	this.shape_752.setTransform(553.5,466.4143);

	this.shape_753 = new cjs.Shape();
	this.shape_753.graphics.f().s("rgba(33,33,33,0.949)").ss(0.1,1,1).p("AkjBsQAAhvBWhPQBVhOB4AAQB4AABWBOQA7A3ATBGQAHAfAAAiQAABuhRh+QhSh+h4AIQh4AJhZB1QgcAlgTAPQgqAhgBhMg");
	this.shape_753.setTransform(519.6,465.9495);

	this.shape_754 = new cjs.Shape();
	this.shape_754.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQAAhuBWhPQBWhPB4AAQB5AABVBPQBVBPAABuQAAA3gSAAQgTAAgng9gAp0BsIAAgBQAAhuBWhPQBWhPB4AAQB4AABWBPQA8A3ARBFQAJAfgBAiQAABvhRh+QhSh/h4AIQh5AJhZB2QgcAlgTAOQgMAKgJAAQgVAAgBg1g");
	this.shape_754.setTransform(553.3,465.9645);

	this.shape_755 = new cjs.Shape();
	this.shape_755.graphics.f().s("rgba(31,31,31,0.894)").ss(0.1,1,1).p("AkiBsQAAhvBVhPQBWhOB3AAQB5AABVBOQA8A3ASBGQAHAfAAAiQAABuhRh+QhSh/h4AJQh4AJhZB1QgcAlgTAOQgqAiAAhMg");
	this.shape_755.setTransform(519.4,465.5374);

	this.shape_756 = new cjs.Shape();
	this.shape_756.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQABhuBVhPQBVhPB5AAQB5AABVBPQBVBPABBuQgBA3gSAAQgTAAgng9gAp0BsIAAgBQABhuBVhPQBWhPB4AAQB5AABVBPQA7A3ASBFQAJAfgBAiQAABvhRh/QhSh+h4AIQh5AJhZB2QgcAkgTAPQgNAKgJAAQgUAAgBg1g");
	this.shape_756.setTransform(553.1,465.5645);

	this.shape_757 = new cjs.Shape();
	this.shape_757.graphics.f().s("rgba(29,29,29,0.843)").ss(0.1,1,1).p("AkjBsQAAhvBWhPQBVhOB4AAQB4AABWBOQA7A3ASBGQAIAfAAAiQAABuhRh+QhSh+h4AIQh4AJhZB1QgcAlgTAPQgqAhgBhMg");
	this.shape_757.setTransform(519.2,465.0995);

	this.shape_758 = new cjs.Shape();
	this.shape_758.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQAAhuBVhPQBVhPB5AAQB4AABWBPQBWBPAABuQAAA3gTAAQgTAAgng9gAp0BsIAAgBQABhuBVhPQBVhPB5AAQB4AABWBPQA8A3ASBFQAHAfABAiQgBBvhRh+QhSh/h4AIQh5AJhZB2QgcAlgTAOQgNAKgJAAQgUAAgBg1g");
	this.shape_758.setTransform(552.9,465.1145);

	this.shape_759 = new cjs.Shape();
	this.shape_759.graphics.f().s("rgba(28,28,28,0.788)").ss(0.1,1,1).p("AkiBsQAAhvBVhPQBVhOB4AAQB4AABWBOQA7A3ATBFQAHAfAAAiQAABvhRh+QhSh/h4AJQh4AIhZB2QgdAlgSAOQgqAhAAhMg");
	this.shape_759.setTransform(519,464.6745);

	this.shape_760 = new cjs.Shape();
	this.shape_760.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBsIAAgBQgBhuBWhPQBVhPB5AAQB4AABWBPQA7A2ATBGQAHAfABAiQgBBvhRh/QhSh+h4AIQh5AJhZB1QgdAlgSAPQgNAKgJAAQgUAAAAg1g");
	this.shape_760.setTransform(552.7,464.7145);

	this.shape_761 = new cjs.Shape();
	this.shape_761.graphics.f().s("rgba(26,26,26,0.737)").ss(0.1,1,1).p("AkiBsQAAhvBVhPQBVhOB4AAQB4AABWBOQA7A3ATBFQAHAfAAAjQAABuhRh+QhRh+h4AIQh5AJhYB1QgdAlgTAPQgqAhAAhMg");
	this.shape_761.setTransform(518.75,464.2495);

	this.shape_762 = new cjs.Shape();
	this.shape_762.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQAAhuBVhPQBVhPB5AAQB4AABWBPQBWBPAABuQAAA3gTAAQgTAAgng9gApzBsIAAgBQAAhuBVhPQBVhPB5AAQB4AABWBPQA8A3ASBFQAHAfABAiQAABvhRh+QhSh/h4AIQh5AJhZB2QgdAlgSAOQgNAKgJAAQgVAAAAg1g");
	this.shape_762.setTransform(552.45,464.2645);

	this.shape_763 = new cjs.Shape();
	this.shape_763.graphics.f().s("rgba(24,24,24,0.682)").ss(0.1,1,1).p("AkiBsQAAhvBVhPQBWhOB3AAQB5AABVBOQA8A3ASBFQAIAfAAAiQAABvhRh+QhSh/h4AJQh4AIhZB2QgdAlgTAOQgqAhAAhMg");
	this.shape_763.setTransform(518.55,463.8245);

	this.shape_764 = new cjs.Shape();
	this.shape_764.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBsIAAgBQgBhuBWhPQBVhPB5AAQB4AABWBPQA7A2ATBGQAHAfABAiQAABvhRh/QhTh+h3AIQh6AJhYB1QgdAlgTAPQgNAKgJAAQgUAAAAg1g");
	this.shape_764.setTransform(552.25,463.8645);

	this.shape_765 = new cjs.Shape();
	this.shape_765.graphics.f().s("rgba(22,22,22,0.631)").ss(0.1,1,1).p("AkjBsQAAhvBWhPQBVhOB4AAQB4AABWBOQA7A3ATBFQAHAfAAAiQAABvhRh+QhRh+h4AIQh5AJhZB1QgcAlgTAPQgqAggBhMg");
	this.shape_765.setTransform(518.35,463.3868);

	this.shape_766 = new cjs.Shape();
	this.shape_766.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQAAhuBWhPQBWhPB4AAQB5AABVBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBsIAAgBQgBhuBWhPQBWhPB4AAQB4AABWBPQA8A3ARBFQAIAfAAAiQAABvhRh+QhSh/h3AIQh6AJhYB1QgdAmgTAOQgNAKgIAAQgVAAAAg1g");
	this.shape_766.setTransform(552.05,463.4145);

	this.shape_767 = new cjs.Shape();
	this.shape_767.graphics.f().s("rgba(20,20,20,0.58)").ss(0.1,1,1).p("AkiBrQAAhuBVhPQBWhPB3AAQB5AABVBPQA8A3ASBFQAHAfAAAiQAABvhQh+QhSh/h4AIQh5AJhYB2QgdAlgTAPQgqAgAAhMg");
	this.shape_767.setTransform(518.15,462.9618);

	this.shape_768 = new cjs.Shape();
	this.shape_768.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQAAhuBWhPQBWhPB4AAQB5AABVBPQBVBPABBuQgBA3gSAAQgTAAgng9gAp0BsIAAgBQAAhuBWhPQBWhPB4AAQB5AABVBPQA8A3ARBFQAJAfgBAiQAABvhRh+QhSh/h3AIQh5AJhaB2QgcAlgTAPQgNAKgIAAQgVAAgBg2g");
	this.shape_768.setTransform(551.85,462.9645);

	this.shape_769 = new cjs.Shape();
	this.shape_769.graphics.f().s("rgba(18,18,18,0.525)").ss(0.1,1,1).p("AkjBsQAAhvBWhPQBVhOB4AAQB4AABWBOQA7A3ASBFQAIAfAAAiQAABvhRh+QhSh+h3AIQh5AIhZB2QgcAlgTAPQgqAggBhMg");
	this.shape_769.setTransform(517.95,462.5368);

	this.shape_770 = new cjs.Shape();
	this.shape_770.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQAAhuBVhPQBVhPB5AAQB4AABWBPQBVBPABBuQAAA3gTAAQgTAAgng9gAp0BsIAAgBQABhuBVhPQBVhPB5AAQB5AABVBPQA7A2ASBFQAJAfAAAjQAABvhRh+QhSh/h4AIQh5AJhaB1QgcAmgTAOQgNAKgIAAQgVAAgBg1g");
	this.shape_770.setTransform(551.65,462.5645);

	this.shape_771 = new cjs.Shape();
	this.shape_771.graphics.f().s("rgba(17,17,17,0.475)").ss(0.1,1,1).p("AkiBsQAAhvBVhPQBVhOB4AAQB4AABWBOQA7A3ATBFQAHAfAAAiQAABwhRh/QhRh+h4AIQh5AJhYB1QgeAmgSAOQgqAgAAhMg");
	this.shape_771.setTransform(517.75,462.0991);

	this.shape_772 = new cjs.Shape();
	this.shape_772.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQgBhuBWhPQBVhPB5AAQB4AABWBPQBWBPAABuQAAA3gTAAQgTAAgng9gApzBsIAAgBQAAhuBVhPQBVhPB5AAQB4AABWBPQA7A3ATBFQAHAfABAiQgBBvhQh+QhSh/h4AIQh6AJhYB1QgdAmgTAPQgNAJgJAAQgVAAABg1g");
	this.shape_772.setTransform(551.45,462.1145);

	this.shape_773 = new cjs.Shape();
	this.shape_773.graphics.f().s("rgba(15,15,15,0.42)").ss(0.1,1,1).p("AkiBsQAAhvBVhPQBWhOB3AAQB5AABVBOQA7A3ATBFQAIAfAAAiQgBBvhQh+QhSh+h4AIQh4AIhZB1QgdAmgTAPQgqAgAAhMg");
	this.shape_773.setTransform(517.55,461.6741);

	this.shape_774 = new cjs.Shape();
	this.shape_774.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBrQgBhuBWhPQBWhPB4AAQB4AABWBPQA7A2ATBFQAHAfAAAiQAABwhRh+QhSh/h3AIQh6AJhYB1QgdAmgUAOQgMAKgJAAQgUAAAAg2g");
	this.shape_774.setTransform(551.25,461.7145);

	this.shape_775 = new cjs.Shape();
	this.shape_775.graphics.f().s("rgba(13,13,13,0.369)").ss(0.1,1,1).p("AkjBsQAAhvBWhPQBVhOB4AAQB4AABWBOQA7A3ATBFQAHAfAAAiQAABwhRh/QhRh+h4AIQh5AIhZB2QgdAmgTAOQgqAgAAhMg");
	this.shape_775.setTransform(517.35,461.2491);

	this.shape_776 = new cjs.Shape();
	this.shape_776.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQAAhuBWhPQBWhPB4AAQB5AABVBPQBVBPAABuQAAA3gSAAQgTAAgng9gAp0BsIAAgBQAAhuBWhPQBWhPB4AAQB4AABWBPQA7A2ASBFQAJAfgBAjQAABvhRh+QhSh/h3AIQh6AJhZB1QgdAmgTAPQgMAJgJAAQgVAAAAg1g");
	this.shape_776.setTransform(551.05,461.2645);

	this.shape_777 = new cjs.Shape();
	this.shape_777.graphics.f().s("rgba(11,11,11,0.318)").ss(0.1,1,1).p("AkiBrQAAhuBVhPQBWhPB3AAQB5AABVBPQA7A3ATBEQAHAfAAAjQAABvhQh+QhSh+h4AHQh5AJhYB1QgdAngTAOQgqAgAAhMg");
	this.shape_777.setTransform(517.15,460.8115);

	this.shape_778 = new cjs.Shape();
	this.shape_778.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQABhuBVhPQBVhPB5AAQB5AABVBPQBVBPABBuQAAA3gTAAQgTAAgng9gAp0BsIAAgBQABhuBVhPQBWhPB4AAQB5AABVBPQA7A3ASBEQAJAfgBAjQAABvhQh+QhSh+h4AHQh5AJhaB1QgdAngSAOQgNAKgJAAQgVAAAAg2g");
	this.shape_778.setTransform(550.85,460.8145);

	this.shape_779 = new cjs.Shape();
	this.shape_779.graphics.f().s("rgba(9,9,9,0.263)").ss(0.1,1,1).p("AkjBsQAAhvBWhPQBVhOB4AAQB4AABWBOQA7A3ASBFQAIAfAAAiQAABwhRh/QhSh+h3AIQh5AIhZB1QgdAngTAOQgqAgAAhMg");
	this.shape_779.setTransform(516.95,460.3865);

	this.shape_780 = new cjs.Shape();
	this.shape_780.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQAAhuBVhPQBVhPB5AAQB4AABWBPQBWBPAABuQAAA3gTAAQgTAAgng9gAp0BrQABhuBVhPQBVhPB5AAQB4AABWBPQA7A2ATBFQAHAfABAiQgBBwhQh+QhSh/h4AIQh5AJhaB1QgcAmgUAPQgMAJgJAAQgVAAAAg2g");
	this.shape_780.setTransform(550.65,460.4145);

	this.shape_781 = new cjs.Shape();
	this.shape_781.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQABhuBVhPQBVhPB5AAQB5AABVBPQBVBPABBuQAAA3gTAAQgTAAgng9gAp0BsIAAgBQABhuBVhPQBWhPB4AAQB5AABVBPQA7A3ASBEQAJAfgBAjQABBvhRh+QhSh+h3AHQh6AJhZB1QgdAngTAOQgNAKgIAAQgVAAgBg2g");
	this.shape_781.setTransform(550.4,459.9645);

	this.shape_782 = new cjs.Shape();
	this.shape_782.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQAAhuBVhPQBVhPB5AAQB4AABWBPQBWBPAABuQAAA3gTAAQgTAAgng9gApzBrQAAhuBVhPQBVhPB5AAQB4AABWBPQA7A2ATBFQAHAfABAiQgBBwhQh+QhSh/h3AIQh6AJhZB1QgeAmgSAPQgNAJgJAAQgVAAABg2g");
	this.shape_782.setTransform(550.2,459.5645);

	this.shape_783 = new cjs.Shape();
	this.shape_783.graphics.f("#232323").s().p("AIoBlQhNh0h4gRQh3gRhfCFQhfCHAAhwQgBhuBWhPQBWhPB4AAQB4AABWBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBrQgBhuBWhPQBVhPB5AAQB4AABWBPQA7A2ATBFQAHAfABAiQAABwhRh+QhSh+h3AHQh6AJhZB1QgdAngUAOQgMAJgIAAQgVAAAAg2g");
	this.shape_783.setTransform(550,459.1145);

	this.shape_784 = new cjs.Shape();
	this.shape_784.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQAAhuBWhPQBWhPB4AAQB5AABVBPQBWBPgBBuQAAA3gSAAQgTAAgng9gApzBrQgBhuBWhPQBWhPB4AAQB4AABWBPQA7A2ASBFQAIAfAAAiQAABwhQh+QhSh/h3AIQh6AJhZB1QgeAmgTAPQgMAJgJAAQgUAAAAg2g");
	this.shape_784.setTransform(549.8,458.7145);

	this.shape_785 = new cjs.Shape();
	this.shape_785.graphics.f("#232323").s().p("AIoBlQhNh0h3gRQh4gRhfCFQhgCHAAhwQAAhuBWhPQBWhPB4AAQB5AABVBPQBVBPABBuQgBA3gSAAQgTAAgng9gAp0BrQAAhuBWhPQBWhPB4AAQB5AABVBPQA7A2ASBFQAJAggBAiQABBwhSiAQhRh+h5AIQh5AJhZB2QgdAmgTAOQgMAJgJAAQgVAAAAg2g");
	this.shape_785.setTransform(549.6,458.2645);

	this.shape_786 = new cjs.Shape();
	this.shape_786.graphics.f("#232323").s().p("AIoBkQhNhzh3gRQh4gRhfCFQhgCFAAhvQAAhtBWhOQBWhOB4AAQB5AABVBOQBVBOABBtQgBA2gSAAQgTAAgng8gAp0BqQAAhtBWhOQBWhOB4AAQB5AABVBOQA7A2ASBEQAJAfgBAiQABBvhSh+QhRh+h5AJQh5AIhZB1QgcAmgUAOQgMAJgJAAQgVAAAAg2g");
	this.shape_786.setTransform(549.6,457.9895);

	this.shape_787 = new cjs.Shape();
	this.shape_787.graphics.f("#232323").s().p("AIoBjQhNhyh3gRQh4gQhfCDQhgCDAAhtQAAhsBWhOQBWhNB4AAQB5AABVBNQBVBOABBsQgBA2gSAAQgTAAgng8gAp0BpQAAhsBWhOQBWhNB4AAQB5AABVBNQA7A2ASBDQAJAfgBAiQABBthSh9QhRh8h5AJQh5AIhZB0QgcAlgUAOQgMAJgJAAQgVAAAAg1g");
	this.shape_787.setTransform(549.6,457.702);

	this.shape_788 = new cjs.Shape();
	this.shape_788.graphics.f("#232323").s().p("AIoBiQhNhxh3gQQh4gRhfCCQhgCCAAhsQAAhrBWhNQBWhMB4AAQB5AABVBMQBVBNABBrQgBA1gSAAQgTAAgng7gAp0BoQAAhrBWhNQBWhMB4AAQB5AABVBMQA7A1ASBDQAJAegBAiQABBshSh7QhRh7h5AIQh5AIhZBzQgcAlgUAOQgMAIgJAAQgVAAAAg0g");
	this.shape_788.setTransform(549.6,457.427);

	this.shape_789 = new cjs.Shape();
	this.shape_789.graphics.f("#232323").s().p("AIoBhQhNhwh3gQQh4gQhfCAQhgCBAAhrQAAhqBWhMQBWhLB4AAQB5AABVBLQBVBMABBqQgBA0gSAAQgTAAgng6gAp0BnQAAhqBWhMQBWhLB4AAQB5AABVBLQA7A0ASBCQAJAegBAiQABBrhSh6QhRh6h5AIQh5AIhZByQgcAkgUAOQgMAJgIAAQgWAAAAg0g");
	this.shape_789.setTransform(549.6,457.158);

	this.shape_790 = new cjs.Shape();
	this.shape_790.graphics.f("#232323").s().p("AIoBgQhNhuh3gRQh4gQhfB/QhgCAAAhqQAAhpBWhLQBWhLB4AAQB5AABVBLQBVBLABBpQgBA0gSAAQgTAAgng6gAp0BmQAAhpBWhLQBWhLB4AAQB5AABVBLQA7A0ASBBQAJAegBAhQABBqhSh5QhRh4h5AIQh5AIhZBwQgcAkgUAOQgMAIgJAAQgVAAAAgzg");
	this.shape_790.setTransform(549.6,456.8646);

	this.shape_791 = new cjs.Shape();
	this.shape_791.graphics.f("#232323").s().p("AIoBfQhNhth3gQQh4gQhfB9QhgB/AAhpQAAhoBWhKQBWhKB4AAQB5AABVBKQBVBKABBoQgBAzgSAAQgTAAgng5gAp0BlQAAhoBWhKQBWhKB4AAQB5AABVBKQA7AzASBAQAJAegBAhQABBphSh4QhRh3h5AIQh5AIhZBvQgcAjgUAOQgMAJgJAAQgVAAAAgzg");
	this.shape_791.setTransform(549.6,456.6021);

	this.shape_792 = new cjs.Shape();
	this.shape_792.graphics.f("#232323").s().p("AIoBeQhNhsh3gQQh4gQhfB8QhgB+AAhoQAAhnBWhJQBWhKB4AAQB5AABVBKQBVBJABBnQgBAzgSAAQgTAAgng5gAp0BkQAAhnBWhJQBWhKB4AAQB5AABVBKQA7AyASBAQAJAdgBAhQABBohSh3QhRh2h5AIQh5AIhZBuQgcAjgUAOQgMAIgIAAQgWAAAAgyg");
	this.shape_792.setTransform(549.6,456.308);

	this.shape_793 = new cjs.Shape();
	this.shape_793.graphics.f("#232323").s().p("AIoBdQhNhrh3gPQh4gQhfB7QhgB8AAhnQAAhmBWhIQBWhJB4AAQB5AABVBJQBVBIABBmQgBAygSAAQgTAAgng4gAp0BjQAAhmBWhIQBWhJB4AAQB5AABVBJQA7AyASA/QAJAdgBAgQABBnhSh2QhRh0h5AIQh5AIhZBsQgcAjgUANQgMAIgJAAQgVAAAAgxg");
	this.shape_793.setTransform(549.6,456.0396);

	this.shape_794 = new cjs.Shape();
	this.shape_794.graphics.f("#232323").s().p("AIoBcQhNhqh3gPQh4gQhfB6QhgB6AAhlQAAhlBWhIQBWhHB4AAQB5AABVBHQBVBIABBlQAAAxgTAAQgTAAgng3gAp0BiQAAhlBWhIQBWhHB4AAQB5AABVBHQA7AyASA+QAJAdgBAgQABBlhSh0QhRhzh5AIQh5AHhZBsQgcAigUAOQgMAIgJAAQgVAAAAgxg");
	this.shape_794.setTransform(549.6,455.7706);

	this.shape_795 = new cjs.Shape();
	this.shape_795.graphics.f("#232323").s().p("AIoBbQhNhoh3gQQh4gPhfB4QhgB5AAhkQAAhkBWhHQBWhHB4AAQB5AABVBHQBVBHABBkQgBAxgSAAQgTAAgng3gAp0BhQAAhkBWhHQBWhHB4AAQB5AABVBHQA7AxASA+QAJAcgBAgQABBkhShzQhRhyh5AIQh5AIhZBqQgcAigUANQgMAIgJAAQgVAAAAgwg");
	this.shape_795.setTransform(549.6,455.4706);

	this.shape_796 = new cjs.Shape();
	this.shape_796.graphics.f("#232323").s().p("AIoBaQhNhnh3gQQh4gPhfB3QhgB4AAhjQAAhjBWhGQBWhGB4AAQB5AABVBGQBVBGABBjQgBAwgSAAQgTAAgng2gAp0BgQAAhjBWhGQBWhGB4AAQB5AABVBGQA7AwASA9QAJAcgBAgQABBjhShyQhRhwh5AHQh5AIhZBpQgcAigUANQgMAIgJAAQgVAAAAgwg");
	this.shape_796.setTransform(549.6,455.2081);

	this.shape_797 = new cjs.Shape();
	this.shape_797.graphics.f("#232323").s().p("AIoBZQhNhmh3gPQh4gPhfB1QhgB3AAhiQAAhiBWhFQBWhFB4AAQB5AABVBFQBVBFABBiQgBAvgSAAQgTAAgng1gAp0BfQAAhiBWhFQBWhFB4AAQB5AABVBFQA7AwASA8QAJAcgBAfQABBihShwQhRhwh5AIQh5AHhZBoQgcAhgUANQgMAIgJAAQgVAAAAgvg");
	this.shape_797.setTransform(549.6,454.9331);

	this.shape_798 = new cjs.Shape();
	this.shape_798.graphics.f("#232323").s().p("AIoBYQhNhlh3gPQh4gOhfB0QhgB1AAhhQAAhhBWhEQBWhFB4AAQB5AABVBFQBVBEABBhQgBAvgSAAQgTAAgng1gAp0BeQAAhhBWhEQBWhFB4AAQB5AABVBFQA7AvASA8QAJAbgBAfQABBhhShvQhRhuh5AHQh5AIhZBmQgcAhgUANQgMAIgJAAQgVAAAAgvg");
	this.shape_798.setTransform(549.6,454.6331);

	this.shape_799 = new cjs.Shape();
	this.shape_799.graphics.f("#232323").s().p("AIoBXQhNhkh3gPQh4gOhfBzQhgBzAAhgQAAhfBWhEQBWhDB4AAQB5AABVBDQBVBEABBfQgBAvgSAAQgTAAgng0gAp0BcQAAhfBWhEQBWhDB4AAQB5AABVBDQA7AvASA7QAJAbgBAeQABBghShtQhRhth5AHQh5AHhZBmQgcAhgUAMQgMAIgIAAQgWAAAAgvg");
	this.shape_799.setTransform(549.6,454.3641);

	this.shape_800 = new cjs.Shape();
	this.shape_800.graphics.f("#232323").s().p("AIoBWQhNhih3gPQh4gOhfBxQhgByAAheQAAhfBWhDQBWhCB4AAQB5AABVBCQBVBDABBfQgBAtgSAAQgTAAgngzgAp0BcQAAhfBWhDQBWhCB4AAQB5AABVBCQA7AvASA6QAJAbgBAeQABBehShsQhRhsh5AIQh5AHhZBkQgcAggUANQgMAHgJAAQgVAAAAgtg");
	this.shape_800.setTransform(549.6,454.0957);

	this.shape_801 = new cjs.Shape();
	this.shape_801.graphics.f("#232323").s().p("AIoBVQhNhih3gOQh4gOhfBwQhgBxAAheQAAhdBWhCQBWhCB4AAQB5AABVBCQBVBCABBdQgBAugSAAQgTAAgngzgAp0BaQAAhdBWhCQBWhCB4AAQB5AABVBCQA7AuASA5QAJAbgBAdQABBehShrQhRhrh5AIQh5AHhZBjQgcAggUAMQgMAIgIAAQgWAAAAgug");
	this.shape_801.setTransform(549.6,453.8016);

	this.shape_802 = new cjs.Shape();
	this.shape_802.graphics.f("#232323").s().p("AIoBUQhNhgh3gOQh4gOhfBuQhgBwAAhdQAAhbBWhCQBWhBB4AAQB5AABVBBQBVBCABBbQgBAtgSAAQgTAAgngygAp0BZQAAhbBWhCQBWhBB4AAQB5AABVBBQA7AtASA5QAJAagBAdQABBdhShqQhRhph5AHQh5AHhZBiQgcAggUAMQgMAHgIAAQgWAAAAgtg");
	this.shape_802.setTransform(549.6,453.5391);

	this.shape_803 = new cjs.Shape();
	this.shape_803.graphics.f("#232323").s().p("AIoBTQhNhfh3gOQh4gOhfBuQhgBuAAhbQAAhbBWhBQBWhBB4AAQB5AABVBBQBVBBABBbQgBAsgSAAQgTAAgngygAp0BZQAAhbBWhBQBWhBB4AAQB5AABVBBQA7AtASA4QAJAagBAdQABBbhShpQhRhoh5AIQh5AHhZBgQgcAfgUAMQgMAHgJAAQgVAAAAgrg");
	this.shape_803.setTransform(549.6,453.2458);

	this.shape_804 = new cjs.Shape();
	this.shape_804.graphics.f("#232323").s().p("AIoBSQhNheh3gOQh4gNhfBsQhgBtAAhbQAAhZBWhAQBWhAB4AAQB5AABVBAQBVBAABBZQgBAsgSAAQgTAAgngxgAp0BXQAAhZBWhAQBWhAB4AAQB5AABVBAQA7AsASA3QAJAagBAcQABBbhShoQhRhmh5AHQh5AHhZBfQgcAfgUAMQgMAHgJAAQgVAAAAgsg");
	this.shape_804.setTransform(549.6,452.9767);

	this.shape_805 = new cjs.Shape();
	this.shape_805.graphics.f("#232323").s().p("AIoBRQhNhdh3gOQh4gNhfBqQhgBsAAhZQAAhZBWg/QBWg/B4AAQB5AABVA/QBVA/ABBZQgBAsgSAAQgTAAgngxgAp0BWQAAhZBWg/QBWg/B4AAQB5AABVA/QA7AsASA3QAJAZgBAcQABBZhShmQhRhlh5AHQh5AGhZBfQgcAegUAMQgMAHgIAAQgWAAAAgrg");
	this.shape_805.setTransform(549.6,452.7017);

	this.shape_806 = new cjs.Shape();
	this.shape_806.graphics.f("#232323").s().p("AIoBQQhNhch3gNQh4gNhfBpQhgBqAAhYQAAhXBWg/QBWg+B4AAQB5AABVA+QBVA/ABBXQgBArgSAAQgTAAgngwgAp0BVQAAhXBWg/QBWg+B4AAQB5AABVA+QA7ArASA2QAJAZgBAcQABBYhShlQhRhkh5AHQh5AHhZBdQgcAegUAMQgMAHgIAAQgWAAAAgrg");
	this.shape_806.setTransform(549.6,452.4142);

	this.shape_807 = new cjs.Shape();
	this.shape_807.graphics.f("#232323").s().p("AIoBPQhNhah3gOQh4gNhfBoQhgBpAAhXQAAhWBWg+QBWg9B4AAQB5AABVA9QBVA+ABBWQgBAqgSAAQgTAAgngvgAp0BUQAAhWBWg+QBWg9B4AAQB5AABVA9QA7ArASA1QAJAZgBAbQABBXhShjQhRhjh5AHQh5AGhZBcQgcAegUALQgMAHgJAAQgVAAAAgqg");
	this.shape_807.setTransform(549.6,452.1392);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_716},{t:this.shape_715}]},485).to({state:[{t:this.shape_718},{t:this.shape_717}]},1).to({state:[{t:this.shape_720},{t:this.shape_719}]},1).to({state:[{t:this.shape_722},{t:this.shape_721}]},1).to({state:[{t:this.shape_724},{t:this.shape_723}]},1).to({state:[{t:this.shape_726},{t:this.shape_725}]},1).to({state:[{t:this.shape_728},{t:this.shape_727}]},1).to({state:[{t:this.shape_730},{t:this.shape_729}]},1).to({state:[{t:this.shape_732},{t:this.shape_731}]},1).to({state:[{t:this.shape_734},{t:this.shape_733}]},1).to({state:[{t:this.shape_736},{t:this.shape_735}]},1).to({state:[{t:this.shape_738},{t:this.shape_737}]},1).to({state:[{t:this.shape_740},{t:this.shape_739}]},1).to({state:[{t:this.shape_742},{t:this.shape_741}]},1).to({state:[{t:this.shape_744},{t:this.shape_743}]},1).to({state:[{t:this.shape_746},{t:this.shape_745}]},1).to({state:[{t:this.shape_748},{t:this.shape_747}]},1).to({state:[{t:this.shape_750},{t:this.shape_749}]},1).to({state:[{t:this.shape_752},{t:this.shape_751}]},1).to({state:[{t:this.shape_754},{t:this.shape_753}]},1).to({state:[{t:this.shape_756},{t:this.shape_755}]},1).to({state:[{t:this.shape_758},{t:this.shape_757}]},1).to({state:[{t:this.shape_760},{t:this.shape_759}]},1).to({state:[{t:this.shape_762},{t:this.shape_761}]},1).to({state:[{t:this.shape_764},{t:this.shape_763}]},1).to({state:[{t:this.shape_766},{t:this.shape_765}]},1).to({state:[{t:this.shape_768},{t:this.shape_767}]},1).to({state:[{t:this.shape_770},{t:this.shape_769}]},1).to({state:[{t:this.shape_772},{t:this.shape_771}]},1).to({state:[{t:this.shape_774},{t:this.shape_773}]},1).to({state:[{t:this.shape_776},{t:this.shape_775}]},1).to({state:[{t:this.shape_778},{t:this.shape_777}]},1).to({state:[{t:this.shape_780},{t:this.shape_779}]},1).to({state:[{t:this.shape_781}]},1).to({state:[{t:this.shape_782}]},1).to({state:[{t:this.shape_783}]},1).to({state:[{t:this.shape_784}]},1).to({state:[{t:this.shape_785}]},1).to({state:[{t:this.shape_786}]},1).to({state:[{t:this.shape_787}]},1).to({state:[{t:this.shape_788}]},1).to({state:[{t:this.shape_789}]},1).to({state:[{t:this.shape_790}]},1).to({state:[{t:this.shape_791}]},1).to({state:[{t:this.shape_792}]},1).to({state:[{t:this.shape_793}]},1).to({state:[{t:this.shape_794}]},1).to({state:[{t:this.shape_795}]},1).to({state:[{t:this.shape_796}]},1).to({state:[{t:this.shape_797}]},1).to({state:[{t:this.shape_798}]},1).to({state:[{t:this.shape_799}]},1).to({state:[{t:this.shape_800}]},1).to({state:[{t:this.shape_801}]},1).to({state:[{t:this.shape_802}]},1).to({state:[{t:this.shape_803}]},1).to({state:[{t:this.shape_804}]},1).to({state:[{t:this.shape_805}]},1).to({state:[{t:this.shape_806}]},1).to({state:[{t:this.shape_807,p:{y:452.1392}}]},1).to({state:[{t:this.shape_807,p:{y:443.7392}}]},1).to({state:[]},1).wait(762));

	// Каркас_11
	this.shape_808 = new cjs.Shape();
	this.shape_808.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQgBBkhGBFQhFBIhkgBQhjABhGhIQhGhFAAhkQAAhiBGhHQBGhFBjgBQBjABBGBFQBGBHABBig");
	this.shape_808.setTransform(521.6,475.9007);

	this.shape_809 = new cjs.Shape();
	this.shape_809.graphics.f("#FFFFFF").s().p("ADRDRQgbgQgYgXQhGhHAAhjQAAhiBGhHQBGhFBkgBQBjAABHBGQBGBGAABjIAAAEQgCBhhEBFQhHBGhjAAQhCAAg1gfgAlHDwQhkABhGhIQhGhFAAhkQAAhiBGhHQBGhFBkgBQBjABBGBFQBGBHABBiQgBBkhGBFQhEBHhjAAIgCAAg");
	this.shape_809.setTransform(554.425,475.925);

	this.shape_810 = new cjs.Shape();
	this.shape_810.graphics.f("#232323").s().p("EAGqAkBQihgnidg3QhUgehXATQg0ANg0AHQjCAbjCAYQkdAlkhARIgSACQnBAcm6hSQi9gjilhfIgegSQhTg4g3hRQgtg/gIhOIgHhFQgYlEBDk9QBCk1DVjkQAlgmAfgtQCCi2C2iFIDDiMQBag+Bag3QGnkGHkh0QBpgaBrgUQCLgaCNgQQAwgGAvgCQATjGAsjCIAFgYQBunMCCnHQBBjlB+jGQBTiACMAtQAyAQAjApQBGBVANBuQAYC7AqC4QAzDaCHCwQCtiZDTBFIAjANQAdAMAbAQQAVguAYgrQBqjDCbijQBThZBMhfQBpiDCeAeQAtAIAdAkQBbB0gNCVQgCAUAAAVIAAAGQAHFIgZFIQgIBZgWBWQBbBbAwB2IAIAWQAXA9APBCQA1DwgKD3QgIDRhdC9QhVCtiYB2IgYAQQAyCaANChIAUD0QAUDggODiQgMDBhUCqQgUAoggAeQgtArg1AlQgvAfgzAVQgcAMgdAKQjbAwjRhTIgNgHQhmByiIBEQhLAkhVABIg2ABQlCAAk3hOgAbDpyQhkAAhGBGQhHBGABBkQgBBjBHBGQAXAXAcARQA0AeBCABQBkgBBGhGQBEhEAChhIABgEQgBhkhGhGQhGhGhiAAIgBAAgATcjZQBGhFAAhlQAAhihGhIQhHhFhjgBQhjABhHBFQhGBHAABjQABBlBFBFQBHBHBjgBQBkABBGhHg");
	this.shape_810.setTransform(414.1788,514.6779);

	this.shape_811 = new cjs.Shape();
	this.shape_811.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhGhGAAhkQAAhjBGhGQBGhGBjAAQBkAABFBGQBHBGAABjg");
	this.shape_811.setTransform(521.6,475.95);

	this.shape_812 = new cjs.Shape();
	this.shape_812.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhGgBhkQAAhiBGhHQBGhGBkAAQBjAABHBGQBGBGAABjQAAAAAAABQAAABAAAAQAAABAAAAQAAABAAAAQgDBhhDBFQhGBFhkABQhCAAg1gfgAnxCqQhGhGAAhkQAAhiBGhHQBGhGBkAAQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_812.setTransform(554.425,475.95);

	this.shape_813 = new cjs.Shape();
	this.shape_813.graphics.f("#232323").s().p("EAGqAkBQihgnidg3QhUgehXATQg0ANg0AHQjCAbjCAYQkdAlkiARIgRACQnBAcm6hSQi8gjimhfIgegSQhTg4g3hRQgshAgJhNIgHhFQgYlEBDk9QBCk2DWjkQAkgmAfgsQCCi2C2iFIDEiNQBYg9Bbg3QGnkGHih5QBpgZBrgUQCLgZCNgPQAvgHAwgBQATjHAtjBIAFgYQBvnMCHnHQBDjkB/jFQBUiACLAuQAzAQAiAqQBFBVANBuQAXC7AoC4QAxDbCGCxQCuiYDSBDIAjANQAdAMAaANQAVguAagnQBqjCCdifQBUhYBNheQBqiDCeAfQAtAJAdAkQBaB0gPCVIgEAjIAAAGQAGFIgaFBQgIBZgWBWQBbBbAwB2IAIAWQAXA9APBCQA1DwgKD3QgJDRhcC9QhVCtiXB2IgZAQQAzCaAMChIAUD0QAVDggPDiQgMDBhUCqQgUAoggAeQgtArg1AlQgvAfgzAVQgcAMgdAKQjbAwjRhTIgNgHQhmByiIBEQhLAkhVABIg2ABQlCAAk3hOgAYZosQhHBGABBkQAABkBGBFQAYAYAbAQQA1AfBCAAQBkgBBFhGQBEhEADhhQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABAAQgBhkhGhGQhGhGhjAAQhkAAhGBGgAOIosQhGBGAABkQABBkBFBFQBHBHBjAAQBkAABGhHQBGhFAAhkQAAhkhGhGQhGhGhkAAQhjAAhHBGg");
	this.shape_813.setTransform(414.1966,514.6939);

	this.shape_814 = new cjs.Shape();
	this.shape_814.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhGgBhkQAAhiBGhHQBGhGBkAAQBjAABHBGQBGBHAABiIAAAEQgCBihEBEQhGBGhkAAQhCAAg1gfgAnxCqQhGhGAAhkQAAhiBGhHQBGhGBkAAQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_814.setTransform(554.425,475.95);

	this.shape_815 = new cjs.Shape();
	this.shape_815.graphics.f("#232323").s().p("EAGqAkBQihgoidg3QhUgehXATQg0AOg0AHQjCAajCAYQkdAlkiASIgRABQnBAcm6hRQi8gjimhfIgegTQhTg3g3hRQgshBgJhNIgHhFQgYlEBDk8QBCk3DWjjQAkgmAfgtQCCi2C2iFIDEiMQBYg9Bbg4QGnkFHfh9QBpgaBrgTQCMgYCNgPQAvgHAvgBQAVjGAtjCIAGgXQBwnMCLnIQBEjkCBjEQBUh+CMAuQAyAQAiArQBFBVAMBvQAWC7AnC4QAvDbCFCyQCviWDQBBIAjANQAdANAZAIQAVgtAbgkQBrjCCgiZQBVhYBNheQBriBCeAgQAtAIAcAlQBaB1gQCVQgDAUgEAIIAAAGQAFFIgbE7QgIBZgWBWQBbBbAwB1IAIAWQAXA9APBDQA1DwgKD2QgIDRhdC+QhUCsiYB2IgZAQQAzCaAMCiIAUD0QAVDfgPDiQgMDChUCqQgUAoggAdQgtAsg1AkQgvAggzAVQgcAMgdAJQjbAwjRhSIgNgHQhmBxiIBEQhLAkhVACIg2AAQlCAAk3hNgAYZotQhGBHAABjQAABkBGBGQAYAYAbAPQA1AfBCAAQBkAABFhGQBFhEAChhIAAgFQAAhjhHhHQhGhGhjAAQhkABhGBFgAOIotQhGBHAABjQABBkBFBGQBHBGBjAAQBkAABGhGQBGhGAAhkQAAhjhGhHQhGhGhkAAQhjABhHBFg");
	this.shape_815.setTransform(414.1966,514.7136);

	this.shape_816 = new cjs.Shape();
	this.shape_816.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhGgBhkQAAhiBGhHQBHhGBjAAQBjAABHBGQBGBHAABiIAAAEQgCBihEBEQhGBGhkAAQhCAAg1gfgAnxCqQhGhGAAhkQAAhiBGhHQBGhGBkAAQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_816.setTransform(554.425,475.95);

	this.shape_817 = new cjs.Shape();
	this.shape_817.graphics.f("#232323").s().p("EAGpAkBQihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QGnkFHdiCQBpgYBrgTQCLgYCNgPQAwgGAvgBQAVjGAujCIAGgXQBynLCOnJQBHjjCCjEQBVh+CLAwQAyAQAiArQBEBWALBvQAVC7AlC4QAuDcCECzQCwiVDPA/IAiANQAeAMAYAGQAVgtAcggQBrjCCkiUQBVhXBOhdQBriBCeAhQAtAJAcAlQBZB1gRCVQgDAUgGABIAAAGQAEFIgdE1QgGBZgYBWQBdBbAuB1IAJAWQAXA+APBCQA1DwgKD2QgIDRhdC+QhVCsiYB2IgYAQQAyCaANCiIAUD0QAUDfgODiQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg1AAQlDAAk3hNgAYYotQhGBHAABjQABBkBFBGQAYAYAbAPQA1AfBCAAQBkAABGhGQBEhEAChhIAAgFQAAhjhGhHQhHhGhjAAQhjABhHBFgAOIotQhGBHAABjQAABkBGBGQBGBGBkAAQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFg");
	this.shape_817.setTransform(414.2196,514.7267);

	this.shape_818 = new cjs.Shape();
	this.shape_818.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhGhFAAhlQAAhiBGhHQBGhFBjgBQBkAABFBGQBHBGAABjg");
	this.shape_818.setTransform(521.6,475.95);

	this.shape_819 = new cjs.Shape();
	this.shape_819.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhGgBhkQAAhiBGhHQBHhGBjAAQBkAABGBGQBGBHAABiIAAAEQgCBihEBEQhGBGhkAAQhCAAg1gfgAnxCqQhGhFAAhlQAAhiBGhHQBGhFBkgBQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_819.setTransform(554.425,475.95);

	this.shape_820 = new cjs.Shape();
	this.shape_820.graphics.f("#232323").s().p("EAGpAkBQihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QGnkFHaiGQBpgYBsgTQCLgYCNgOQAwgGAvAAQAWjHAujBIAGgXQB0nLCTnJQBHjjCEjCQBWh+CLAwQAxASAiAqQBEBXAKBvQATC7AlC5QAsDcCCCzQCxiTDOA9IAiANQAeANAXACQAVgtAdgdQBtjBCmiPQBVhWBPhdQBtiACdAiQAtAKAcAkQBXB2gRCVQgDAUgJgFIAAAGQADFIgeEuQgGBZgYBWQBdBbAuB1IAJAXQAXA9APBCQA1DxgKD1QgIDRhdC+QhVCsiYB2IgYAQQAyCaANCiIAUD0QAUDfgODiQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg1AAQlDAAk3hNgAYYotQhGBHAABjQABBkBFBGQAYAYAbAPQA1AfBCAAQBkAABGhGQBEhEAChhIAAgFQAAhjhGhHQhGhGhkAAQhjABhHBFgAOIotQhGBHAABjQAABlBGBFQBGBGBkAAQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFg");
	this.shape_820.setTransform(414.2196,514.7279);

	this.shape_821 = new cjs.Shape();
	this.shape_821.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhGhFAAhlQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBGAABjg");
	this.shape_821.setTransform(521.6,475.95);

	this.shape_822 = new cjs.Shape();
	this.shape_822.graphics.f("#FFFFFF").s().p("ADRDRQgbgQgYgXQhFhGgBhkQAAhiBGhHQBHhGBjAAQBkAABGBGQBGBHAABiIAAAEQgCBihEBEQhGBGhkAAQhCAAg1gfgAnxCqQhGhFAAhlQAAhiBGhHQBGhFBkgBQBkABBFBFQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_822.setTransform(554.425,475.95);

	this.shape_823 = new cjs.Shape();
	this.shape_823.graphics.f("#232323").s().p("EAGpAkAQihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgSQhTg4g4hRQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QGnkGHYiKQBqgYBqgSQCMgXCNgOQAwgGAvAAQAWjGAwjBIAGgYQB1nKCXnKQBJjiCFjBQBXh9CKAxQAzASAgAqQBDBXAKBvQASC8AjC5QAqDcCCC0QCyiTDMA9IAiANQAeANAWgBQAVguAegYQBtjCCpiKQBXhVBPhcQBtiACeAjQAsAKAcAlQBXB4gTCUQgDATgLgLIAAAGQABFIgeEnQgGBagYBVQBdBcAuB1IAJAWQAXA9APBCQA1DxgKD2QgIDShdC8QhVCuiYB1IgYAQQAyCaANChIAUD0QAUDggODiQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg1ABQlDAAk3hOgAYYotQhGBGAABkQABBkBFBFQAYAYAbAQQA1AfBCAAQBkAABGhHQBEhEAChhIAAgEQAAhkhGhGQhGhGhkAAQhjAAhHBGgAOIotQhGBHAABjQAABkBGBFQBGBHBkAAQBkAABFhHQBHhFAAhkQAAhkhHhGQhFhFhkgBQhkABhGBFg");
	this.shape_823.setTransform(414.2196,514.762);

	this.shape_824 = new cjs.Shape();
	this.shape_824.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhFBHhkAAQhjABhGhIQhGhFAAhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBGAABjg");
	this.shape_824.setTransform(521.6,475.9507);

	this.shape_825 = new cjs.Shape();
	this.shape_825.graphics.f("#FFFFFF").s().p("AnxCpQhGhFAAhkQAAhiBGhHQBGhFBkgBQBkABBFBFQBHBGAABjQAABkhHBFQhFBHhkAAIgDAAQhiAAhFhHgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBHhGBjAAQBkAABGBGQBGBGAABjIAAAEQgCBhhEBEQhGBHhkAAQhCAAg1gfg");
	this.shape_825.setTransform(554.425,475.9507);

	this.shape_826 = new cjs.Shape();
	this.shape_826.graphics.f("#232323").s().p("EAGpAkAQihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgSQhTg4g4hRQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QGnkGHWiOQBqgYBqgRQCMgXCNgNQAwgGAvAAQAXjGAwjBIAGgYQB3nJCbnLQBLjiCGjAQBYh9CKAzQAyASAhArQBCBYAJBuQAQC8AiC5QAqDcB/C2QC0iSDKA7IAiAOQAeAMAVgEQAVguAfgVQBujACsiFQBXhVBQhcQBuh+CdAkQAtAKAbAlQBWB4gUCUQgDAUgNgSIAAAGQAAFIgfEgQgGBagYBVQBdBcAuB1IAJAWQAXA9APBCQA1DxgKD2QgIDShdC8QhVCuiYB1IgYAQQAyCaANChIAUD0QAUDhgODhQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg1ABQlDAAk3hOgAOIotQhGBHAABjQAABkBGBFQBGBIBkgBQBkAABFhHQBHhFAAhkQAAhkhHhGQhFhFhkgBQhkABhGBFgAYYotQhGBGAABkQABBkBFBFQAYAYAbAQQA1AfBCAAQBkAABGhHQBEhEAChhIAAgEQAAhkhGhGQhGhGhkAAQhjAAhHBGg");
	this.shape_826.setTransform(414.2196,514.7733);

	this.shape_827 = new cjs.Shape();
	this.shape_827.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhFBIhkgBQhjABhGhIQhGhFAAhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBHAABig");
	this.shape_827.setTransform(521.6,475.9507);

	this.shape_828 = new cjs.Shape();
	this.shape_828.graphics.f("#FFFFFF").s().p("AlHDwQhkABhGhIQhGhFAAhkQAAhiBGhHQBGhFBkgBQBkABBFBFQBHBHAABiQAABkhHBFQhEBHhjAAIgCAAgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBHhGBjAAQBkAABGBGQBGBGAABjIAAAEQgCBhhEBEQhGBHhkAAQhCAAg1gfg");
	this.shape_828.setTransform(554.425,475.9507);

	this.shape_829 = new cjs.Shape();
	this.shape_829.graphics.f("#232323").s().p("EAGpAkAQihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QGnkFHUiTQBpgYBrgQQCMgXCNgMQAwgGAvAAQAYjGAwjBIAHgXQB4nKCfnLQBNjhCHi/QBah8CJAzQAxASAhAsQBCBYAIBvQAPC7AhC6QAnDdB/C2QC0iQDJA5IAiANQAeANAUgHQAVguAggSQBvjACviAQBXhUBQhbQBwh+CdAlQAsALAbAlQBVB4gUCUQgDAVgQgZIAAAGQgBFIggEaQgGBZgYBWQBdBbAuB1IAJAXQAXA9APBCQA1DxgKD1QgIDShdC9QhVCtiYB1IgYAQQAyCbANChIAUD0QAUDggODhQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg1AAQlDAAk3hNgATbjaQBHhGAAhkQAAhihHhIQhFhFhkgBQhkABhGBFQhGBHAABjQAABlBGBFQBGBHBkgBQBkABBFhHgAYYouQhGBHAABjQABBkBFBGQAYAXAbARQA1AeBCAAQBkAABGhGQBEhEAChhIAAgFQAAhjhGhHQhGhGhkAAQhjABhHBFg");
	this.shape_829.setTransform(414.2196,514.8067);

	this.shape_830 = new cjs.Shape();
	this.shape_830.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhFBIhkgBQhjABhGhHQhGhGAAhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBHAABig");
	this.shape_830.setTransform(521.6,475.9507);

	this.shape_831 = new cjs.Shape();
	this.shape_831.graphics.f("#FFFFFF").s().p("AnxCqQhGhGAAhkQAAhiBGhHQBGhFBkgBQBkABBFBFQBHBHAABiQAABkhHBFQhFBIhkgBIgDAAQhiAAhFhGgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBHhGBjAAQBkAABGBGQBGBGAABjIAAAEQgCBhhEBEQhGBHhkAAQhCAAg1gfg");
	this.shape_831.setTransform(554.425,475.9507);

	this.shape_832 = new cjs.Shape();
	this.shape_832.graphics.f("#232323").s().p("EAGpAkAQihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QGnkFHRiXQBqgXBrgRQCMgWCNgMQAwgFAvAAQAYjGAyjBIAGgXQB6nJCknMQBOjgCJi/QBZh7CJA0QAyATAgAsQBBBYAIBvQANC8AgC6QAmDcB9C4QC1iPDIA3IAiAOQAdANAUgLQAVguAhgOQBvjACyh6QBYhUBRhbQBwh9CdAnQAtAKAaAmQBUB5gVCUQgDAUgSggIAAAGQgDFIggEUQgGBZgYBWQBdBbAuB1IAJAXQAXA9APBCQA1DxgKD1QgIDShdC9QhVCtiYB1IgYAQQAyCbANChIAUD0QAUDggODhQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg1AAQlDAAk3hNgAOIotQhGBGAABkQAABkBGBFQBGBHBkgBQBkABBFhHQBHhFAAhlQAAhihHhIQhFhFhkgBQhkABhGBGgAYYouQhGBHAABjQABBkBFBGQAYAXAbARQA1AeBCAAQBkAABGhGQBEhEAChhIAAgFQAAhjhGhHQhGhGhkAAQhjABhHBFg");
	this.shape_832.setTransform(414.2196,514.8294);

	this.shape_833 = new cjs.Shape();
	this.shape_833.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhGhGAAhkQAAhiBGhHQBGhFBjgBQBkAABFBGQBHBHAABig");
	this.shape_833.setTransform(521.6,476);

	this.shape_834 = new cjs.Shape();
	this.shape_834.graphics.f("#FFFFFF").s().p("AnxCqQhGhGAAhkQAAhiBGhHQBGhFBkgBQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGgADSDRQgcgQgYgYQhFhFgBhkQAAhjBGhGQBHhGBjAAQBkAABGBGQBGBGAABjIAAAEQgCBhhEBEQhGBHhkAAQhCAAg0gfg");
	this.shape_834.setTransform(554.425,475.975);

	this.shape_835 = new cjs.Shape();
	this.shape_835.graphics.f("#232323").s().p("EAGpAj/Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgSQhTg4g4hRQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QGnkGHPibQBqgXBrgQQCMgVCNgMQAwgGAvABQAZjGAyjAIAHgXQB8nJCnnMQBPjgCLi+QBbh6CIA1QAxATAgAsQBBBZAGBvQANC7AeC7QAlDcB7C5QC3iODGA2IAiAOQAdANATgPQAVgtAigLQBwi/C1h2QBYhSBShbQBxh8CcAoQAtAKAaAnQBUB5gXCTQgDAVgUgmIAAAGQgDFIgiEMQgGBagYBVQBdBcAuB1IAJAWQAXA9APBCQA1DxgKD2QgIDShdC8QhVCuiYB1IgYAQQAyCaANChIAUD0QAUDhgODhQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg1ABQlDAAk3hOgAOIouQhGBHAABjQAABkBGBGQBGBGBkAAQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFgAYYouQhGBGAABkQABBkBFBFQAYAYAcAQQA0AfBCAAQBkAABGhHQBEhEAChhIAAgEQAAhkhGhGQhGhGhkAAQhjAAhHBGg");
	this.shape_835.setTransform(414.2196,514.8744);

	this.shape_836 = new cjs.Shape();
	this.shape_836.graphics.f("#FFFFFF").s().p("ADSDRQgcgPgYgYQhFhGgBhkQAAhiBGhHQBHhFBjgBQBkAABGBGQBGBGAABjIAAAEQgCBhhEBFQhGBGhkAAQhCAAg0gfgAnxCqQhGhGAAhkQAAhiBGhHQBGhFBkgBQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_836.setTransform(554.425,475.975);

	this.shape_837 = new cjs.Shape();
	this.shape_837.graphics.f("#232323").s().p("EAGpAj/Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgSQhTg4g4hRQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QGnkGHNifQBqgXBrgQQCMgVCOgLQAvgFAvABQAajGAzjAIAGgXQB+nICrnNQBRjgCMi8QBbh6CJA2QAxAUAgAsQA/BZAGBvQALC8AdC6QAjDeB7C5QC4iNDEA0IAiAOQAcANATgSQAVgtAjgHQBxi/C3hwQBahTBRhZQByh8CcApQAtAMAaAmQBTB5gYCUQgCAKgLgXQgJgOgDACIAAAGQgCCkgMCDIgZEoQgGBYgYBXQBdBbAuB1IAJAWQAXA9APBDQA1DwgKD2QgIDRhdC+QhVCsiYB2IgYAQQAyCaANCiIAUD0QAUDfgODiQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg1ABQlDAAk3hOgAYYouQhGBHAABjQABBkBFBGQAYAYAcAPQA0AfBCAAQBkAABGhGQBEhFAChhIAAgEQAAhkhGhGQhGhGhkAAQhjABhHBFgAOIouQhGBHAABjQAABkBGBGQBGBGBkAAQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFg");
	this.shape_837.setTransform(414.2196,514.8962);

	this.shape_838 = new cjs.Shape();
	this.shape_838.graphics.f("#FFFFFF").s().p("ADSDRQgcgPgYgYQhFhGgBhkQAAhiBGhHQBHhFBjgBQBkAABGBGQBGBHAABiIAAAEQgCBhhEBFQhGBGhkAAQhCAAg0gfgAnxCqQhGhGAAhkQAAhiBGhHQBGhFBkgBQBkAABFBGQBHBHAABiQAABkhHBGQhFBGhkAAQhkAAhGhGg");
	this.shape_838.setTransform(554.425,475.975);

	this.shape_839 = new cjs.Shape();
	this.shape_839.graphics.f("#232323").s().p("EAGpAj/Qihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QDTiDDWh6QDZhzDwg5QBqgWBrgQQCNgUCNgLQAvgFAvABQAbjFAzjBIAHgXQB/nICvnMQBUjgCMi7QBdh5CHA3QAxAUAgAsQA/BaAFBvQAKC8AbC6QAiDeB5C6QC5iMDCAzIAjAOQAcANASgVQAVguAkgDQByi+C5hrQBahSBThZQBzh6CcApQArAMAbAmQBSB6gZCUQgCAKgNgaQgJgRgDABIgBAHQgCCjgNCAIgZEkQgGBZgYBWQBdBbAuB2IAJAWQAXA9APBCQA1DwgKD3QgIDRhdC9QhVCtiYB2IgYAQQAyCaANChIAUD0QAUDggODhQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg1AAQlDAAk3hNgAYYouQhGBGAABkQABBkBFBFQAYAYAcAQQA0AfBCAAQBkAABGhHQBEhEAChhIAAgEQAAhkhGhGQhGhHhkAAQhjABhHBGgAOIouQhGBHAABjQAABkBGBFQBGBHBkAAQBkAABFhHQBHhFAAhkQAAhkhHhGQhFhGhkAAQhkAAhGBGg");
	this.shape_839.setTransform(414.2196,514.92);

	this.shape_840 = new cjs.Shape();
	this.shape_840.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhGhFAAhlQAAhiBGhHQBGhFBjgBQBkAABFBGQBHBHAABig");
	this.shape_840.setTransform(521.6,476);

	this.shape_841 = new cjs.Shape();
	this.shape_841.graphics.f("#FFFFFF").s().p("ADSDRQgcgPgYgZQhFhFgBhkQAAhiBGhHQBHhFBjgBQBkAABGBGQBGBHAABiIAAAFQgCBghEBEQhGBHhkAAQhCAAg0gfgAnxCpQhGhFAAhkQAAhiBGhHQBGhFBkgBQBkAABFBGQBHBHAABiQAABkhHBFQhFBHhkAAQhkAAhGhHg");
	this.shape_841.setTransform(554.425,475.9998);

	this.shape_842 = new cjs.Shape();
	this.shape_842.graphics.f("#232323").s().p("EAGpAj+Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgSQhTg4g4hRQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QDTiDDVh9QDYh1Dwg5QBqgWBrgPQCNgUCNgKQAvgFAvABQAbjGA1i/IAGgXQCBnHC0nOQBUjeCOi7QBdh4CIA4QAxAUAfAsQA/BaAEBwQAIC7AbC7QAfDeB4C7QC6iKDBAxIAiAOQAeANAQgZQAVgtAlAAQByi9C9hmQBahSBThYQB1h6CbArQArAMAbAmQBQB7gZCUQgCAKgOgeQgKgTgEABIAAAGQgDCjgNB9IgaEhQgGBZgYBWQBdBbAuB1IAJAWQAXA9APBDQA1DwgKD2QgIDRhdC+QhVCsiYB2IgYAQQAyCaANCiIAUD0QAUDfgODiQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg1ABQlDAAk3hOgAbCp1QhjABhHBFQhGBHAABjQABBkBFBGQAYAYAcAPQA0AfBCAAQBkAABGhGQBEhEAChhIAAgFQAAhjhGhHQhFhGhjAAIgCAAgAOIovQhGBHAABjQAABlBGBFQBGBGBkAAQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFg");
	this.shape_842.setTransform(414.2196,514.9635);

	this.shape_843 = new cjs.Shape();
	this.shape_843.graphics.f("#FFFFFF").s().p("ADSDRQgcgQgYgYQhFhFgBhkQAAhiBGhHQBHhGBjAAQBkAABGBGQBGBHAABiIAAAEQgCBhhEBEQhGBHhkAAQhCAAg0gfgAnxCpQhGhFAAhkQAAhiBGhHQBGhFBkgBQBkAABFBGQBHBHAABiQAABkhHBFQhFBHhkAAQhkAAhGhHg");
	this.shape_843.setTransform(554.425,476);

	this.shape_844 = new cjs.Shape();
	this.shape_844.graphics.f("#232323").s().p("EAGpAj+Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgTQhTg2g4hSQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QDUiDDTiAQDXh2Dwg5QBqgWBrgOQCNgUCNgKQAwgEAvABQAcjFA0jAIAHgXQCCnHC4nNQBWjeCPi6QBfh4CHA5QAxAVAeAsQA+BbAEBvQAHC8AZC7QAeDeB3C8QC6iJDAAvIAiAOQAdANAQgcQAVgtAmAEQByi9DAhhQBbhQBUhYQB1h6CaAsQAtANAZAmQBQB8gbCTQgCAKgOghQgLgWgEAAIAAAGQgECkgOB6IgaEdQgGBZgYBWQBdBbAuB1IAJAWQAXA+APBCQA1DwgKD2QgIDRhdC+QhVCsiXB2IgZAQQAyCaANCiIAUD0QAVDfgPDiQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg1ABQlDAAk3hOgAYYovQhGBHAABjQABBkBFBGQAYAYAcAPQA0AfBCAAQBkAABGhGQBEhEAChhIAAgFQAAhjhGhHQhGhGhkAAQhjABhHBFgAOIovQhGBHAABjQAABlBGBFQBGBGBkAAQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFg");
	this.shape_844.setTransform(414.2196,514.9982);

	this.shape_845 = new cjs.Shape();
	this.shape_845.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhFBHhkAAQhiABhHhIQhGhFAAhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBGAABjg");
	this.shape_845.setTransform(521.6,476.0007);

	this.shape_846 = new cjs.Shape();
	this.shape_846.graphics.f("#FFFFFF").s().p("AnyCpQhFhFAAhkQAAhiBFhHQBHhFBjgBQBlABBFBFQBGBGAABjQAABkhGBFQhFBHhlAAIgCAAQhhAAhHhHgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBGhGBkAAQBkAABGBGQBGBGAABjIAAAEQgCBhhEBEQhHBHhjAAQhCAAg1gfg");
	this.shape_846.setTransform(554.45,476.0007);

	this.shape_847 = new cjs.Shape();
	this.shape_847.graphics.f("#232323").s().p("EAGpAj9Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgTQhTg2g4hSQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3IGmkFQDWh4Dwg6QBqgVBrgOQCNgTCNgJQAwgFAvABQAcjFA2i/IAGgXQCEnGC8nOQBYjdCRi5QBeh3CHA6QAxAUAeAtQA9BbADBvQAGC9AYC7QAcDeB2C8QC7iHC/AtIAiAOQAcAOAQggQAVgtAnAIQBzi9DChcQBchPBUhYQB1h4CbAtQAtAMAZAoQBPB8gcCSQgCAKgPgkQgMgYgEgBIAAAGQgFCkgOB2IgbEaQgGBZgYBWQBdBbAvB1IAIAXQAXA9APBCQA1DxgKD1QgJDRhcC+QhVCsiXB2IgZAQQAzCaAMCiIAUD0QAVDfgPDiQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg2ABQlCAAk3hOgAOIowQhGBHAABjQAABlBGBFQBHBHBjgBQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhFhkgBQhkABhGBFgAYYowQhGBHAABjQABBkBGBGQAYAYAbAPQA1AfBCAAQBjAABGhGQBEhEAChhIABgFQgBhjhGhHQhGhGhkAAQhjABhHBFg");
	this.shape_847.setTransform(414.2313,515.0516);

	this.shape_848 = new cjs.Shape();
	this.shape_848.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhFBHhkAAQhiABhHhIQhFhFgBhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBGAABjg");
	this.shape_848.setTransform(521.6,476.0007);

	this.shape_849 = new cjs.Shape();
	this.shape_849.graphics.f("#FFFFFF").s().p("AnyCpQhFhFAAhkQAAhiBFhHQBHhFBjgBQBlABBFBFQBGBGAABjQAABkhGBFQhFBHhkAAIgDAAQhhAAhHhHgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBGhGBkAAQBkAABGBGQBGBGAABjIAAAEQgBBhhFBEQhFBHhlAAQhCAAg1gfg");
	this.shape_849.setTransform(554.45,476.0007);

	this.shape_850 = new cjs.Shape();
	this.shape_850.graphics.f("#232323").s().p("EAGpAj9Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgTQhTg2g4hSQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QDUiDDRiFQDWh6Dvg5QBqgVBsgOQCLgSCOgJQAwgEAvABQAdjFA2i/IAHgXQCFnGDBnOQBYjdCTi3QBfh3CHA7QAxAVAdAtQA9BcACBvQAEC8AXC7QAbDeB0C+QC9iGC9ArIAiAPQAcANAPgjQAVgtAoAMQB0i9DEhWQBchQBVhWQB3h3CaAuQAsANAZAnQBOB8gdCTQgCAKgQgoQgNgbgEgBIAAAGQgFCjgPBzQgNB/gNCYQgIBZgWBWQBbBbAwB1IAIAXQAXA9APBCQA1DxgKD1QgIDShdC9QhUCtiYB1IgZAQQAzCbAMChIAUD0QAVDfgPDiQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg2ABQlCAAk3hOgAOIowQhGBHAABkQABBkBFBFQBHBHBjgBQBkAABFhGQBHhGAAhkQAAhjhHhHQhFhFhkgBQhkABhGBFgAYYowQhGBHAABjQABBkBGBGQAYAXAbARQA1AeBCAAQBkAABFhGQBFhEAChhIAAgFQAAhjhHhHQhGhGhkAAQhjABhHBFg");
	this.shape_850.setTransform(414.2313,515.0964);

	this.shape_851 = new cjs.Shape();
	this.shape_851.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhGBFQhGBIhkgBQhiABhHhHQhFhGgBhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBHAABig");
	this.shape_851.setTransform(521.6,476.0007);

	this.shape_852 = new cjs.Shape();
	this.shape_852.graphics.f("#FFFFFF").s().p("AnxCqQhFhGgBhkQAAhiBFhHQBHhFBjgBQBlABBFBFQBGBHAABiQAABkhGBFQhFBIhkgBIgDAAQhhAAhGhGgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBGhGBkAAQBkAABGBGQBGBGAABjIAAAEQgBBhhFBEQhFBHhlAAQhCAAg1gfg");
	this.shape_852.setTransform(554.45,476.0007);

	this.shape_853 = new cjs.Shape();
	this.shape_853.graphics.f("#232323").s().p("EAGpAj9Qihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QDUiDDQiHQDVh8Dvg5QBqgUBsgOQCMgSCNgIQAwgEAvABQAejFA3i/IAGgXQCHnFDFnOQBajcCUi3QBgh2CGA8QAxAVAdAuQA8BcACBvQADC8AVC7QAaDfByC+QC9iEC8ApIAiAOQAdAPAOgnQAVguApAQQA6heBWgzICrh8QBdhPBWhWQB2h2CbAvQAsANAYAnQBOB+geCSQgCAKgSgrQgNgdgEgDIAAAGQgGCkgPBvQgOB8gNCXQgIBagWBVQBbBcAwB1IAIAWQAXA9APBCQA2DxgLD2QgIDShdC8QhUCuiYB1IgZAQQAzCaAMChIAUD0QAVDhgPDgQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg2AAQlCAAk3hNgAOIowQhGBHAABjQABBkBFBGQBHBHBjgBQBkABBGhIQBGhFAAhkQAAhjhHhHQhFhFhkgBQhkABhGBFgAYYowQhGBGAABkQABBkBGBFQAYAYAbAQQA1AfBCAAQBkAABFhHQBFhEAChhIAAgEQAAhkhHhGQhGhGhkAAQhjAAhHBGg");
	this.shape_853.setTransform(414.2446,515.1295);

	this.shape_854 = new cjs.Shape();
	this.shape_854.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQABBkhHBFQhGBHhkAAQhiAAhHhHQhFhFgBhkQAAhjBGhGQBGhGBjAAQBkAABFBFQBHBIAABig");
	this.shape_854.setTransform(521.6007,476.0502);

	this.shape_855 = new cjs.Shape();
	this.shape_855.graphics.f("#FFFFFF").s().p("AlHDwQhjAAhHhGQhFhGgBhkQAAhiBFhHQBHhFBjgBQBlAABFBGQBGBHAABiQABBkhHBFQhFBHhjAAIgBAAgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBGhGBkAAQBkAABGBGQBGBGAABjIAAAEQgBBhhFBEQhFBHhlAAQhCAAg1gfg");
	this.shape_855.setTransform(554.45,476.0252);

	this.shape_856 = new cjs.Shape();
	this.shape_856.graphics.f("#232323").s().p("EAGpAj8Qihgnicg3QhUgehYATQgzANg1AHQjCAbjBAYQkeAlkhARIgSACQnBAcm6hSQi8gjimhfIgdgTQhTg2g4hSQgshAgIhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QDUiDDPiKQDUh+Dvg5QBqgUBsgNQCMgSCOgHQAvgFAvACQAfjFA3i+IAHgXQCInEDJnPQBdjcCUi1QBhh2CGA9QAwAWAeAtQA7BdAABvQADC8ATC8QAYDfBxC+QC/iDC6AoIAiAOQAcAOAOgpQAVguAqATQA6heBXgxQBTg5Bag/QBdhOBXhVQB4h3CZAxQAtANAYAoQBMB+gfCSQgCAKgSgvQgOgggFgDIAAAGQgGCkgQBsQgOB6gNCWQgHBZgXBWQBcBbAvB1IAIAXQAYA9AOBCQA2DxgLD1QgIDShdC9QhUCtiYB1IgZAQQAzCbAMChIAUD0QAVDggPDhQgMDBhVCqQgUAogfAeQguArg1AlQguAfgzAVQgdAMgdAKQjbAwjQhTIgNgHQhmByiJBEQhLAkhVABIg2ABQlCAAk3hOgAOIowQhGBGAABkQABBkBFBFQBHBHBjAAQBkAABGhHQBHhFgBhlQAAhihHhIQhFhFhkAAQhkAAhGBGgAYYoxQhGBHAABjQABBkBGBGQAYAXAbARQA1AeBCAAQBkAABFhGQBFhEAChhIAAgFQAAhjhHhHQhGhGhkAAQhjABhHBFg");
	this.shape_856.setTransform(414.2446,515.1846);

	this.shape_857 = new cjs.Shape();
	this.shape_857.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhGBGQhGBGhkAAQhiAAhHhGQhFhGgBhkQAAhiBGhHQBGhGBjAAQBkAABFBGQBHBGAABjg");
	this.shape_857.setTransform(521.65,476.05);

	this.shape_858 = new cjs.Shape();
	this.shape_858.graphics.f("#FFFFFF").s().p("AnxCqQhGhGAAhkQAAhiBFhHQBHhFBjgBQBkAABGBGQBGBHABBiQAABkhHBGQhFBGhkAAQhkAAhGhGgADRDRQgbgQgYgYQhFhFgBhkQAAhjBGhGQBGhGBkAAQBkAABGBGQBGBGAABjIAAAEQgCBhhEBEQhGBHhkAAQhCAAg1gfg");
	this.shape_858.setTransform(554.475,476.025);

	this.shape_859 = new cjs.Shape();
	this.shape_859.graphics.f("#232323").s().p("EAGpAj8Qihgoicg3QhUgehYATQgzAOg1AHQjCAajBAYQkeAlkhASIgSABQnBAcm6hRQi8gjimhfIgdgTQhTg3g4hRQgshBgIhNIgHhFQgYlEBDk8QBCk3DVjjQAkgmAfgtQCCi2C3iFIDDiMQBZg9Bbg4QDUiDDOiNQDTh/Dvg5QBrgUBrgMQCNgRCNgIQAwgDAuABQAgjEA4i/IAHgXQCKnDDNnQQBejaCVi1QBjh1CFA+QAwAXAdAtQA6BdAABvQAAC9ATC7QAXDfBwDAQC/iDC5AnIAiAOQAcAOANgtQAKgXAUALQASACAPgNQA7hdBYgvQBUg3Bbg+QBehNBXhVQB5h1CZAxQArAOAZAoQBMB+ghCSQgCAKgTgyQgOgigFgEIAAAGQgHCjgQBpQgOB3gOCVQgHBagXBVQBcBcAvB1IAIAWQAYA9AOBCQA2DxgLD2QgIDShdC8QhUCuiYB1IgZAQQAzCaAMChIAUD0QAVDhgPDgQgMDChVCqQgUAogfAdQguAsg1AkQguAggzAVQgdAMgdAJQjbAwjQhSIgNgHQhmBxiJBEQhLAkhVACIg2AAQlCAAk3hNgAOIoxQhGBHAABjQABBkBFBGQBHBGBjAAQBkAABGhGQBGhGAAhkQAAhjhHhHQhFhGhkAAQhkABhGBFgAYYoxQhGBGABBkQAABkBGBFQAYAYAbAQQA1AfBCAAQBkAABFhHQBFhEAChhIAAgEQAAhkhHhGQhGhGhkAAQhjAAhHBGg");
	this.shape_859.setTransform(414.2446,515.2282);

	this.shape_860 = new cjs.Shape();
	this.shape_860.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhGhFAAhlQAAhiBFhHQBHhFBjgBQBjAABGBGQBGBHABBig");
	this.shape_860.setTransform(521.35,475.6);

	this.shape_861 = new cjs.Shape();
	this.shape_861.graphics.f("#FFFFFF").s().p("AnxCqQhFhFgBhlQAAhiBFhHQBHhFBjgBQBkAABGBGQBHBGAABjQAABkhGBGQhGBGhkAAQhkAAhGhGgADSDRQgcgQgYgXQhGhGAAhkQAAhjBGhGQBHhFBjgBQBkAABGBFQBGBHAABjIAAAEQgCBhhEBEQhGBHhjAAQhCAAg1gfg");
	this.shape_861.setTransform(554.15,475.6);

	this.shape_862 = new cjs.Shape();
	this.shape_862.graphics.f("#232323").s().p("EAGoAkAQihgoicg4QhUgehXATQg0ANg0AHQjCAZjDAXQkdAkkfASIgSABQnCAcm5hSQi8gjimhgIgdgSQhTg4g3hRQgshAgJhNIgHhFQgYlEBEk9QBCk2DWjkQAkglAfgtQCCi2C3iFIDDiMQBZg9BXg2QDTiDDQiLQDVh+Dvg6QBrgUBrgNQCMgSCOgIQAvgEAvABQAejFA3i+IAHgYQCHnEDGnPQBbjbCTi3QBhh2CGA8QAwAVAeAuQA8BcABBvQACC9AVC7QAaDeByC+QC9iEC8ApIAiAPQAdANAOgmQAVguApAQQA6heBWgzICsh7QBchOBWhWQB4h3CaAwQArANAZAnQBNB+geCSQgCAKgRgrQgOgegEgDIAAAGQgGCkgQBuQgOB8gOCWQgGBagYBVQBdBcAvB1IAIAWQAYA9AOBCQA2DwgKD3QgIDRhdC9QhVCtiXB2IgZAQQAzCaAMChIAVD0QAUDhgNDyQgMDBhWCpQgVAogfAeQgtArg2AkQgtAhg0AUIg6AVQjaAvjRhTIgNgHQhlBxiKBDQhLAkhVACIgqAAQlIAAk9hQgAOGo2QhFBHAABjQAABkBGBFQBGBHBkAAQBkAABFhHQBHhFAAhkQgBhkhGhGQhGhGhkAAQhjABhHBFgAYXo2QhGBGAABkQAABkBGBFQAYAXAbARQA1AeBCAAQBkAABFhGQBFhEAChhIAAgFQAAhjhHhHQhFhFhkAAQhkAAhGBGg");
	this.shape_862.setTransform(414.089,515.3275);

	this.shape_863 = new cjs.Shape();
	this.shape_863.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhGBFQhGBHhkAAQhiABhHhIQhFhFgBhkQAAhiBGhHQBHhFBigBQBkABBGBFQBGBGAABjg");
	this.shape_863.setTransform(521.05,475.1507);

	this.shape_864 = new cjs.Shape();
	this.shape_864.graphics.f("#FFFFFF").s().p("AnxCpQhFhFgBhkQAAhiBGhHQBHhFBjgBQBkABBGBFQBGBGAABjQAABkhGBFQhGBHhkAAIgDAAQhhAAhGhHgAFIDvQhCAAg1geQgbgRgYgXQhGhFABhkQAAhjBGhGQBFhGBlAAQBjAABFBFQBHBGAABkIgBADQgBBhhFBEQhFBHhjAAIgBAAg");
	this.shape_864.setTransform(553.85,475.1507);

	this.shape_865 = new cjs.Shape();
	this.shape_865.graphics.f("#232323").s().p("EAGnAkEQihgoicg4QhUgfhXATQg0ANg0AGQjCAZjDAWQkdAkkeAQIgRABQnBAbm6hSQi8gkimheIgdgTQhTg4g3hRQgshAgIhNIgHhFQgYlEBDk9QBDk2DWjjQAkgmAfgtQCDi1C2iFIDEiMQBZg9BSg0QDTiDDSiJQDXh9Dwg6QBqgVBrgOQCMgUCOgIQAvgEAvABQAdjFA2jAIAGgXQCFnFC+nPQBYjcCRi5QBfh3CHA6QAxAVAeAtQA9BcACBvQAGC8AXC7QAcDeB1C9QC7iHC/AtIAiAOQAcANAPggQAVgtAoAJQBzi9DDhaQBchQBVhXQB1h4CbAuQAsANAZAnQBPB8gcCTQgCAKgQgmQgMgZgEgBIAAAGQgFCkgQB0QgNCAgOCYQgHBZgXBWQBdBbAuB1IAJAWQAXA9APBCQA2DxgKD2QgIDShcC8QhVCuiXB1IgZAQQAzCbANChIAUD0QAVDfgLEFQgODBhWCpQgVAogfAdQguArg1AkQguAhgzAUIg7AUQjaAvjRhVIgNgHQhmByiKBCQhLAkhUABIgjAAQlMAAlAhTgAOFo7QhGBHAABjQABBkBFBFQBHBIBjgBQBkAABGhHQBGhFAAhkQAAhkhGhGQhGhFhkgBQhjABhHBFgAYWo7QhGBGAABkQAABkBFBFQAYAXAcARQA0AeBCAAQBkABBGhIQBEhEAChhIAAgEQAAhkhHhGQhFhFhjAAQhkAAhGBGg");
	this.shape_865.setTransform(413.914,515.3858);

	this.shape_866 = new cjs.Shape();
	this.shape_866.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjABhGhIQhGhFAAhkQAAhiBGhHQBGhFBjgBQBkABBFBFQBHBHAABig");
	this.shape_866.setTransform(520.75,474.7007);

	this.shape_867 = new cjs.Shape();
	this.shape_867.graphics.f("#FFFFFF").s().p("AnxCpQhFhFgBhkQAAhiBGhHQBHhFBjgBQBkABBGBFQBGBHAABiQAABkhGBGQhGBGhkAAIgCAAQhiAAhGhHgADRDRQgbgQgYgYQhGhFABhkQAAhiBGhHQBGhFBkgBQBkAABEBFQBGBGABBkIAAADQgCBhhEBEQhGBHhkAAQhCAAg1geg");
	this.shape_867.setTransform(553.525,474.7007);

	this.shape_868 = new cjs.Shape();
	this.shape_868.graphics.f("#232323").s().p("EAGlAkIQifgoicg5QhVgghXATQgzANg1AGQjCAYjDAWQkdAikcAQIgRABQnBAbm6hTQi8gkimhfIgdgTQhTg3g3hRQgshBgIhNIgHhFQgYlEBEk8QBEk3DWjjQAkglAfgtQCCi2C3iEIDEiMQBZg9BOgyQDTiEDUiGQDXh8Dxg7QBqgVBrgPQCMgUCOgKQAvgEAvABQAcjGA0i/IAHgYQCCnGC2nOQBVjeCPi6QBeh4CHA4QAxAVAeAsQA/BbAEBvQAHC8AaC7QAfDdB3C8QC6iJDBAvIAiAPQAdANAQgaQAVguAmADQBzi+C9hjQBbhRBUhYQBzh6CcAsQAsAMAaAmQBQB7gaCUQgCAKgOgfQgLgVgDABIgBAGQgDCkgQB5IgbEdQgGBagXBWQBcBbAvB1IAJAWQAXA9APBCQA2DwgKD2QgHDShdC9QhUCuiXB1IgZAQQAzCbANChIAVD0QAUDfgJEWQgODBhXCpQgUAoggAdQgvArg1AkQgtAfg0AVQgdALgdAJQjbAujRhVIgMgHQhnBwiKBCQhLAkhVABIgTAAQlUAAlIhWgAOEpBQhGBHAABjQAABlBGBFQBGBHBkgBQBkABBFhHQBHhFAAhkQAAhkhHhGQhFhGhkgBQhkABhGBFgAYUpAQhGBGAABkQgBBjBHBGQAYAYAbAPQA1AfBCAAQBkgBBFhGQBEhEAChhIAAgFQAAhjhHhHQhEhEhkAAQhjAAhHBGg");
	this.shape_868.setTransform(413.7651,515.4767);

	this.shape_869 = new cjs.Shape();
	this.shape_869.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhGBGQhGBGhkAAQhjAAhGhGQhGhGAAhkQAAhiBGhHQBGhFBjgBQBkAABGBGQBGBHAABig");
	this.shape_869.setTransform(520.45,474.3);

	this.shape_870 = new cjs.Shape();
	this.shape_870.graphics.f("#FFFFFF").s().p("AnwCpQhGhFAAhkQgBhjBHhGQBGhGBkAAQBkAABFBGQBGBGAABjQAABkhGBFQhGBHhkAAQhjAAhGhHgADRDRQgbgQgYgYQhGhGABhjQAAhjBGhGQBHhGBjAAQBkAABDBFQBHBGABBjIAAAEQgCBhhFBEQhEBHhlAAQhBAAg2geg");
	this.shape_870.setTransform(553.2,474.3);

	this.shape_871 = new cjs.Shape();
	this.shape_871.graphics.f("#232323").s().p("EAGkAkNQifgqicg5QhUgghYASQgzANg1AGQjDAYjCAUQkdAhkaAQIgSABQnBAam5hTQi8gkimhfIgdgTQhTg4g3hRQgshAgIhOIgHhFQgXlEBEk8QBEk2DWjjQAkgmAfgsQCDi2C3iEIDEiLQBZg9BJgxQDTiEDWiEQDah6Dwg8QBqgXBrgPQCNgVCNgKQAvgFAvAAQAbjFAzjAIAGgXQB/nICvnNQBSjfCNi8QBbh5CJA3QAxATAfAsQA/BaAGBvQAKC8AcC7QAiDdB5C6QC5iMDDAzIAiAOQAdANASgTQAVguAkgEQBxi/C5htQBahRBShaQBzh7CcAqQAsALAaAnQBSB5gYCUQgCAKgMgZQgKgQgDACIAAAGQgDCkgOB/IgbEjQgGBagXBVQBcBcAvB1IAJAWQAXA9APBCQA2DxgJD1QgIDRhcC+QhUCtiXB2IgZAQQAzCbANChIAVD0QAdE4gQDOQgPDChXCoQgVAoggAdQguArg1AjQgvAggzAUQgdALgdAJQjbAtjQhWIgNgHQhnBwiKBCQhMAihUABIgMAAQlYAAlLhXgAOCpGQhGBHAABjQABBkBFBGQBHBGBjAAQBkAABGhGQBGhGAAhkQAAhjhGhHQhGhGhkAAQhjABhHBFgAYTpGQhGBHAABjQgBBkBGBFQAYAYAbAQQA1AeBCAAQBkAABFhHQBFhEABhhIAAgFQAAhjhHhGQhDhFhkAAQhkABhGBFg");
	this.shape_871.setTransform(413.6054,515.5693);

	this.shape_872 = new cjs.Shape();
	this.shape_872.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhFBHhkAAQhjAAhGhHQhFhFgBhkQAAhjBGhGQBHhGBiAAQBkABBGBFQBGBHAABig");
	this.shape_872.setTransform(520.15,473.85);

	this.shape_873 = new cjs.Shape();
	this.shape_873.graphics.f("#FFFFFF").s().p("AnxCpQhFhFAAhkQAAhjBGhGQBGhGBkAAQBkABBFBFQBHBIAABhQAABkhHBFQhGBHhkAAQhjAAhHhHgADSDRQgcgQgYgYQhGhFABhjQAAhjBGhGQBHhGBjgBQBkAABDBEQBHBHAABjIAAADQgBBihEBDQhGBHhkABQhCAAg0geg");
	this.shape_873.setTransform(552.875,473.85);

	this.shape_874 = new cjs.Shape();
	this.shape_874.graphics.f("#232323").s().p("EAGjAkRQifgqicg6QhUgghXASQg1AMg0AGQjDAXjCAUQkeAfkXAQIgSABQnBAZm5hTQi8gkimhgIgdgTQhTg2g3hSQgshBgIhNIgGhFQgXlEBEk8QBEk3DXjiQAkgmAfgsQCDi2C3iEIFhj3QDTiEDYiCQDch5Dxg9QBqgXBrgQQCLgVCOgMQAvgFAvAAQAajGAyjAIAGgXQB8nJCnnMQBQjgCKi9QBah7CJA1QAxATAgAsQBABZAIBvQAMC7AeC7QAlDcB8C5QC2iODHA2IAhAOQAeANATgOQAVgtAigLQBwi/C0h3QBYhTBShaQBxh9CcAoQAtALAaAmQBUB5gXCUQgDATgTgkIgBAGQgDFIgmEJQgHBagXBVQBdBbAvB1IAJAXQAXA9APBCQA2DwgJD2QgHDShcC9QhUCtiYB2IgYAQQAzCaANCiIAWD0QAKBwAHCbQAFCRgIB8QgPDBhYCoQgVAnggAdQgvArg1AjQguAgg0AUIg6AUQjbArjQhWIgNgHQhmBwiMBBQhLAihVABIgIAAQlaAAlMhagAOBpLQhGBGAABkQABBkBEBFQBHBHBkAAQBjAABGhHQBHhFAAhkQAAhjhGhHQhGhFhkgBQhjAAhHBGgAYRpLQhFBHgBBjQgBBjBHBGQAXAYAcAPQA1AfBCAAQBjgBBGhHQBEhEABhhIAAgEQAAhkhHhGQhDhEhjAAQhkABhHBFg");
	this.shape_874.setTransform(413.4502,515.6647);

	this.shape_875 = new cjs.Shape();
	this.shape_875.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhGBGhjAAQhjABhHhIQhFhFAAhkQAAhjBGhGQBGhFBjgBQBkABBFBFQBHBHAABig");
	this.shape_875.setTransform(519.85,473.4007);

	this.shape_876 = new cjs.Shape();
	this.shape_876.graphics.f("#FFFFFF").s().p("AnxCpQhFhFAAhkQAAhjBGhGQBGhFBkgBQBkABBFBFQBHBHAABiQAABkhHBGQhGBGhkAAIgCAAQhiAAhGhHgADRDQQgbgPgYgYQhGhFABhkQAAhiBGhHQBHhFBjgBQBkAABDBEQBGBGABBjIAAAEQgCBhhEBEQhFBHhkAAIgEABQg/AAg0gfg");
	this.shape_876.setTransform(552.575,473.4007);

	this.shape_877 = new cjs.Shape();
	this.shape_877.graphics.f("#232323").s().p("EAGiAkUQifgqicg7QhUghhXASQgzANg1AGQjDAWjCATQkfAfkVAOIgRABQnBAZm6hTQi8glilhfIgegTQhSg4g3hRQgshBgIhNIgGhFQgXlEBFk8QBEk3DXjiQAkgmAfgsQCDi1C3iEIDEiLQBag9A/gtQDTiFDbiAQDch3Dyg+QBpgYBrgQQCNgXCMgMQAwgGAvAAQAYjGAxjAIAGgYQB5nICfnMQBNjhCIi/QBZh8CJAzQAyASAgAsQBCBYAIBvQAPC8AhC5QAnDdB+C2QC1iQDJA6IAiANQAdANAVgHQAVguAggSQBvjACviAQBYhUBQhbQBvh+CdAlQAsALAbAmQBWB3gVCVQgDAUgQgZIAAAGQgBFIgmEVQgHBZgXBWQBdBbAvB1IAJAWQAYA9APBCQA2DwgJD2QgHDRhcC+QhTCuiYB2IgZAQQAzCaAOChIAVD0QALBwAICkQAGCYgIB9QgQDChZCnQgVAnggAdQgvArg1AjQgvAggzATQgdAMgeAIQjbArjPhXIgNgIQhoBwiLBBQhLAihVAAQlegBlQhcgAOApRQhGBGAABkQAABkBFBFQBHBIBjgBQBkAABGhGQBHhGAAhkQAAhjhHhHQhFhFhkgBQhkABhGBFgAYQpRQhGBHAABjQgBBkBGBFQAYAYAbAPQA1AfBCgBQBkAABFhHQBEhEAChhIAAgFQgBhjhGhGQhDhEhkAAQhjABhHBFg");
	this.shape_877.setTransform(413.2953,515.8047);

	this.shape_878 = new cjs.Shape();
	this.shape_878.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhHQhGhFAAhkQAAhiBGhHQBHhGBiAAQBkAABGBGQBGBHAABig");
	this.shape_878.setTransform(519.55,473);

	this.shape_879 = new cjs.Shape();
	this.shape_879.graphics.f("#FFFFFF").s().p("AnxCpQhFhFAAhkQAAhjBGhHQBGhFBkAAQBkAABGBGQBGBGAABjQAABkhHBFQhGBHhkAAQhjAAhHhHgADSDQQgcgPgYgYQhHhFAChkQAAhiBGhHQBHhFBjAAQBlAABBBCQBIBHAABjIAAADQgBBihEBEQhGBHhjAAIgFAAQg/AAgzgeg");
	this.shape_879.setTransform(552.25,473);

	this.shape_880 = new cjs.Shape();
	this.shape_880.graphics.f("#232323").s().p("EAROAl4QlegClPheQifgqibg8QhUghhYASQgzAMg1AFQjCAWjDASQkfAekTAOIgSABQnBAZm5hUQi8glilhgIgegTQhRg3g4hSQgrhBgIhNIgHhFQgWlEBFk8QBEk2DXjiQAkgmAggsQCCi1C4iEIDEiLQBag8A7gsQGkkLHbisQBqgZBrgRQCLgXCOgOQAvgGAvAAQAXjGAwjBIAGgXQB2nKCYnKQBJjjCGjBQBXh8CKAxQAyASAhArQBDBXAJBvQASC7AjC5QAqDdCAC1QC0iTDLA9IAiANQAdANAXgCQAVgtAegZQBtjACqiKQBXhVBPhcQBtiACeAkQAsAKAcAlQBXB3gTCUQgDAVgMgNIAAAGQABFIgmEgQgGBYgXBXQBdBbAvB0IAJAXQAYA9APBCQA2DwgJD2QgGDShcC9QhUCtiXB3IgZAQQAzCaAOChIAWD0QAKBwAJCtQAHCegICAQgRDBhZCnQgVAnggAdQgvAqg2AkQgvAfgzATQgdAMgeAIQjbAqjPhYIgNgHQhoBviLBAQhLAihTAAIgDAAgAN+pXQhGBHAABjQAABlBGBFQBGBHBkAAQBkAABFhHQBHhFAAhkQAAhkhGhGQhGhGhkAAQhjAAhHBFgAYPpWQhGBHAABjQgCBjBGBFQAYAYAcAQQA1AfBCgBQBjAABGhIQBEhEABhhIAAgEQAAhkhHhGQhChDhkAAQhkABhGBFg");
	this.shape_880.setTransform(413.1312,515.9213);

	this.shape_881 = new cjs.Shape();
	this.shape_881.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQgBBkhGBFQhGBGhjAAQhjAAhHhHQhFhFAAhkQAAhiBGhHQBGhFBjgBQBkAABFBGQBHBIAABig");
	this.shape_881.setTransform(519.25,472.55);

	this.shape_882 = new cjs.Shape();
	this.shape_882.graphics.f("#FFFFFF").s().p("AnwCpQhGhFAAhkQAAhjBGhHQBHhFBjAAQBkAABGBGQBGBIAABhQAABlhHBEQhFBHhkAAQhkAAhGhHgADRDQQgbgPgYgYQhGhFAChkQAAhiBGhHQBGhFBkAAQBkAABBBCQBIBGAABkIAAADQgCBhhEBFQhFBHhkAAIgEAAQg/AAg0geg");
	this.shape_882.setTransform(551.925,472.55);

	this.shape_883 = new cjs.Shape();
	this.shape_883.graphics.f("#232323").s().p("EARNAl+QlegDlPhfQifgribg8QhUghhXARQg1AMg0AFQjDAVjCASQkfAckRANIgSABQnBAZm5hVQi8gkilhgIgegTQhRg4g4hRQgrhBgIhNIgGhFQgXlEBGk8QBFk2DXjiQAkgmAfgsQCEi1C3iEIDEiKQBag9A2gqQGkkLHgiqQBqgZBqgSQCMgYCNgOQAwgGAvgBQAVjGAvjCIAFgXQB0nLCQnJQBGjjCEjDQBVh+CLAwQAyASAiAqQBDBWALBvQAUC7AlC5QAtDcCDCzQCxiVDPBAIAiANQAdAMAYAFQAVgtAcggQBsjBCliTQBVhXBOhcQBsiBCeAhQAtAKAcAlQBYB2gRCUQgDAUgHAAIAAAGQADFIglEqQgHBagWBWQBdBbAvB0IAJAWQAXA9AQBCQA3DwgJD3QgHDRhcC+QhTCtiXB3IgZAQQAzCaAOChIAWD0QALBwAKC1QAHClgICCQgSDBhZCnQgWAoggAcQgvArg2AiQguAfg0ATIg7ATQjbAqjPhZIgNgHQhoBviMA/QhJAhhTAAIgEAAgAN9pcQhGBHAABjQAABkBFBFQBHBHBjAAQBkAABGhGQBGhFABhkQAAhjhHhIQhFhGhkAAQhkABhGBFgAYNpbQhGBGAABkQgBBjBFBFQAZAYAbAPQA1AfBCgBQBkAABFhHQBEhFABhhIAAgEQAAhkhHhGQhChChkAAQhjAAhHBGg");
	this.shape_883.setTransform(412.9896,516.0394);

	this.shape_884 = new cjs.Shape();
	this.shape_884.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQgBBkhGBGQhFBGhkAAQhjAAhGhHQhGhFAAhkQAAhjBGhGQBGhGBjAAQBkABBGBFQBGBHAABig");
	this.shape_884.setTransform(518.95,472.1002);

	this.shape_885 = new cjs.Shape();
	this.shape_885.graphics.f("#FFFFFF").s().p("AlGDwQhjAAhHhHQhGhFAAhkQABhjBFhGQBHhGBkAAQBjABBGBFQBGBHABBiQgBBkhGBGQhGBGhjAAIgBAAgADRDQQgbgQgYgXQhHhGADhiQAAhjBGhGQBHhGBjAAQBkAABBBCQBHBGAABkIAAADQgBBhhEBFQhFBGhjABIgFAAQg/AAg0geg");
	this.shape_885.setTransform(551.6,472.1002);

	this.shape_886 = new cjs.Shape();
	this.shape_886.graphics.f("#232323").s().p("EARLAmEQlegElPhgQifgsiag9QhTghhYARQg1ALg0AGQjDATjCASQkfAbkPANIgSABQnBAYm5hVQi8glilhgIgdgTQhTg4g2hRQgshBgIhNIgGhFQgWlFBGk7QBFk2DXjiQAkgmAggsQCDi0C4iEIDEiKQBag9AygoQGikNHmimQBpgaBrgTQCLgYCNgQQAwgGAvgBQAUjGAtjCIAGgYQBwnLCJnIQBEjkCAjEQBUh/CMAuQAyAQAiArQBFBVAMBuQAXC8AnC4QAwDbCFCxQCviWDRBCIAjANIA3AXQAVgtAagmQBrjCCficQBUhYBNheQBqiCCeAgQAtAIAdAlQBaB1gQCUQgCAVgDALIAAAGQAFFIglE2QgGBZgXBWQBdBaAwB2IAJAWQAXA9APBCQA4DwgJD2QgGDShcC9QhTCuiXB2IgZAQQAzCaAPChIAVD0QALBwALC/QAICrgICEQgSDBhbCmQgVAnghAdQgvAqg2AjQguAfg0ATIg7ATQjcAojOhZIgNgIQhpBviLA/QhKAghQAAIgHAAgAN7piQhGBHAABjQAABkBGBGQBGBGBkAAQBkABBFhHQBHhFAAhkQAAhkhGhGQhGhGhkgBQhjABhHBFgAYMphQhGBHAABjQgDBjBHBFQAYAYAbAPQA1AfBCgBQBkgBBFhGQBEhFABhhIAAgEQAAhkhHhGQhBhChkAAQhkABhGBFg");
	this.shape_886.setTransform(412.8343,516.1898);

	this.shape_887 = new cjs.Shape();
	this.shape_887.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhHQhGhFAAhkQABhjBFhGQBHhGBiAAQBkAABGBGQBGBHAABig");
	this.shape_887.setTransform(518.6002,471.7);

	this.shape_888 = new cjs.Shape();
	this.shape_888.graphics.f("#FFFFFF").s().p("AnwCpQhFhGgBhjQABhjBGhGQBGhFBkgBQBkAABFBGQBHBIgBBhQAABkhGBGQhGBGhkAAQhjAAhHhHgADRDQQgbgRgYgXQhGhFAChiQABhjBFhGQBHhGBjAAQBkAABBBBQBHBHABBiIAAAEQgCBhhEBEQhFBIhjAAIgEABQhAAAg0geg");
	this.shape_888.setTransform(551.275,471.7);

	this.shape_889 = new cjs.Shape();
	this.shape_889.graphics.f("#232323").s().p("EARJAmKQlegGlOhhQifgtiag9QhTghhYAQQg0AMg1AFImFAjQkfAakNANIgSABQnBAXm5hVQi8glilhgIgdgUQhTg3g2hSQgshBgHhNIgGhFQgWlEBGk8QBFk1DYjiQAkgmAfgsQCEi0C4iEIDEiKQBag8AtgnQGjkNHqikQBpgaBqgUQCMgZCNgQQAvgHAvgBQATjHAsjCIAGgXQBtnNCBnGQBCjlB9jGQBTiACMAtQAyAPAjAqQBGBVAOBuQAYC7AqC3QAzDbCHCwQCtiaDUBGIAjANQAdAMAcARQAVgtAXgtQBqjDCZilQBUhZBLhfQBpiDCeAdQAtAJAeAkQBbBzgOCVQgCAVACAXIAAAGQAHFIgkFBQgGBZgXBWQBdBbAwB0IAJAXQAXA8APBCQA4DwgJD3QgGDRhbC+QhTCuiXB2IgZAQQAzCaAPChIAWD0QALBwALDHQAJCygICGQgSDBhcCmQgWAnggAdQgvAqg3AiQguAeg0ATQgdAMgeAHQjcAojOhaIgNgIQhpBviMA+QhJAhhRAAIgHgBgAN6poQhGBGgBBkQABBkBFBFQBHBHBjAAQBkAABGhGQBGhFAAhlQABhihHhIQhFhGhkAAQhkABhGBFgAYKpnQhFBGgBBkQgCBjBGBFQAYAXAbAQQA2AfBCgBQBjgBBFhHQBEhFAChhIAAgEQgBhjhHhHQhBhBhkAAQhjAAhHBGg");
	this.shape_889.setTransform(412.6788,516.3542);

	this.shape_890 = new cjs.Shape();
	this.shape_890.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhHQhGhFAAhkQABhjBFhHQBHhFBiAAQBkABBGBFQBGBHAABig");
	this.shape_890.setTransform(518.3002,471.2502);

	this.shape_891 = new cjs.Shape();
	this.shape_891.graphics.f("#FFFFFF").s().p("AlGDwQhjAAhGhHQhGhFgBhkQABhjBGhGQBHhFBjgBQBkABBGBFQBGBHgBBjQAABjhGBGQhFBGhkAAIgBAAgADRDQQgbgRgYgXQhGhEAChjQABhiBGhHQBGhGBkAAQBjAABBBBQBHBGABBjIAAAEQgCBhhEBEQhEBIhlAAIgEABQg/AAg0geg");
	this.shape_891.setTransform(550.95,471.2502);

	this.shape_892 = new cjs.Shape();
	this.shape_892.graphics.f("#232323").s().p("EARIAmQQlegHlOhiQifguiag9QhTgjhYARQg0ALg1AFQjDATjCAPQkfAZkMAMIgRABQnBAXm5hWQi8glikhgIgegTQhSg4g3hSQgrhBgIhNIgGhFQgVlEBGk8QBFk1DYjiQAkglAggsQCEi1C4iDIDEiKQBag8ApgmQGikOHvigQBpgbBqgUQCLgbCNgRQAwgGAvgCQARjHArjCIAGgYQBqnNB6nFQA+jlB7jIQBRiBCMArQAzAPAjApQBIBUAPBuQAaC7AtC2QA1DaCKCuQCribDXBJIAiAMQAeAMAdAXQAVgtAWgzQBojDCUivQBShZBKhhQBniECfAbQAtAIAeAkQBcBygLCVQgCAUAGAkIAAAGQAJFIgjFLQgGBagWBVQBdBbAwB1IAIAWQAYA9APBCQA4DwgID2QgHDShbC9QhTCuiXB3IgYAQQAzCaAPChIAWD0QALBwANDPQAJC4gICJQgUDBhcCmQgVAnghAcQgwAqg2AiQguAfg1ASQgcALgeAIQjdAnjNhbIgNgIQhpBuiNA+QhIAghRAAIgHgBgAN4puQhFBHgBBjQAABkBGBFQBGBHBjAAQBlABBFhHQBHhFAAhkQAAhkhGhGQhGhGhkgBQhjABhHBFgAYJptQhGBHgBBjQgCBjBGBFQAYAXAcAQQA1AfBCgBQBkgBBFhHQBDhFAChhIAAgEQgBhkhHhGQhAhAhkAAQhkAAhGBFg");
	this.shape_892.setTransform(412.5094,516.5017);

	this.shape_893 = new cjs.Shape();
	this.shape_893.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABlhHBFQhGBGhjAAQhjAAhHhHQhFhFAAhkQABhjBFhGQBHhGBiAAQBkABBGBFQBGBHAABig");
	this.shape_893.setTransform(518.0002,470.8002);

	this.shape_894 = new cjs.Shape();
	this.shape_894.graphics.f("#FFFFFF").s().p("AlGDwQhjAAhHhGQhFhGAAhkQABhjBFhGQBHhGBjAAQBkABBGBFQBGBHAABjQAABkhHBFQhFBGhjAAIgCAAgADSDQQgcgQgYgYQhGhEAChjQAAhiBHhHQBGhFBkgBQBkAAA/BBQBIBGAABjIAAAEQgBBghEBFQhFBHhjABIgEABQhAAAgzgeg");
	this.shape_894.setTransform(550.625,470.8002);

	this.shape_895 = new cjs.Shape();
	this.shape_895.graphics.f("#232323").s().p("EARGAmWQlegJlOhjQieguiag+QhTgihYAPQg0AMg1AEQjDASjDAPQkeAYkKALIgRABQnBAXm5hWQi8gmikhgIgegTQhSg4g2hSQgshBgHhNIgHhFQgVlEBHk8QBGk1DYjhQAlgmAfgsQCEi0C4iDIDEiKQBag8AkgkQGhkOH1ifQBpgbBqgVQCLgbCNgSQAugIAwgBQAQjHAqjDIAFgXQBpnNBxnEQA7jmB5jKQBPiBCNAoQAzAPAkAoQBIBUAQBtQAeC6AuC3QA5DZCLCsQCpidDaBLIAjANQAeALAfAeQAVguATg5QBnjFCOi3QBRhbBJhhQBmiGCfAaQAtAHAeAjQBeBygKCVQgBAUAKAvIABAGQAKFIghFXQgGBZgXBWQBdBbAwB0IAJAWQAYA9APBCQA4DwgID2QgGDRhbC+QhTCuiXB3IgYAQQA0CaAOChIAWD0QAMBwANDZQAKC+gICLQgVDBhcClQgWAnghAcQgvAqg3AiQguAeg1ASQgdAMgeAHQjbAmjOhcIgNgHQhqBtiMA9QhIAfhPAAIgKAAgAN3p0QhGBHgBBjQABBkBFBGQBGBGBkAAQBkABBFhHQBHhFAAhkQABhkhHhGQhFhGhkgBQhkABhGBFgAYHpzQhGBHAABjQgCBjBFBFQAZAYAbAPQA1AfBCgBQBkgCBFhGQBDhFAChhIAAgFQgBhjhHhGQhAhAhkAAQhjAAhHBFg");
	this.shape_895.setTransform(412.355,516.6733);

	this.shape_896 = new cjs.Shape();
	this.shape_896.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBFQhGBHhjAAQhjAAhHhHQhFhGAAhjQAAhjBGhHQBHhFBiAAQBkAABGBGQBGBHAABig");
	this.shape_896.setTransform(517.7002,470.4);

	this.shape_897 = new cjs.Shape();
	this.shape_897.graphics.f("#FFFFFF").s().p("AnvCpQhGhGAAhjQAAhjBHhHQBGhFBkAAQBkAABFBGQBHBHgBBiQAABlhHBEQhFBHhlAAQhjAAhGhHgADSDPQgcgPgYgYQhGhFADhiQAAhiBGhHQBHhFBjAAQBkgBA/BBQBGBEACBlIAAAEQgBBghEBFQhEBHhlABIgEAAQg/AAgzgeg");
	this.shape_897.setTransform(550.3,470.4);

	this.shape_898 = new cjs.Shape();
	this.shape_898.graphics.f("#232323").s().p("EAREAmcQlegKlNhkQifgviZg/QhTgihYAPQg0ALg1AFQjDAQjDAPQkfAWkHALIgSABQnBAXm4hXQi8glikhhIgegTQhRg4g3hSQgshBgHhNIgGhFQgVlEBHk8QBGk1DYjhQAlgmAfgrQCEi1C5iCIDEiKQBag8AggiQGhkQH5ibQBpgcBqgWQCLgcCMgTQAvgHAvgCQAPjIApjCIAFgXQBlnPBqnBQA5jnB2jLQBOiDCNAnQAzANAkApQBJBSASBtQAgC6AxC2QA7DYCOCrQCnigDdBPIAjAMQAdAMAiAjQAVguAQhAQBnjECHjBQBPhcBJhiQBkiHCfAYQAuAGAeAjQBeBwgHCVQgBAVAQA7IAAAGQANFHghFiQgGBagWBVQBdBbAwB0IAJAXQAYA8APBCQA4DwgID2QgGDShaC+QhTCuiXB3IgYAQQA0CZAOCiIAXD0QALBwAPDhQAKDFgICNQgVDBhdCkQgXAnggAcQgwAqg3AiQgvAeg0ASIg7ASQjcAljNhcIgNgIQhqBtiNA9QhHAehOAAIgMAAgAN1p6QhGBHAABjQAABkBFBGQBHBHBjAAQBkAABGhHQBHhFAAhkQAAhjhGhHQhGhGhkAAQhjAAhHBFgAYGp4QhHBGAABkQgDBiBHBFQAYAYAbAPQA1AfBCgBQBkgBBFhIQBEhEABhhIAAgFQgChkhGhFQg/hAhkAAQhkAAhGBGg");
	this.shape_898.setTransform(412.205,516.8366);

	this.shape_899 = new cjs.Shape();
	this.shape_899.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhGBGhjAAQhjAAhHhHQhFhGAAhjQAAhjBGhHQBHhFBiAAQBkABBGBFQBGBHAABig");
	this.shape_899.setTransform(517.4002,469.9502);

	this.shape_900 = new cjs.Shape();
	this.shape_900.graphics.f("#FFFFFF").s().p("AlFDwQhkAAhGhHQhGhGAAhjQAAhjBHhHQBGhFBkAAQBkABBFBFQBHBHgBBiQAABlhHBFQhFBGhjAAIgBAAgADSDPQgcgPgYgYQhHhFAEhiQAAhiBGhGQBHhGBjAAQBkAAA+A/QBIBGABBkIAAADQgBBghEBGQhFBHhjABIgEAAQhAAAgzgeg");
	this.shape_900.setTransform(549.975,469.9502);

	this.shape_901 = new cjs.Shape();
	this.shape_901.graphics.f("#232323").s().p("EARCAmiQlegLlMhmQiegviahAQhTgjhYAPQg0ALg1AEImGAeQkfAWkFAKIgSABQnBAWm4hXQi8gmikhhIgegTQhRg4g3hSQgrhBgHhNIgGhFQgVlEBIk7QBGk1DYjhQAlgmAfgsQCEi0C4iCIDFiKQBag7AbghQGhkQH+iZQBpgdBqgWQCKgdCNgUQAvgHAvgDQAOjHAnjDIAFgXQBinPBjnAQA1joB0jMQBMiECOAlQAzANAlAoQBKBRATBtQAiC6AzC1QA+DYCQCoQCliiDgBSIAjAMQAeALAjAqQAVguAOhGQBljFCCjKQBOhcBHhkQBiiICgAVQAtAGAfAjQBhBvgGCVQgBAVAUBGIABAGQAPFHgfFtQgGBZgWBWQBdBaAwB1IAJAWQAXA9AQBCQA4DwgHD2QgGDRhbC/QhTCuiWB3IgYAQQA0CZAOCiIAXD0QAMBwAPDqQALDLgICPQgWDBheCkQgWAnghAcQgwApg3AiQgvAeg0ASQgdAKgeAIQjdAljMheIgNgIQhrBtiNA8QhGAehMAAIgPAAgAN0qAQhHBGAABkQAABkBGBFQBGBHBkAAQBkABBFhHQBHhFAAhkQABhkhHhGQhFhGhkgBQhkABhGBFgAYEp+QhGBGAABjQgEBjBHBFQAYAXAcAQQA1AeBCgBQBjgBBFhHQBEhFABhhIAAgEQgBhkhIhGQg+g/hkAAQhjAAhHBGg");
	this.shape_901.setTransform(412.0521,517.0076);

	this.shape_902 = new cjs.Shape();
	this.shape_902.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQgBBkhGBFQhGBGhjAAQhkAAhGhHQhFhFAAhkQAAhjBGhHQBHhFBiAAQBkABBGBFQBGBIAABig");
	this.shape_902.setTransform(517.1,469.5002);

	this.shape_903 = new cjs.Shape();
	this.shape_903.graphics.f("#FFFFFF").s().p("AlGDwQhjAAhGhHQhFhFAAhkQAAhiBGhIQBHhFBjAAQBkABBFBFQBGBIABBiQgBBkhHBFQhFBGhjAAIgCAAgADSDPQgcgPgYgYQhHhEAEhjQAAhiBGhGQBHhGBjAAQBlAAA9A/QBHBGABBjIAAAEQAABghDBGQhGBHhjABIgFAAQg/AAgzgeg");
	this.shape_903.setTransform(549.65,469.5002);

	this.shape_904 = new cjs.Shape();
	this.shape_904.graphics.f("#232323").s().p("EARAAmnQlegMlMhnQiegwiZhAQhTgkhYAQQg0AKg1AEQjDAPjDANQkfAVkDAKIgSABQnBAWm4hYQi8gmikhhIgdgTQhSg4g2hSQgshBgHhNIgGhFQgUlEBIk8QBGk1DZjgQAkgmAggsQCEi0C5iCIDEiJQAtgeAMgQQAUgTAkgaQGfkRIFiWQBngeBrgWQCKgeCMgVQAwgIAugDQANjGAmjEIAFgXIC6uOQAzjoBxjOQBKiFCPAkQAzAMAlAnQBLBRAVBtQAkC4A2C1QBADXCTCnQCjikDiBUIAkAMQAdALAmAwQAVguALhNQBkjGB7jSQBOheBFhkQBhiKCfAUQAuAGAfAiQBiBtgDCWQgCAUAaBSIABAHQAQFHgdF3QgFBZgWBWQBcBaAxB1IAJAWQAXA9AQBCQA4DwgHD2QgFDShbC9QhTCuiWB4IgYAQQA0CZAOCiIAXDzQAMBwAQDzQAMDSgJCRQgWDBhfCkQgWAnghAcQgvAog4AiQgvAeg0ASQgdAKgfAHQjcAkjMheIgNgIQhrBsiNA8QhHAehOAAIgNgBgANyqHQhGBHAABjQAABlBFBFQBGBHBkAAQBkAABGhGQBGhFABhkQAAhjhGhIQhGhFhkgBQhjAAhHBFgAYDqFQhHBHAABjQgDBiBHBFQAXAYAcAPQA1AfBCgBQBkgBBFhIQBDhFABhhIAAgEQgBhjhIhGQg9g/hkAAQhjAAhHBFg");
	this.shape_904.setTransform(411.9004,517.2019);

	this.shape_905 = new cjs.Shape();
	this.shape_905.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhGBGhjAAQhjAAhGhHQhGhGAAhjQAAhjBHhHQBGhFBjAAQBkABBFBFQBGBHAABig");
	this.shape_905.setTransform(516.8,469.1002);

	this.shape_906 = new cjs.Shape();
	this.shape_906.graphics.f("#FFFFFF").s().p("AlFDwQhkAAhGhHQhGhFAAhkQAAhjBHhHQBGhEBkgBQBkABBGBFQBGBHAABiQgBBkhGBGQhHBGhiAAIgBAAgADRDPQgbgQgYgXQhHhEAEhjQAAhjBGhGQBHhFBkAAQBjAAA+A+QBHBFABBkQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQgBBghDBFQhFBHhjABIgFABQg/AAg0geg");
	this.shape_906.setTransform(549.35,469.1002);

	this.shape_907 = new cjs.Shape();
	this.shape_907.graphics.f("#232323").s().p("EAQ/AmtQlegOlMhoQidgxiahAQhSgjhYAOQg1AKg0AEQjDAPjDAMQkfATkCAKIgSAAQnAAWm5hYQi7gmikhhIgegUQhRg4g3hSQgqhBgIhNIgGhFQgUlEBIk7QBHk1DZjgQAlgmAfgsQCFi0C4iCIDFiJQAsgdAKgPQASgTAkgaQGfkRIJiUQBpgeBpgXQCKggCMgVQAwgIAvgDQALjHAljDIAEgYQBdnQBUm8QAvjpBujPQBJiGCPAhQA0AMAlAnQBMBPAWBtQAnC4A4C0QBDDWCUClQCiilDlBWIAjAMQAeALAoA1QAVgtAIhTQBjjHB1jbQBMhfBEhkQBfiMCgASQAuAFAfAiQBkBsgCCVQAAAKAPAvQALAmAEAUIABAGQATFHgcGCQgFBZgXBWQBdBaAxB1IAJAWQAYA8APBDQA5DwgHD2QgGDRhaC+QhTCuiWB4IgYAQQA0CZAPCiIAXDzQAMBwARD8QANDYgJCTQgXDBhgCkQgWAnghAbQgwAqg3AgQgwAeg0ASIg7ARQjdAjjMhfIgNgIQhsBsiNA7QhGAdhNAAIgOAAgANxqNQhGBHAABjQAABkBFBGQBGBHBkAAQBjAABHhGQBGhGABhkQAAhjhGhHQhGhFhkgBQhjAAhHBFgAYCqLQhHBGAABkQgEBjBHBEQAYAXAbAQQA2AeBCgBQBjgBBFhHQBDhFAChhQgBgBAAAAQAAgBAAAAQAAgBAAAAQAAgBABgBQgChkhHhFQg9g+hkAAQhkAAhGBFg");
	this.shape_907.setTransform(411.7462,517.403);

	this.shape_908 = new cjs.Shape();
	this.shape_908.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQAABkhHBFQhGBGhjAAQhjAAhHhHQhFhGAAhjQABhjBGhHQBGhFBjAAQBkABBFBFQBGBIAABig");
	this.shape_908.setTransform(516.4502,468.6502);

	this.shape_909 = new cjs.Shape();
	this.shape_909.graphics.f("#FFFFFF").s().p("AlFDwQhkAAhGhHQhFhGgBhjQAChjBFhHQBHhEBjgBQBkABBGBFQBGBIAABiQgBBkhGBFQhGBGhjAAIgBAAgADSDPQgcgPgYgXQhHhGAEhiQABhiBGhHQBGhFBkAAQBkAAA9A+QBHBGABBjIAAAFQgBBfhDBFQhEBIhkABIgFABQg/AAgzgeg");
	this.shape_909.setTransform(549,468.6502);

	this.shape_910 = new cjs.Shape();
	this.shape_910.graphics.f("#232323").s().p("EAQ9AmyQlegPlLhpQiegyiZhAQhSgkhYAOQg1AKg0AEImGAZQkgATj/AIIgSABQnBAVm4hYQi7gmikhiIgegTQhRg4g2hSQgshBgGhOIgGhFQgUlEBIk7QBIk1DYjfQAlgmAggsQCEi0C5iBIDFiJQAsgeAIgOQAQgSAjgaQGfkSIPiRQBogfBpgYQCKggCMgWQAvgJAvgDQAKjHAkjDIAEgYQBanQBMm7QAtjpBrjRQBIiHCPAgQAzAMAmAmQBOBOAXBsQApC5A6CzQBGDUCWCkQCfioDpBaIAkALQAdALArA7QAVgtAFhaIDQmrQBLhfBDhmQBdiMCgAPQAuAEAgAiQBlBqAACWQAAAKASA1QANAqAFAVIAAAGQAUE7gZGZQgFBZgWBWQBeBaAwB1IAJAWQAXA9AQBCQA5DvgHD2QgFDThbC9QhRCuiXB4IgYAQQA0CZAPCiIAXDzQAMBwASEEQANDggJCVQgYDBhfCjQgXAnghAbQgwApg4AhQgvAdg1ARQgdALgeAHQjdAijLhgIgNgIQhsBsiNA7QhGAchLAAIgRgBgANwqTQhGBGgBBkQAABkBFBFQBHBHBjAAQBkABBGhHQBHhFAAhkQAAhjhGhHQhFhGhkgBQhkABhGBFgAYAqRQhGBGgBBkQgEBiBHBFQAYAXAcAQQA1AeBCgBQBkgCBEhHQBDhFAChhIAAgFQgChjhHhGQg9g9hkAAQhjAAhHBFg");
	this.shape_910.setTransform(411.5808,517.6112);

	this.shape_911 = new cjs.Shape();
	this.shape_911.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABlhHBFQhGBGhjAAQhjAAhHhIQhFhFAAhjQABhjBFhHQBIhFBiAAQBkABBFBFQBGBHAABig");
	this.shape_911.setTransform(516.1502,468.2502);

	this.shape_912 = new cjs.Shape();
	this.shape_912.graphics.f("#FFFFFF").s().p("AlFDwQhjAAhHhIQhFhFAAhjQABhjBFhHQBIhFBjAAQBkABBFBGQBGBGAABiQAABlhHBFQhFBGhjAAIgCAAgADRDPQgbgQgYgXQhHhFAEhhQABhjBGhGQBHhGBjAAQBkABA8A9QBIBFABBkIAAAEQAABghEBFQhFBHhjACIgEAAQhAAAg0gdg");
	this.shape_912.setTransform(548.675,468.2502);

	this.shape_913 = new cjs.Shape();
	this.shape_913.graphics.f("#232323").s().p("EAQ7Am4QlegRlLhqQidgyiZhBQhSglhYAOQg0AKg1AEQjDANjEALQkfARj9AIIgSABQnBAUm4hYQi6gnilhhIgdgUQhSg4g2hSQgrhBgHhNIgGhFQgTlEBJk7QBHk0DZjgQAlgmAfgsQCFi0C5iBIDFiJQAsgdAFgOQAPgRAjgZQGekUIViOQBnggBqgYQCJghCMgXQAvgJAvgEQAJjGAijEIAEgYQBXnRBFm4QApjqBqjSQBEiHCQAdQA0ALAnAmQBOBNAZBsQArC3A9CzQBIDUCZChQCcipDsBcIAkALQAeALAsBBQAVgtADhhQBgjHBojtQBKhgBBhnQBciNCgANQAtAEAhAhQBmBpACCWQAAAKAVA7QAPAuAGAXIABAGQALCjgBDLQgBDCgKCuQgFBZgXBWQBeBaAwB1IAJAWQAYA9AQBBQA5DwgHD2QgFDShaC+QhSCuiWB4IgYAQQA0CZAPCiIAYDzQALBwATENQAODmgJCXQgZDAhgCkQgXAmghAcQgxAog3AhQgwAdg0ARQgdAKgeAHQjdAijMhhIgMgIQhtBsiNA6QhEAbhLAAIgTAAgANuqaQhGBHgBBjQAABlBGBFQBGBHBkAAQBkABBFhHQBHhFAAhkQABhkhHhGQhFhGhkgBQhjAAhHBFgAX+qXQhFBGgBBkQgFBhBHBFQAZAYAbAPQA1AeBCgBQBkgBBFhIQBDhFABhhIAAgEQgChjhHhGQg8g9hkgBQhjABhIBFg");
	this.shape_913.setTransform(411.428,517.8341);

	this.shape_914 = new cjs.Shape();
	this.shape_914.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQgBBkhGBFQhHBGhiAAQhkAAhGhHQhFhGAAhjQABhjBFhHQBIhFBiAAQBkABBFBFQBGBIAABig");
	this.shape_914.setTransform(515.8502,467.8002);

	this.shape_915 = new cjs.Shape();
	this.shape_915.graphics.f("#FFFFFF").s().p("AlFDwQhkAAhGhHQhFhGAAhjQABhjBFhHQBIhFBjAAQBkABBFBGQBHBHgBBiQgBBkhGBFQhGBGhjAAIgBAAgADRDPQgbgQgYgXQhHhEAEhiQAAhjBHhGQBHhGBjAAQBkAAA8A+QBIBEABBlIAAAEQgBBghDBFQhFBHhjACIgFAAQg/AAg0gdg");
	this.shape_915.setTransform(548.35,467.8002);

	this.shape_916 = new cjs.Shape();
	this.shape_916.graphics.f("#232323").s().p("EAQ5Am9QlegSlKhsQidgyiZhCQhSglhYAOQg0AKg1ADQjEANjDAJQkfARj7AHIgSABQnBAUm3hZQi8gmikhiIgdgTQhRg5g3hSQgqhBgHhNIgGhFQgTlEBJk7QBIk1DZjfQAlgmAfgrQCFizC5iCIDFiJQAtgdACgNQAOgRAhgZQGekUIaiMQBoggBpgZQCJgiCMgYQAugJAvgEQAJjHAgjEIAFgXQBTnRA+m2QAmjrBnjTQBDiJCQAcQA0AKAnAlQBPBNAbBsQAtC2A/CyQBLDTCbCgQCaitDvBgIAkALQAeAKAvBHQAVgtgBhnQAwhjAniAQArh4A/hiQBJhhBAhnQBZiPChALQAuADAgAhQBoBpAECVQAAAKAXBAQASAzAHAYIAAAGQANCjAADRQAADFgKCvQgFBagWBWQBeBaAwB0IAJAWQAYA8AQBDQA5DvgHD2QgFDThZC9QhTCuiVB4IgZARQA1CaAPCgIAYD0QAMBwAUEVQAODsgKCaQgZDAhhCjQgXAnghAbQgxAog3AhQgwAcg1ASQgdAKgeAGQjdAhjLhhIgMgIQhuBriNA5QhDAbhJAAIgWAAgANsqgQhFBGgBBjQAABlBFBFQBGBHBkAAQBjABBHhHQBGhFABhkQAAhjhGhHQhFhGhkgBQhjABhIBFgAX9qeQhHBGAABkQgEBiBGBEQAZAYAbAPQA1AeBCgBQBkgBBFhIQBDhFABhhIAAgEQgChkhHhFQg8g9hkAAQhkAAhGBFg");
	this.shape_916.setTransform(411.2702,518.0581);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_810},{t:this.shape_809},{t:this.shape_808}]},485).to({state:[{t:this.shape_813},{t:this.shape_812},{t:this.shape_811}]},1).to({state:[{t:this.shape_815},{t:this.shape_814},{t:this.shape_811}]},1).to({state:[{t:this.shape_817},{t:this.shape_816},{t:this.shape_811}]},1).to({state:[{t:this.shape_820},{t:this.shape_819},{t:this.shape_818}]},1).to({state:[{t:this.shape_823},{t:this.shape_822},{t:this.shape_821}]},1).to({state:[{t:this.shape_826},{t:this.shape_825},{t:this.shape_824}]},1).to({state:[{t:this.shape_829},{t:this.shape_828},{t:this.shape_827}]},1).to({state:[{t:this.shape_832},{t:this.shape_831},{t:this.shape_830}]},1).to({state:[{t:this.shape_835},{t:this.shape_834},{t:this.shape_833}]},1).to({state:[{t:this.shape_837},{t:this.shape_836},{t:this.shape_833}]},1).to({state:[{t:this.shape_839},{t:this.shape_838},{t:this.shape_833}]},1).to({state:[{t:this.shape_842},{t:this.shape_841},{t:this.shape_840}]},1).to({state:[{t:this.shape_844},{t:this.shape_843},{t:this.shape_840}]},1).to({state:[{t:this.shape_847},{t:this.shape_846},{t:this.shape_845}]},1).to({state:[{t:this.shape_850},{t:this.shape_849},{t:this.shape_848}]},1).to({state:[{t:this.shape_853},{t:this.shape_852},{t:this.shape_851}]},1).to({state:[{t:this.shape_856},{t:this.shape_855},{t:this.shape_854}]},1).to({state:[{t:this.shape_859},{t:this.shape_858},{t:this.shape_857}]},1).to({state:[{t:this.shape_862},{t:this.shape_861},{t:this.shape_860}]},1).to({state:[{t:this.shape_865},{t:this.shape_864},{t:this.shape_863}]},1).to({state:[{t:this.shape_868},{t:this.shape_867},{t:this.shape_866}]},1).to({state:[{t:this.shape_871},{t:this.shape_870},{t:this.shape_869}]},1).to({state:[{t:this.shape_874},{t:this.shape_873},{t:this.shape_872}]},1).to({state:[{t:this.shape_877},{t:this.shape_876},{t:this.shape_875}]},1).to({state:[{t:this.shape_880},{t:this.shape_879},{t:this.shape_878}]},1).to({state:[{t:this.shape_883},{t:this.shape_882},{t:this.shape_881}]},1).to({state:[{t:this.shape_886},{t:this.shape_885},{t:this.shape_884}]},1).to({state:[{t:this.shape_889},{t:this.shape_888},{t:this.shape_887}]},1).to({state:[{t:this.shape_892},{t:this.shape_891},{t:this.shape_890}]},1).to({state:[{t:this.shape_895},{t:this.shape_894},{t:this.shape_893}]},1).to({state:[{t:this.shape_898},{t:this.shape_897},{t:this.shape_896}]},1).to({state:[{t:this.shape_901},{t:this.shape_900},{t:this.shape_899}]},1).to({state:[{t:this.shape_904},{t:this.shape_903},{t:this.shape_902}]},1).to({state:[{t:this.shape_907},{t:this.shape_906},{t:this.shape_905}]},1).to({state:[{t:this.shape_910},{t:this.shape_909},{t:this.shape_908}]},1).to({state:[{t:this.shape_913},{t:this.shape_912},{t:this.shape_911}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[{t:this.shape_916},{t:this.shape_915},{t:this.shape_914}]},1).to({state:[]},1).wait(747));

	// Слой_32
	this.instance_48 = new lib.фоны_фонприхожая();
	this.instance_48.setTransform(0,0,0.3326,0.3326);
	this.instance_48._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_48).wait(485).to({_off:false},0).wait(60).to({_off:true},16).wait(747));

	// фраза
	this.shape_917 = new cjs.Shape();
	this.shape_917.graphics.f("#232323").s().p("AgiAlQgGgHgBgdQAAgbAEgGQADgFAMgDQAMgDAUAAIAIAAQAGAAAJAHQAIAGAAAKQAAAUgHAKQgHAKgRAMQgPAMgGAAQgQAAgHgHg");
	this.shape_917.setTransform(1115.05,424.025);

	this.shape_918 = new cjs.Shape();
	this.shape_918.graphics.f("#232323").s().p("AghAlQgIgHABgdQAAgbACgGQAEgFAMgDQAMgDAUAAIAHAAQAHAAAJAHQAJAGAAAKQgBAUgHAKQgHAKgQAMQgQAMgHAAQgPAAgGgHg");
	this.shape_918.setTransform(1097,424.025);

	this.shape_919 = new cjs.Shape();
	this.shape_919.graphics.f("#232323").s().p("AghAlQgIgHAAgdQAAgbADgGQAEgFAMgDQAMgDAUAAIAIAAQAGAAAIAHQAJAGAAAKQABAUgIAKQgHAKgQAMQgQAMgHAAQgPAAgGgHg");
	this.shape_919.setTransform(1078.95,424.025);

	this.shape_920 = new cjs.Shape();
	this.shape_920.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_920.setTransform(1049.025,410.975);

	this.shape_921 = new cjs.Shape();
	this.shape_921.graphics.f("#232323").s().p("AiVESQgXgeAAgrQAAhQAjg8QAjg9AsgmQArgmBLgXQAagHAJgEQAJgFgBgKQgNg3gTgWQgSgWgegMQgegMgZAAQgJAAgSAIQgUAHgJAGQgOAIgLAAQgOAAAAgOQAAgQAXgaQAXgbA6AAIAOAAQA5AAAsAeQAsAeATA4QASA4AABeQAAA/gpBbQgoBbg+AvQg+AvhGAAQgaAAgVgdgAgLgBQhiBaAAByQAAAPAGANQAFANAGAAQAaAAAWgJQAVgJAegdQAfgdAagrQAYgrAMgoQALgnABgVIABgkQhSARgqAkg");
	this.shape_921.setTransform(1011.15,401.075);

	this.shape_922 = new cjs.Shape();
	this.shape_922.graphics.f("#232323").s().p("AhrCxQgfgWgDggIgBgIQgDgjAZgnQAagoBlgyQBCghAAgbQAAgOgMgIQgMgIgJAAQgaAAhKAmIgHACQgdABAAgVQAAghA5gVQA4gXAqAAQAaAAAdAVQAdAVAAAjQAAAdgTAaQgSAchLAoQg8AigVAVQgWAWAAAbQAAAVASAFQATAHAKAAQBBAAA0gbQASgKAIABQATgBAAAVQAAAegyAWQgyAUhMAAQgkAAgggUg");
	this.shape_922.setTransform(973.1289,411);

	this.shape_923 = new cjs.Shape();
	this.shape_923.graphics.f("#232323").s().p("Ah8CrQgfgiAAg7QAAhkBEhbQBEhaBPAAQAaAAARARQARARAAAYQAAA3g1AxQg1AxhYAvQgTAKAAAPQAAAdARASQARARAhAAQBLAABPhTQALgMAGAAQALAAAAASQAAAkg/AzQg/AyhDAAQg5AAgeghgAgehnQgoAwgRBDQCUhXAAg2QAAgVgTAAQggAAgoAvg");
	this.shape_923.setTransform(936.775,410.725);

	this.shape_924 = new cjs.Shape();
	this.shape_924.graphics.f("#232323").s().p("Ah2CvQgdgfAAg2QAAhaBJhnQBJhlA9AAQAdAAAUAeQAVAfAAAiQAAAWgJAOQgJAPgJAAQgVAAgIgpQgKgsgRAAQglAAgxBXQgyBVAAA8QAAA8BEAAQAzAABGgwQAYgSAMABQAMAAAAANQAAAbg/ApQg/Aog8AAQg0AAgcgeg");
	this.shape_924.setTransform(899.325,410.85);

	this.shape_925 = new cjs.Shape();
	this.shape_925.graphics.f("#232323").s().p("AiDENQghgvAAhbQAAhtAnhvQAmhwA6g5QA4g5A7AAQAkAAAVAXQAWAXAAAqQAAAhgdAtQgcAugvApQBQAgAAB4QAABag5BEQg5BEhBAAQg7AAgigvgAg/AlIgkAaQgFAfAAAkQAABAATAgQATAhAiAAQAuAAAfgyQAfgxAAg8IAAAAQAAg1gTggQgTgfgYAAQgHAAhGA1gAgRi+QgvBFgbB5QCHhnAggtQAggtAAgZQAAgpgiAAQguAAgtBFg");
	this.shape_925.setTransform(864.675,399.875);

	this.shape_926 = new cjs.Shape();
	this.shape_926.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_926.setTransform(795.425,411.425);

	this.shape_927 = new cjs.Shape();
	this.shape_927.graphics.f("#232323").s().p("AjACwQAAgYAhgpQAignA1hcQA2heAhhKQAGgNANAAQAFAAAOAFQANAEAEAGQAEAFANA8QAsDXAvAoQALAKACADQADADAAAGQgBALgGAJQgIAJgGACQgHADgVAAQgHAAgbgkQgbglgkihQgJgsgGgOQgIgBgJARQhICQgkA0IgIAOQgsBOgVAAQgbAAAAgag");
	this.shape_927.setTransform(753,411.025);

	this.shape_928 = new cjs.Shape();
	this.shape_928.graphics.f("#232323").s().p("AjTCtQgVgfAAg7QAAg+AQhMQAQhMAJgaIAHgWQAEgOAfgHQAFgDAFAAQAJAAAGAYQAAAPgIAXQgYBDAAAaQAAAHAEABQBRhOBFAAQAqAAAcAgQAdAgAAAbQAABRhTBLQhSBLhUAAQgmAAgVgfgAhBgzQgbAOghAfIgUARQgIAHgMACQgHAnAAAnQAAA1ApAAQAvAAA7g4QA5g5AAg0QAAgVgLgPQgMgPgTAAQgcAAgbAOgAB+CHQAAg+AbiSQAKg1AAgLQAAgWAIgQQAIgQAPAAQASAAAKAJQALAIAAALQAAALgFASQgcBkgGAnQgGApAAA3QAAAaAHAiIABAKQAAAHgLAKQgMAKgNAAQgiAAAAg/g");
	this.shape_928.setTransform(706.275,409.575);

	this.shape_929 = new cjs.Shape();
	this.shape_929.graphics.f("#232323").s().p("AifEUQgXgrAAg0QAAhcA5hSQA4hRBAAAQAHAAANAMQALAKAGgDQgOgjgvgqQgtgogBgcQAAgXAPgOQAPgOAogLQAxgOAzgRQA0gRALgFQAGgDAIgBQALABAAAUQAAAMgcAUQgcAUhHARQgtAMgKAFQgJAFAAAGQAAANAaAXQBnBbAACHQAAA7geBDQggBDgzAhQgyAggyAAQgsABgXgsgAhMAqQgsBMgBBBQAAAnALAWQALAVAQAAQAXABAmgcQAlgcAYg2QAXg3AAgvQAAgngLgYQgLgZgKABQg9gBgtBMg");
	this.shape_929.setTransform(663.5,398.35);

	this.shape_930 = new cjs.Shape();
	this.shape_930.graphics.f("#232323").s().p("AiwDJQgJgJAAgJQAAgNAKgvQARhVARjFQABgTANgPQANgQARAAQAJAAAGALQAGAJAAAPQAAANgEAQQgUBIgFBMQBTgOBBhdQAfgrAYgSQAXgTAaAAQALAAAKAKQALAJAAAOQAAARghAKQgRAFgPANQgPAMgqAwQghAmgaANIgCADQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABQAZANAcAoQAqA5AUAPQAVAPAbAAIALgBQANAAAAAMQAAANgPAPQgQANgiAAQgbAAgZgWQgZgXghg0QgRgegRgRQgQgPgTAAQgFAAgVAGQgWAIgDAHQgCAGgCAoIgBBBQAAANgMAKQgNAKgOAAQgPAAgIgIg");
	this.shape_930.setTransform(593.675,410.6);

	this.shape_931 = new cjs.Shape();
	this.shape_931.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_931.setTransform(550.075,410.975);

	this.shape_932 = new cjs.Shape();
	this.shape_932.graphics.f("#232323").s().p("Ag5DxQgMgRAAhRQAAhNAdjdIACgNQAAgMgNAAQgVAAg8AGQg7AFgZAAQgmAAgMgMQgEgHAAgKQAAgQAMgGQALgFA5gBQBGAAA4gFQA4gFBzgQQAsgGAnAAQAUAAATADQASACAHADQAIACAEAKQAFAKAAAGQAAAZgSAAQgLAAgUgCQgVgCgjAAQgjAAgzAFQg0AFgFAMQgGAMgNB9QgMB9AAA9QAAAdAIAlIACAIQAAAQgIAMQgIANgMAAQgTAAgMgSg");
	this.shape_932.setTransform(508.725,404.775);

	this.shape_933 = new cjs.Shape();
	this.shape_933.graphics.f("#FFFFFF").s().p("EioChYsMEsagvoMAjrDhAMksaAvog");
	this.shape_933.setTransform(722.375,339.95);

	this.shape_934 = new cjs.Shape();
	this.shape_934.graphics.f("#232323").s().p("AgiAlQgGgHgBgdQABgbADgGQADgFAMgDQAMgDAUAAIAHAAQAHAAAJAHQAIAGABAKQAAAUgIAKQgHAKgRAMQgPAMgGAAQgQAAgHgHg");
	this.shape_934.setTransform(1060.7,424.025);

	this.shape_935 = new cjs.Shape();
	this.shape_935.graphics.f("#232323").s().p("AghAlQgIgHABgdQAAgbACgGQAEgFAMgDQAMgDAUAAIAHAAQAHAAAIAHQAKAGgBAKQAAAUgHAKQgHAKgQAMQgQAMgHAAQgPAAgGgHg");
	this.shape_935.setTransform(1042.65,424.025);

	this.shape_936 = new cjs.Shape();
	this.shape_936.graphics.f("#232323").s().p("AgiAlQgGgHgBgdQAAgbAEgGQADgFAMgDQAMgDAUAAIAIAAQAGAAAJAHQAIAGABAKQAAAUgIAKQgHAKgRAMQgPAMgGAAQgQAAgHgHg");
	this.shape_936.setTransform(1024.6,424.025);

	this.shape_937 = new cjs.Shape();
	this.shape_937.graphics.f("#232323").s().p("AihC/QgKgOAAgIQAAgJAkgfIATgPQA0gjA0gxIgnAAQgTgBgagOQgagOgGgRQgGgSAAgQQAAgyA3gqQA2gpBMgOQAJAAAWgFIAYgDIARADIAMgCQALAAALAHQAMAHADALQAAAJgPAhQgMAagNBNQgMBMAAAxQAAAVAEAjQACARAAALQAAAGgLAHQgKAGgJAAQgVAAgGgKQgHgKAAgeIADhyQg0AsgWAVQgZAYgLAHQgwAngWAcQgDAEgIAFQgHAEgDAAQgQAAgJgPgAgQh5Qg9AfAAAsQAAANAQAJQAQAJAdAAQA0AAAcgKQAIgGAFgRIAYhhQgEgHgFAAQgxAAg7Afg");
	this.shape_937.setTransform(996.775,410.625);

	this.shape_938 = new cjs.Shape();
	this.shape_938.graphics.f("#232323").s().p("ABSAdQAAgLgJAAQghAAguAEQgwAEgVAGQgUAGgFAFQgFAFgDAWQgEAWAAAXIAAArQAAAmgjAAQgdAAAAgmQAAgYAHgmQALhGAMipQABgWADgGQACgGALgHQAKgHAMAAQAaAAAAAUIgIA1QgJAyAAAbQAAATAOAAQAaAABGgIQBHgKADgFQAEgHAIhRQAGhBAjAAQAdAAAAAdQAAAGgFAVQgbBwAABLQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQg3AAAAiqg");
	this.shape_938.setTransform(957.175,410.975);

	this.shape_939 = new cjs.Shape();
	this.shape_939.graphics.f("#232323").s().p("AiWESQgWgeAAgrQAAhQAkg8QAig9ArgmQAsgmBMgXQAZgHAJgEQAJgFgBgKQgNg3gSgWQgTgWgfgMQgdgMgZAAQgJAAgTAIQgTAHgJAGQgOAIgMAAQgNAAAAgOQAAgQAXgaQAXgbA5AAIAQAAQA4AAAsAeQAsAeASA4QATA4AABeQAAA/goBbQgpBbg/AvQg9AvhGAAQgZAAgXgdgAgLgBQhiBaAAByQAAAPAFANQAGANAHAAQAaAAAVgJQAVgJAegdQAfgdAZgrQAagrALgoQALgnABgVIAAgkQhRARgqAkg");
	this.shape_939.setTransform(918.4,401.075);

	this.shape_940 = new cjs.Shape();
	this.shape_940.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_940.setTransform(772.725,411.425);

	this.shape_941 = new cjs.Shape();
	this.shape_941.graphics.f("#232323").s().p("AlMBiQAAgzAWiHQAJg2AAgYQAAgXAVAAQAnAAAAA4QAAAagNBNQgPBXgBATQAWgVArhGQA7hiAdgaQAcgaAeAAQAXAAAOAeQANAfADByQAAAdAFAOQAEAOACAAQARAAA3hvQAdg8AcgfQAcgfAiAAQAdAAANAeQANAdAFA6QAFA5AMAxQALAwAdAOQAUAJAAANQAAAMgQANQgSANgOAAQgbAAgXgiQgWgjgLhxQgFgugFgUQgFgTgJAAQgPAAgUAcQgVAcgtBVQgiBEgTAWQgRAWgRAAQgPAAgMgMQgMgMgDgRQgDgRgDhDQgGhugOgSQggAAhsDAQgkBBgGAGQgGAGgQAFQgQAEgLAAQgXAAAAhcg");
	this.shape_941.setTransform(717.3,410.475);

	this.shape_942 = new cjs.Shape();
	this.shape_942.graphics.f("#232323").s().p("AiECkQgbgcAAgaQAAgKAKgFQALgGAJAAQAIAAAGAEQAFAEAIASQAOAaAjAAQAoAAAngXQAogXAOgnQAOgmAAgKQABgIgHAAQgEAAgqAJQgpAIgxAAQgMAAgIgHQgHgIAAgIQgBgQAmgIIAJgCIAdgEQBNgIATgIQgEgpgSgXQgSgZgcAAQguAAgxAoQgUARgEACQgFADgGAAQgXAAAAgYQAAgjA5gaQA4gbA1AAQAfAAAgAWQAgAWANArQALAsAAAhQAABLg4BIQg4BIh5AAQghAAgagcg");
	this.shape_942.setTransform(660.15,411.425);

	this.shape_943 = new cjs.Shape();
	this.shape_943.graphics.f("#232323").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_943.setTransform(593.425,411.425);

	this.shape_944 = new cjs.Shape();
	this.shape_944.graphics.f("#232323").s().p("AiVESQgXgeAAgrQAAhQAjg8QAjg9AsgmQArgmBLgXQAagHAJgEQAJgFgBgKQgNg3gTgWQgSgWgegMQgegMgZAAQgJAAgSAIQgUAHgJAGQgOAIgLAAQgOAAAAgOQAAgQAXgaQAXgbA6AAIAOAAQA5AAAsAeQAsAeATA4QASA4AABeQAAA/gpBbQgoBbg+AvQg+AvhGAAQgZAAgWgdgAgLgBQhiBaAAByQAAAPAGANQAFANAGAAQAaAAAWgJQAVgJAegdQAfgdAZgrQAZgrAMgoQALgnABgVIABgkQhSARgqAkg");
	this.shape_944.setTransform(556.1,401.075);

	this.shape_945 = new cjs.Shape();
	this.shape_945.graphics.f("#FFFFFF").s().p("AgiAlQgGgHAAgdQAAgbACgGQAEgFAMgDQAMgDAUAAIAHAAQAHAAAJAHQAIAGABAKQAAAUgIAKQgHAKgRAMQgPAMgGAAQgPAAgIgHg");
	this.shape_945.setTransform(1294.45,424.025);

	this.shape_946 = new cjs.Shape();
	this.shape_946.graphics.f("#FFFFFF").s().p("AghAlQgIgHAAgdQAAgbADgGQAEgFAMgDQAMgDAUAAIAIAAQAGAAAIAHQAJAGAAAKQABAUgIAKQgHAKgQAMQgQAMgHAAQgPAAgGgHg");
	this.shape_946.setTransform(1276.4,424.025);

	this.shape_947 = new cjs.Shape();
	this.shape_947.graphics.f("#FFFFFF").s().p("AgiAlQgHgHAAgdQAAgbAEgGQADgFAMgDQAMgDAUAAIAHAAQAHAAAJAHQAIAGABAKQAAAUgIAKQgHAKgRAMQgPAMgGAAQgPAAgIgHg");
	this.shape_947.setTransform(1258.35,424.025);

	this.shape_948 = new cjs.Shape();
	this.shape_948.graphics.f("#FFFFFF").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_948.setTransform(1228.425,410.975);

	this.shape_949 = new cjs.Shape();
	this.shape_949.graphics.f("#FFFFFF").s().p("AlMBiQAAgzAWiHQAJg2AAgYQAAgXAVAAQAnAAAAA4QAAAagNBNQgPBXAAATQAVgVArhGQA7hiAdgaQAcgaAeAAQAXAAANAeQAOAfADByQAAAdAFAOQAEAOACAAQAQAAA3hvQAeg8AcgfQAcgfAiAAQAcAAANAeQANAdAGA6QAFA5AMAxQAKAwAeAOQAUAJAAANQAAAMgQANQgSANgOAAQgcAAgWgiQgWgjgMhxQgEgugFgUQgFgTgJAAQgPAAgUAcQgUAcguBVQgiBEgTAWQgSAWgPAAQgQAAgMgMQgLgMgEgRQgDgRgEhDQgEhugPgSQghAAhrDAQgkBBgGAGQgGAGgQAFQgQAEgLAAQgXAAAAhcg");
	this.shape_949.setTransform(1172.45,410.475);

	this.shape_950 = new cjs.Shape();
	this.shape_950.graphics.f("#FFFFFF").s().p("AiGCgQgggkAAg2QAAhaA+hYQA8hYBUAAQA5AAAjArQAjAsAAA7QAABbhIBOQhJBOhNAAQgwAAgfglgAg/hGQgpBFAAA+QAAAjAPAXQAPAWAZAAQAzAAA1g5QA1g6AAhFQAAgrgUgbQgVgbgiAAQg3AAgpBGg");
	this.shape_950.setTransform(1113.225,411.425);

	this.shape_951 = new cjs.Shape();
	this.shape_951.graphics.f("#FFFFFF").s().p("AiwDJQgJgJAAgJQAAgNAKgvQARhVARjFQABgTANgPQANgQARAAQAJAAAGALQAGAJAAAPQAAANgEAQQgUBIgFBMQBTgOBBhdQAfgrAYgSQAXgTAaAAQALAAAKAKQALAJAAAOQAAARghAKQgRAFgPANQgPAMgqAwQghAmgaANIgCADQAAAAAAABQAAAAABAAQAAABAAAAQABAAABABQAZANAcAoQAqA5AUAPQAVAPAbAAIALgBQANAAAAAMQAAANgPAPQgQANgiAAQgbAAgZgWQgZgXghg0QgRgegRgRQgQgPgTAAQgFAAgVAGQgWAIgDAHQgCAGgCAoIgBBBQAAANgMAKQgNAKgOAAQgPAAgIgIg");
	this.shape_951.setTransform(1073.825,410.6);

	this.shape_952 = new cjs.Shape();
	this.shape_952.graphics.f("#FFFFFF").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_952.setTransform(1000.425,411.775);

	this.shape_953 = new cjs.Shape();
	this.shape_953.graphics.f("#FFFFFF").s().p("ABSAdQAAgLgJAAQghAAguAEQgwAEgVAGQgUAGgFAFQgFAFgDAWQgEAWAAAXIAAArQAAAmgjAAQgdAAAAgmQAAgYAHgmQALhGAMipQABgWADgGQACgGALgHQAKgHAMAAQAaAAAAAUIgIA1QgJAyAAAbQAAATAOAAQAaAABGgIQBHgKADgFQAEgHAIhRQAGhBAjAAQAdAAAAAdQAAAGgFAVQgbBwAABLQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQg3AAAAiqg");
	this.shape_953.setTransform(958.375,410.975);

	this.shape_954 = new cjs.Shape();
	this.shape_954.graphics.f("#FFFFFF").s().p("AiVESQgXgeAAgrQAAhQAjg8QAjg9AsgmQArgmBLgXQAagHAJgEQAJgFgBgKQgNg3gTgWQgSgWgegMQgfgMgYAAQgKAAgRAIQgTAHgKAGQgOAIgLAAQgOAAAAgOQAAgQAXgaQAXgbA6AAIAOAAQA5AAAsAeQAsAeASA4QATA4AABeQAAA/gpBbQgoBbg+AvQg+AvhGAAQgaAAgVgdgAgLgBQhiBaAAByQAAAPAGANQAEANAHAAQAaAAAWgJQAVgJAegdQAfgdAZgrQAZgrAMgoQALgnABgVIABgkQhSARgqAkg");
	this.shape_954.setTransform(919.6,401.075);

	this.shape_955 = new cjs.Shape();
	this.shape_955.graphics.f("#FFFFFF").s().p("AiED5Qg2gkAAgZQAAgMAFgLQAGgLAIAAQAEAAAFAGQAuBHBgAAQA8AAAehKQAehLAIhzQg1Axg2AcQg0AdgcAAQghAAgUgcQgTgcAAgoQAAg7AXhRQAWhRAMgLQAMgLAUAAQAKAAAGANQAGAMAAANQAAAJgIAOQguBQAABVQAAATAHAPQAIAOAPAAQATAAAdgKQAbgMAjgbQAkgbAMgQQANgRAFgVQAFgVAChGQAChHAgAAQATAAAGALQAFAJAAAdQAAAVgGBGIgCAdQgKC7guBqQguBrhXAAQhFAAg1gkg");
	this.shape_955.setTransform(875.325,420.375);

	this.shape_956 = new cjs.Shape();
	this.shape_956.graphics.f("#FFFFFF").s().p("AifEUQgXgrAAg0QAAhcA5hSQA4hRBAAAQAIAAAMAMQALAKAGgDQgOgjgvgqQgugoAAgcQAAgXAPgOQAPgOAogLQAxgOAzgRQA1gRAKgFQAHgDAGgBQAMABAAAUQAAAMgcAUQgcAUhHARQguAMgKAFQgIAFgBAGQAAANAbAXQBoBbAACHQAAA7ggBDQgeBDg0AhQgzAggxAAQgsABgXgsgAhLAqQgtBMAABBQAAAnAKAWQAKAVARAAQAXABAmgcQAlgcAYg2QAXg3AAgvQAAgngLgYQgLgZgJABQg+gBgsBMg");
	this.shape_956.setTransform(840.95,398.35);

	this.shape_957 = new cjs.Shape();
	this.shape_957.graphics.f("#FFFFFF").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_957.setTransform(767.825,411.775);

	this.shape_958 = new cjs.Shape();
	this.shape_958.graphics.f("#FFFFFF").s().p("AjBCwQAAgYAigpQAhgnA3hcQA2heAfhKQAHgNAMAAQAGAAAOAFQANAEAEAGQAEAFANA8QArDXAwAoQAMAKABADQACADAAAGQABALgIAJQgGAJgHACQgHADgUAAQgIAAgbgkQgbglgkihQgJgsgGgOQgJgBgHARQhJCQglA0IgIAOQgsBOgUAAQgbAAgBgag");
	this.shape_958.setTransform(724.25,411.025);

	this.shape_959 = new cjs.Shape();
	this.shape_959.graphics.f("#FFFFFF").s().p("AjTCtQgVgfAAg7QAAg+AQhMQAQhMAJgaIAHgWQAEgOAfgHQAFgDAFAAQAJAAAGAYQAAAPgIAXQgYBDAAAaQAAAHAEABQBRhOBFAAQAqAAAcAgQAdAgAAAbQAABRhTBLQhSBLhUAAQgmAAgVgfgAhBgzQgbAOghAfIgUARQgIAHgMACQgHAnAAAnQAAA1ApAAQAvAAA7g4QA5g5AAg0QAAgVgLgPQgMgPgTAAQgcAAgbAOgAB+CHQAAg+AbiSQAKg1AAgLQAAgWAIgQQAIgQAPAAQASAAAKAJQALAIAAALQAAALgFASQgcBkgGAnQgGApAAA3QAAAaAHAiIABAKQAAAHgLAKQgMAKgNAAQgiAAAAg/g");
	this.shape_959.setTransform(677.525,409.575);

	this.shape_960 = new cjs.Shape();
	this.shape_960.graphics.f("#FFFFFF").s().p("AifEUQgXgrAAg0QAAhcA5hSQA4hRBAAAQAIAAAMAMQALAKAGgDQgOgjgvgqQgtgoAAgcQAAgXAOgOQAPgOAogLQAxgOA0gRQA0gRAKgFQAHgDAGgBQAMABAAAUQAAAMgcAUQgcAUhIARQgsAMgLAFQgIAFgBAGQABANAaAXQBnBbABCHQAAA7ggBDQgfBDgzAhQgyAggyAAQgsABgXgsgAhLAqQguBMABBBQAAAnAKAWQALAVAQAAQAXABAmgcQAlgcAYg2QAXg3AAgvQAAgngLgYQgLgZgJABQg+gBgsBMg");
	this.shape_960.setTransform(634.75,398.35);

	this.shape_961 = new cjs.Shape();
	this.shape_961.graphics.f("#FFFFFF").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_961.setTransform(561.625,411.775);

	this.shape_962 = new cjs.Shape();
	this.shape_962.graphics.f("#FFFFFF").s().p("AkXDYQgJgJAAgIQACgOADgEQAfglAWgrQAWgqAihUQAjhWAJg2QAFgXAdAAQARAAAHAFQAGAFAHAQQAFARABAMIANBDIALBFQAFAdANAvQALAwAHAAQAFAAAJgWIAdhEIASgkIAohSQAhhEASgfQASgfAGgGQAGgGAIAAQANAAARAHQAQAHABAJIADBJIAEBuQACAzAFAlQAEAlALAWQAQAkAAAUQAAARgOAGQgNAGgNAAQgYAAgNgnQgOgngFi6QgCg4gFgMQgdAtg0BsQgLAZgMAXIgOAhQgmBVgbAAQgVAAgKgFQgKgFgJgYQgJgXgShXQgVhigHgXQgYA2gTAxQgcBJgaAvQgaAugMAJQgLAJgMAAQgKAAgJgIg");
	this.shape_962.setTransform(507.95,410.375);

	this.shape_963 = new cjs.Shape();
	this.shape_963.graphics.f("#FFFFFF").s().p("ABdCaQgPglAAhHIAAgMIAAgLQgtBLguAqQgvApgoAAQgYAAgYgbQgYgbAAg4QAAguAWhZQAThLAAgeQAKgVAWAAQAPAAAJALQAIAKAAALQAAAZgRAtQghBYAAA/QAAA5AbAAQAiAAA1g6QA0g6AlhnQAPgpAKgMQAJgNAQAAQAXAAAAAgQAAAEgGAVQgVBNAABEQAABSAbAYQAOANAAAJQAAAJgOAIQgPAJgLAAQgZAAgPglg");
	this.shape_963.setTransform(454.825,411.775);

	this.shape_964 = new cjs.Shape();
	this.shape_964.graphics.f("#FFFFFF").s().p("AiwDJQgJgJAAgJQAAgNAKgvQARhVARjFQABgTANgPQANgQARAAQAJAAAGALQAGAJAAAPQAAANgEAQQgUBIgFBMQBTgOBBhdQAfgrAYgSQAXgTAaAAQALAAAKAKQALAJAAAOQAAARghAKQgRAFgPANQgPAMgqAwQghAmgaANIgCADQAAAAAAABQAAAAAAAAQABABAAAAQABAAABABQAZANAcAoQAqA5AUAPQAVAPAbAAIALgBQANAAAAAMQAAANgPAPQgQANgiAAQgbAAgZgWQgZgXghg0QgRgegRgRQgQgPgTAAQgFAAgVAGQgWAIgDAHQgCAGgCAoIgBBBQAAANgMAKQgNAKgOAAQgPAAgIgIg");
	this.shape_964.setTransform(414.275,410.6);

	this.shape_965 = new cjs.Shape();
	this.shape_965.graphics.f("#FFFFFF").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_965.setTransform(370.675,410.975);

	this.shape_966 = new cjs.Shape();
	this.shape_966.graphics.f("#FFFFFF").s().p("Ag5DxQgMgRAAhRQAAhNAdjdIACgNQAAgMgNAAQgVAAg8AGQg7AFgZAAQgmAAgMgMQgEgHAAgKQAAgQAMgGQALgFA5gBQBGAAA4gFQA4gFBzgQQAsgGAnAAQAUAAATADQASACAHADQAIACAEAKQAFAKAAAGQAAAZgSAAQgLAAgUgCQgVgCgjAAQgjAAgzAFQg0AFgFAMQgGAMgNB9QgMB9AAA9QAAAdAIAlIACAIQAAAQgIAMQgIANgMAAQgTAAgMgSg");
	this.shape_966.setTransform(329.325,404.775);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_933},{t:this.shape_932},{t:this.shape_931},{t:this.shape_930},{t:this.shape_929},{t:this.shape_928},{t:this.shape_927},{t:this.shape_926,p:{x:795.425}},{t:this.shape_925},{t:this.shape_924},{t:this.shape_923},{t:this.shape_922,p:{x:973.1289}},{t:this.shape_921},{t:this.shape_920},{t:this.shape_919},{t:this.shape_918},{t:this.shape_917}]},446).to({state:[{t:this.shape_933},{t:this.shape_944},{t:this.shape_943},{t:this.shape_942},{t:this.shape_941},{t:this.shape_940},{t:this.shape_922,p:{x:810.9289}},{t:this.shape_926,p:{x:848.325}},{t:this.shape_939},{t:this.shape_938},{t:this.shape_937},{t:this.shape_936},{t:this.shape_935},{t:this.shape_934}]},20).to({state:[{t:this.shape_933},{t:this.shape_966},{t:this.shape_965},{t:this.shape_964},{t:this.shape_963},{t:this.shape_962},{t:this.shape_961},{t:this.shape_960},{t:this.shape_959},{t:this.shape_958},{t:this.shape_957},{t:this.shape_956},{t:this.shape_955},{t:this.shape_954},{t:this.shape_953},{t:this.shape_952},{t:this.shape_951},{t:this.shape_950},{t:this.shape_949},{t:this.shape_948},{t:this.shape_947},{t:this.shape_946},{t:this.shape_945}]},19).to({state:[{t:this.shape_933},{t:this.shape_966},{t:this.shape_965},{t:this.shape_964},{t:this.shape_963},{t:this.shape_962},{t:this.shape_961},{t:this.shape_960},{t:this.shape_959},{t:this.shape_958},{t:this.shape_957},{t:this.shape_956},{t:this.shape_955},{t:this.shape_954},{t:this.shape_953},{t:this.shape_952},{t:this.shape_951},{t:this.shape_950},{t:this.shape_949},{t:this.shape_948},{t:this.shape_947},{t:this.shape_946},{t:this.shape_945}]},37).to({state:[]},39).wait(747));

	// глазки
	this.instance_49 = new lib.Анимация25("synched",0);
	this.instance_49.setTransform(804.1,188.85);
	this.instance_49._off = true;

	this.instance_50 = new lib.Анимация26("synched",0);
	this.instance_50.setTransform(825.85,176);
	this.instance_50._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_49).wait(412).to({_off:false},0).to({_off:true,x:825.85,y:176},12).wait(884));
	this.timeline.addTween(cjs.Tween.get(this.instance_50).wait(412).to({_off:false},12).to({rotation:-6.7325,x:712.5,y:201.85},12).to({_off:true},11).wait(861));

	// Слой_29
	this.instance_51 = new lib.Анимация23("synched",0);
	this.instance_51.setTransform(809.55,282.9);
	this.instance_51._off = true;

	this.instance_52 = new lib.Анимация24("synched",0);
	this.instance_52.setTransform(830.75,270.55);
	this.instance_52._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_51).wait(412).to({_off:false},0).to({_off:true,x:830.75,y:270.55},12).wait(884));
	this.timeline.addTween(cjs.Tween.get(this.instance_52).wait(412).to({_off:false},12).to({rotation:-10.2005,x:733,y:292.25},12).to({_off:true},11).wait(861));

	// Каркас_19
	this.shape_967 = new cjs.Shape();
	this.shape_967.graphics.f("#232323").s().p("EgGUAySQhUgog+hHQgzhNALhmQADgpANgyIAFgTQgDg2AJg9QAPimgDioQgFhwgShvIhMo2IgNgBQgkgBhIgLIjhMPQgxCuhDCnQhLCjiHB9QhLA/hfAcQhPAVhUgIQhfgFhcghQhZglgxhaQgshjA0hwQAzhzBBhqQAQg+gGhDQgLomg7oiQgTizguivQgUhBgSg/QgIgwAKgmIhGmgIgtkPQgijRgYjUQgtmsAJmuIAEizQgghJgehWQhJjWgZjBQgfhogHhpIgBgdQgHgQgEgSQgIgfgGhHQgYkyg6kvQgEg8AIg7QAOg6AygoQA2ghBFAOQCfAOCNBYQCfBaCKB7IAEADQB/gjCFgGQB0gDBuAsQAgAQAbAXQA8hKA/hHQA9hFBChBQAxgvA7giQBBgcBJAIQBlAGBUA9QAtAoAWBKQAKAhAFAuQAHAcAEAhQAOBwgEByQAADcgbDaIgHAkIgGDCQAAAiALAgQAWArAuAXQAYAVAdAlIAHAJIAYAQQEACyDpDNQA3A2AvA8QA6BNAtBVQAeAwAJASQAOAcAEAYQBxDABLDSQAcBPAWBRQAyCsAkCvQBMFKAPFVQgEBSgRBkIgMBGIBPgSQBXgVA+gYQAvgSAwgZQC4iECZiqQBJhIBBhPQAzhDAnhLQBXiZBGijQAshjAohmIBwkYIAGgQQAyh7Akh/QAWhjAihhQAxhaBzgHQBLANAhBUQAdBGgMBPQgGBqgeB0IAAAFIABAKQACAcgGAnQgkEMiPDwIgxBkIgTAmQhACQhiC9QghBAgmA8QhcCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh0BhQjRCdkDBGQhpAmhxAUIgPAYQivEYhwE7IhJDiIhRD/QhHDwhaDoQhDCIhhB1QgvA3hAAjQgnAPgoAAQhGAAhHgtg");
	this.shape_967.setTransform(975.1374,418.5317);

	this.shape_968 = new cjs.Shape();
	this.shape_968.graphics.f("#232323").s().p("EgGhAyRQhUgng+hIQgzhNALhlQADgpANgzIAFgSQgDg2AJg9QAPingDinQgFhxgShvIhMo2IgNgBQgkAAhIgMQhxGJiVGDQgzCthFCmQhNCiiKB7QhLA+hgAcQhPAThUgKQhfgGhcghQhYgogwhaQgqhkA1hvQA1hxBChqQASg+gGhDQgColg0okQgRizgsiwQgShAgRhBQgIgvALgmIhBmhIgpkOQgejUgXjKQgqmsAMmuIAFizQgfhJgehXQhHjVgYjCQgehogGhqIgBgdIgLgiQgHgegGhIQgWkyg3kvQgEg8AJg7QANg6AzgnQA2giBFAPQCfAQCNBZQCeBbCJB7IAEAEQB/gjCFgEQB0gCBuAsQAgAQAbAXQA9hJA/hGQA9hFBChBQAygvA7ghQBBgbBKAIQBkAGBUA+QAtAqAVBJQAKAhAFAuQAHAcADAhQANBwgFByQgBDcgdDaIgHAkIgHDCQAAAiAKAgQAWArAuAYQAXAUAdAlIAHAJIAYARQD+C0DoDPQA2A1AvA9QA5BOAuBVQAdAwAJASQAOAcADAYQBwDABJDTQAcBPAWBSQAwCsAkCkQBMFLAPFVQgEBSgRBjIgMBHIBPgTQBXgVA+gXQAvgTAwgYQC4iECZiqQBJhJBBhPQAzhCAnhMQBXiYBGiQQAshjAphmIBykYIAHgPQAyh6Alh/QAXhkAihgQAyhZBzgHQBLANAhBUQAcBIgMBOQgHBpgfB0IAAAGIABAJQABAcgGAnQgmEMiRDvQgkBJgMAFIgTAnQhACQhiC8QghBAgmA9QhcCIh3BzQg4BJgUATIgSAQQgpAxgzA3QhlBwh0BhQjRCekDBGQhpAlhxAVIgPAXQivEZhwE6IhJDjIhRD/QhHDvhaDoQhDCJhhB0QgvA3hAAjQgnAQgoAAQhFAAhIgug");
	this.shape_968.setTransform(976.429,418.5603);

	this.shape_969 = new cjs.Shape();
	this.shape_969.graphics.f("#232323").s().p("EgGuAyTQhUgog+hHQgzhNALhmQADgpANgyIAFgTQgDg2AJg9QAPimgDioQgFhwgShvIhMo2IgNgBQgkgBhIgLQhxGIi5GAQg3CshHClQhPChiLB5QhNA8hgAbQhPAShUgLQhfgGhbgkQhXgpgvhaQgphlA3hvQA2hwBEhpQASg+gFhDQAGolgsokQgPi0goiwQgThAgPhBQgHgvALgnIg6mhIgmkPQgbjUgVjBQgmmrAOmvIAGizQgfhJgdhXQhFjWgXjBQgdhpgFhpIgBgdQgHgQgEgTQgHgegFhIQgVkyg0kvQgEg8AJg8QAPg5AygnQA3ghBFAPQCeARCNBaQCdBcCIB8IAEAEQCAghCFgEQBzgCBuAtQAgARAbAXQA9hJBAhGQA9hDBDhBQAygvA8ghQBBgbBJAKQBkAHBUA+QAtAqAUBJQAKAhAEAuQAHAdADAgQANBxgGBxQgDDdgfDZIgHAkIgIDCQgBAiAKAgQAVArAvAYQAXAVAdAlIAGAKIAYAQQD9C2DnDQQA2A2AuA+QA5BNAsBWQAeAwAIASQANAcAEAZQBvDBBHDTQAbBPAWBSQAuCsAkCaQBMFKAPFVQgEBSgRBkIgMBGIBPgSQBXgVA+gYQAvgSAwgZQC4iECZiqQBJhIBBhPQAzhDAnhLICdkWQAthjAphlIB0kXIAHgPQAzh6Amh/QAYhjAihgQAzhZBzgGQBLAPAgBTQAcBIgNBOQgIBqgfBzIAAAGIAAAJQACAcgHAnQgoELiSDuQgkBIgMgPIgTAmQhACQhiC9QghBAgmA8QhcCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh0BhQjRCdkDBGQhpAmhxAUIgPAYQivEYhwE7IhJDiIhRD/QhHDwhaDoQhCCIhiB1QgvA3hAAjQgnAPgoAAQhFAAhIgtg");
	this.shape_969.setTransform(977.7071,418.4277);

	this.shape_970 = new cjs.Shape();
	this.shape_970.graphics.f("#232323").s().p("EgG7AyYQhUgog9hHQg0hNAMhmQADgpAMgyIAFgTQgDg2AJg9QAPimgCioQgFhwgThvIhLo2IgNgBQglgBhIgLQg4DEhrC/QhfDAhMDAQg5CrhKClQhRCgiNB3QhOA7hgAZQhQARhUgMQhegJhbgkQhXgqgthbQgnhlA4huQA4hvBFhoQATg+gDhDQANolgkolQgMi0gmixQgShAgOhBQgHgvAMgnIg0miIgikQQgYjTgUi4QgkmsASmuIAIizQgfhJgchXQhEjXgVjBQgdhpgEhqIgBgdQgGgPgEgTQgHgegFhIQgSkygzkwQgDg8AKg7QAPg6AygmQA3ghBFAQQCfASCLBbQCdBdCHB9IAEAEQCAggCFgEQB0AABtAuQAfAQAbAYQA+hJBAhFQA/hDBDhBQAxgtA9ghQBBgaBJAJQBkAIBUA/QArAqAVBJQAJAiAEAtQAHAdADAgQAMBygHBxQgFDcggDZIgHAkIgKDCQAAAiAJAgQAVArAuAZQAXAUAcAmIAHAJIAYARQD8C3DlDTQA1A2AuA+QA4BNAsBXIAmBCQANAcADAZQBtDCBGDTQAbBQAVBSIBRE7QBMFKAOFVQgDBSgRBkIgNBGIBQgSQBWgVA+gYQAwgSAvgZQC4iECZiqQBJhIBChPQAzhDAnhLQBWiZBFhqQAuhjAqhkIB3kWIAGgQQA0h5Anh+QAZhkAjhfQAzhZBzgFQBLAPAfBUQAbBIgNBNQgIBqghB0IABAFIAAAKQABAcgGAmQgrELiUDtQgSAkgLgHQgLAAgGAGIgUAmQg/CQhiC9QghBAgnA8QhbCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh1BhQjQCdkEBGQhpAmhwAUIgPAYQiwEYhvE7IhKDiIhQD/QhHDwhbDoQhBCIhjB1QguA3hAAjQgoAPgoAAQhFAAhIgtg");
	this.shape_970.setTransform(978.9753,417.9008);

	this.shape_971 = new cjs.Shape();
	this.shape_971.graphics.f("#232323").s().p("EgHIAydQhUgng9hIQg0hNAMhlQADgpAMgzIAFgSQgDg2AJg9QAPingCinQgFhxgThvIhLo2IgNgBQglAAhIgMQg4DEh8C+QhsC+hTC/Qg7CrhMCiQhUCfiOB2QhPA6hgAXQhQAQhUgNQhfgKhagmQhWgrgshcQgmhmA6htQA6huBGhnQAVg+gEhDQAVolgcolQgJi0gkixQgQhBgOhBQgGgvAMgmIgumkIgdkPIgomCQggmsAUmuIAJizQgehKgbhXQhDjXgUjCQgbhpgEhpIgBgdIgKgiQgGgfgFhIQgPkygxkwQgDg8AKg7QAPg5AzgnQA3ggBFAQQCeAUCLBbQCcBfCGB+IAEADQCBgfCFgCQBzABBtAuQAgAQAaAYQA/hIBAhEQA/hEBDg/QAzguA8ggQBCgaBJAKQBkAJBTA/QArAqAUBKQAJAiAEAtQAGAdADAhQALBwgIByQgGDcghDZIgIAkIgLDBQgBAiAJAgQAVAtAuAYQAXAVAcAmIAHAJIAXARQD7C5DjDUQA1A3AuA9QA3BOArBXQAdAwAIATQANAcADAZQBsDCBFDUQAZBQAVBSQAsCtAkCDQBMFLAOFVQgDBSgRBjIgNBHIBQgTQBWgVA+gXQAwgTAvgYQC4iECZiqQBJhJBChPQAzhCAnhMQArhNAlgoQAmgzAlhHIBZjHIB4kVIAHgPQA1h6Anh+QAZhjAlhfQAzhYB0gFQBKAQAfBUQAbBIgOBOQgJBqgiBzIABAFIAAAKQABAcgHAmQgtELiVDrQgSAkgKgSQgLgHgGACIgUAnQg/CQhiC8QghBAgnA9QhbCIh3BzQg4BJgUATIgSAQQgpAxgzA3QhlBwh1BhQjQCekEBGQhpAlhwAVIgPAXQiwEZhvE6IhKDjIhQD/QhHDvhbDoQhBCJhjB0QguA3hAAjQgnAPgpAAQhFAAhIgtg");
	this.shape_971.setTransform(980.2557,417.3954);

	this.shape_972 = new cjs.Shape();
	this.shape_972.graphics.f("#232323").s().p("EgHUAyiQhUgng+hIQgzhNALhlQADgpANgzIAFgSQgDg2AJg9QAPingDinQgFhxgShvIhMo2IgNgBQgkAAhIgMQg4DEiNC7Qh6C9hZC+Qg+CphOCiQhWCeiQBzQhPA5hhAWQhQAPhUgPQhfgLhZgnQhVgsgrhdQglhmA8hsQA7huBIhmQAVg+gChCQAdokgUomQgHi0ghiyQgQhBgNhCQgEgvAMgmIgomkIgakQQgSjVgSijQgdmsAYmuIAKizQgdhJgbhYQhBjYgTjBQgbhpgDhqIAAgdQgGgPgEgTQgGgfgEhIQgOkygukwQgCg8AKg7QAPg6A0glQA3ggBEAQQCfAVCKBcQCcBgCFB/IADAEQCBgfCFgBQBzABBtAwQAfAQAbAZQA/hIBBhEQA/hDBEg/QAzgtA8ggQBCgaBJALQBkAJBSBAQAsArASBKQAJAhAEAuQAGAdACAgQALBygJBwQgHDdgjDYIgIAkIgNDCQgBAiAJAfQAVAtAtAYQAXAVAcAnIAGAJIAYARQD5C7DiDVQA0A3AtA/QA3BOArBXQAcAwAJATQAMAcADAZQBrDDBDDVQAZBPAUBTQArCsAjB5QBMFLAPFVQgEBSgRBjIgMBHIBPgTQBXgVA+gXQAvgTAwgYQC4iECZiqQBJhJBBhPQAzhCAnhMQArhNAlgfQAlgsAlhFQAvhhArhkIB7kUIAHgQQA1h4Aph+QAZhjAmhfQA0hYBzgDQBLAQAeBUQAZBIgOBOQgJBpgiBzIAAAGIAAAJQABAcgHAnQgvEKiXDqQgSAkgKgdQgKgQgGAAIgTAnQhACQhiC8QghBAgmA9QhcCIh3BzQg4BJgUATIgSAQQgpAxgzA3QhlBwh0BhQjRCekDBGQhpAlhxAVIgPAXQivEZhwE6IhJDjIhRD/QhHDvhaDoQhCCJhiB0QgvA3hAAjQgnAPgoAAQhFAAhIgtg");
	this.shape_972.setTransform(981.5071,416.8814);

	this.shape_973 = new cjs.Shape();
	this.shape_973.graphics.f("#232323").s().p("EgHhAynQhUgng9hIQg0hNAMhlQADgpAMgzIAFgSQgDg2AJg9QAPingCinQgFhxgThvIhLo2IgNgBQglAAhIgMQg4DEieC5QiGC7hgC8QhACohRChQhYCciSByQhPA3hiAVQhRAOhTgQQhegMhZgpQhVgtgphdQgjhoA9hqQA8huBKhkQAWg+gBhCQAlokgNomQgEi0gfizQgPhBgLhBQgEgxANgkIgjmlIgVkQQgQjVgQiaQgbmsAcmuIALiyQgdhKgahYQhAjYgRjCQgahpgChpIAAgdQgHgRgDgSQgGgegDhIQgLkzgtkwQgCg8ALg7QAQg5A0gmQA3gfBEARQCfAWCJBdQCbBhCECAIAEAEQCAgeCFAAQB0ACBsAwQAfARAaAYQA/hHBChEQBAhCBEg/QAzgtA9gfQBCgYBJALQBkAKBSBAQArArASBKQAJAgADAvQAGAdACAgQAJBxgJBxQgJDdgkDYIgJAkIgODBQgBAhAJAhQAUAsAuAZQAWAVAcAnIAGAJIAXASQD5C8DfDXQA1A3AsA/QA2BPArBXQAcAwAIATQAMAcADAZQBpDEBBDVQAZBPATBTQAVBXATA2QASA/AUBPQBMFLAOFVQgDBSgRBjIgNBHIBQgTQBWgVA+gXQAwgTAvgYQC4iECZiqQBJhJBChPQAzhCAnhMQArhNAjgWQAlglAlhCQAwhhAshkIB8kTIAHgPQA2h4Aqh+QAbhiAlhfQA1hXBzgDQBLAQAdBVQAaBIgPBOQgLBpgjBzIAAAGIABAJQAAAcgHAmQgwEKiZDpQgTAjgIgnQgKgYgFgDIgUAnQg/CQhiC8QghBAgnA9QhbCIh3BzQg4BJgUATIgSAQQgpAxgzA3QhlBwh1BhQjQCekEBGQhpAlhwAVIgPAXQiwEZhvE6IhKDjIhQD/QhHDvhbDoQhBCJhjB0QguA3hAAjQgnAPgpAAQhFAAhIgtg");
	this.shape_973.setTransform(982.7688,416.3996);

	this.shape_974 = new cjs.Shape();
	this.shape_974.graphics.f("#232323").s().p("EgHtAysQhUgog+hHQgzhNALhmQADgpANgyIAFgTQgDg2AJg9QAPimgDioQgFhwgShvIhMo2IgNgBQgkgBhIgLQg4DEivC2QiTC4hnC7QhCCnhTCgQhbCbiTBvQhQA2hiAUQhRAMhTgQQhfgOhYgqQhUgugoheQghhoA+hqQA/hsBKhkQAXg8AAhDQAtokgFolQgCi1gcizQgOhBgKhCQgEgwAOglIgdmlIgRkQQgHhrgIhIQgHhRgGhiQgXmsAemtQAFhmAHhMQgdhKgZhYQg+jZgPjBQgahqgBhpIAAgdQgGgQgEgTQgGgegChIQgJkygrkxQgBg8ALg7QARg5AzglQA5gfBDARQCeAYCJBeQCaBhCDCBIAEAEQCBgdCFABQBzADBsAxQAfARAaAZQA/hHBDhDQBAhCBFg+QAzgtA9gfQBCgYBJAMQBkAKBRBBQArAsASBJQAHAiAEAuQAGAdACAgQAIBygKBwQgLDcgmDYIgIAkIgPDBQgCAiAJAgQATAtAuAZQAWAVAbAnIAHAJIAXASQD3C+DeDYQA0A4AsA/QA2BPApBYQAcAxAIASQAMAcACAZQBoDFBADVQAYBQATBTQAUBWASAxQATA7ATBOQBMFKAPFVQgEBSgRBkIgMBGIBPgSQBXgVA+gYQAvgSAwgZQC4iECZiqQBJhIBBhPQAzhDAnhLQArhNAjgOQAjgdAmg/IBdjEIB+kSIAHgQQA4h4Aqh9QAchiAlheQA2hYBzgBQBLARAcBVQAZBIgPBNQgLBpgkBzIAAAGIAAAJQAAAcgHAnQgyEJibDnQgTAkgHgzQgIgggGgFIgTAmQhACQhiC9QghBAgmA8QhcCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh0BhQjRCdkDBGQhpAmhxAUIgPAYQivEYhwE7IhJDiIhRD/QhHDwhaDoQhCCIhiB1QgvA3hAAjQgnAPgoAAQhFAAhIgtg");
	this.shape_974.setTransform(984.013,415.9328);

	this.shape_975 = new cjs.Shape();
	this.shape_975.graphics.f("#232323").s().p("EgH6AywQhUgng9hIQg0hNAMhlQADgpAMgzIAFgSQgDg2AJg9QAPingCinQgFhxgThvIhLo2IgNgBQglAAhIgMQg4DEi/CzQihC2htC5QhFCnhVCeQhdCaiUBtQhSA2hiASQhRALhSgSQhfgPhXgrQhUgwgmheQgghoBAhqQBAhrBMhjQAXg8ABhDQA1oiADomQABi1gaizQgMhBgKhCQgDgwAOglIgWmmIgOkRQgFhqgHhDQgHhNgFhhQgUmtAhmsQAGhmAHhMQgbhKgahYQg8jZgOjCQgZhpgBhqIABgdQgGgQgDgSQgGgggChHQgHkygokxQgBg8AMg7QAQg5A0gkQA5gfBDASQCeAYCIBfQCaBjCBCCIAEAEQCBgcCFACQBzAEBsAxQAfASAaAYQBAhGBChDQBBhBBFg+QAzgsA+geQBCgYBJAMQBkALBQBCQArAsARBJQAIAiADAuIAHA9QAIBygLBwQgMDcgoDYIgJAjIgQDBQgCAiAIAgQAUAtAtAZQAWAWAbAnIAGAJIAXASQD2DADcDaQAzA4AsA/QA2BQAoBXQAbAxAIATQAMAcADAZQBmDGA+DVQAYBQASBTQATBXATArQASA3AUBMQBMFLAOFVQgDBSgRBjIgNBHIBQgTQBWgVA+gXQAwgTAvgYQC4iECZiqQBJhJBChPQAzhCAnhMQArhNAhgEQAjgXAlg8QAxhhAuhiICAkRIAHgPQA5h4Aqh8QAdhiAmhfQA2hXB0AAQBKARAcBVQAZBIgRBOQgMBpgkByIAAAGIAAAJQAAAcgIAnQgzEJicDlQgUAjgGg9QgHgogFgIIgUAnQg/CQhiC8QghBAgnA9QhbCIh3BzQg4BJgUATIgSAQQgpAxgzA3QhlBwh1BhQjQCekEBGQhpAlhwAVIgPAXQiwEZhvE6IhKDjIhQD/QhHDvhaDoQhCCJhjB0QguA3hAAjQgnAPgoAAQhGAAhIgtg");
	this.shape_975.setTransform(985.252,415.478);

	this.shape_976 = new cjs.Shape();
	this.shape_976.graphics.f("#232323").s().p("EgHyAy1QhUgog+hHQgzhNALhmQADgpANgyIAFgTQgDg2AJg9QAPimgDioQgFhwgShvIhMo2IgNgBQgkgBhIgLQg4DEjRCwQitCzh0C3QhHCmhXCdQhfCZiWBqQhTA1hiAQQhRAKhSgTQhegQhXgsQhTgyglheQgfhpBChoQBBhrBOhhQAYg8AChDQA8oiALomQAEi0gXizQgMhCgJhCQgCgwAOglIgQmlIgKkSQgDhqgGg+QgGhKgFhfQgRmtAkmsIAPiyQgchKgYhYQg7jagNjBQgXhqAAhpIAAgdQgFgQgEgTQgGgegBhIQgFkygmkxQAAg8AMg7QASg4A0glQA3geBEASQCeAZCHBhQCZBkCBCCIADAEQCCgbCFADQBzAEBrAyQAfASAZAZQBBhGBDhCQBBhBBGg9QAzgsA+geQBCgXBJANQBkAMBQBCQAqAsAQBKQAJAiACAtQAFAeABAgQAIBxgMBxQgODbgpDYIgJAjIgSDBQgCAiAIAgQATAsAtAaQAWAWAbAnIAGAJIAXASQD0DCDaDbQAzA5AsA/QA0BQAoBYQAbAxAIATQAMAcACAZQBlDGA9DWQAWBRASBSQATBXASAmQATAzATBLQBMFKAPFVQgEBSgRBkIgMBGIBPgSQBXgVA+gYQAvgSAwgZQC4iECZiqQBJhIBBhPQAzhDAnhLQArhNAgAEQAigQAmg5QAxhgAvhiICCkQIAHgPQA5h3Ash8QAchiAoheQA3hXBzAAQBKATAbBVQAYBJgQBMQgNBpglByIAAAGIAAAJQAAAcgJAnQg1EIieDkQgUAjgEhIQgGgwgFgKIgTAmQhACQhiC9QghBAgmA8QhcCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh0BhQjRCdkDBGQhpAmhxAUIgPAYQivEYhwE7IhJDiIhRD/QhHDwhZDoQhDCIhiB1QgvA3hAAjQgnAPgoAAQhFAAhIgtg");
	this.shape_976.setTransform(984.5016,415.0342);

	this.shape_977 = new cjs.Shape();
	this.shape_977.graphics.f("#232323").s().p("EgHfAy5QhUgog9hHQg0hNAMhmQADgpAMgyIAFgTQgDg2AJg9QAPimgCioQgFhwgThvIhLo2IgNgBQglgBhIgLQg4DEjhCsQi6Cxh6C1QhKClhZCcQhiCXiXBpQhTAzhiAPQhSAJhSgUQhdgShXguQhSgygkhfQgehpBEhoQBDhpBPhgQAZg8ADhDQBEohATolQAGi1gUi0QgLhCgIhCQgCgwAPgkIgKmmIgGkRQgChrgGg5QgFhGgEheQgOmsAnmsIAQiyQgbhLgXhXQg5jagMjCQgXhpABhqIAAgdQgFgQgDgSQgFgggBhHQgDkygkkxQAAg8ANg7QARg4A1gkQA4geBEATQCdAbCGBgQCYBmCACDIAEAEQCCgaCEADQBzAGBqAzQAgASAZAZQBBhGBEhBQBBhBBGg8QA0gsA+gdQBCgXBIANQBkANBQBDQAqAsAQBKQAHAiADAuQAEAcACAhQAGBxgMBxQgQDbgqDXIgKAjIgTDBQgCAiAIAgQASAtAtAaQAWAWAaAnIAGAJIAXASQDyDDDZDdQAzA5ArBAQA0BQAnBYQAbAyAHASQAMAdACAZQBjDHA8DWQAWBQARBTQASBXATAhQASAuAUBKQBMFKAOFVQgDBSgRBkIgNBGIBQgSQBWgVA+gYQAwgSAvgZQC4iECZiqQBJhIBChPQAzhDAnhLQArhNAeAOQAhgKAmg2QAyhgAvhhICEkPIAHgPQA6h3Ath8QAdhhAoheQA3hWB0ABQBJATAbBVQAYBIgRBOQgOBogmByIAAAGIAAAJQAAAcgJAmQg3EIifDiQgUAjgDhSQgFg4gEgNIgUAmQg/CQhiC9QghBAgnA8QhbCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh1BhQjQCdkEBGQhpAmhwAUIgPAYQiwEYhvE7IhKDiIhQD/QhHDwhbDoQhBCIhjB1QguA3hAAjQgoAPgoAAQhFAAhIgtg");
	this.shape_977.setTransform(982.5726,414.603);

	this.shape_978 = new cjs.Shape();
	this.shape_978.graphics.f("#232323").s().p("EgHMAy9QhUgog9hHQg0hNAMhmQADgpAMgyIAFgTQgDg2AJg9QAPimgCioQgFhwgThvIhLo2IgNgBQglgBhIgLQg4DEjxCpQjHCuiBCzQhMCjhcCbQhjCWiZBmQhTAyhjAOQhSAIhSgWQhdgThWguQhRg0gjhgQgbhpBEhmQBFhpBQhfQAag8AEhDQBLofAbomQAJi0gSi0QgKhCgHhCQAAgwAPgkIgEmmIgCkSQgBhqgFg1QgFhCgDhdQgLmsAqmrIARiyQgahKgXhYQg3jagLjCQgWhqAChpIAAgdQgFgQgDgTQgFgfAAhHQgBkyghkxQAAg8ANg7QASg4A1gkQA4gdBDATQCdAcCGBiQCXBmB/CEIAEAEQCCgZCEAEQBzAGBqA0QAfASAZAaQBChFBDhBQBChABHg8QA0grA+gdQBDgXBIAOQBjANBPBEQAqAsAPBKQAIAiACAuQAEAdABAgQAGBygNBwQgRDbgsDXIgKAjIgVDAQgDAiAIAgQATAtAsAbQAWAWAaAnIAGAJIAXATQDwDEDYDeQAyA6AqBAQA0BQAnBZQAaAxAHATQAMAdACAYQBhDIA6DWQAVBRARBTQASBXASAbQATAqAUBJQBMFKAOFVQgDBSgRBkIgNBGIBQgSQBWgVA+gYQAwgSAvgZQC4iECZiqQBJhIBChPQAzhDAnhLQArhNAcAXQAggCAmg1QAzheAvhiICGkNIAIgPQA6h3Auh7QAehhAphdQA3hWB0ABQBJAUAbBVQAWBIgRBOQgOBognByIAAAFIAAAKQgBAbgJAnQg5EHihDhQgUAjgBheQgEg/gDgQIgUAmQg/CQhiC9QghBAgnA8QhbCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh1BhQjQCdkEBGQhpAmhwAUIgPAYQiwEYhvE7IhKDiIhQD/QhHDwhbDoQhBCIhjB1QguA3hAAjQgnAPgpAAQhFAAhIgtg");
	this.shape_978.setTransform(980.6639,414.211);

	this.shape_979 = new cjs.Shape();
	this.shape_979.graphics.f("#232323").s().p("EgG5AzBQhUgog9hHQg0hNAMhmQADgpAMgyIAFgTQgDg2AJg9QAPimgCioQgFhwgThvIhLo2IgNgBQglgBhIgLQg4DEkCClQjUCriHCxQhOCiheCaQhmCUiaBkQhUAxhjAMQhRAHhSgXQhdgUhVgwQhQg1gihgQgbhpBHhmQBFhoBSheQAbg7AFhDQBUoeAiolQAMi0gQi0QgJhDgGhCQAAgwAQgkIACmmIABkRQAChrgFgvQgEg/gDhcQgImsAtmqIATixQgahLgXhYQg2jagIjCQgWhrAChoIABgdIgIgjQgEgfAAhHQABkygfkxQABg8ANg7QASg4A1gjQA5gdBDAUQCdAcCFBjQCWBnB+CFIAEAEQCCgYCEAGQBzAHBpA0QAfASAZAaQBChEBEhBQBDg/BGg8QA1gqA+gdQBCgWBJAOQBjAOBPBEQApAtAPBKQAHAiACAuQAEAcABAhQAEBxgNBwQgTDbguDWIgKAjIgWDBQgCAhAHAgQASAuAtAaQAVAXAaAnIAGAJIAXATQDtDGDXDgQAzA6ApBAQAzBQAmBZQAaAyAHATQALAcACAZQBhDIA3DXQAVBQAQBTQARBYATAWQATAmAUBHQBMFKAOFVQgDBSgRBkIgNBGIBQgSQBWgVA+gYQAwgSAvgZQC4iECZiqQBJhIBChPQAzhDAnhLQArhNAaAgQAfAFAmgzQA0heAwhgICHkNIAIgPQA7h1Avh7QAfhiAphcQA4hWB0ADQBJAUAZBVQAXBJgSBNQgPBogoBxIAAAGIAAAJQgBAcgJAmQg7EHiiDfQgVAjABhoQgChIgDgSIgUAmQg/CQhiC9QghBAgnA8QhbCIh3BzQg4BJgUATIgSAQQgpAygzA3QhlBwh1BhQjQCdkEBGQhpAmhwAUIgPAYQiwEYhvE7IhKDiIhQD/QhHDwhbDoQhBCIhjB1QguA3hAAjQgnAPgpAAQhFAAhIgtg");
	this.shape_979.setTransform(978.7531,413.816);

	this.shape_980 = new cjs.Shape();
	this.shape_980.graphics.f("#232323").s().p("EgGnAyzQhVgng+hGQg1hMAKhmQADgpAMgzIAEgSQgDg2AIg9QANingFinQgHhxgUhuIhTo1IgNgBQgkAAhIgKQg2DEj0CrQjICwiAC0QhLClhaCbQhiCWiYBoQhTAzhjAPQhRAJhTgVQhdgThWgtQhSgzgjhgQgdhpBEhnQBDhpBPhgQAag8ADhCQBHohAWolQAHi0gUi1QgKhCgIhCQgBgwAPgkIgImmIgFkRQgBhrgGgzQgFhBgFhcQgPmsAlmrIAPiyQgbhKgYhYQg6jagMjBQgXhqAAhpIAAgdQgFgQgEgTQgFgegBhIQgFkxgkkyQAAg8AMg6QARg4A0glQA5geBDATQCdAZCHBhQCZBkCACDIAEAEQCBgaCEACQB0AGBqAyQAfASAZAZQBChGBChCQBChABFg9QA0gsA+geQBCgXBIANQBkAMBQBDQAqAsAQBKQAIAhACAuQAGAdABAhQAHBwgNBxQgODbgqDXIgJAkIgSDAQgCAiAIAgQATAtAsAaQAWAWAbAmIAGAKIAXASQDyDCDaDcQAzA4ArBAQA1BQAnBYQAbAxAIATQALAcADAZQBkDGA8DWQAWBQASBTQATBXASAZQATApAVBHQBQFKAUFVQgDBSgQBkIgLBGIBPgTQBWgWA+gZQAvgSAvgaQC3iHCWisQBIhJBBhQQAyhEAmhLQAqhOAcAaQAggBAlgzQAyhgAuhiICDkPIAHgPQA6h3Ash8QAdhhAoheQA2hWB0AAQBJASAcBWQAXBIgQBNQgOBpglBxIAAAGIAAAJQAAAcgJAnQg2EIieDiQgUAjgChgQgEhCgEgRIgTAmQg9CRhgC+QggBAgmA+QhZCIh2B1Qg3BKgTATIgSARIhbBqQhjBxh0BiQjOChkCBJQhpAnhwAWIgPAYQirEbhsE7IhGDkQgoCAglCAQhEDxhXDpQhBCJhgB2QguA3g/AkQgpAQgpAAQhEAAhHgrg");
	this.shape_980.setTransform(976.5568,414.6403);

	this.shape_981 = new cjs.Shape();
	this.shape_981.graphics.f("#232323").s().p("EgGNAylQhWgmg/hFQg2hMAJhmQADgpAKgzIAFgSQgFg2AIg9QAKiogHinQgIhvgVhvIhbo0IgNAAQgkgBhJgIQgzDFjmCwQi8C1h6C3QhGCmhXCdQhfCZiVBsQhSA0hiARQhRALhTgTQhegQhXgsQhTgwglhfQgghoBChpQBAhrBOhiQAYg8AChDQA5oiAJomQADi0gYi0QgMhBgJhCQgCgwAOglIgSmlIgLkRQgDhrgIg2QgGhEgHhdQgYmsAemsIAMiyQgchKgahXQg+jZgQjBQgZhpgChqIAAgcQgGgRgDgSQgGgfgDhHQgJkygrkwQgCg8AMg7QAQg5A0glQA3gfBEASQCeAWCJBeQCaBiCDCAIADAEQCBgdCFABQBzACBrAxQAgASAaAYQBAhHBBhDQBAhCBFg+QAzgsA9gfQBCgZBIAMQBkAKBRBBQArArASBKQAIAiAEAtQAFAdACAhQAJBwgKBxQgLDbglDZIgJAjIgPDBQgBAiAJAgQATAsAuAZQAWAVAbAnIAHAJIAXASQD2C+DeDXQA0A4AsA/QA2BPApBXQAcAwAIATQAMAdADAYQBnDFBBDUQAYBRATBSQAUBWATAdQAUArAVBJQBVFIAYFVQgCBSgOBkIgKBGIBPgUQBVgXA+gZQAugUAwgaQC0iKCUitQBIhLA/hQQAxhEAlhNQAphNAeATQAggGAkg3QAwhgAthjIB+kSIAHgPQA3h3Aqh+QAbhiAmheQA1hXB0gCQBJARAdBVQAaBHgQBOQgLBpgkByIABAGIAAAJQAAAcgHAnQgyEJiaDmQgTAkgEhaQgHg9gEgPIgSAnQg8CShdC/QgeBBgmA9QhXCKh0B3Qg3BKgTAUIgRARIhaBrQhiBzhxBjQjNCjkBBNQhoAohwAYIgOAYQioEdhnE9IhEDlIhJEBQhBDxhUDqQg/CLheB3QgtA4g/AlQgqARgrAAQhCAAhGgpg");
	this.shape_981.setTransform(973.5782,415.4989);

	this.shape_982 = new cjs.Shape();
	this.shape_982.graphics.f("#232323").s().p("EgE+AyVQhWgkhAhFQg3hLAIhmQABgpALgzIAEgSQgFg2AGg9QAJingKioQgJhwgXhuIhjozIgNAAQgkAAhIgHQgxDFjXC2QiyC5hyC6QhCCnhUCgQhaCbiTBvQhRA3hiATQhRAMhTgRQhegOhYgpQhUgvgoheQgihoA/hqQA/hsBKhjQAXg+AAhCQAtokgEolQgBi0gcizQgOhCgLhCQgDgvANglIgbmlIgSkRQgGhrgJg5QgIhGgIheQgfmsAVmsIAJizQgehJgbhXQhCjXgTjBQgchpgEhpIAAgdQgGgRgEgSQgHgegEhIQgPkygwkvQgDg8ALg7QAPg5AzgmQA3ggBEAQQCeAUCLBbQCcBfCFB+IAEAEQCAggCFgBQBzAABsAvQAgAQAaAYQA/hIBAhEQA/hDBEg/QAxguA9ggQBCgZBIAKQBlAIBSBAQArArAUBIQAJAiAEAuQAGAcACAhQAMBwgIBxQgHDdghDYIgJAkIgLDBQgBAiAKAfQAUAtAuAYQAWAVAdAmIAGAJIAYARQD6C5DiDUQA1A3AtA9QA3BOArBXQAdAwAIATQANAcADAYQBsDDBDDTQAaBQAUBSQAWBWAUAhQAUAuAXBJQBZFHAcFUQAABSgNBkIgKBHIBPgVQBWgZA9gaQAugUAvgbQCyiLCSiwQBGhMA/hRQAwhFAkhMQAohOAfALQAggLAkg5QAuhiArhjIB5kUIAHgQQA0h4Aoh+QAZhiAlhgQAzhYB0gEQBKAQAeBUQAbBHgOBOQgJBqgiByIABAGIAAAJQABAcgHAnQgsEKiWDpQgTAkgGhSQgIg3gFgNIgRAnQg7CUhZC/QgfBCgkA+QhWCLhyB4Qg1BLgTAUIgSARIhXBsQhhB0hwBlQjKCmkBBQQhnAqhwAZIgOAYQikEghiE+IhBDmQgkCBgiCBQg9DxhRDsQg+CMhdB4QgrA4g/AmQgrATgsAAQhBAAhFgog");
	this.shape_982.setTransform(965.2336,416.3705);

	this.shape_983 = new cjs.Shape();
	this.shape_983.graphics.f("#232323").s().p("EgDvAyFQhWgjhBhEQg4hKAGhmQABgpAKg0IAEgSQgGg2AGg9QAGiogMinQgLhvgYhvIhqoxIgNABQglAAhIgHQguDHjJC6QimC9hrC8Qg+CphPCiQhYCdiQByQhQA5hhAWQhQANhUgOQhegLhZgoQhVgtgqhdQglhnA9hrQA8huBIhlQAWg+gChDQAgokgRolQgFi0ghizQgPhBgNhBQgEgwANglIgmmlIgYkQQgJhqgKg9QgJhIgKhfQgomsAOmsIAFizQgfhJgdhWQhFjXgYjAQgdhogGhqIgBgdQgGgPgEgTQgIgegFhIQgVkxg2kvQgDg8AJg7QAOg5AygnQA3ghBEAPQCfAQCMBZQCeBcCHB8IAEADQCAghCFgFQBzgBBtAsQAhARAaAXQA9hJBAhGQA9hEBChAQAygvA8ghQBAgbBJAJQBlAGBTA/QAtApAUBJQAKAhAFAuQAHAdADAgQANBxgGBxQgCDcgeDZIgHAkIgIDBQAAAiAKAgQAVArAuAYQAXAVAdAlIAHAJIAXARQD+C0DmDQQA2A1AuA+QA5BMAtBWQAdAwAJASQANAcAEAZQBvDABIDTQAbBPAWBRQAXBWAUAkQAVAxAYBJQBeFGAgFUQABBSgLBlIgJBGIBOgWQBWgZA8gbQAvgWAugaQCwiPCQiyQBFhMA9hSQAwhGAihMQAnhPAgAFQAhgRAjg7QAshjAphlIB0kWIAGgPQAzh6Alh/QAYhjAihfQAyhZB0gHQBKAPAgBTQAcBHgMBOQgIBpgfB0IAAAGIABAJQABAcgGAnQgnELiSDsQgSAkgIhKQgJgxgFgLIgRAoQg4CUhYDAQgdBCgjA/QhUCMhxB6Qg0BLgTAUIgRASIhWBtQhfB1hvBnQjICoj/BUQhnAshwAaIgNAYQigEihfFAIg9DmIhDEDQg6DzhODtQg7CLhcB6QgrA5g9AnQgsAUgvAAQg/AAhEgmg");
	this.shape_983.setTransform(956.8689,417.2608);

	this.shape_984 = new cjs.Shape();
	this.shape_984.graphics.f("#232323").s().p("EgCfAyDQhXgihChDQg4hKAEhlQAAgqAJgzIAEgTQgGg1AEg9QAEiogOinQgMhvgahuIhyowIgNAAQgkAChJgGQgqDHi7C+QiaDAhjC/Qg7CrhLCjQhUCfiOB2QhOA6hgAYQhQARhUgNQhfgKhaglQhWgrgshcQgnhmA6htQA5hvBGhnQAUg+gDhDQATokgeolQgKi0gliyQgQhAgOhBQgFgwALgmIgwmjIgekQQgLhqgMhAQgLhLgMhfQgvmrAFmtIADizQghhIgehWQhKjUgbjBQgfhogIhpIgCgdQgGgPgFgTQgHgegHhHQgbkxg7kuQgFg8AIg8QANg5AygoQA2gjBEAOQCfAPCOBWQCfBYCLB6IAEADQB/gkCEgHQB0gDBuAqQAgAQAbAXQA8hKA+hHQA8hGBBhCQAxgvA7giQBAgcBKAHQBkAFBVA9QAuAoAVBJQAKAhAGAuQAHAcAEAgQAPBxgDBxQABDcgZDaIgHAkIgEDCQAAAhALAgQAWArAvAXQAXAUAdAlIAHAJIAYAQQEBCwDqDLQA3A1AwA8QA6BMAuBVQAeAvAKASQANAbAEAZQBzC/BMDRQAcBPAYBRQAZBVAVAoQAWAzAYBKQBiFFAmFTQABBSgJBlIgIBHIBOgYQBVgbA8gbQAugWAugbQCviRCNi0QBDhOA9hSQAuhHAihMQAmhQAggCQAhgWAig+IBSjJIBukYIAHgQQAwh7Ajh/QAWhjAghhQAwhaB0gIQBLANAhBTQAeBGgMBOQgFBqgdB0IAAAGIABAJQACAcgFAnQgjELiNDwQgRAlgKhCQgKgsgGgJIgQAoQg2CVhVDBQgdBCgiBAQhSCNhvB7QgzBNgTAUIgRASIhUBuQheB3htBoQjGCrj+BXQhmAthvAcIgOAYQicEkhaFBIg6DnQghCCgeCCQg3D0hLDtQg5CNhaB7QgrA6g9AnQgtAVgvAAQg+AAhDgkg");
	this.shape_984.setTransform(948.4553,416.6664);

	this.shape_985 = new cjs.Shape();
	this.shape_985.graphics.f("#232323").s().p("EgBPAyAQhXgghDhDQg5hJADhmQAAgpAIgzIADgTQgGg2ADg9QACiogQimQgOhvgchuIh5ouIgNABQgkABhJgFQgoDIisDCQiODDhcDCQg2CrhIClQhQCiiLB5QhMA8hgAaQhQAShUgLQhfgHhbgjQhXgpguhbQgphlA3huQA3hxBDhoQATg+gFhDQAGolgrokQgOi0gpixQgShAgQhBQgGgvAKgmIg6miIgkkPQgOhpgNhEQgNhNgOhhQg3mpgCmuIgCiyQghhIgghWQhPjTgejAQghhngJhpIgDgdIgMgiQgIgegIhHQggkxhBksQgGg8AHg8QAMg5AxgqQA1giBFAMQCfALCQBTQChBXCMB2IAEADQB+gmCFgJQBzgGBvAoQAhAPAcAXQA6hMA9hIQA6hFBBhEQAvgwA7gkQBAgdBJAGQBkADBWA7QAvAoAXBIQAKAhAHAuQAIAcAEAgQASBwgCByQAGDcgWDaIgGAkIAADCQABAiALAfQAWArAwAWQAYATAeAlIAHAIIAYAQQEECrDuDHQA4A0AxA7QA8BLAvBUQAgAvAJASQAOAbAFAZQB2C7BQDRQAdBOAaBQQAaBVAWAsQAXA1AZBLQBmFDArFTQADBSgJBlIgHBHIBOgYQBUgcA8gdQAugWAugcQCsiTCLi2QBDhOA7hUQAuhGAghOQAlhQAhgJQAhgcAghAQAqhkAlhmIBpkbIAGgQQAuh7AgiAQAVhlAehgQAvhcBzgKQBLAMAjBSQAeBGgJBPQgDBpgbB1IAAAGIABAJQACAcgEAnQgeEMiJDyQgQAlgLg6QgLgmgGgGIgQAoQgzCVhTDDQgbBDgiA/QhQCOhuB9QgyBNgSAVIgRASIhTBvQhcB4hsBqQjDCuj9BaQhmAuhuAeIgNAYQiYEmhWFDIg3DnIg8EFQgzD0hIDvQg3COhZB7QgqA7g9AoQguAXgxAAQg8AAhCgjg");
	this.shape_985.setTransform(939.9952,416.102);

	this.shape_986 = new cjs.Shape();
	this.shape_986.graphics.f("#232323").s().p("EAABAx9QhXgghEhBQg6hIAChmQgBgqAHgzIAEgSQgIg2ADg9QgBiogSimQgQhwgdhsIiAotIgNABQglAChIgEQgmDJidDFQiBDFhVDEQgzCthECnQhLCjiIB8QhLA9hgAdQhPAUhUgJQhfgFhcghQhYgngxhZQgrhkA0hwQA0hxBBhqQARg/gGhDQgHolg4ojQgSizgtiwQgUg/gRhBQgIgvAKgmIhEmhIgrkPQgQhogPhHQgPhPgPhhQg/mpgLmtIgEizQgjhHgihVQhSjSgii/QgjhngLhpIgDgdQgIgPgFgSQgJgegJhHQgmkxhGkrQgIg8AGg7QAMg7AvgpQA1gkBFALQCgAICRBRQCjBTCOB0IAEADQB+gpCEgLQBzgIBwAmQAhAPAcAVQA5hMA7hJQA6hHA/hFQAugxA6glQA/geBKAFQBlABBXA5QAuAnAZBIQAMAhAHAtQAIAcAFAhQAUBvAAByQAKDcgRDaIgGAlIADDBQACAiAMAfQAXArAwAVQAYATAfAkIAHAIIAZAQQEHCmDyDCQA5AzAxA6QA+BLAxBTQAgAuAKARQAOAbAFAZQB6C6BUDOQAfBOAbBQQAcBVAXAuQAYA5AaBLQBrFCAuFSQAFBSgIBlIgGBHIBOgZQBUgdA7geQAugXAtgcQCriWCIi3QBChQA6hUQAshGAghPQAjhRAhgQQAhghAghCQAnhmAjhnIBkkcIAGgQQArh9AfiAQAShlAdhhQAthcBzgNQBLALAlBRQAfBGgIBOQgBBqgZB1IABAGIABAJQADAcgEAnQgZEOiED0QgQAlgMgyQgLgggGgEIgQAoQgyCWhPDEQgbBDghBAQhOCPhsB+QgxBOgSAVIgQASQgkA1guA8QhaB5hrBrQjACxj8BeQhlAvhuAfIgNAZQiUEnhSFEIg0DoIg4EGQgwD1hEDvQg1CPhYB9QgoA7g9ApQgwAXgyAAQg8AAhAggg");
	this.shape_986.setTransform(931.4977,415.5423);

	this.shape_987 = new cjs.Shape();
	this.shape_987.graphics.f("#232323").s().p("EABRAx4QhXgehFhBQg8hHABhmQgBgpAHgzIADgTQgIg1ACg+QgEiogUimQgRhvgehsIiIorIgNABQglAChJgCQgjDIiODJQh1DHhODFQguCvhACoQhICliFB/QhJBAhfAfQhPAWhUgHQhfgDhdgfQhZglgzhYQgthjAyhxQAxhyA+hsQAPhAgHhCQgUolhFohQgXizgxiuQgVhAgShAQgKgvAKgmIhOmfIgykOQgkjRghiUQhImngSmuIgHizQglhGgjhUQhWjRgli+QgmhmgNhpIgDgdIgNghQgJgegLhHQgskvhMkqQgIg7AFg9QAKg6AvgrQA0glBFAKQCgAFCSBOQClBRCQBxIAEADQB+grCEgOQBzgLBwAlQAiAOAcAVQA3hOA6hKQA5hIA9hGQAugyA5glQA/ggBJAEQBlgCBYA4QAwAnAZBHQAMAgAJAuQAJAcAFAgQAVBvADByQAPDcgODaIgFAlIAHDBQACAiAMAfQAZAqAwAUQAZATAfAjIAHAJIAZAPQELChD1C+QA6AxAzA6QA+BJAzBSQAhAtAKASQAQAbAFAYQB8C4BYDNQAhBMAcBRQAeBTAYAzQAZA6AcBNQBvFBAzFRQAFBSgGBlIgFBHIBNgbQBUgeA7geQAtgYAtgdQCpiYCFi5QBBhQA5hUQArhIAfhPQAjhRAggYQAhgmAehFQAlhmAihoIBekeIAGgQQAph9AciBQAQhlAbhiQAshdBygPQBMAJAmBRQAhBFgHBPQABBqgXB1IABAGIABAJQADAbgCAoQgUEOiAD3QgPAlgNgqQgLgZgGgDIgQAoQgvCXhNDGQgaBCggBAQhMCRhqCAQgwBOgSAVIgQATIhQBxQhZB7hpBsQi+Czj7BiQhkAwhuAhIgMAZQiQEqhOFEIgwDpIg1EGQgtD2hBDwQgzCQhVB+QgpA7g8AqQgwAZg1AAQg6AAg/gfg");
	this.shape_987.setTransform(922.9982,415.0491);

	this.shape_988 = new cjs.Shape();
	this.shape_988.graphics.f("#232323").s().p("EAChAxzQhYgdhGhAQg7hGgBhmQgCgpAGg0IADgTQgJg1ABg9QgFiogXimQgThvgfhsIiQopIgNABQgkADhJgBQggDJiADKQhpDKhGDHQgqCvg8CqQhECmiCCDQhIBBheAhQhOAYhVgFQhgAAhcgdQhagjg1hXQgwhiAvhyQAvh0A8htQANg/gJhDQghokhRofQgbizg2itQgWg/gUg/QgLgvAJgnIhXmcIg4kNQgrjQgjibQhQmmgamtIgLiyQgmhHgkhTQhajPgpi+QgnhlgPhoIgEgdQgIgPgGgSQgKgegMhHQgxkuhSkpQgJg7AEg8QAIg7AvgrQAzgmBGAIQCgADCTBLQCmBMCTBvIAEAEQB8guCEgQQBzgNBxAjQAhANAeAVQA1hPA5hLQA3hKA8hGQAtgzA5gnQA+ghBKACQBkgDBZA3QAxAlAbBHQANAgAJAtQAJAcAGAgQAYBvAEBxQASDcgJDbIgEAlIAKDBQADAiANAfQAZApAxATQAZATAgAiIAHAJIAaAOQEMCcD6C6QA6AxA1A4QBABIA0BRQAiAtAKARQAQAbAGAYQCAC1BbDMQAjBMAdBPQA/CoAxBsQBzE+A4FRQAGBSgEBlIgEBHIBMgbQBUgfA6gfQAtgYAtgeQCmibCEi7QA/hRA4hVQArhIAdhQQAhhRAggfQAggsAdhGQAkhnAfhoIBakhIAFgQQAnh+AZiBQAPhlAZhjQAphdBzgSQBMAIAnBQQAjBFgGBOQADBqgVB2IABAGIACAJQAEAcgDAnQgPEOh6D6QgPAlgNgiQgMgTgGgBIgPAoQgtCYhLDHQgYBCggBBQhKCShoCBQgvBPgSAVIgPATIhPBzQhXB7hoBuQi8C1j5BlQhjAzhuAhIgMAZQiMEshJFGIgtDqQgaCDgXCDQgqD2g+DyQgxCQhUB/QgnA8g7ArQgyAag2AAQg5AAg+gdg");
	this.shape_988.setTransform(914.4638,414.5307);

	this.shape_989 = new cjs.Shape();
	this.shape_989.graphics.f("#232323").s().p("EADxAxtQhYgdhHg+Qg9hFgChmQgCgpAFg0IACgTQgKg1ABg9QgIiogYilQgUhvghhsIiXomIgNABQgkAEhJgCQgdDKhxDMQheDMg+DIQgmCvg4CsQhACoh/CFQhHBEhdAjQhOAZhUgDQhfAChegaQhaghg3hWQgzhgAthzQArh1A6hvQANhAgMhCQgtojhfoeQgfixg5isQgYg+gWg/QgMgvAIgnIhhmaIg+kMQgvjOgoihQhXmlgimtIgOiyQgnhFgnhTQhdjNgti9QgohlgShoIgEgdQgIgPgGgSQgLgdgNhHQg3kthXkoQgLg7ADg8QAIg6AtgtQAzgnBGAHQCgAACVBIQCnBKCVBsIAEADQB7gwCEgTQBygOByAgQAiANAdAUQA1hQA3hMQA2hLA7hHQArg0A5gnQA9gjBKABQBkgEBaA0QAxAkAdBHQANAgAKAtQAKAcAHAfQAZBvAHBxQAWDbgFDcIgDAkIANDCQAEAiANAeQAbApAwASQAZASAhAiIAIAJIAZAOQEQCXD9C1QA8AvA1A4QBABGA3BRQAiArALASQAQAaAHAYQCDC0BgDJQAjBMAfBOQBCCmAzBzQB4E+A8FQQAIBSgEBlIgDBHIBNgdQBSggA7ggQAsgYAsgfQClicCBi9QA+hSA3hWQAphJAdhQQAghRAggmQAfgyAbhJQAhhnAehpIBUkiIAFgQQAlh/AXiCQANhlAXhjQAohfBygTQBMAGApBQQAjBDgDBPQAEBrgSB2IABAGIABAJQAFAbgCAoQgJEOh3D8QgOAmgNgbQgMgNgGABIgOApQgsCXhHDJQgYBDgeBBQhJCThmCCQguBPgRAWIgQATIhNB0QhVB8hmBwQi6C4j4BoQhjAzhsAkIgMAZQiIEuhFFGIgqDqQgYCEgVCEQgnD3g6DyQgvCRhTCAQgmA9g7ArQgyAbg4AAQg4AAg9gbg");
	this.shape_989.setTransform(905.92,414.0447);

	this.shape_990 = new cjs.Shape();
	this.shape_990.graphics.f("#232323").s().p("EAFBAxmQhZgbhHg+Qg+hEgEhmQgDgpAFg0IACgTQgLg1AAg9QgKingbimQgWhvghhqIifolIgMABQglAEhJAAQgaDKhiDOQhSDMg3DJQgiCxg0CtQg8Cph7CJQhGBFhcAlQhNAchUgCQhfAEhfgYQhbgeg5hVQg1hgAqhzQAph3A3hvQALhAgNhCQg6ohhsocQgjixg9irQgag9gXg/QgMguAGgnIhqmYIhFkKQgzjOgsinQhfmigqmtIgRiyQgphEgohSQhhjMgwi8QgqhkgUhoIgFgcIgPghQgLgegOhGQg9kshckmQgLg7ABg8QAGg7AtgtQAygoBGAGQCggECWBGQCpBHCXBpIAEADQB7gyCDgVQBygRByAeQAiAMAeAUQAzhRA2hNQA0hLA6hJQArg1A3goQA9gjBKgBQBkgHBbAzQAyAkAdBFQAPAgAKAtQAKAcAIAfQAcBvAIBwQAbDbgCDcIgCAkIARDCQAEAhAOAeQAbApAxARQAZASAiAhIAIAIIAaAOQERCSEBCwQA9AvA2A2QBDBFA3BQQAjArALARQARAbAHAXQCHCxBjDIQAlBLAgBOQBFClA2B6QB8E8BBFPQAIBRgCBmIgCBHIBMgeQBTghA6ghQArgZAsgfQCiieB/i/QA9hSA1hYQAphJAbhQQAghTAfgtQAeg2AahLQAfhoAchqIBOkjIAFgQQAiiAAViCQALhmAVhjQAnhfBxgWQBMAFArBPQAlBDgDBPQAHBqgQB2IABAGIABAJQAGAbgCAoQgEEOhyD/QgNAmgNgTQgMgHgGADIgNApQgqCYhFDJQgXBFgdBAQhHCUhkCDQgtBRgRAWIgPATIhMB0QhTB+hlBxQi3C7j2BrQhiA0htAlIgLAaQiEEwhAFHIgnDrQgXCEgTCEQgjD3g4DzQgtCRhQCBQgmA+g6AsQg0Adg5AAQg2AAg8gag");
	this.shape_990.setTransform(897.4251,413.5768);

	this.shape_991 = new cjs.Shape();
	this.shape_991.graphics.f("#232323").s().p("EgS/AxxQhbgbg7hUQg4heAoh1QAmh3A0hxQAKhAgOhCQhHogh4oZQgoiwhBipQgbg9gYg+QgOguAGgnIh0mWIhLkIIhol5QhnmhgymsIgVixQgphEgqhRQhljKgzi8QgshjgWhnIgFgdIgQggQgLgdgQhGQhCkshikjQgMg7AAg8QAFg7AsgvQAxgoBHAEQCfgGCYBDQCqBECZBmIAEADQB6g0CDgYQBxgTBzAcQAjAMAeATQAxhSA1hOQAzhNA4hJQAqg2A2gpQA8glBKgCQBkgIBcAxQAzAjAfBFQAOAfAMAtQAKAbAJAgQAdBuALBxQAeDaADDcIgCAkIAVDBQAFAhAOAeQAcApAxAQQAbARAhAhIAIAIIAaANQEVCOEECqQA9AuA3A1QBEBFA5BOQAlArAKAQQASAaAHAYQCLCuBmDGQAmBLAiBNICBEkQCAE7BFFNQAKBSgBBlIgBBIIBMgfQBSgjA5ghQAsgaArggQCgigB8jAQA8hTA0hYQAohKAahRQAfhTAdgzQAdg8AZhNQAdhpAahqIBJklIAEgQQAhiAASiDQAIhmAUhkQAkhgBygXQBMADAsBOQAmBCgBBQQAJBqgOB3IABAFIACAJQAFAbAAAoQAAEOhtEBQgMAngNgMQgLgBgGAFIgNApQgnCZhCDKQgXBEgcBCQhECUhjCFQgsBRgQAWIgPATIhKB2QhTB+hjBzQi0C9j1BvQhhA2hsAmIgLAaQiAEwg8FJIgkDrIgmEJQggD4g0DzQgsCShOCDQglA9g5AtQhkA6h7g0QhZgahIg8QhAhEgFhmQgDgpAEg0IACgTQgLg0gCg+QgMingdilQgXhugkhrIiloiIgNACQgkAEhJABQgYDKhTDPQhGDNgwDKQgeCygvCtQg4Crh5CLQhDBHhbAnQhNAehVAAIgoACQhLAAhLgSg");
	this.shape_991.setTransform(888.8973,414.3081);
	this.shape_991._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_967}]},412).to({state:[{t:this.shape_968}]},1).to({state:[{t:this.shape_969}]},1).to({state:[{t:this.shape_970}]},1).to({state:[{t:this.shape_971}]},1).to({state:[{t:this.shape_972}]},1).to({state:[{t:this.shape_973}]},1).to({state:[{t:this.shape_974}]},1).to({state:[{t:this.shape_975}]},1).to({state:[{t:this.shape_976}]},1).to({state:[{t:this.shape_977}]},1).to({state:[{t:this.shape_978}]},1).to({state:[{t:this.shape_979}]},1).to({state:[{t:this.shape_980}]},1).to({state:[{t:this.shape_981}]},1).to({state:[{t:this.shape_982}]},1).to({state:[{t:this.shape_983}]},1).to({state:[{t:this.shape_984}]},1).to({state:[{t:this.shape_985}]},1).to({state:[{t:this.shape_986}]},1).to({state:[{t:this.shape_987}]},1).to({state:[{t:this.shape_988}]},1).to({state:[{t:this.shape_989}]},1).to({state:[{t:this.shape_990}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[{t:this.shape_991}]},1).to({state:[]},1).wait(861));
	this.timeline.addTween(cjs.Tween.get(this.shape_991).wait(436).to({_off:false},0).wait(10).to({_off:true},1).wait(861));

	// фонн
	this.shape_992 = new cjs.Shape();
	this.shape_992.graphics.f().s("#232323").ss(0.1,1,1).p("EiCbhFWMDeDAAAMAm0AAAMAAACKtMgm0AAAMjeDAAA");
	this.shape_992.setTransform(1058.225,403.375);

	this.shape_993 = new cjs.Shape();
	this.shape_993.graphics.f("#FFFFFF").s().p("EhbnBFXMgm0AAAMAAAiKtMAm0AAAMDeDAAAMAAACKtg");
	this.shape_993.setTransform(809.875,403.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_993},{t:this.shape_992}]},412).to({state:[]},35).wait(861));

	// глазочки
	this.shape_994 = new cjs.Shape();
	this.shape_994.graphics.f().s("#232323").ss(0.1,1,1).p("ACnAAQAABFgxAxQgxAxhFAAQhEAAgxgxQgxgxAAhFQAAhEAxgxQAxgxBEAAQBFAAAxAxQAxAxAABEg");
	this.shape_994.setTransform(278.6,305.55);

	this.shape_995 = new cjs.Shape();
	this.shape_995.graphics.f("#232323").s().p("AD9B2QgxgxAAhFQAAhEAxgxQAxgxBFAAQBFAAAxAxQAxAxAABEQAABFgxAxQgxAxhFAAQhFAAgxgxgAnoB2QgxgxAAhFQAAhEAxgxQAxgxBFAAQBFAAAxAxQAxAxAABEQAABFgxAxQgxAxhFAAQhFAAgxgxg");
	this.shape_995.setTransform(315.675,305.55);

	this.shape_996 = new cjs.Shape();
	this.shape_996.graphics.f().s("rgba(32,32,32,0.922)").ss(0.1,1,1).p("AipAAQAAhFAygxQAygyBFAAQA5AAArAgQAKAIAJAJQAyAzAABEQAABGgxAxQgMAMgKAHQgrAfg3AAQhGgBgxgwQgyg0AAhEg");
	this.shape_996.setTransform(278.6,305.55);

	this.shape_997 = new cjs.Shape();
	this.shape_997.graphics.f("#232323").s().p("AD7B4QgxgyAAhGQAAhFAxgyQAygxBGAAQBGAAAyAxQAyAyAABFQAABGgyAyQgyAxhGAAQhGAAgygxgAnqB4QgygzAAhFQAAhFAygyQAygxBGAAQA5AAArAgQAKAIAJAJQAyAzAABEQAABGgxAyQgMALgKAIQgrAeg3AAQhHAAgxgxg");
	this.shape_997.setTransform(315.725,305.55);

	this.shape_998 = new cjs.Shape();
	this.shape_998.graphics.f().s("rgba(30,30,30,0.847)").ss(0.1,1,1).p("AirAAQAAhGAygyQAzgzBGAAQA6AAArAhQALAIAJAJQAzA0AABFQAABHgzAyQgLAMgLAHQgrAgg4AAQhHgBgxgxQgzg0AAhGg");
	this.shape_998.setTransform(278.6,305.55);

	this.shape_999 = new cjs.Shape();
	this.shape_999.graphics.f("#232323").s().p("AD7B5QgzgyAAhHQAAhGAzgzQAxgyBIAAQBHAAAyAyQAzAzgBBGQABBHgzAyQgyAzhHAAQhIAAgxgzgAnsB6Qgzg0AAhGQAAhGAzgyQAzgzBHAAQA5AAAsAhQAKAIAJAJQA0A0AABFQgBBHgyAyQgLAMgLAHQgrAgg4AAQhIgBgygxg");
	this.shape_999.setTransform(315.75,305.55);

	this.shape_1000 = new cjs.Shape();
	this.shape_1000.graphics.f().s("rgba(27,27,27,0.769)").ss(0.1,1,1).p("AiuAAQAAhHAzgzQA0gzBHAAQA6AAAtAhQAKAIAKAJQAzA1AABGQAABIgzAzQgLALgLAIQgrAgg5AAQhJgBgygxQg0g1AAhGg");
	this.shape_1000.setTransform(278.6,305.55);

	this.shape_1001 = new cjs.Shape();
	this.shape_1001.graphics.f("#232323").s().p("AD5B7QgzgzAAhIQAAhHAzgzQAzgzBIgBQBIABAzAzQA0AzgBBHQABBIg0AzQgzAzhIABQhIgBgzgzgAnuB8Qgzg1AAhGIAAgBQAAhHAygzQA0gzBIgBQA7ABAsAiQALAHAJAKQAzA0AABGQABBIgzAzQgMALgLAIQgrAgg5ABQhKgCgygxg");
	this.shape_1001.setTransform(315.8,305.55);

	this.shape_1002 = new cjs.Shape();
	this.shape_1002.graphics.f().s("rgba(24,24,24,0.694)").ss(0.1,1,1).p("AiwAAQAAhIA0g0QA0g0BIAAQA7AAAuAiQAKAIAKAKQA0A0AABIQAABJg0AzQgLAMgLAIQgsAgg6ABQhJgBgzgzQg0g1gBhIg");
	this.shape_1002.setTransform(278.575,305.575);

	this.shape_1003 = new cjs.Shape();
	this.shape_1003.graphics.f("#232323").s().p("AD4B9Qg0g0AAhJQAAhIA0g0QA0g0BJAAQBJAAA0A0QAzA0AABIQAABJgzA0Qg0A0hJAAQhJAAg0g0gAnvB9Qg1g1AAhIIAAAAQAAhIA0g0QA0g0BJAAQA7AAAtAiQALAIAJAKQA0A0AABIQAABJgzAzQgLAMgLAIQgtAgg5ABQhKgBgzgzg");
	this.shape_1003.setTransform(315.825,305.575);

	this.shape_1004 = new cjs.Shape();
	this.shape_1004.graphics.f().s("rgba(22,22,22,0.616)").ss(0.1,1,1).p("AiyAAQAAhJA0g0QA1g1BJAAQA8AAAuAiQALAIAJAKQA1A1AABJQAABKg0A0QgLALgLAIQgtAig6AAQhLgBgzgzQg2g2AAhJg");
	this.shape_1004.setTransform(278.575,305.575);

	this.shape_1005 = new cjs.Shape();
	this.shape_1005.graphics.f("#232323").s().p("AD3B+Qg1g0AAhKQAAhJA1g1QA0g0BKAAQBKAAA1A0QA0A1AABJQAABKg0A0Qg1A1hKAAQhKAAg0g1gAnxB/Qg2g2AAhJIAAAAQAAhJA0g0QA1g1BKAAQA8AAAuAiQALAIAJAKQA1A1AABJQAABKg0A0QgLALgLAIQgtAig6AAQhMgBgzgzg");
	this.shape_1005.setTransform(315.875,305.575);

	this.shape_1006 = new cjs.Shape();
	this.shape_1006.graphics.f().s("rgba(19,19,19,0.537)").ss(0.1,1,1).p("Ai1AAQAAhKA1g1QA2g2BKAAQA9AAAuAjQALAIAKAKQA2A2AABKQAABLg1A1QgMALgLAIQgtAig7ABQhMgBg0g0Qg2g3gBhKg");
	this.shape_1006.setTransform(278.575,305.575);

	this.shape_1007 = new cjs.Shape();
	this.shape_1007.graphics.f("#232323").s().p("AD1CAQg1g1AAhLQAAhKA1g1QA1g2BMAAQBLAAA1A2QA1A1AABKQAABLg1A1Qg1A2hLAAQhMAAg1g2gAnzCBQg3g3AAhKIAAAAQAAhKA1g1QA2g2BLAAQA9AAAuAjQALAIAJAKQA2A2AABKQAABLg1A1QgLALgLAIQguAig7ABQhMgBg0g0g");
	this.shape_1007.setTransform(315.925,305.575);

	this.shape_1008 = new cjs.Shape();
	this.shape_1008.graphics.f().s("rgba(16,16,16,0.463)").ss(0.1,1,1).p("Ai3ABQAAhLA1g2QA3g3BLAAQA9ABAvAjQALAIAKAKQA3A3AABLQAABLg2A2QgLALgLAJQguAig8AAQhNAAg1g0Qg3g4AAhLg");
	this.shape_1008.setTransform(278.6,305.55);

	this.shape_1009 = new cjs.Shape();
	this.shape_1009.graphics.f("#232323").s().p("AD0CCQg2g2AAhLQAAhMA2g2QA2g2BMAAQBMAAA2A2QA2A2AABMQAABLg2A2Qg2A2hMAAQhMAAg2g2gAn1CDQg4g3AAhLIAAAAQAAhMA2g2QA2g2BMAAQA+AAAvAjQAKAJALAKQA2A2AABMQAABLg1A2QgMALgLAIQguAjg8AAQhNAAg1g1g");
	this.shape_1009.setTransform(315.975,305.55);

	this.shape_1010 = new cjs.Shape();
	this.shape_1010.graphics.f().s("rgba(13,13,13,0.384)").ss(0.1,1,1).p("Ai6ABQAAhMA2g3QA4g3BMAAQA/AAAvAkQAKAIALAKQA3A4AABMQAABMg2A2QgMAMgLAJQguAig9ABQhOAAg1g1Qg5g5AAhMg");
	this.shape_1010.setTransform(278.6,305.55);

	this.shape_1011 = new cjs.Shape();
	this.shape_1011.graphics.f("#232323").s().p("ADyCEQg2g3AAhMQAAhNA2g2QA3g3BNAAQBNAAA3A3QA3A2AABNQAABMg3A3Qg3A3hNgBQhNABg3g3gAn3CFQg5g4AAhMIAAAAQAAhNA2g2QA4g4BMABQA/AAAwAkQAKAIALAKQA3A3AABNQAABMg2A2QgMAMgLAIQguAjg9AAQhPAAg1g1g");
	this.shape_1011.setTransform(316.025,305.55);

	this.shape_1012 = new cjs.Shape();
	this.shape_1012.graphics.f().s("rgba(11,11,11,0.306)").ss(0.1,1,1).p("Ai8ABQAAhNA2g3QA5g5BNAAQA/ABAwAkQALAIALAKQA4A5AABNQAABNg3A3QgMAMgLAIQgvAkg9AAQhQAAg2g1Qg5g6AAhNg");
	this.shape_1012.setTransform(278.6,305.55);

	this.shape_1013 = new cjs.Shape();
	this.shape_1013.graphics.f("#232323").s().p("ADxCFQg3g3AAhNQAAhOA3g3QA3g4BPAAQBOAAA3A4QA4A3AABOQAABNg4A3Qg3A4hOAAQhPAAg3g4gAn5CIQg6g6AAhNIAAAAQAAhNA3g3QA4g5BOAAQBAAAAvAlQALAHALALQA4A4AABOQAABNg3A3QgMALgLAJQgvAkg9AAQhQAAg2g1g");
	this.shape_1013.setTransform(316.075,305.55);

	this.shape_1014 = new cjs.Shape();
	this.shape_1014.graphics.f("#232323").s().p("ADwCHQg4g4gBhPQABhOA4g4QA4g4BPAAQBPAAA4A4QA5A4AABOQAABPg5A4Qg4A4hPAAQhPAAg4g4gAn7CJQg6g6AAhOIAAgBQgBhOA4g3QA5g5BOAAQBBAAAxAkQAKAJALAKQA5A5AABOQAABPg4A3QgLAMgLAJQgwAkg/AAQhQAAg3g2g");
	this.shape_1014.setTransform(316.1,305.575);

	this.shape_1015 = new cjs.Shape();
	this.shape_1015.graphics.f("#232323").s().p("ADvCJQg5g5gBhQQABhPA5g5QA4g5BQAAQBRAAA4A5QA5A5ABBPQgBBQg5A5Qg4A5hRAAQhQAAg4g5gAn9CLQg7g7gBhPIAAgBQAAhPA4g4QA6g6BQAAQBCABAwAkQAMAJALAKQA5A6AABPQAABQg4A4QgMAMgLAJQgwAkg/ABQhTAAg3g3g");
	this.shape_1015.setTransform(316.15,305.575);

	this.shape_1016 = new cjs.Shape();
	this.shape_1016.graphics.f("#232323").s().p("ADuCLQg6g6AAhRQAAhQA6g6QA5g5BRAAQBRAAA6A5QA5A6AABQQAABRg5A6Qg6A5hRAAQhRAAg5g5gAn/CNQg8g7AAhRIAAgBQAAhQA5g5QA6g6BRAAQBCAAAxAlQAMAJALALQA6A6AABQQAABRg5A5QgLAMgMAIQgxAlhAABQhSAAg5g3g");
	this.shape_1016.setTransform(316.175,305.575);

	this.shape_1017 = new cjs.Shape();
	this.shape_1017.graphics.f("#232323").s().p("ADsCMQg6g6AAhSQAAhRA6g6QA6g7BTAAQBSAAA6A7QA6A6AABRQAABSg6A6Qg6A7hSAAQhTAAg6g7gAoECMQg6g6AAhSQAAhRA6g6QA6g7BSAAQBDAAAyAmQAMAJAMAMQA6A6AABRQAABSg6A6QgLALgMAJQgzAnhDAAQhSAAg6g7g");
	this.shape_1017.setTransform(316.225,305.575);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_995},{t:this.shape_994}]},392).to({state:[{t:this.shape_997},{t:this.shape_996}]},1).to({state:[{t:this.shape_999},{t:this.shape_998}]},1).to({state:[{t:this.shape_1001},{t:this.shape_1000}]},1).to({state:[{t:this.shape_1003},{t:this.shape_1002}]},1).to({state:[{t:this.shape_1005},{t:this.shape_1004}]},1).to({state:[{t:this.shape_1007},{t:this.shape_1006}]},1).to({state:[{t:this.shape_1009},{t:this.shape_1008}]},1).to({state:[{t:this.shape_1011},{t:this.shape_1010}]},1).to({state:[{t:this.shape_1013},{t:this.shape_1012}]},1).to({state:[{t:this.shape_1014}]},1).to({state:[{t:this.shape_1015}]},1).to({state:[{t:this.shape_1016}]},1).to({state:[{t:this.shape_1017}]},1).to({state:[]},8).wait(895));

	// Слой_24
	this.shape_1018 = new cjs.Shape();
	this.shape_1018.graphics.f().s("#232323").ss(0.1,1,1).p("A1/AAMAr/AAA");
	this.shape_1018.setTransform(316.3,335.1);

	this.shape_1019 = new cjs.Shape();
	this.shape_1019.graphics.f("#FFFFFF").s().p("A5CJAIGG9ZMAr/AAAIAAauQs7OFtMAAQr4AAsGrag");
	this.shape_1019.setTransform(296.775,465.7032);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1019},{t:this.shape_1018}]},389).to({state:[]},24).wait(895));

	// КОТ2___копия
	this.instance_53 = new lib.Анимация16("synched",0);
	this.instance_53.setTransform(305.05,443.75);
	this.instance_53._off = true;

	this.instance_54 = new lib.Анимация17("synched",0);
	this.instance_54.setTransform(299.9,241.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_53}]},389).to({state:[{t:this.instance_54}]},3).to({state:[]},21).wait(895));
	this.timeline.addTween(cjs.Tween.get(this.instance_53).wait(389).to({_off:false},0).to({_off:true,x:299.9,y:241.75},3).wait(916));

	// Слой_22
	this.instance_55 = new lib.фоны_фонстол2();
	this.instance_55.setTransform(-47,-119,0.3499,0.3499);

	this.shape_1020 = new cjs.Shape();
	this.shape_1020.graphics.f().s("#232323").ss(0.1,1,1).p("EiCbhFWMEE3AAAMAAACKtMkE3AAA");
	this.shape_1020.setTransform(809.875,403.375);

	this.shape_1021 = new cjs.Shape();
	this.shape_1021.graphics.f("#FFFFFF").s().p("EiCbBFXMAAAiKtMEE3AAAMAAACKtg");
	this.shape_1021.setTransform(809.875,403.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1021},{t:this.shape_1020},{t:this.instance_55}]},382).to({state:[]},31).wait(895));

	// Слой_113
	this.shape_1022 = new cjs.Shape();
	this.shape_1022.graphics.f("#232323").s().p("Ai/CzQAAg2B4htIARgQQhGhoAAg4QAAgyAqAAQAMAAAFAKQAGAKADAkQAEA4AsA/QBghUAihCQAMgVAGgGQAHgFAKAAQANAAALAKQALAKAAAPQAAAjirCcQA7BMBCAlIAQAKQABADAAAHQAAAPgLAMQgLAMgPAAQgwAAhmiJQhQBFgZBGQgKAYgKALQgqgCAAglg");
	this.shape_1022.setTransform(404.475,247.525);

	this.shape_1023 = new cjs.Shape();
	this.shape_1023.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_1023.setTransform(364.075,246.675);

	this.shape_1024 = new cjs.Shape();
	this.shape_1024.graphics.f("#232323").s().p("AifEVQgXgsAAg0QAAhcA5hRQA5hRA/AAQAIgBAMALQALALAGgCQgOglgvgqQgugnAAgcQAAgWAPgOQAPgOAogLQAxgOAzgSQA1gRAKgFQAGgDAIAAQALgBAAAWQAAALgcAUQgcAUhHASQguAKgJAGQgKAFAAAGQAAANAbAYQBoBagBCIQAAA6geBEQggBCgzAhQgzAhgxAAQgsAAgXgrgAhMAqQgsBMgBBAQAAAnALAWQAKAXARAAQAXAAAmgcQAmgcAXg3QAXg2AAgwQAAgngLgXQgLgYgJgBQg+ABgtBLg");
	this.shape_1024.setTransform(328.05,234.05);

	this.shape_1025 = new cjs.Shape();
	this.shape_1025.graphics.f("#232323").s().p("ABbCiQgSglAAhFQgxBCgvAhQgxAhgoAAQgbAAgTgXQgUgXAAgkQAAhcBThqQBShqBRAAQAdAAAPAhQAEAMAKAAQAcAAAAAVQAAALgDATQgTBnAAAqQAABWAgAQQAPAJAAAMQAAALgPALQgPALgOAAQgbAAgRglgAg3g2Qg+BWAAA5QAAApAbAAQAmAABEhOQBFhNAAhCQAAgyghAAQgvAAg8BXg");
	this.shape_1025.setTransform(284.725,246.675);

	this.shape_1026 = new cjs.Shape();
	this.shape_1026.graphics.f("#232323").s().p("AifEVQgXgsAAg0QAAhcA5hRQA5hRA/AAQAHgBANALQALALAGgCQgNglgwgqQgtgngBgcQAAgWAPgOQAPgOAogLQAxgOAzgSQA0gRALgFQAGgDAIAAQALgBAAAWQAAALgcAUQgcAUhHASQgtAKgKAGQgKAFABAGQgBANAbAYQBnBaAACIQAAA6geBEQgfBCg0AhQgyAhgyAAQgsAAgXgrgAhMAqQgtBMAABAQAAAnALAWQAKAXASAAQAWAAAmgcQAmgcAXg3QAXg2AAgwQAAgngKgXQgMgYgKgBQg9ABgtBLg");
	this.shape_1026.setTransform(248.7,234.05);

	this.shape_1027 = new cjs.Shape();
	this.shape_1027.graphics.f().s("#232323").ss(6,1,1).p("AbiAAQAAH6oEFlQoEFlraAAQrZAAoEllQoEllAAn6QAAn4IElmQIEllLZAAQLaAAIEFlQIEFmAAH4g");
	this.shape_1027.setTransform(317.75,239.45);

	this.shape_1028 = new cjs.Shape();
	this.shape_1028.graphics.f("#FFFFFF").s().p("AzdNfQoElmAAn5QAAn5IEllQIEllLZAAQLaAAIEFlQIEFlAAH5QAAH5oEFmQoEFlraAAQrZAAoEllg");
	this.shape_1028.setTransform(317.75,239.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1028},{t:this.shape_1027},{t:this.shape_1026},{t:this.shape_1025},{t:this.shape_1024},{t:this.shape_1023},{t:this.shape_1022}]},369).to({state:[]},13).to({state:[]},870).wait(56));

	// Слой_21
	this.instance_56 = new lib.вкорме10();
	this.instance_56.setTransform(284,30,0.4802,0.4802);

	this.shape_1029 = new cjs.Shape();
	this.shape_1029.graphics.f().s("#4A4A4A").ss(0.1,1,1).p("ECCcAQ0MAAAA0jMkE3AAAMAAAiKtMEE3AAAMAAABU6");
	this.shape_1029.setTransform(809.875,403.375);

	this.shape_1030 = new cjs.Shape();
	this.shape_1030.graphics.f("#4A4A4A").s().p("EhrbAAJQgFgbAigRQAcgPAmAAMDGcAAIINjAAQAoAAAgAeQAhAdgeASIuuABMjGmAAPQhNAAgIgqg");
	this.shape_1030.setTransform(1052.6568,507.325);

	this.shape_1031 = new cjs.Shape();
	this.shape_1031.graphics.f("#FFFFFF").s().p("EiCbBFXMAAAiKtMEE3AAAMAAABU6MjGcgAHQgmAAgcAOQgiARAFAdQAIApBNAAMDGmgAOMAAAA0jg");
	this.shape_1031.setTransform(809.875,403.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1031},{t:this.shape_1030},{t:this.shape_1029},{t:this.instance_56}]},369).to({state:[]},14).wait(925));

	// лваки
	this.shape_1032 = new cjs.Shape();
	this.shape_1032.graphics.f("#232323").s().p("ADxMiQgrgTgXgoQglhCAThsQgkALg1gXQg6gegdgKQgTgGgmgGIhagMIhbgLQgDAagSAVQgSAUgZAHQgZAGgagJQgZgJgQgVQgOgTgFgdQgDgTgBgjQgChdABgzQAChQAIg/IAJhBIAJhCQAIhAgChbIgEidQgCg3ACghQADgwAJgnQAXhZBFhQQBMhZBlgqQAlgPAigHQA1gLA2AIQA2AHAxAYQBIAkA4BGQAzBBAeBUQAaBKARBtQANBTAJBrQAHBpACCDQABBPgCCeQAAA4gCAbQgCAugIAlIgJApQgGAYgDARQgDAUgBApQgBApgDAUQgFAlgSAdQgUAggeAOQgSAIgUAAQgXAAgYgLg");
	this.shape_1032.setTransform(1164.1783,806.6563);

	this.shape_1033 = new cjs.Shape();
	this.shape_1033.graphics.f("#232323").s().p("AaqQqQgrgTgXgoQgmhCAUhtQglAMg0gXQg7gegegKQgSgHgmgGIhbgMIhagKQgDAagSAUQgSAUgZAHQgZAHgagJQgagJgPgVQgOgTgFgeQgEgTAAgiQgChdABgzQABhQAIhAIAKhBIAJhBQAHhCgBhaIgFicQgBg4ACggQACgxAKgmQAXhaBEhQQBNhZBlgqQAkgPAigGQA1gLA3AHQA3AHAwAYQBJAkA3BHQAzBAAeBUQAbBKARBuQANBRAIBrQAIBpABCEQABBPgBCfQgBA3gBAcQgDAugHAkIgKApQgGAZgCAQQgDAVgBAoQgBApgDAUQgGAmgRAcQgUAhgeANQgTAJgUAAQgWAAgYgLgA8XHeQgbgCgVgWQgVgUgJgdQgHgXgBggIABg5IABhqQABg/AFgrQADgXAMhAQAMg6ANgfIAUgnQANgZAFgPQAJgZAFgsQAGgzAEgTQAFgUASgtQAPgoAFgZQACgKACgsQACghAHgTQAGgPANgVIAVgjQAPgcAOg0IAQhFQAKgoAKgcQASgtAXgaQAKgLATgQQAVgSAJgJIAtg4QAbgiAZgMQARgHAWgDQAOgBAaAAICRgBQAgAAASADQAbAEASANQAMAJANARIAWAdQAKAMAVASQAYAUAJAIQAtAvAQBQQAKA1AABeIgBKvQAAAqgDAXQgFAkgOAZQgRAdggANQgiANgbgPQgEAcgUAVQgVAXgbADQgiAFgegYQgdgXgMgkQgJgfACgoQABgYAIgvQgSgQgiAGQgoAJgTADQgjAFgjgOQgjgOgWgcQghAyg8AWQg9AXg6gRQgdBfAEBiIAEBFQAAAngHAcQgKAjgaAYQgZAWgdAAIgHAAg");
	this.shape_1033.setTransform(986.595,820.9048);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1032}]},348).to({state:[{t:this.shape_1033}]},10).to({state:[]},12).wait(938));

	// ВОДА___копия
	this.shape_1034 = new cjs.Shape();
	this.shape_1034.graphics.f("#0B88F0").s().p("Eh95AQBMAAAggBMD7zAAAMAAAAgBg");
	this.shape_1034.setTransform(793.2,-168.7);

	this.shape_1035 = new cjs.Shape();
	this.shape_1035.graphics.f("#0B88F0").s().p("Eh95gOJMAAAggCMD7zAAAMAAAAgCUg9wA8Vg+9AAAUg+8AAAhAKg8Vg");
	this.shape_1035.setTransform(793.2,24.3625);

	this.shape_1036 = new cjs.Shape();
	this.shape_1036.graphics.f("#0B88F0").s().p("Eh95gsTMAAAggCMD7zAAAMAAAAgCUg8iB4pg+9AAAUg+8AAAhBYh4pg");
	this.shape_1036.setTransform(793.2,217.4229);

	this.shape_1037 = new cjs.Shape();
	this.shape_1037.graphics.f("#0B88F0").s().p("Eh95gkFMAAAg7VMD7zAAAMAAAA9ZUg8dCBcg+tAAAUg/LAABhBeiDhg");
	this.shape_1037.setTransform(793.2,339.5253);

	this.shape_1038 = new cjs.Shape();
	this.shape_1038.graphics.f("#0B88F0").s().p("Eh95gb3MAAAhWpMD7zAAAMAAABayUg8bCKOg+eAABUg/ZAAAhBhiOYg");
	this.shape_1038.setTransform(793.2,461.6619);

	this.shape_1039 = new cjs.Shape();
	this.shape_1039.graphics.f("#0B88F0").s().p("Eh95gTpMAAAhx8MD7zAAAMAAAB4JUg8aCTCg+SAAAUg/lAAAhBiiZPg");
	this.shape_1039.setTransform(793.2,583.7826);

	this.shape_1040 = new cjs.Shape();
	this.shape_1040.graphics.f("#0B88F0").s().p("Eh95gLbMAAAiNPMD7zAAAMAAACVhUg8bCbzg+HAABUg/vAAChBiikIg");
	this.shape_1040.setTransform(793.2,705.9357);

	this.shape_1041 = new cjs.Shape();
	this.shape_1041.graphics.f("#0B88F0").s().p("Eh95gDOMAAAioiMD7zAAAMAAACy4Ug8cCkpg9+AAAUg/4AAAhBhiu/g");
	this.shape_1041.setTransform(793.2,828.0682);

	this.shape_1042 = new cjs.Shape();
	this.shape_1042.graphics.f("#0B88F0").s().p("Ehv6AfAQi/osi+pKUgEGhDlgEIhJKQgOqpgSrMIAAgBUAyrAE+Ap0gJvUAn0gKFAqSgDKQVCjJWOgKID2gBIMzD9QBIGnBLGpQCpPfCiPrQCjOmCHOvQCLMSBcMZQBiIxAkI2QAjIJAVI1QgiL0guMRIg0LAQntXUoEVNQqza7rFVrQl1LUlzJFUgjnA3+gkIAAAUg5EAABg6YiLxg");
	this.shape_1042.setTransform(794.425,803.4912);

	this.shape_1043 = new cjs.Shape();
	this.shape_1043.graphics.f("#0B88F0").s().p("EhpDAuZQiZoWiaoxUgIKg+LgIShJVQgcqAgjrIIAAAAUA0WAJ9AiogTfUAjHgULAoDgGTQTamTV0gTIDugDIKFH8QCQGBCWGFQFTOKFDOfQFGNYENNsQEXLVC4LjQDDIMBJIWQBFHeArI4QhELIhcMCQgzFRg2FTQmhWfnRV0QpraSqOWHQlbLklWI1UglXA9tgl7AAAUg1qAAAg20h7ng");
	this.shape_1043.setTransform(795.65,780.4671);

	this.shape_1044 = new cjs.Shape();
	this.shape_1044.graphics.f("#0B88F0").s().p("EhiNA9iUgOCg+UgOPhUXQgqpXg1rCUA2AAO7AbdgdOUAebgeQAlygJdQR0pdVagcIDlgFQG3LNHYLrQH9MzHlNUQHpMLGUMnQGiKYEUKuQElHnBsH3QBpGzBAI6QhmKciKL0QmVahn8brQokZppVWjQlCL0k5IlUgnMBD+gn0AAAUgyKAAAgzMhr/g");
	this.shape_1044.setTransform(796.875,759.1932);

	this.shape_1045 = new cjs.Shape();
	this.shape_1045.graphics.f("#0B88F0").s().p("EhUMBVKUgTwg5AgUEhZ8Ig6jxIh3yxIAAgBUA3gAT1AUWgmnIAQgXUAXHgkFAfJgNZQGClGGvjLQKll0MThgQBygRB0gMQDVDIDkDpIKjKzQGiG0GhHHQDLDeDIDjQIuJJHuJnIBLBfQIGIkF9I9QCYCsB7CvQCrDyBxD3QDSF4CSHoIAGA/QBcHYgZILQABB6gCCEQhqOJi9RRQiXL9i1MxQjpNokANgQjoL1j3LbQkSL/kRJhIgsBfQkwKbksIWUgmvBCZgnWAAAUgsNAABgs/hT2g");
	this.shape_1045.setTransform(786.1076,741.6625);

	this.shape_1046 = new cjs.Shape();
	this.shape_1046.graphics.f("#0B88F0").s().p("EhH9BrYUgZfgzrgZ4hfjIhqlaQhFoWhUq6IAAgBUA5UAY1ANQgwcIAKgaUAP0gp5AYhgRWQE7mZFzkBQJmoGLwiwQBxgfB0gXQD4BtERCpQGID2GYEEQHwFEH2FYQD0CpDxCtQKWHAJfHiIBdBKQJpGwHlHNQC1CLCbCOQDaDFCkDLQE7E8DlGXIAWA2QEIGmA2HXQAYB1ATCHQARNSh0TLQhkMGiNNkQi0N1jVOcQi+MLjRMHQjjMIjoKeIglBlQkDLfj5IpUgsGBWcgs6AAAUgmKAAAgmxg+gg");
	this.shape_1046.setTransform(786.7643,733.1988);

	this.shape_1047 = new cjs.Shape();
	this.shape_1047.graphics.f("#0B88F0").s().p("Eg8lCAIUgfNguVgfthlLQhNjfhOjlQhUoQhmrfIAAAAUA7IAd0AGJg6RIAGgbUAIggvuAR4gVTQD0nrE2k4QIqqYLNkBQBwgrB0gjQEaASE+BpQHGCZHYCpQI8DTJMDqQEdByEZB3QMAE3LPFdIBuA2QLME8JPFcQDRBqC8BuQEHCZDYCeQGjEBE5FEIAmAtQG1F0CEGkQAvBxAnCJQCOMbgsVEQgxMQhmOVQh/OEipPZQiUMgirMyQi0MSi/LbIgeBsQjWMjjHI6UgxgBtbgyiAABUggDAAAggfgsHg");
	this.shape_1047.setTransform(792.9364,734.0844);

	this.shape_1048 = new cjs.Shape();
	this.shape_1048.graphics.f("#0B88F0").s().p("Egx2CTuUgk7go/glhhqyQhmkThmkbQhjoMh5sBIAAgBUA88AizgA9hEEIABgeUABNg1iALOgZQQCuo/D5ltQHssrKqlQQBwg6B0gtQE9hKFrApQIEA8IYBOQKIBiKiB7QFGA9FCBCQNnCtNADYICAAhQMwDIK3DsQDtBJDdBOQE2BsELByQIMDFGLDzIA3AjQJhFDDSFwQBGBsA9CMQEILjAeW+QABMag+PGQhKOTh+QVQhpM3iGNdQiEMbiXMYIgXByQioNmiVJNUg29CHdg4NAABQ55AA6L8xg");
	this.shape_1048.setTransform(803.1008,742.3402);

	this.shape_1049 = new cjs.Shape();
	this.shape_1049.graphics.f("#0B88F0").s().p("EiBZAIeQhxoIiMskUA+wAnygIEhN4UgIWhQrALUgZNQLV5MU7hNQT+hJVqAYQVKAYUPByQUYByQzDAQRbDGLiEDQMOEREfE9QIeJUB8eFUABiAYDgCsAkLQh8Z1j2dTQh7OphjJfUg8cCkpg9+AAAUg/4AAAhBhiu/g");
	this.shape_1049.setTransform(815.5901,753.2463);

	this.shape_1050 = new cjs.Shape();
	this.shape_1050.graphics.f("#0B88F0").s().p("Eh80AJAIgPgtQhxoFiKsbIAAgBUA+aAnkgHphM0IgUjQUgHuhMjAKZgZdQBUjMBeiwQKgzmRih/QEAgeEKgMQQCgtREAOQExAFEvAIQQFAfPhBSQFfAdFRAjQNZBaLYFZQOmE7J4HTQCrBrCQBxQGAD/C2EVQHaLjCSbnUACRAYygBTAivIgHDkQgnbNDJUJQAZCHAdB1IgkD9QhgIChZGTUg71ChSg9WAAAUg/xAABhBaiudg");
	this.shape_1050.setTransform(787.575,753.2561);

	this.shape_1051 = new cjs.Shape();
	this.shape_1051.graphics.f("#0B88F0").s().p("Eh8nAI0IgNgrQhwoDiJsTIAAgBUA+DAnWgHMhLvIgVjTUgHphLIAJtgaOQBNjNBYitQKBz0Qyi6QD7gtEJgNQP5gyQ9ALQEtADEuAIQP9AaPaBNQFbAbFQAhQMqBRKhImQLwGwIQKkQCGCNBzCWQEhEtCZFBQGWNyCpZLUADAAZfAAHAhUIACDmQAteHJ3M+QBKBXBSBBIglD7Qh2HphwGYUg7OCd7g8tAABUg/zAAAhBciuog");
	this.shape_1051.setTransform(785.875,753.2661);

	this.shape_1052 = new cjs.Shape();
	this.shape_1052.graphics.f("#0B88F0").s().p("Eh8bAIpIgKgrQhvn/iJsMIAAgBUA9uAnIgGyhKrIgUjWUgHkhJsAJBgbAQBFjNBSirQJj0CQCj1QD1g8EJgOQPxg1QzAHQEqABEuAHQP0AWPTBIQFXAZFPAfQL8BIJqL0QI6IkGmN1QBhCvBXC7QDEFcB7FsQFSQCDAWtQDuaNBhf5IAMDoUACAAhAAQnAF1QB6AmCHAMIgmD7QiLHOiJGeUg6nCalg8DAABUg/1AABhBfiu0g");
	this.shape_1052.setTransform(784.2,753.2606);

	this.shape_1053 = new cjs.Shape();
	this.shape_1053.graphics.f("#0B88F0").s().p("Eh8OAIeQhxoIiNskUA+xAnygIEhN4UgIXhQrALVgZNQLV5MU7hNQT+hJVpAYQVKAYUPByUAUZAByAMfAweUAMfAweAF2A/nUADsAoCAckgGRIgnD6Ug8cCkpg9+AAAUg/4AAAhBhiu/g");
	this.shape_1053.setTransform(782.5,753.2463);

	this.shape_1054 = new cjs.Shape();
	this.shape_1054.graphics.f("#0B88F0").s().p("EghLBxxUgSpgPcgTQgm2QtF7coOxZQmMtCuzxeQjRmAkDpZUAzAAoAgB7gyrUAAUgwVAPBgN4QMlvvTxglQTMgiUaibQTLh2SbirQS6jEM7dsQNPYQJFdrIAhCgIgtF1QkZeeObioQBsgiB8gWIhMDbQpQVtpqZ0UgQeArOgP2AEEQ2LNk21TIQsbJVslAAQvsAAv+ubgEh44gfaIAJAAIAFALIgOgLg");
	this.shape_1054.setTransform(754.25,940.9083);

	this.shape_1055 = new cjs.Shape();
	this.shape_1055.graphics.f("#0B88F0").s().p("EgZwBGrUgRsgKdgSugpGUgOoghfgE0gH3Qgmg7hChFQIQBpBzqHQI+v/SsikQN3mRSnADQSZAGTNlPQRJkEQpnHQRZn6NaK5QPHEcMTCyQARAOASAJIiEE2QsBZnGPkhQAXhAAfAFQg3BSg4BpQo4RLpndgUgPuAvKgOVgR4Qyjrjzoc7QuhTCvGABQozAAo/mcgEh1EgxzIASAAQF/GdEzD/QRbJmFXFjQrGiM2w3Zg");
	this.shape_1055.setTransform(748.425,1123.3676);

	this.shape_1056 = new cjs.Shape();
	this.shape_1056.graphics.f("#0B88F0").s().p("EgY0A1vQsvkKtl6IQE0CYFEB/QPJDMRdArQJXAYJeiHQtPZeuVAAQjrAAjwhrgEAsqAVXQhFiqhFiRQHPkWHLllQLUpEKSmoQGQyBFwoiQBKhjBIg6QA/gfA9BdQB9GcTq0xIDaj3QgSA9gTA0QvhYHw/PZQkACSkKCrQi/IljFKsQoactnvAAQmCAAlnxcgANXXbUAPNgj5AN8Ac6QnwEqn1DQQobDwoVB2QBmjEBmjdgEhRPACtUgKXgDbgcIgpTIAaABQH5DZGUB6QazFbBBhqUABbgBqAQJAnhQEWKWERIMQweoHtpspgEAqgAQcIAAAAg");
	this.shape_1056.setTransform(784,1138.3323);

	this.shape_1057 = new cjs.Shape();
	this.shape_1057.graphics.f("#0B88F0").s().p("Eh6ZhG6UAzWABxgB+gLMUgB+gLMARrAtmUARsAtlAPwAAfUAPxAAfANKgwgUANMgwgALSA9xUALTA9vAONg3AUAONg3BALAAJEQLAJFfMzhIgoD7Ug8cCkmg99AACUg8LAABg9nibNg");
	this.shape_1057.setTransform(819.5875,1387.9797);
	this.shape_1057._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1034}]},303).to({state:[{t:this.shape_1035}]},1).to({state:[{t:this.shape_1036}]},1).to({state:[{t:this.shape_1037}]},1).to({state:[{t:this.shape_1038}]},1).to({state:[{t:this.shape_1039}]},1).to({state:[{t:this.shape_1040}]},1).to({state:[{t:this.shape_1041}]},1).to({state:[{t:this.shape_1042}]},1).to({state:[{t:this.shape_1043}]},1).to({state:[{t:this.shape_1044}]},1).to({state:[{t:this.shape_1045}]},1).to({state:[{t:this.shape_1046}]},1).to({state:[{t:this.shape_1047}]},1).to({state:[{t:this.shape_1048}]},1).to({state:[{t:this.shape_1049}]},1).to({state:[{t:this.shape_1050}]},1).to({state:[{t:this.shape_1051}]},1).to({state:[{t:this.shape_1052}]},1).to({state:[{t:this.shape_1053}]},1).to({state:[{t:this.shape_1054}]},1).to({state:[{t:this.shape_1055}]},1).to({state:[{t:this.shape_1056}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[{t:this.shape_1057}]},1).to({state:[]},1).wait(938));
	this.timeline.addTween(cjs.Tween.get(this.shape_1057).wait(326).to({_off:false},0).wait(43).to({_off:true},1).wait(938));

	// некстфон
	this.instance_57 = new lib.фоны_фонкорм();
	this.instance_57.setTransform(74,-97,0.3283,0.3283);

	this.shape_1058 = new cjs.Shape();
	this.shape_1058.graphics.f().s("#4A4A4A").ss(0.1,1,1).p("ECCcAAAMkE3AAA");
	this.shape_1058.setTransform(809.875,847.25);

	this.shape_1059 = new cjs.Shape();
	this.shape_1059.graphics.f("#FFFFFF").s().p("EiCbBFXMAAAiKtMEE3AAAMAAACKtg");
	this.shape_1059.setTransform(809.875,403.375);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1059},{t:this.shape_1058},{t:this.instance_57}]},313).to({state:[]},57).wait(938));

	// КОТЫ
	this.instance_58 = new lib.городскиежильцыперсонажи58();
	this.instance_58.setTransform(243,76,0.5009,0.5009);

	this.instance_59 = new lib.городскиежильцыперсонажи59pngкопия();
	this.instance_59.setTransform(243,82,0.5282,0.5282);

	this.shape_1060 = new cjs.Shape();
	this.shape_1060.graphics.f("#0B88F0").s().p("EAtWAFSQgbgDgcgPQgigSgTgbQgXgeAEggQACgQAMgYQAPgdADgKIAIgnQAFgXAKgMQAJgMAXgNQAbgOAIgHQALgJANgUQAPgXAHgIQAcgdA4gDQAggCBCADIBKgCQAqACAYASQAgAZAIAwQAFAegHAcQgHAegTAVQgNAPgVANIgoAVIiYBHQglASgQAPQgFAGgPAUQgNAQgKAHQgSANgZAAIgKAAgEguEACuQgLgFghgVQgXgOhHgkIheguQgfgQgPgJQgZgQgPgRQgbgfgIgzQgGghABg7QABgoAEgVQAHghARgUQAZgdA1gKQBDgMBGAYQBCAXA1AxQBfBbAiCYQARBJgPAuQgKAegXAUQgZAWgdABIgCAAQgVAAgagMg");
	this.shape_1060.setTransform(952.8344,189.5381);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_58,p:{scaleX:0.5009,scaleY:0.5009,x:243,y:76}}]},273).to({state:[{t:this.shape_1060},{t:this.instance_58,p:{scaleX:0.0509,scaleY:0.0509,x:782,y:479}},{t:this.instance_59}]},18).to({state:[]},22).wait(995));

	// ФОН12
	this.shape_1061 = new cjs.Shape();
	this.shape_1061.graphics.f("#FFFFFF").s().p("EiAGBEWMAAAiIrMEANAAAMAAACIrg");
	this.shape_1061.setTransform(2437.875,418.775);

	this.shape_1062 = new cjs.Shape();
	this.shape_1062.graphics.f().s("#FFFFFF").ss(0.1,1,1).p("EiAGBEWMAAAiIrMEANAAAMAAACIr");
	this.shape_1062.setTransform(798.125,418.775);

	this.shape_1063 = new cjs.Shape();
	this.shape_1063.graphics.f().s("#FFFFFF").ss(0.1,1,1).p("EiAGBEWMAAAiIrIAIAAMEAFAAA");
	this.shape_1063.setTransform(798.125,418.775);

	this.shape_1064 = new cjs.Shape();
	this.shape_1064.graphics.f("#0B88F0").s().p("EglQAFbQruhwABifQgBidLuhwQLvhwQkAAQEJAAD2AHQB4gvD4gmQHmhLKuAAQKuAAHlBLQHmBLgBBpQABBpnfBKQgZARgjAKQgfAKg/ALQjCAgh/AcQh6AahpAfQh9B1pQBZQrtBwwlAAQwkAArvhwg");
	this.shape_1064.setTransform(710.95,631.925);

	this.shape_1065 = new cjs.Shape();
	this.shape_1065.graphics.f("#FFFFFF").s().p("EiAGBEWMAAAiIrMEAFAAAIAIAAMAAABMSIlLAFUhEAAA3giBAAUUg4qAAggtVgAHQg9AAgiAGQg0AJggAaQAjAaA1AIQAiAGBAAAUBmcAAPBmCgBoIEmgFMAAAA69gEgy/AeRQruBwAACfQAACeLuBwQLuBwQlAAQQlAALthwQJPhYB+h1QBpgfB6gbQB/gbDBghQA/gKAggKQAjgLAZgSQHehKAAhoQAAhqnlhLQnlhKquAAQqtAAnmBKQj5Anh5AuQj1gHkJAAQwlAAruBwg");
	this.shape_1065.setTransform(798.875,418.775);

	this.shape_1066 = new cjs.Shape();
	this.shape_1066.graphics.f("#232323").s().p("EhxNAB6QhAAAghgGQg2gIgigaQAggaA0gJQAigGA8AAUAtWAAHA4rgAgUAh/gATBEAgA3IFLgFQDkgECOgFQGFgNE1ggQBOgIAnACQBBACAuAXQh7A2ijAZQhuAQi8AJQkUAOm0AIIkmAFUhZKABbhZfAAAQs6AAs7gCg");
	this.shape_1066.setTransform(1005.225,476.0577);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1062},{t:this.shape_1061}]},270).to({state:[{t:this.shape_1066},{t:this.shape_1065},{t:this.shape_1064},{t:this.shape_1063}]},3).to({state:[]},40).wait(995));

	// ВОДА
	this.shape_1067 = new cjs.Shape();
	this.shape_1067.graphics.f("#0B88F0").s().p("Eh95AQBMAAAggBMD7zAAAMAAAAgBg");
	this.shape_1067.setTransform(793.2,-168.7);

	this.shape_1068 = new cjs.Shape();
	this.shape_1068.graphics.f("#0B88F0").s().p("Eh95gOJMAAAggCMD7zAAAMAAAAgCUg9wA8Vg+9AAAUg+8AAAhAKg8Vg");
	this.shape_1068.setTransform(793.2,24.3625);

	this.shape_1069 = new cjs.Shape();
	this.shape_1069.graphics.f("#0B88F0").s().p("Eh95gsTMAAAggCMD7zAAAMAAAAgCUg8iB4pg+9AAAUg+8AAAhBYh4pg");
	this.shape_1069.setTransform(793.2,217.4229);

	this.shape_1070 = new cjs.Shape();
	this.shape_1070.graphics.f("#0B88F0").s().p("Eh95gkFMAAAg7VMD7zAAAMAAAA9ZUg8dCBcg+tAAAUg/LAABhBeiDhg");
	this.shape_1070.setTransform(793.2,339.5253);

	this.shape_1071 = new cjs.Shape();
	this.shape_1071.graphics.f("#0B88F0").s().p("Eh95gb3MAAAhWpMD7zAAAMAAABayUg8bCKOg+eAABUg/ZAAAhBhiOYg");
	this.shape_1071.setTransform(793.2,461.6619);

	this.shape_1072 = new cjs.Shape();
	this.shape_1072.graphics.f("#0B88F0").s().p("Eh95gTpMAAAhx8MD7zAAAMAAAB4JUg8aCTCg+SAAAUg/lAAAhBiiZPg");
	this.shape_1072.setTransform(793.2,583.7826);

	this.shape_1073 = new cjs.Shape();
	this.shape_1073.graphics.f("#0B88F0").s().p("Eh95gLbMAAAiNPMD7zAAAMAAACVhUg8bCbzg+HAABUg/vAAChBiikIg");
	this.shape_1073.setTransform(793.2,705.9357);

	this.shape_1074 = new cjs.Shape();
	this.shape_1074.graphics.f("#0B88F0").s().p("Eh95gDOMAAAioiMD7zAAAMAAACy4Ug8cCkpg9+AAAUg/4AAAhBhiu/g");
	this.shape_1074.setTransform(793.2,828.0682);

	this.shape_1075 = new cjs.Shape();
	this.shape_1075.graphics.f("#0B88F0").s().p("Eh0qATMUgEshGMgEvhNjQgOp4gSqbUAygAE+ApqgJvUAt6gKFAwZgDKQUajJVmgKIDkgBQCSQCCeQNQCpRxCiR8QCjQUCHQfQCLNSBcNZQBiI7AkJCQAjHmAVITQjNKwjZKvQpebiqDYQQrOZkrhT3QmRKrmPINUgeuAphgfIAAAUg7VAABg8viXAg");
	this.shape_1075.setTransform(794.425,799.7635);

	this.shape_1076 = new cjs.Shape();
	this.shape_1076.graphics.f("#0B88F0").s().p("EhrcAoyUgJWhCQgJghQ9QgcpngjqvUA0QAJ9AijgTfUAmLgULArGgGTQTGmTVhgTIDkgDQEkNoE8N8QFTPRFDPoQFGOQENOjQEXL1C4MDQDDISBJIcQBFHNArImQiaKnixLRQn6bBo/Z9Qp5ZnqbVNQlpLQllIYUgi8A16gjdAAAUg2xAAAg3+iApg");
	this.shape_1076.setTransform(795.65,776.7624);

	this.shape_1077 = new cjs.Shape();
	this.shape_1077.graphics.f("#0B88F0").s().p("EhiNA9iUgOCg+UgOPhUXQgqpXg1rCUA2AAO7AbdgdOUAebgeQAlygJdQR0pdVagcIDlgFQG3LNHYLrQH9MzHlNUQHpMLGUMnQGiKYEUKuQElHnBsH3QBpGzBAI6QhmKciKL0QmVahn8brQokZppVWjQlCL0k5IlUgnMBD+gn0AAAUgyKAAAgzMhr/g");
	this.shape_1077.setTransform(796.875,759.1932);

	this.shape_1078 = new cjs.Shape();
	this.shape_1078.graphics.f("#0B88F0").s().p("EhY/BRbUgStg6ZgS+hXvIh/0eUA3xAT6AUWgm9UAWqgoWAgggMmQQhsmVTgmIDmgHQJKIyJ1JaQKmKUKILAQKLKGIaKtQItI7FyJYQGGG8CQHSQCMGaBUJMQgxKThjMWQkwaDm5dWQnPZsoPX6QkaMYkOIwUgrbBTwgsNAABUgtjAABguahZEg");
	this.shape_1078.setTransform(798.1,747.0956);

	this.shape_1079 = new cjs.Shape();
	this.shape_1079.graphics.f("#0B88F0").s().p("EhPwBkcUgXYg2egXuhbIQhHo3hYrqUA5gAY4ANQgwsUAO7gybAbNgPwQPOvwVMgwIDngHQLcGWMTHJQNPH1MpItQMwIBKgIxQK4HeHOIDQHoGRC0GsQCvGCBpJfQACKJg7M5QjLZil2fEQl6ZtnJZRQjyM8jkI8UgvqBlTgwnAAAUgo6AABgpnhH3g");
	this.shape_1079.setTransform(799.3033,740.5863);

	this.shape_1080 = new cjs.Shape();
	this.shape_1080.graphics.f("#0B88F0").s().p("EhG2B2kUgcDgyhgcdheiQhVonhpr+UA7QAd3AGJg6cUAHKg8gAV7gS6QN6y5VIg5IDmgKQNuD8OxE4QP4FWPMGZQPSF8MmG2QNFGBIpGtQJKFnDYGHQDSFoB/JyQA1J/gTNbUgBnAZDgEzAgxQklZwmDamQjKNhi5JIUgz6B4mg1DAABUgkQAAAgk0g4cg");
	this.shape_1080.setTransform(802.5104,739.7158);

	this.shape_1081 = new cjs.Shape();
	this.shape_1081.graphics.f("#0B88F0").s().p("Eg+SCHzUggugulghNhh8QhjoXh7sRUA9AAi0gA9hEKUgAmhGmAQogWDQMn2DVBhDIDpgKQQABgRNCnQSiC3RtEFQR1D4OtE6QPQEkKFFYQKsE8D8FiQD1FOCUKGQBpJ1AUN+UgACAYigDvAieQjRZzk8b8QijOGiOJTUg4LCNtg5fAAAUgflAAAggAgqzg");
	this.shape_1081.setTransform(808,744.6371);

	this.shape_1082 = new cjs.Shape();
	this.shape_1082.graphics.f("#0B88F0").s().p("EiBZAIeQhxoIiMskUA+wAnygIEhN4UgIWhQrALUgZNQLV5MU7hNQT+hJVqAYQVKAYUPByQUYByQzDAQRbDGLiEDQMOEREfE9QIeJUB8eFUABiAYDgCsAkLQh8Z1j2dTQh7OphjJfUg8cCkpg9+AAAUg/4AAAhBhiu/g");
	this.shape_1082.setTransform(815.5901,753.2463);

	this.shape_1083 = new cjs.Shape();
	this.shape_1083.graphics.f("#0B88F0").s().p("Eh80AJAIgPgtQhxoFiKsbIAAgBUA+aAnkgHphM0IgUjQUgHuhMjAKZgZdQBUjMBeiwQKgzmRih/QEAgeEKgMQQCgtREAOQExAFEvAIQQFAfPhBSQFfAdFRAjQNZBaLYFZQOmE7J4HTQCrBrCQBxQGAD/C2EVQHaLjCSbnUACRAYygBTAivIgHDkQgnbNDJUJQAZCHAdB1IgkD9QhgIChZGTUg71ChSg9WAAAUg/xAABhBaiudg");
	this.shape_1083.setTransform(787.575,753.2561);

	this.shape_1084 = new cjs.Shape();
	this.shape_1084.graphics.f("#0B88F0").s().p("Eh8nAI0IgNgrQhwoDiJsTIAAgBUA+DAnWgHMhLvIgVjTUgHphLIAJtgaOQBNjNBYitQKBz0Qyi6QD7gtEJgNQP5gyQ9ALQEtADEuAIQP9AaPaBNQFbAbFQAhQMqBRKhImQLwGwIQKkQCGCNBzCWQEhEtCZFBQGWNyCpZLUADAAZfAAHAhUIACDmQAteHJ3M+QBKBXBSBBIglD7Qh2HphwGYUg7OCd7g8tAABUg/zAAAhBciuog");
	this.shape_1084.setTransform(785.875,753.2661);

	this.shape_1085 = new cjs.Shape();
	this.shape_1085.graphics.f("#0B88F0").s().p("Eh8bAIpIgKgrQhvn/iJsMIAAgBUA9uAnIgGyhKrIgUjWUgHkhJsAJBgbAQBFjNBSirQJj0CQCj1QD1g8EJgOQPxg1QzAHQEqABEuAHQP0AWPTBIQFXAZFPAfQL8BIJqL0QI6IkGmN1QBhCvBXC7QDEFcB7FsQFSQCDAWtQDuaNBhf5IAMDoUACAAhAAQnAF1QB6AmCHAMIgmD7QiLHOiJGeUg6nCalg8DAABUg/1AABhBfiu0g");
	this.shape_1085.setTransform(784.2,753.2606);

	this.shape_1086 = new cjs.Shape();
	this.shape_1086.graphics.f("#0B88F0").s().p("Eh8OAIeQhxoIiNskUA+xAnygIEhN4UgIXhQrALVgZNQLV5MU7hNQT+hJVpAYQVKAYUPByUAUZAByAMfAweUAMfAweAF2A/nUADsAoCAckgGRIgnD6Ug8cCkpg9+AAAUg/4AAAhBhiu/g");
	this.shape_1086.setTransform(782.5,753.2463);

	this.shape_1087 = new cjs.Shape();
	this.shape_1087.graphics.f("#0B88F0").s().p("EghLBxxUgSpgPcgTQgm2QtF7coOxZQmMtCuzxeQjRmAkDpZUAzAAoAgB7gyrUAAUgwVAPBgN4QMlvvTxglQTMgiUaibQTLh2SbirQS6jEM7dsQNPYQJFdrIAhCgIgtF1QkZeeObioQBsgiB8gWIhMDbQpQVtpqZ0UgQeArOgP2AEEQ2LNk21TIQsbJVslAAQvsAAv+ubgEh44gfaIAJAAIAFALIgOgLg");
	this.shape_1087.setTransform(754.25,940.9083);

	this.shape_1088 = new cjs.Shape();
	this.shape_1088.graphics.f("#0B88F0").s().p("EgZwBGrUgRsgKdgSugpGUgOoghfgE0gH3Qgmg7hChFQIQBpBzqHQI+v/SsikQN3mRSnADQSZAGTNlPQRJkEQpnHQRZn6NaK5QPHEcMTCyQARAOASAJIiEE2QsBZnGPkhQAXhAAfAFQg3BSg4BpQo4RLpndgUgPuAvKgOVgR4Qyjrjzoc7QuhTCvGABQozAAo/mcgEh1EgxzIASAAQF/GdEzD/QRbJmFXFjQrGiM2w3Zg");
	this.shape_1088.setTransform(748.425,1123.3676);

	this.shape_1089 = new cjs.Shape();
	this.shape_1089.graphics.f("#0B88F0").s().p("EgY0A1vQsvkKtl6IQE0CYFEB/QPJDMRdArQJXAYJeiHQtPZeuVAAQjrAAjwhrgEAsqAVXQhFiqhFiRQHPkWHLllQLUpEKSmoQGQyBFwoiQBKhjBIg6QA/gfA9BdQB9GcTq0xIDaj3QgSA9gTA0QvhYHw/PZQkACSkKCrQi/IljFKsQoactnvAAQmCAAlnxcgANXXbUAPNgj5AN8Ac6QnwEqn1DQQobDwoVB2QBmjEBmjdgEhRPACtUgKXgDbgcIgpTIAaABQH5DZGUB6QazFbBBhqUABbgBqAQJAnhQEWKWERIMQweoHtpspgEAqgAQcIAAAAg");
	this.shape_1089.setTransform(784,1138.3323);

	this.shape_1090 = new cjs.Shape();
	this.shape_1090.graphics.f("#0B88F0").s().p("Eh6ZhG6UAzWABxgB+gLMUgB+gLMARrAtmUARsAtlAPwAAfUAPxAAfANKgwgUANMgwgALSA9xUALTA9vAONg3AUAONg3BALAAJEQLAJFfMzhIgoD7Ug8cCkmg99AACUg8LAABg9nibNg");
	this.shape_1090.setTransform(819.5875,1387.9797);
	this.shape_1090._off = true;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1067}]},231).to({state:[{t:this.shape_1068}]},1).to({state:[{t:this.shape_1069}]},1).to({state:[{t:this.shape_1070}]},1).to({state:[{t:this.shape_1071}]},1).to({state:[{t:this.shape_1072}]},1).to({state:[{t:this.shape_1073}]},1).to({state:[{t:this.shape_1074}]},1).to({state:[{t:this.shape_1075}]},1).to({state:[{t:this.shape_1076}]},1).to({state:[{t:this.shape_1077}]},1).to({state:[{t:this.shape_1078}]},1).to({state:[{t:this.shape_1079}]},1).to({state:[{t:this.shape_1080}]},1).to({state:[{t:this.shape_1081}]},1).to({state:[{t:this.shape_1082}]},1).to({state:[{t:this.shape_1083}]},1).to({state:[{t:this.shape_1084}]},1).to({state:[{t:this.shape_1085}]},1).to({state:[{t:this.shape_1086}]},1).to({state:[{t:this.shape_1087}]},1).to({state:[{t:this.shape_1088}]},1).to({state:[{t:this.shape_1089}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[{t:this.shape_1090}]},1).to({state:[]},1).wait(998));
	this.timeline.addTween(cjs.Tween.get(this.shape_1090).wait(254).to({_off:false},0).wait(55).to({_off:true},1).wait(998));

	// Слой_16
	this.shape_1091 = new cjs.Shape();
	this.shape_1091.graphics.f("#232323").s().p("ADFCgQhDhCAAheQAAhdBDhCQBChDBeAAQBeAABCBDQBDBCAABdQAABehDBCQhCBDheAAQheAAhChDgAoFCgQhChCAAheQAAhdBChCQBDhDBeAAQBeAABDBDQBCBCAABdQAABehCBCQhDBDheAAQheAAhDhDg");
	this.shape_1091.setTransform(951.6,419.75);

	this.shape_1092 = new cjs.Shape();
	this.shape_1092.graphics.f("#232323").s().p("ADACeQhBhCAAhcQAAhbBBhBQBBhBBdAAQBcAABBBBQBBBBAABbQAABchBBCQhBBBhcgBQhdABhBhBgAn6CeQhBhCAAhcQAAhbBBhBQBBhBBcAAQBdAABABBQBCBBAABbQAABchCBCQhABBhdgBQhcABhBhBg");
	this.shape_1092.setTransform(951.6,419.75);

	this.shape_1093 = new cjs.Shape();
	this.shape_1093.graphics.f("#232323").s().p("AC9CaQhAhAAAhaQAAhZBAhAQBAhABaAAQBaAABABAQBABAgBBZQABBahABAQhABAhaAAQhaAAhAhAgAnvCaQhAhAAAhaQAAhZBAhAQA/hABbAAQBZAABBBAQBABAgBBZQABBahABAQhBBAhZAAQhbAAg/hAg");
	this.shape_1093.setTransform(951.6,419.775);

	this.shape_1094 = new cjs.Shape();
	this.shape_1094.graphics.f("#232323").s().p("AC4CXQg+g/AAhYQAAhXA+g/QA/g+BYAAQBZAAA+A+QA/A/AABXQAABYg/A/Qg+A+hZAAQhYAAg/g+gAnlCXQg+g/AAhYQAAhXA+g/QA/g+BYAAQBYAAA+A+QA/A/AABXQAABYg/A/Qg+A+hYAAQhYAAg/g+g");
	this.shape_1094.setTransform(951.6,419.775);

	this.shape_1095 = new cjs.Shape();
	this.shape_1095.graphics.f("#232323").s().p("AC0CTQg9g9AAhWQAAhVA9g+QA+g9BWAAQBWAAA9A9QA+A+AABVQAABWg+A9Qg9A+hWAAQhWAAg+g+gAnbCTQg9g9AAhWQAAhVA9g+QA9g9BXAAQBWAAA9A9QA9A+AABVQAABWg9A9Qg9A+hWAAQhXAAg9g+g");
	this.shape_1095.setTransform(951.625,419.775);

	this.shape_1096 = new cjs.Shape();
	this.shape_1096.graphics.f("#232323").s().p("ACxCQQg8g7AAhVQAAhUA8g7QA7g8BVAAQBUAAA8A8QA8A7AABUQAABVg8A7Qg8A8hUAAQhVAAg7g8gAnQCQQg8g7AAhVQAAhUA8g7QA8g8BUAAQBVAAA7A8QA8A7AABUQAABVg8A7Qg7A8hVAAQhUAAg8g8g");
	this.shape_1096.setTransform(951.625,419.8);

	this.shape_1097 = new cjs.Shape();
	this.shape_1097.graphics.f("#232323").s().p("ACtCNQg7g6ABhTQgBhSA7g6QA6g6BTAAQBTAAA6A6QA6A6AABSQAABTg6A6Qg6A6hTAAQhTAAg6g6gAnGCNQg6g6AAhTQAAhSA6g6QA7g6BTAAQBSAAA7A6QA6A6AABSQAABTg6A6Qg7A6hSAAQhTAAg7g6g");
	this.shape_1097.setTransform(951.6,419.775);

	this.shape_1098 = new cjs.Shape();
	this.shape_1098.graphics.f("#232323").s().p("ACpCKQg5g5AAhRQAAhQA5g5QA5g5BQAAQBRAAA5A5QA5A5AABQQAABRg5A5Qg5A5hRAAQhQAAg5g5gAm7CKQg5g5AAhRQAAhQA5g5QA5g5BQAAQBRAAA5A5QA5A5AABQQAABRg5A5Qg5A5hRAAQhQAAg5g5g");
	this.shape_1098.setTransform(951.625,419.775);

	this.shape_1099 = new cjs.Shape();
	this.shape_1099.graphics.f("#232323").s().p("AClCHQg4g4AAhPQAAhOA4g3QA3g4BPAAQBPAAA4A4QA3A3AABOQAABPg3A4Qg4A3hPAAQhPAAg3g3gAmxCHQg3g4AAhPQAAhOA3g3QA4g4BPAAQBPAAA3A4QA4A3AABOQAABPg4A4Qg3A3hPAAQhPAAg4g3g");
	this.shape_1099.setTransform(951.625,419.775);

	this.shape_1100 = new cjs.Shape();
	this.shape_1100.graphics.f("#232323").s().p("AChCDQg3g2AAhNQAAhMA3g3QA2g2BNAAQBNAAA2A2QA3A3AABMQAABNg3A2Qg2A3hNAAQhNAAg2g3gAmmCDQg3g2AAhNQAAhMA3g3QA2g2BNAAQBNAAA2A2QA3A3AABMQAABNg3A2Qg2A3hNAAQhNAAg2g3g");
	this.shape_1100.setTransform(951.625,419.8);

	this.shape_1101 = new cjs.Shape();
	this.shape_1101.graphics.f("#232323").s().p("ACdCAQg1g1AAhLQAAhKA1g1QA1g1BLAAQBLAAA1A1QA1A1AABKQAABLg1A1Qg1A1hLAAQhLAAg1g1gAmcCAQg1g1AAhLQAAhKA1g1QA1g1BLAAQBLAAA1A1QA1A1AABKQAABLg1A1Qg1A1hLAAQhLAAg1g1g");
	this.shape_1101.setTransform(951.625,419.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1091}]},252).to({state:[{t:this.shape_1092}]},1).to({state:[{t:this.shape_1093}]},1).to({state:[{t:this.shape_1094}]},1).to({state:[{t:this.shape_1095}]},1).to({state:[{t:this.shape_1096}]},1).to({state:[{t:this.shape_1097}]},1).to({state:[{t:this.shape_1098}]},1).to({state:[{t:this.shape_1099}]},1).to({state:[{t:this.shape_1100}]},1).to({state:[{t:this.shape_1101}]},1).to({state:[]},49).wait(997));

	// ГЛАЗА
	this.shape_1102 = new cjs.Shape();
	this.shape_1102.graphics.f().s("#FFFFFF").ss(0.1,1,1).p("AJ4AAQAAByhRBQQhRBShyAAQhyAAhRhSQhQhQAAhyQAAhxBQhRQBRhRByAAQByAABRBRQBRBRAABxgAhQAAQAAByhRBQQhQBShyAAQhyAAhRhSQhRhQAAhyQAAhxBRhRQBRhRByAAQByAABQBRQBRBRAABxg");
	this.shape_1102.setTransform(952.025,419.25);

	this.shape_1103 = new cjs.Shape();
	this.shape_1103.graphics.f("#0B88F0").s().p("AHwOnQgvgCgYgjQgSgdgBhAQgBhGgNgbQgSgkhJgsQhIgsgRgmQgKgWgBgjIAAg8QgCgsABgVQADglAQgWQAcglBMgEQBSgDAzAXQAtAVAgAtQAeAoAPA1QANAsAEA5QACAigBBFIgBCRQAAAlgDAWQgGAggQAVQgZAfgrAAIgGAAgEgnXgCCQgzgLgbhHIgSg4QgMghgOgTQgYghgxgWIhZgiQhsgmhIhLQhRhTgEhkQgChDAigmQAggkBBgLQA/gLA/ARQBAARAxAoQAiAbAqA0QA7BKALAMIAmAoQAVAYALAUQAOAZAJApIANBFQAHAdASA4QAOAygCAjQgCAvggAiQgbAeggAAQgHAAgIgBgEAjfgEHQgdglADgtQACgnAYgqQAPgbAjgtIDgkhQAcgkARgTQAagcAbgSQAtgdBDgKQAsgHBOAAQAzABAeAGQArAKAZAaQAVAWAKAkQAHAaADApQADA0gCAhQgEAugOAjQgYA5g4ApQgyAlhCASQg1AOhKAFIiBAGQghABgTAEQgcAFgTANQgbASguBOQgnBCgrAGIgLABQgiAAgcghg");
	this.shape_1103.setTransform(816.3094,137.329);

	this.shape_1104 = new cjs.Shape();
	this.shape_1104.graphics.f("#FFFFFF").s().p("AChDCQhQhQAAhyQAAhxBQhRQBRhQBygBQByABBRBQQBRBRAABxQAAByhRBQQhRBRhyAAQhyAAhRhRgAomDCQhRhQAAhyQAAhxBRhRQBRhQBygBQByABBQBQQBRBRAABxQAAByhRBQQhQBRhyAAQhyAAhRhRg");
	this.shape_1104.setTransform(952.025,419.25);

	this.shape_1105 = new cjs.Shape();
	this.shape_1105.graphics.f("#0B88F0").s().p("Ak+MAQgvgCgYgjQgSgdgBhAQgBhGgNgbQgSgkhJgsQhIgsgRgmQgKgWgBgjIAAg8QgCgsABgVQADglAQgWQAcglBMgEQBSgDAzAXQAtAVAgAtQAeAoAPA1QANAsAEA5QACAigBBFIgBCRQAAAlgDAWQgGAggQAVQgZAfgrAAIgGAAgEA0OAEKQgegkADgtQADgnAXgqQAPgcAjgsIDhkhQAcgkAQgSQAbgdAagRQAugeBCgKQAtgHBNABQA0AAAdAHQAsAJAZAaQAVAWAKAlQAGAZADAqQADAzgCAhQgDAvgPAjQgXA4g4AoQgyAlhDASQg0AOhLAFIiBAGQggACgTADQgdAGgTANQgaARguBPQgnBCgrAGIgLABQgjAAgbgigEg4FgAkQgzgKgbhIIgSg4QgMgggOgUQgYgggxgXIhZghQhsgnhIhKQhRhUgEhjQgChDAigmQAgglBBgLQA/gKA/AQQBAARAxAoQAiAbAqA1QA7BKALALIAmAoQAVAYALAVQAOAZAJApIANBFQAHAcASA4QAOAzgCAjQgCAuggAjQgbAeggAAQgIAAgHgCg");
	this.shape_1105.setTransform(801.0344,21.5265);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1104},{t:this.shape_1103},{t:this.shape_1102}]},252).to({state:[{t:this.shape_1105},{t:this.shape_1104},{t:this.shape_1102}]},10).to({state:[]},49).wait(997));

	// ВАЗА_НОВАЯ
	this.instance_60 = new lib.городскиежильцыперсонажиЦ2346();
	this.instance_60.setTransform(349,0,0.4269,0.4269);
	this.instance_60._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_60).wait(251).to({_off:false},0).wait(1).to({_off:true},59).wait(997));

	// ПЯТНО
	this.shape_1106 = new cjs.Shape();
	this.shape_1106.graphics.f("#FFFFFF").s().p("A4qYsMAAAgxWMAxWAAAMAAAAxWg");
	this.shape_1106.setTransform(333.7,405.7);
	this.shape_1106._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1106).wait(219).to({_off:false},0).to({_off:true},19).wait(1070));

	// ГЛАЗА2
	this.instance_61 = new lib.Анимация14("synched",0);
	this.instance_61.setTransform(319.25,416.3);
	this.instance_61._off = true;

	this.instance_62 = new lib.Анимация15("synched",0);
	this.instance_62.setTransform(314.1,208.05);

	this.shape_1107 = new cjs.Shape();
	this.shape_1107.graphics.f().s("#FFFFFF").ss(0.1,1,1).p("AYs4rMAAAAxXMgxXAAAMAAAgxX");
	this.shape_1107.setTransform(311.8,403.65);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_61}]},219).to({state:[{t:this.instance_62,p:{x:314.1,y:208.05}}]},3).to({state:[{t:this.shape_1107},{t:this.instance_62,p:{x:319.5,y:205.15}}]},9).to({state:[]},7).wait(1070));
	this.timeline.addTween(cjs.Tween.get(this.instance_61).wait(219).to({_off:false},0).to({_off:true,x:314.1,y:208.05},3).wait(1086));

	// КОТ2
	this.instance_63 = new lib.Анимация16("synched",0);
	this.instance_63.setTransform(305.05,352.6);
	this.instance_63._off = true;

	this.instance_64 = new lib.Анимация17("synched",0);
	this.instance_64.setTransform(299.9,144.35);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_63}]},219).to({state:[{t:this.instance_64}]},3).to({state:[]},16).wait(1070));
	this.timeline.addTween(cjs.Tween.get(this.instance_63).wait(219).to({_off:false},0).to({_off:true,x:299.9,y:144.35},3).wait(1086));

	// Каркас_15
	this.shape_1108 = new cjs.Shape();
	this.shape_1108.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgKQAKgSAEgUQAIgaAMgYIACgEQAEgMAAgRQAKAQAFARQAHAVgCAWQgEAcgUAWQgOAPgSAKQgRAKgaAFgAiHEpQgegFgdgNIAWgLQATgKARgOQAKgFAKgGQAHgHAGgJQAJgLAKgJIAIgOIAHgOQAJgOAKgMQAEgMgCgNQADgRAJgOQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgGALIgMAYIgKAPIgHAQIgQAaQgHAIgEALIgEAKQgHAMgIALQgLAOgPALIgeAWQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgHAVIgTAyQgLAbgPAZQgRAVgWAPIg5ArIgPAOgABTgXIgZgNIADgUQAHg/ABhAQAPgvAugeQAsgaA2ALIARA5IAEASQAEAWgLAUIgVAmQgIAaAbAUQAiASApgZQAagJAcgDQAPgCAKAMQAEANgUAJIg6AdIg3AaIgsAPIghALIgUAKQgjgcgygZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA6AEA+QgtgVgggKg");
	this.shape_1108.setTransform(1207.7458,169.1915);

	this.shape_1109 = new cjs.Shape();
	this.shape_1109.graphics.f("#232323").s().p("AggGFIhZgLQgngGgngMQgpgOglgXQhXgzhGhKIgHgIQgMgOgJgQQgKgYgBgaQgDggAGggQANguAngeQAXgYAagVQAhgWAogIQA9gPA+ACIAAhzQAAgXAEgWQADgMAGgMIAXgtQAJgQAMgQQAVgRAfAEQAYAAAYAFQAdALAUAbQAQAPAPAPIABACIAlgWQARgJARgGQAfgJAgADQAdgBAcAJQAfANAQAhQAJAPAFASQAQAwgGAxQA+gDA4AbQArAjgTBCQgUAtg0AUQg7AkhBAZIguARIABABQAWAkAHArQAEAggFAhQgLA9gwAtQguAohAAHQgcAEgeAAQgdAAgggFgACcCrIgCAEQgMAXgIAaQgEAVgKASQgHAJgIAJIgYAbQAagFARgKQASgKAOgPQAUgWAEgcQACgXgHgVQgFgQgKgRQAAARgEANgAgZAPIgJAOQgCAKAAAJQADATgEARQgJAPgDAQQACANgEANQgKAMgJAOIgHANIgIAPQgKAIgJALQgGAKgHAGQgKAHgKAFQgRANgTALIgWAKQAdAOAeAEIAiAEIAEgGQAXgSAagQIAegXQAPgKALgPQAIgKAHgMIAEgKQAEgLAHgJIAQgZIAHgQIAKgPIAMgZIAGgKQgWgQgbgMIhAgZgAlxAoIgNAMQgTAfAKAgQAPAeAYAXIANALIAPgOIA5gsQAWgPARgVQAPgZALgbIATgxIAHgVQgWgCgYADQgqAGgoAOIgGADQAIAHACAKQAEANgGALQgOAagYgDQgMgBgKgIIgEgFIgDADgACBkHQguAfgPAvQgBA/gHA/IgDAUIAZANQAyAaAjAbIAUgKIAhgKIAsgPIA3gbIA6gdQAUgIgEgOQgKgMgPACQgcADgaAJQgpAagigSQgbgUAIgbIAVglQALgUgEgWIgEgSIgRg6QgQgDgPAAQgkAAgfASgAhAk1IgPAdQgKAQgEASQgCARAAAPIABBuQAgAKAtAVQgEg9AMg7QAGghAQggIgKgIIgageQgOgQgPAAQgGAAgGADg");
	this.shape_1109.setTransform(1207.8268,169.439);

	this.shape_1110 = new cjs.Shape();
	this.shape_1110.graphics.f("rgba(255,255,255,0.067)").s().p("ABmEfIAPgTQALgSAEgUQAIgaANgYIACgDQAEgMAAgRQAJAQAGAQQAGAWgCAWQgFAcgUAWQgOAPgTAJQgRAKgYADgAiKEoQgegFgdgOIAWgKQATgLARgNIAUgLQAIgHAFgJQAJgLALgIIAIgPIAHgNIATgaQAEgMgBgOQADgPAJgPQAFgRgGgVQAAgIADgKIAIgOIABgBQAiAMAgAPQAbAMAVAQIgGALIgMAYIgKAPIgIAQQgGANgKAMQgHAJgEALIgFAJQgGANgJAKQgLANgPAKQgPAMgPALQgaAQgXARIgEAGgAlhCnQgYgWgPgcQgLggATgfIANgMIADgDIAFAFQAKAIALABQAYACAPgaQAFgLgDgMQgCgKgJgIIAGgCQAogOAqgGQAYgDAXACIgIAUIgTAyQgKAbgQAZQgQAWgXAOIg4AqIgQANgABUgVIgZgOIAEgTQAIg/gEhCQAOgwA2gaQAtgZA1AMIAQA6IAEARQAEAWgLAUIgWAlQgIAbAaAUQAiATApgZQAagJAcgCQAPgCAKAMQAEAPgUAHIg6AcIg4AZIgsAPIghAKIgVAKQgigdgygagAhghmIgBhuQAAgQADgQQAEgSAJgQIAQgdQAVgIATAVIAaAdIAKAJQgPAggHAhQgMA8AFA8QgugVgggKg");
	this.shape_1110.setTransform(1182.3708,155.0915);

	this.shape_1111 = new cjs.Shape();
	this.shape_1111.graphics.f("#232323").s().p("AgkGFIhZgMQgngHgngMQgogOglgXQhWg1hGhKIgHgIQgMgOgJgQQgKgYgBgXQgDggAGggQANgtAngfQAWgYAbgUQAggXAogHQA+gQA9ACIAAhzQAAgXAEgVQADgMAHgMIAXgtQAJgRAMgQQAUgQAfAEQAYgBAZAFQAdAMAUAbIAeAdIACADQASgNATgKIAhgPQAfgJAqAIQAdABAbAIQAfANAQAiQAIAQAGASQAPAugHAyQA9gBA4AbQArAkgVBBQgVAtgzAUQg8AihCAYIguARIABABQAVAkAHArQAEAhgGAgQgMA9gxAsQgvAng+AEQgbAEgcAAQgfAAghgFgACaCuIgCAEQgNAYgIAZQgEAVgLASIgPASIgXAYQAYgCARgKQATgKAOgPQAUgWAFgcQACgVgGgWQgGgRgJgQQAAARgEAMgAgcAOIgIAPQgDAKAAAIQAGAUgFARQgJAQgDAPQABANgEAMIgTAaIgHAOIgIAOQgLAJgJAKQgFAKgIAGIgUAMQgRANgTAKIgWALQAdANAeAFIAiAEIAEgGQAXgSAagQQAPgKAPgMQAPgKALgOQAJgJAGgNIAFgKQAEgLAHgJQAKgLAGgOIAIgPIAKgPIAMgYIAGgLQgVgRgbgMQgggOgigMgAl0AnIgNAMQgTAgALAfQAPAcAYAXIAMALIAQgOIA4gpQAXgPAQgWQAQgYAKgbIATgyIAIgVQgXgBgYADQgqAGgoAOIgGACQAJAIACAKQADAMgFALQgPAZgYgBQgLgBgKgJIgFgEIgDACgACGkEQg2AbgOAwQAEBBgIA/IgEAUIAZANQAyAaAiAdIAVgKIAhgKIAsgOIA4gaIA6gcQAUgHgEgOQgKgMgPABQgcACgaAJQgpAZgigTQgagUAIgaIAWgmQALgTgEgWIgEgSIgQg6QgRgEgQAAQgjAAgeARgAhCk2IgQAeQgJAQgEASQgDAQAAAPIABBuQAgALAuAVQgFg9AMg7QAHghAPghIgKgIIgagdQgOgQgPAAQgFAAgGACg");
	this.shape_1111.setTransform(1182.4669,155.3437);

	this.shape_1112 = new cjs.Shape();
	this.shape_1112.graphics.f("rgba(255,255,255,0.067)").s().p("ABiEhQAJgJAGgJQAMgSAEgVQAJgZANgYIACgDQAEgMABgRQAJAQAFARQAHAWgEAVQgFAcgVAWQgOAPgTAJQgRAJgXABgAiNEmQgdgFgegOIAWgKQAUgKARgNIAUgMIANgPQAJgLALgIIAIgOIAHgOIAUgaQAEgLgBgOQADgPAKgQQAEgQgHgWQAAgIADgKIAIgOIABgBQAiANAiAQQAbANAVAQIgGALIgNAYIgKAPIgIAPQgHANgKAMQgHAJgEAKIgFAKQgHANgJAJQgLAOgOAJQgPAMgQAKQgaAQgXARIgEAGgAljCkQgYgXgPgZQgLggATggIANgLIADgDIAFAEQAKAJALABQAYADAPgbQAFgLgDgMQgCgKgJgHIAGgDQAogOAqgGQAYgDAXABIgIAVIgTAyQgKAbgQAZQgQAVgXAPQgcAWgcASIgQANgABVgTIgYgOQACgIACgMQAJg+gJhFQAOgwA9gXQAtgYA2ANIAPA6IAEASQADAWgMAUQgLATgMARQgIAbAaAUQAhAUAqgZQAbgHAbgDQAQAAAKALQADAPgVAHIg6AbIg4AXIgsAPIgiAJIgUAKQgigdgygbgAhihnIgBhuQAAgPADgRQAEgSAJgQIAQgdQAVgIATAVIAbAeIAJAIQgPAggHAhQgMA8AFA8QgugVgggKg");
	this.shape_1112.setTransform(1157.0323,141.0165);

	this.shape_1113 = new cjs.Shape();
	this.shape_1113.graphics.f("#232323").s().p("AgoGFIhYgNQgogHgngMQgngPglgXQhWg1hFhMIgHgHQgMgOgJgQQgJgZgCgTQgDggAGggQANgtAngfQAWgZAbgUQAggXAogHQA+gPA9ACIAAhzQAAgXAEgWQADgMAHgMIAXgtQAJgQAMgQQAUgRAfAEQAYAAAZAFQAdALAUAbQAQAPAOAPIACACQASgMATgKQAQgJARgGQAfgJAzAMQAdABAbAJQAeAOAQAiQAIAQAFASQAOAwgHAxQA9gBA3AdQArAlgWBAQgWAsg0ATQg8AhhCAYIguAPIABACQAUAkAGArQAEAhgHAgQgOA9gxArQgvAng9ABQgaAEgaAAQggAAgjgGgACYCyIgCADQgNAYgJAZQgEAVgMASQgGAJgJAJIgWAWQAXgBARgJQATgJAOgPQAVgWAFgcQAEgVgHgWQgFgRgJgQQgBARgEAMgAgeAOIgIAOQgDAKAAAIQAHAWgEAQQgKAQgDAPQABAOgEALIgUAaIgHAOIgIAOQgLAIgJALIgNAPIgUAMQgRANgUAKIgWAKQAeAOAdAFIAiAEIAEgGQAXgRAagQQAQgKAPgMQAOgJALgOQAJgJAHgNIAFgKQAEgKAHgJQAKgMAHgNIAIgPIAKgPIANgYIAGgLQgVgQgbgNQgigQgigNgAl2AnIgNALQgTAgALAgQAPAZAYAXIAMALIAQgNQAcgSAcgWQAXgPAQgVQAQgZAKgbIATgyIAIgVQgXgBgYADQgqAGgoAOIgGADQAJAHACAKQADAMgFALQgPAbgYgDQgLgBgKgJIgFgEIgDADgACLkBQg9AXgOAwQAJBFgJA+QgCAMgCAIIAYAOQAyAbAiAdIAUgKIAigJIAsgPIA4gXIA6gbQAVgHgDgPQgKgLgQAAQgbADgbAHQgqAZghgUQgagUAIgbQAMgRALgTQAMgUgDgWIgEgSIgPg6QgTgFgSAAQghAAgdAQgAhEk2IgQAdQgJAQgEASQgDARAAAPIABBuQAgAKAuAVQgFg8AMg8QAHghAPggIgJgIIgbgeQgOgQgPAAQgGAAgFADg");
	this.shape_1113.setTransform(1157.1365,141.2472);

	this.shape_1114 = new cjs.Shape();
	this.shape_1114.graphics.f("rgba(255,255,255,0.067)").s().p("ABIE4IAWgVIAQgSQALgRAFgVQAKgYANgYIABgEQAFgMABgRQAJAQAFARQAGAWgEAWQgFAbgVAWQgOAPgUAJQgRAIgVAAIgCAAgAiQElQgdgFgegPIAXgJQATgLARgMIAUgMQAIgGAFgJQAKgLAKgIIAJgOIAHgOIAUgZQAFgLgBgOQAEgPAJgPQAGgRgKgWQAAgJADgJIAIgPIABAAQAiANAkARQAbAOAVARIgHAKIgMAYIgLAPIgIAPQgIANgKALQgHAJgEALIgFAJQgIAMgIAKQgMANgOAJQgPAMgQAKQgZAPgYARIgEAGgAllChQgXgXgQgXQgLgfATggIANgMIADgCIAFAEQAKAJALABQAYACAPgaQAFgLgDgMQgCgKgJgIIAGgCQAogOAqgGQAYgDAXABIgIAVIgTAyQgKAbgQAZQgQAVgXAPQgcAWgcAPQgKAHgFAGgABXgRIgZgOIAFgUQAKg+gOhHQAOgwBFgTQAtgXA1ANIAOA6IAEASQADAWgMAUQgLATgNARQgJAaAaAVQAhAVAqgYQAbgIAcgBQAPgBAKAMQADAOgVAHIg7AaQgbANgeAKQgVAHgXAGIghAJIgVAKQghgegxgcgAhkhnIgBhuQAAgQADgQQAEgSAJgQIAQgeQAVgIATAWIAbAdIAJAIQgPAhgHAhQgMA7AFA9QgugVgggKg");
	this.shape_1114.setTransform(1131.6823,126.9428);

	this.shape_1115 = new cjs.Shape();
	this.shape_1115.graphics.f("#232323").s().p("AgsGFIhYgOQgogHgmgNQgogPglgYQhVg2hEhLIgHgIQgLgOgJgQQgLgYgBgRQgDggAGggQANgsAnggQAWgYAbgUQAggXAogHQA+gQA9ACIAAhzQAAgWAEgWQADgMAHgMIAXgtQAJgRAMgPQAUgRAfAEQAYgBAZAFQAdAMAUAbQAQAOAOAQIACACQASgNATgJQAQgJARgHQAfgJA8ASQAcABAcAKQAfAOAOAjQAIAQAEASQAOAvgJAyQA+AAA3AeQApAlgXBAQgWAsg0ASQg+AghCAWIguAPIABACQAUAkAEArQAEAhgIAgQgOA9gyAqQgwAmg7gBQgYADgYAAQgjAAgkgGgACVC1IgBAEQgNAYgKAYQgFAVgLARIgQASIgWAVQAWABASgJQAUgJAOgPQAVgWAFgbQAEgWgGgWQgFgRgJgQQgBARgFAMgAggANIgIAPQgDAJAAAJQAKAWgGARQgJAPgEAPQABAOgFALIgUAZIgHAOIgJAOQgKAIgKALQgFAJgIAGIgUAMQgRAMgTALIgXAJQAeAPAdAFIAiAEIAEgGQAYgRAZgPQAQgKAPgMQAOgJANgNQAHgKAIgMIAFgJQAEgLAHgJQAKgLAIgNIAIgPIALgPIAMgYIAHgKQgVgRgbgOQgkgRgigNgAl4AmIgNAMQgTAgALAfQAQAXAXAXIANALQAFgGAKgHQAcgPAcgWQAXgPAQgVQAQgZAKgbIATgyIAIgVQgXgBgYADQgqAGgoAOIgGACQAJAIACAKQADAMgFALQgPAagYgCQgLgBgKgJIgFgEIgDACgACRj9QhFATgOAwQAOBHgKA+IgFAUIAZAOQAxAcAhAeIAVgKIAhgJQAXgGAVgHQAegKAbgNIA7gaQAVgHgDgOQgKgMgPABQgcABgbAIQgqAYghgVQgagVAJgaQANgRALgTQAMgUgDgWIgEgSIgOg6QgUgFgSAAQggAAgcAPgAhGk3IgQAeQgJAQgEASQgDAQAAAQIABBuQAgAKAuAVQgFg9AMg7QAHghAPghIgJgIIgbgdQgOgQgPAAQgGAAgFACg");
	this.shape_1115.setTransform(1131.7851,127.1389);

	this.shape_1116 = new cjs.Shape();
	this.shape_1116.graphics.f("rgba(255,255,255,0.067)").s().p("ABFE4IAVgTIAQgRQAMgRAFgVQAKgZAOgXIABgEQAFgMABgRQAJARAFARQAFAWgEAVQgGAcgVAVQgOAPgUAIQgOAHgQAAIgJgBgAiTEjQgdgFgdgPIAWgJQATgKASgNIAUgLIANgPQAJgLALgIIAJgOIAIgNIAUgZQAEgLAAgOQAEgQAKgPQAFgQgLgXQAAgJADgKIAIgOIABAAQAiANAnATQAZAOAWASIgHAKIgNAXIgLAPIgJAPQgHANgLALIgLATIgFAKQgIAMgIAKQgNANgNAHQgPAMgQAKQgaAPgYARIgEAGgAlnCeQgXgXgQgVQgLgfATggIANgMIADgCIAFAEQAKAJALABQAYACAPgaQAFgLgDgMQgCgLgJgHIAGgCQAogOAqgGQAYgDAXABIgIAVIgTAyQgKAbgQAZQgQAVgXAPQgcAWgcANQgKAGgFAHgABYgPIgYgPIAFgTQAKg+gShKQAOgwBMgPQAugXA1APIANA6IADASQACAWgMATIgYAkQgJAbAZAVQAhAVAqgXQAbgIAcgBQAQAAAJAMQADAPgVAGIg8AZIg5AWQgVAHgXAGIgiAIIgUAJQgigfgwgcgAhmhoIgBhuQAAgQADgQQAEgSAJgQIAQgeQAVgIATAWIAbAdIAJAIQgPAhgHAhQgMA7AFA9QgugVgggKg");
	this.shape_1116.setTransform(1106.3319,112.8687);

	this.shape_1117 = new cjs.Shape();
	this.shape_1117.graphics.f("#232323").s().p("AgvGEIhZgOQgngIgngMQgngQglgYQhVg2hDhNIgHgIQgLgNgJgRQgKgYgCgNQgDggAGggQANgtAngfQAWgYAbgVQAggWAogIQA+gPA9ACIAAhzQAAgXAEgWQADgMAHgMIAXgtQAJgQAMgQQAUgRAfAEQAYAAAZAFQAdALAUAbQAQAPAOAPIACACQASgMATgKQAQgJARgGQAfgJBFAXQAcABAcAKQAdAPAOAjQAJAQAEASQAMAwgJAxQA+ACA2AeQAoAngXA/QgXAsg1ARQg+AfhCAVIgvAOIABABQATAlAEAsQADAggIAhQgPA7gzAqQgxAlg5gDQgXADgWAAQgkAAglgIgACTC5IgBADQgOAYgKAYQgFAVgMARIgQASIgVATQAVACASgJQAUgIAOgOQAVgVAGgcQAEgWgFgWQgFgRgJgQQgBARgFAMgAgiANIgIAOQgDAKAAAJQALAWgFARQgKAPgEAPQAAAOgEALIgUAZIgIAOIgJAOQgLAIgJAKIgNAQIgUALQgSANgTAJIgWAKQAdAPAdAFIAiAFIAEgGQAYgSAagPQAQgJAPgMQANgIANgNQAIgKAIgMIAFgJIALgTQALgLAHgNIAJgPIALgPIANgXIAHgLQgWgSgZgNQgngUgigNgAl6AmIgNAMQgTAfALAgQAQAUAXAXIANAMQAFgHAKgGQAcgOAcgWQAXgPAQgVQAQgZAKgbIATgxIAIgVQgXgCgYADQgqAGgoAOIgGADQAJAGACALQADANgFALQgPAagYgDQgLgBgKgIIgFgFIgDADgACWj6QhMAPgOAwQASBKgKA+IgFAUIAYAOQAwAcAiAgIAUgKIAigIQAXgFAVgIIA5gWIA8gZQAVgGgDgOQgJgMgQAAQgcABgbAHQgqAXghgUQgZgWAJgaIAYgkQAMgTgCgWIgDgSIgNg7QgVgFgUAAQgeAAgcANgAhIk3IgQAdQgJAQgEASQgDARAAAPIABBuQAgAKAuAVQgFg8AMg8QAHghAPggIgJgIIgbgeQgOgPgPAAQgGAAgFACg");
	this.shape_1117.setTransform(1106.4314,113.0311);

	this.shape_1118 = new cjs.Shape();
	this.shape_1118.graphics.f("rgba(255,255,255,0.067)").s().p("ABCE5IAUgSIAQgRQAMgRAGgVQAKgYAPgXIABgEQAFgMACgRQAIARAEARQAGAWgFAWQgGAbgWAVQgOAOgUAIQgNAGgNAAIgMgBgAiWEiQgdgFgdgQIAWgJQATgKASgMIAUgLIAOgQIAUgSIAJgOIAIgNIAUgZQAGgLgBgOQAEgPAKgPQAGgQgNgYQAAgJADgJIAIgPIABAAQAiANApAVQAZAPAVASIgHAKIgNAXIgLAOIgJAPIgSAYQgIAJgEAKIgGAJQgIANgIAJQgMAMgOAIQgPALgQAKQgaAPgYARIgEAGgAloCaIgogpQgLgfATggIANgMIADgCIAFAEQAKAJALABQAYACAPgaQAFgLgDgMQgCgKgJgIIAGgCQAogOAqgGQAYgDAXABIgIAVIgTAyQgKAbgQAZQgQAVgXAPQgcAWgcALIgPANgABZgNIgYgPIAFgTQAMg+gXhNQAOgwBTgLQAugWA1AQIAMA6IADASQACAWgNATQgMATgMARQgKAZAZAXQAhAVAqgWQAbgHAcgBQAPAAAKAMQACAPgVAGIg7AYIg6AVQgVAHgYAFIghAIIgVAIQghgfgwgdgAhohpIgBhvQAAgPADgQQAEgSAJgQIAQgeQAVgIATAWIAbAdIAJAIQgPAhgHAhQgMA7AFA9QgugVgggKg");
	this.shape_1118.setTransform(1080.9764,98.8305);

	this.shape_1119 = new cjs.Shape();
	this.shape_1119.graphics.f("#232323").s().p("AgzGEIhZgPQgngIgmgNQgogQgkgYQhUg4hDhMIgHgIQgLgOgJgRIgMgiQgDggAGggQANgsAnggQAWgYAbgUQAggXAogHQA+gQA9ACIAAhzQAAgWAEgWQADgMAHgMIAXgtQAJgRAMgQQAUgQAfAEQAYgBAZAFQAdAMAUAbQAQAOAOAQIACACQASgNATgKIAhgPQAfgJBOAcQAcADAbAKQAeAPANAkQAIAQAEASQALAwgKAxQA+ADA1AfQApAngZA/QgYArg1AQQg+AehDAVIgvANIABABQATAlADAsQACAhgIAgQgRA7g0ApQgwAkg3gFQgVACgUAAQgnAAgngIgACRC8IgBAEQgPAXgKAYQgGAVgMARIgQARIgUASQAUAEASgJQAUgIAOgOQAWgVAGgbQAFgWgGgWQgEgRgIgRQgCARgFAMgAgkAMIgIAPQgDAJAAAJQANAYgGAQQgKAPgEAPQABAOgGALIgUAZIgIANIgJAOIgUASIgOAQIgUALQgSAMgTAKIgWAJQAdAQAdAFIAiAFIAEgGQAYgRAagPQAQgKAPgLQAOgIAMgMQAIgJAIgNIAGgJQAEgKAIgJIASgYIAJgPIALgOIANgXIAHgKQgVgSgZgPQgogVgjgNgAl8AlIgNAMQgTAgALAfIAoApIAMAMIAPgNQAcgLAcgWQAXgPAQgVQAQgZAKgbIATgyIAIgVQgXgBgYADQgqAGgoAOIgGACQAJAIACAKQADAMgFALQgPAagYgCQgLgBgKgJIgFgEIgDACgACbj2QhTALgOAwQAXBNgMA+IgFATIAYAPQAwAdAhAfIAVgIIAhgIQAYgFAVgHIA6gVIA7gYQAVgGgCgPQgKgMgPAAQgcABgbAHQgqAWghgVQgZgXAKgZQAMgRAMgTQANgTgCgWIgDgSIgMg6QgWgHgVAAQgdAAgbANgAhKk4IgQAeQgJAQgEASQgDAQAAAPIABBvQAgAKAuAVQgFg9AMg7QAHghAPghIgJgIIgbgdQgOgQgPAAQgGAAgFACg");
	this.shape_1119.setTransform(1081.0771,98.9138);

	this.shape_1120 = new cjs.Shape();
	this.shape_1120.graphics.f("rgba(255,255,255,0.067)").s().p("AA/E5IATgQIARgRQAMgRAGgUQAKgZAPgWIACgEQAFgMACgRQAIASAEAQQAFAWgFAWQgGAbgXAVQgOANgUAIQgLAFgKAAQgIAAgIgCgAiZEgQgdgGgdgPIAXgJQATgJASgNIAUgLQAHgGAGgJQAKgKALgIIAIgOIAJgNIAVgYQAFgLAAgOQAFgPAKgPQAGgRgPgYQAAgJADgJIAIgPIABAAQAjANAqAYQAZAOAVASIgHALIgOAXIgMAOIgJAPIgSAXQgIAJgEAKIgGAJQgIAMgIAKQgOAMgMAGQgQAMgQAJQgaAPgYARIgEAFgAlqCXQgXgYgRgPQgLgfATggIANgMIADgCIAFAEQAKAJALABQAYACAPgaQAFgLgDgMQgCgKgJgIIAGgCQAogOAqgGQAYgDAXABIgIAVIgTAyQgKAbgQAZQgQAVgXAPQgcAWgcAJQgJAGgGAHgABagLIgXgQIAFgTQANg9gchQQAOgwBagHQAvgVA0AQIALA7IADASQABAWgMATIgaAjQgJAaAYAXQAgAVArgVQAcgGAbgBQAPAAAJANQADAOgVAGIg9AWIg5AVIgtALIgiAHIgVAJQgggggwgegAhqhqIgBhuQAAgQADgQQAEgSAJgQIAQgeQAVgIATAWIAbAdIAJAIQgPAhgHAhQgMA7AFA9QgugVgggKg");
	this.shape_1120.setTransform(1055.6014,84.7907);

	this.shape_1121 = new cjs.Shape();
	this.shape_1121.graphics.f("#232323").s().p("Ag3GEIhYgQQgogIgmgOQgngPgkgZQhUg4hChOIgHgIQgLgOgIgQIgNgfQgDggAGggQANgtAngfQAWgYAbgVQAggWAogIQA+gPA9ACIAAhzQAAgXAEgWQADgMAHgMIAXgtQAJgQAMgQQAUgRAfAEQAYAAAZAFQAdALAUAbQAQAPAOAPIACACQASgMATgKQAQgJARgGQAfgJBWAiQAdACAbALQAdAQANAjQAHARAEASQAKAwgKAxQA9ADA1AhQAoAogaA9QgZAsg1APQg/AehDASIgvANIABABQASAlACAsQACAhgJAgQgRA7g1AoQgxAjg1gIQgUACgTAAQgoAAgogIgACPDAIgCADQgPAXgKAYQgGAVgMARIgRARIgTAPQATAGASgIQAUgIAOgOQAXgUAGgbQAFgWgFgWQgEgRgIgRQgCARgFAMgAgmAMIgIAOQgDAKAAAJQAPAYgGARQgKAOgFAPQAAAOgFALIgVAYIgJAOIgIAOQgLAHgKALQgGAJgHAGIgUALQgSAMgTAJIgXAKQAdAPAdAGIAiAFIAEgGQAYgRAagOQAQgKAQgLQAMgHAOgMQAIgJAIgMIAGgJQAEgLAIgIIASgYIAJgPIAMgOIAOgXIAHgKQgVgSgZgPQgqgYgjgNgAl+AlIgNAMQgTAfALAgQARAPAXAYIAMALQAGgGAJgGQAcgKAcgWQAXgPAQgVQAQgZAKgbIATgxIAIgVQgXgCgYADQgqAGgoAOIgGADQAJAHACAKQADANgFALQgPAagYgDQgLgBgKgIIgFgFIgDADgACgjzQhaAHgOAwQAcBQgNA+IgFATIAXAPQAwAeAgAgIAVgIIAigHIAtgMIA5gUIA9gWQAVgGgDgPQgJgMgPAAQgbAAgcAGQgrAVgggVQgYgXAJgZIAagjQAMgTgBgWIgDgSIgLg7QgXgHgWAAQgcAAgaALgAhMk4IgQAdQgJAQgEASQgDARAAAPIABBuQAgAKAuAVQgFg8AMg8QAHghAPggIgJgIIgbgeQgOgPgPAAQgGAAgFACg");
	this.shape_1121.setTransform(1055.728,84.8092);

	this.shape_1122 = new cjs.Shape();
	this.shape_1122.graphics.f("rgba(255,255,255,0.067)").s().p("AA8E5IASgOIARgRQANgRAGgUQALgYAQgXIABgDQAFgMACgRQAJARADARQAEAWgFAWQgGAbgXAUQgQANgTAIQgKAEgJAAQgJAAgIgDgAicEeQgdgGgcgPIAWgJQAUgKASgMIAUgLIAOgPIAUgRIAJgOIAJgNIAVgYQAFgLABgOQAEgPALgPQAGgQgRgaQAAgIADgKIAJgOIAAgBQAjANAsAaQAaAPAUATIgHAKIgPAXIgLAOIgKAOQgIANgLALQgHAIgFAKIgGAJQgHAMgKAJQgNAMgMAGQgQAMgQAJQgaAOgYARIgFAGgAlrCTQgXgYgSgMQgKggATgfIANgMIACgDIAFAFQAJAIAMABQAYACAPgaQAGgLgEgMQgCgKgIgHIAGgDQAogOApgGQAYgDAXACIgHAUIgTAyQgLAbgPAZQgRAWgXAOQgcAWgbAIQgJAGgGAGgABcgKIgXgPIAFgTQAPg+gihTQAOgvBigDQAugUA1ARIAKA7IACASQABAWgNATQgMASgOAQQgKAaAYAXQAgAWArgVQAbgGAcABQAPAAAJANQADAOgWAGIg8AVIg6ATIguALIgiAHIgVAIQgfgggvgggAhrhsIgChuIADggQAEgSAJgQIAQgdQAVgIAUAVIAaAeIAKAIQgPAggIAhQgLA8AEA8QgtgVgggKg");
	this.shape_1122.setTransform(1030.2262,70.7605);

	this.shape_1123 = new cjs.Shape();
	this.shape_1123.graphics.f("#232323").s().p("AA8GLQg8AGg6gOQgtgGgsgKQgngIgmgOQgngRgkgZQhTg5hChNIgGgIQgLgOgIgRQgJgYgFgEQgDggAGggQAMgsAoggQAXgYAagUQAggXAogHQA/gQA8ACIAAhzQABgXAEgVQADgMAGgMIAXgtQAJgRAMgQQAUgQAgAEQAYgBAYAFQAeAMATAaIAfAeIABADQASgNATgJQAQgJASgHQAfgJBeAoQAdADAaALQAeARALAjQAIARADASQAKAwgMAxQA+AEA0AiQAnAogbA9QgZAsg2AOQg/AchDASIgwALIABACQASAlABAsQABAhgJAgQgSA7g2AnQgnAagnAAQgLAAgMgCgACNDDIgBAEQgQAWgLAYQgGAVgNAQIgRARIgSAOQASAHASgHQATgIAQgNQAXgVAGgbQAFgVgEgWQgDgRgJgSQgCARgFAMgAgnALIgJAPQgDAKAAAIQARAZgGARQgLAOgEAPQgBAOgFALIgVAYIgJANIgJAOIgUASIgOAPIgUALQgSAMgUAJIgWAJQAcAPAdAHIAiAFIAFgGQAYgQAagPQAQgJAQgLQAMgGANgMQAKgJAHgMIAGgJQAFgKAHgJQALgKAIgNIAKgPIALgOIAPgWIAHgKQgUgTgagPQgsgbgjgNgAl/AkIgNAMQgTAgAKAfQASANAXAYIAMAMQAGgHAJgGQAbgHAcgWQAXgPARgWQAPgYALgbIATgyIAHgVQgXgBgYADQgpAGgoAOIgGACQAIAIACAKQAEAMgGALQgPAZgYgBQgMgBgJgJIgFgEIgCACgACmjvQhiADgOAvQAiBTgPA+IgFATIAXAQQAvAfAfAgIAVgIIAigGIAugLIA6gUIA8gVQAWgFgDgPQgJgNgPAAQgcAAgbAGQgrAVgggXQgYgXAKgZQAOgRAMgSQANgSgBgXIgCgSIgKg7QgZgIgWAAQgbAAgZALgAhOk5IgQAeQgJAQgEASIgDAfIACBuQAgALAtAVQgEg9ALg7QAIghAPghIgKgIIgagdQgPgQgPAAQgGAAgFACg");
	this.shape_1123.setTransform(1030.341,70.7483);

	this.shape_1124 = new cjs.Shape();
	this.shape_1124.graphics.f("rgba(255,255,255,0.067)").s().p("AA+E5IATgQQAKgHAHgJQANgRAFgVQAMgYAOgXIACgDQAFgMACgRQAIAQAEASQAEAWgEAWQgHAbgWAUQgPAOgUAIQgKAEgKAAQgIAAgJgCgAiZEgQgegGgcgPIAWgJQAUgKARgMIAUgLQAJgGAFgJIAVgSIAIgOIAJgNIAVgYQAFgLAAgOQAFgPAKgPQAGgQgPgZQAAgJACgKIAJgOIAAgBQAkANAqAZQAaAPAUASIgHAKIgOAXIgMAOIgJAPIgSAYQgIAIgFAKIgFAJQgIAMgJAKQgNAMgNAGQgPAMgQAJQgaAPgYARIgFAFgAlqCXQgXgXgSgQQgKggATgfIANgMIADgDIAEAFQAKAIAMABQAYADAOgaQAGgLgEgNQgCgKgIgHIAGgDQAogOAqgGQAYgDAWACIgHAVIgTAxQgLAbgPAZQgRAVgWAPQgdAWgbAKQgJAGgGAGgABbgLIgYgPIAGgTQANg+gehRQAPgwBbgGQAugVA1ARIALA7IACASQACAWgNATQgMATgNAQQgKAZAYAXQAhAWAqgVQAbgHAcAAQAPAAAKANQACAOgVAGIg8AWIg6AUIgtAMIgiAHIgVAIQgggggvgegAhqhrIgBhuQAAgPACgRQAEgSAKgQIAPgdQAVgIAUAVIAbAeIAJAIQgQAggGAhQgMA8AEA8QgtgVgggKg");
	this.shape_1124.setTransform(1003.5012,82.2824);

	this.shape_1125 = new cjs.Shape();
	this.shape_1125.graphics.f("#232323").s().p("Ag3GEIhZgQQgngIgmgNQgngRgkgYQhUg4hChOIgHgIQgMgOgHgQQgKgZgEgGQgDggAGggQANgtAngfQAXgYAagVQAhgWAogIQA9gPA+ACIAAhzQAAgXAEgWQADgMAGgMIAXgtQAJgQAMgQQAVgRAfAEQAYAAAYAFQAdALAUAbQAQAPAPAPIABACQASgMATgKQARgJARgGQAfgJBXAjQAcADAbAKQAeARAMAjQAIAQADASQAMAwgMAxQA+AEA1AgQAoAogbA+QgYArg2AQQg/AchDATIgvANIABABQASAmACArQACAhgJAgQgRA7g1AoQgyAjg1gIQgTACgUAAQgnAAgogJgACPDBIgCADQgOAXgMAYQgFAVgNARQgHAJgKAHIgTAQQATAGASgIQAUgIAPgOQAWgUAHgbQAEgWgEgWQgEgSgIgQQgCARgFAMgAgmAMIgJAOQgCAKAAAJQAPAZgGAQQgKAPgFAPQAAAOgFALIgVAYIgJANIgIAOIgVASQgFAJgJAGIgUALQgRAMgUAKIgWAJQAcAPAeAGIAhAFIAFgFQAYgRAagPQAQgJAPgMQANgGANgMQAJgKAIgMIAFgJQAFgKAIgIIASgYIAJgPIAMgOIAOgXIAHgKQgUgSgagPQgqgZgkgNgAl+AlIgNAMQgTAfAKAgQASAQAXAXIAMALQAGgGAJgGQAbgKAdgWQAWgPARgVQAPgZALgbIATgxIAHgVQgWgCgYADQgqAGgoAOIgGADQAIAHACAKQAEANgGALQgOAagYgDQgMgBgKgIIgEgFIgDADgAChjyQhbAGgPAwQAeBRgNA+IgGATIAYAPQAvAeAgAgIAVgIIAigHIAtgMIA6gUIA8gWQAVgGgCgOQgKgNgPAAQgcAAgbAHQgqAVghgWQgYgXAKgZQANgQAMgTQANgTgCgWIgCgSIgLg7QgYgHgWAAQgcAAgZALgAhNk4IgPAdQgKAQgEASQgCARAAAPIABBuQAgAKAtAVQgEg8AMg8QAGghAQggIgJgIIgbgeQgOgQgPAAQgGAAgGADg");
	this.shape_1125.setTransform(1003.628,82.2842);

	this.shape_1126 = new cjs.Shape();
	this.shape_1126.graphics.f("rgba(255,255,255,0.067)").s().p("ABBE5IAUgRIARgRQAMgRAFgVQALgYAOgXIACgEQAFgMABgRQAJARAEARQAFAWgEAWQgHAbgWAVQgPAOgTAIQgMAFgMAAQgHAAgHgBgAiXEiQgdgGgdgPIAXgJQATgKASgMIAUgLIANgQQAKgKALgIIAIgOIAJgNIAUgZQAGgLgBgOQAFgPAJgPQAGgQgNgYQAAgJACgKIAJgOIAAgBQAjANApAXQAaAOAUASIgHALIgNAWIgMAPIgIAPIgTAYQgHAIgFALIgFAJQgIAMgIAJQgNANgNAHQgPALgRAKQgaAPgXARIgFAGgAloCaIgpgpQgKggATgfIANgMIADgDIAEAFQAKAIAMABQAYADAOgaQAGgLgEgNQgCgKgIgHIAGgDQAogOAqgGQAYgDAWACIgHAVIgTAxQgLAbgPAZQgRAVgWAPQgdAWgbALQgKAHgGAGgABagNIgYgPIAFgTQAMg+gZhOQAPgwBVgJQAugWA0AQIAMA7IADARQACAXgNATIgYAjQgKAaAZAWQAgAVArgWQAbgGAcgBQAPAAAJAMQADAPgVAGIg8AYIg6AUIgsAMIgiAIIgVAIQghgfgvgegAhohqIgBhuQAAgPACgRQAEgSAKgQIAPgdQAVgIAUAVIAbAeIAJAIQgQAggGAhQgMA8AEA8QgtgVgggKg");
	this.shape_1126.setTransform(976.7764,93.8194);

	this.shape_1127 = new cjs.Shape();
	this.shape_1127.graphics.f("#232323").s().p("Ag0GEIhYgPQgogIgmgNQgngRglgYQhUg3hDhNIgGgIQgLgOgJgRIgNghQgDggAGggQANgtAngfQAXgYAagVQAhgWAogIQA9gPA+ACIAAhzQAAgXAEgWQADgMAGgMIAXgtQAJgQAMgQQAVgRAfAEQAYAAAYAFQAdALAUAbQAQAPAPAPIABACQASgMATgKQARgJARgGQAfgJBPAeQAdACAbALQAeAPANAjQAHARAEASQAMAwgKAxQA9ACA1AgQApAngaA/QgYAsg1APQg+AehDAUIgvANIABABQATAmADArQABAhgIAgQgRA8g0AoQgwAkg3gGQgWACgVAAQglAAgngIgACRC9IgCAEQgOAXgLAYQgFAVgMARIgRARIgUARQAUAEASgIQATgIAPgOQAWgVAHgbQAEgWgFgWQgEgRgJgRQgBARgFAMgAgkAMIgJAOQgCAKAAAJQANAYgGAQQgJAPgFAPQABAOgGALIgUAZIgJANIgIAOQgLAIgKAKIgNAQIgUALQgSAMgTAKIgXAJQAdAPAdAGIAiAFIAFgGQAXgRAagPQARgKAPgLQANgHANgNQAIgJAIgMIAFgJQAFgLAHgIIATgYIAIgPIAMgPIANgWIAHgLQgUgSgagOQgogXgkgNgAl8AlIgNAMQgTAfAKAgIApApIALALQAGgGAKgHQAbgLAdgWQAWgPARgVQAPgZALgbIATgxIAHgVQgWgCgYADQgqAGgoAOIgGADQAIAHACAKQAEANgGALQgOAagYgDQgMgBgKgIIgEgFIgDADgACdj1QhVAJgPAwQAZBOgMA+IgFATIAYAPQAvAeAhAfIAVgIIAigIIAsgMIA6gUIA8gYQAVgGgDgPQgJgMgPAAQgcABgbAGQgrAWgggVQgZgWAKgaIAYgjQANgTgCgXIgDgRIgMg7QgWgHgVAAQgdAAgaANgAhLk4IgPAdQgKAQgEASQgCARAAAPIABBuQAgAKAtAVQgEg8AMg8QAGghAQggIgJgIIgbgeQgPgPgPAAQgFAAgGACg");
	this.shape_1127.setTransform(976.8926,93.9125);

	this.shape_1128 = new cjs.Shape();
	this.shape_1128.graphics.f("rgba(255,255,255,0.067)").s().p("ABEE5IAUgTIARgRQAMgRAFgVQAKgZAOgXIABgDQAGgNABgQQAIAQAFARQAFAWgEAWQgFAcgXAUQgOAPgUAIQgMAGgPAAIgLAAgAiUEjQgegGgdgOIAXgKQATgJASgNIAUgLIANgQQAJgJALgJIAJgOIAIgOIAUgYQAFgLAAgOQAEgQAJgOQAGgRgMgXQAAgJADgKIAIgOIABgBQAiANAoAVQAZAOAVARIgGALIgOAXIgLAPIgIAPIgSAYQgIAJgEAKIgFAJQgIAMgIAKQgNAMgNAIQgQAMgQAKQgZAPgYARIgEAGgAlnCdQgXgXgRgUQgLggATgfIANgMIADgDIAFAFQAKAIALABQAYADAPgaQAFgLgDgNQgCgKgJgHIAGgDQAogOAqgGQAYgDAXACIgIAVIgTAxQgKAbgQAZQgQAVgXAPQgcAWgcANIgPANgABYgOIgYgPIAFgTQAMg+gVhMQAOgwBPgNQAugWA0APIANA6IADASQADAWgNATIgYAkQgJAaAZAWQAhAVAqgXQAbgHAcgBQAPAAAJAMQADAPgVAGIg7AYQgcALgeALQgVAHgXAFIgiAIIgVAJQghgegwgdgAhnhpIgBhuQAAgPADgRQAEgSAJgQIAQgdQAVgIATAVIAbAeIAJAIQgPAggHAhQgMA8AFA8QgugVgggKg");
	this.shape_1128.setTransform(950.0569,105.3807);

	this.shape_1129 = new cjs.Shape();
	this.shape_1129.graphics.f("#232323").s().p("AgxGEQgtgGgrgJQgogHgmgNQgogPgkgZQhVg2hDhNIgHgIQgMgOgIgQQgJgZgDgMQgDggAGggQANgsAnggQAWgYAbgUQAggXAogHQA+gQA9ACIAAhzQAAgWAEgWQADgMAHgMIAXgtQAJgRAMgPQAUgRAfAEQAYgBAZAFQAdAMAUAbQAQAOAOAQIACACQASgNATgJQAQgJARgHQAfgJBIAZQAdADAbAKQAeAPANAiQAJARADASQANAwgKAxQA+ABA2AfQAoAngYA/QgYAsg0AQQg+AghDAUIguAOIAAABQAUAlADAsQADAggIAgQgQA8gzAqQgxAkg4gEQgWADgWAAQglAAgmgIgACSC6IgBAEQgOAXgKAYQgFAVgMARIgRASIgUASQAVADARgIQAUgJAOgOQAXgVAFgcQAEgVgFgWQgFgRgIgRQgBARgGAMgAgjAMIgIAPQgDAJAAAJQAMAXgGARQgJAPgEAPQAAAOgFALIgUAZIgIANIgJAPQgLAIgJAKIgNAPIgUAMQgSAMgTAKIgXAJQAdAPAeAGIAiAEIAEgGQAYgRAZgPQAQgJAQgMQANgIANgMQAIgKAIgMIAFgKQAEgKAIgJIASgYIAIgPIALgOIAOgYIAGgKQgVgRgZgPQgogUgigNgAl7AlIgNAMQgTAgALAfQARAUAXAXIAMAMIAPgNQAcgNAcgWQAXgPAQgVQAQgZAKgbIATgyIAIgVQgXgBgYADQgqAGgoAOIgGACQAJAIACAKQADAMgFALQgPAagYgCQgLgBgKgJIgFgEIgDACgACYj5QhPAOgOAwQAVBLgMA+IgFATIAYAPQAwAdAhAfIAVgJIAigIQAXgFAVgIQAegKAcgLIA7gZQAVgGgDgPQgJgMgPABQgcAAgbAIQgqAWghgUQgZgXAJgZIAYgkQANgTgDgWIgDgSIgNg7QgVgFgUAAQgeAAgbAMgAhJk4IgQAeQgJAQgEASQgDAQAAAQIABBuQAgAKAuAVQgFg9AMg7QAHghAPghIgJgIIgbgdQgOgQgPAAQgGAAgFACg");
	this.shape_1129.setTransform(950.1715,105.5159);

	this.shape_1130 = new cjs.Shape();
	this.shape_1130.graphics.f("rgba(255,255,255,0.067)").s().p("ABHE4IAVgUQAJgIAHgJQAMgRAEgVQAKgZAOgXIABgEQAFgMABgRQAJAQAFARQAGAWgEAWQgFAcgWAVQgOAOgUAJQgPAHgSAAIgGAAgAiSEkQgdgFgdgOIAWgKQAUgKARgNIAUgLIANgQIAUgSIAJgOIAIgOIAUgZQAEgLAAgOQAEgPAJgPQAGgRgLgWQAAgJADgKIAIgOIABgBQAiANAlATQAbAOAVARIgHAKIgNAYIgLAPIgIAPIgSAYQgGAJgFAKIgFAKQgIAMgIAKQgMANgOAIQgPAMgQAKQgaAPgXARIgFAGgAlmCgQgXgXgQgWQgLggATgfIANgMIADgDIAFAFQAKAIALABQAYADAPgaQAFgLgDgNQgCgKgJgHIAGgDQAogOAqgGQAYgDAXACIgIAVIgTAxQgKAbgQAZQgQAVgXAPQgcAWgcAPQgKAGgFAHgABXgQIgYgOIAFgUQAKg+gQhJQAOgwBIgRQAugWA1AOIANA6IAEASQADAWgNATQgLATgMARQgJAbAZAVQAhAUAqgXQAbgIAcgBQAPAAAKAMQADAOgVAHIg7AZIg5AWQgVAJgXAFIgiAIIgVAKQghgfgxgcgAhlhoIgBhuQAAgPADgRQAEgSAJgQIAQgdQAVgIATAVIAbAeIAJAIQgPAggHAhQgMA8AFA8QgugVgggKg");
	this.shape_1130.setTransform(923.3319,116.9278);

	this.shape_1131 = new cjs.Shape();
	this.shape_1131.graphics.f("#232323").s().p("AgtGEQgtgFgsgJQgngGgngNQgogQgkgYQhWg2hDhMIgIgIQgKgOgJgQQgKgYgCgPQgDggAGggQANgtAngfQAWgYAagVQAhgWAogIQA+gPA9ACIAAhzQAAgXAEgWQADgMAGgMIAYgtQAJgQALgQQAVgRAfAEQAYAAAYAFQAeALAUAbQAQAPAOAPIACACQARgMAUgKQAQgJARgGQAfgJBAAUQAdACAbAJQAeAPAOAjQAIAQAEASQAOAwgJAxQA+ABA2AeQAqAlgYBBQgXArg1ASQg9AfhDAWIguAPIABABQAUAkAEAsQADAhgIAgQgPA8gyAqQgwAlg6gBQgWACgXAAQgkAAglgHgACUC3IgBAEQgOAXgKAZQgFAVgLARQgHAJgKAIIgUAUQAVACASgJQAUgJAOgOQAWgVAFgcQADgWgFgWQgFgRgJgQQgBARgFAMgAghANIgJAOQgCAKAAAJQAKAWgFARQgJAPgFAPQABAOgEALIgUAZIgIAOIgJAOIgUASIgNAQIgUALQgRANgUAKIgWAKQAdAOAdAFIAiAFIAFgGQAXgRAZgPQARgKAPgMQANgIANgNQAIgKAIgMIAEgKQAGgKAGgJIARgYIAJgPIALgPIANgYIAHgKQgVgRgbgOQglgTgjgNgAl5AmIgNAMQgTAfALAgQAQAWAXAXIANALQAFgHAJgGQAdgPAcgWQAXgPAQgVQAPgZALgbIATgxIAIgVQgXgCgYADQgqAGgoAOIgGADQAJAHACAKQADANgFALQgPAagYgDQgLgBgKgIIgFgFIgDADgACTj8QhIARgOAwQAQBJgKA+IgFAUIAYAOQAxAcAhAfIAVgKIAigIQAXgFAVgJIA5gWIA7gZQAUgHgCgOQgKgMgPAAQgcABgbAIQgqAXghgUQgZgVAJgbQAMgRALgTQANgTgEgWIgDgSIgOg6QgUgGgTAAQgfAAgcAOgAhHk3IgQAdQgKAQgDASQgDARAAAPIABBuQAgAKAtAVQgEg8AMg8QAHghAPggIgJgIIgbgeQgOgPgPAAQgGAAgFACg");
	this.shape_1131.setTransform(923.4498,117.1193);

	this.shape_1132 = new cjs.Shape();
	this.shape_1132.graphics.f("rgba(255,255,255,0.067)").s().p("ABfEiIAQgSQALgRAFgVQAJgZAOgXIABgEQAEgMABgRQAJAQAFARQAGAWgDAWQgFAbgVAWQgOAPgTAJQgSAJgXAAgAiPElQgegFgdgOIAWgKQAUgKARgNIAUgLIANgQQAKgKAKgIIAIgPIAIgNIATgaQAFgLgBgOQAEgPAJgPQAFgRgIgWQAAgJACgJIAJgPIAAAAQAjANAjARQAbANAVARIgHAKIgMAYIgLAPIgIAPIgRAZQgIAJgEAKIgFAKQgHAMgJAKQgLANgOAJQgPAMgQAKQgaAPgXASIgEAGgAlkCiQgYgXgQgYQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgHAVIgTAyQgLAbgPAZQgRAVgWAPQgdAWgcAQIgPANgABWgSIgZgOIAFgTQAKg/gNhGQAPgwBBgVQAtgXA2ANIAOA6IAEASQADAWgMAUIgXAkQgIAaAZAWQAhATAqgYQAbgHAcgCQAPgBAKAMQADAOgVAHIg7AbIg4AXIgsAOIgiAJIgUAJQgigegxgbgAhjhnIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAbAdIAJAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_1132.setTransform(896.6073,128.5165);

	this.shape_1133 = new cjs.Shape();
	this.shape_1133.graphics.f("#232323").s().p("AgqGFIhZgOQgngGgngNQgngPglgYQhWg2hEhLIgHgIQgMgNgJgRQgJgYgCgSQgDggAGggQANgsAnggQAWgYAbgUQAggXAogHQA+gQA9ACIAAhzQAAgWAEgWQADgMAHgMIAXgtQAJgRAMgPQAUgRAfAEQAYgBAZAFQAdAMAUAbQAQAOAOAQIACACQASgNATgJQAQgJARgHQAfgJA4AQQAdABAcAKQAeANAOAjQAJAQAEASQAPAwgJAxQA+AAA2AdQAqAlgWBBQgWAsg0ASQg9AhhCAWIgvAPIABACQAVAlAEAqQAEAhgHAgQgOA9gyArQgvAlg8ABQgZADgZAAQgiAAgjgGgACWC0IgBAEQgOAXgJAZQgEAVgMARIgPASIgWAWQAWAAASgJQATgJAOgPQAWgWAEgbQAEgWgGgWQgFgRgJgQQgBARgFAMgAgfANIgIAPQgDAJAAAJQAJAWgGARQgIAPgEAPQAAAOgEALIgUAaIgHANIgJAPQgKAIgKAKIgNAQIgUALQgRANgTAKIgWAKQAcAOAeAFIAiAFIAEgGQAYgSAagPQAPgKAPgMQAOgJAMgNQAIgKAIgMIAFgKQAEgKAHgJIARgZIAIgPIALgPIANgYIAGgKQgVgRgbgNQgjgRgigNgAl3AmIgNAMQgTAgALAfQAPAYAYAXIAMALIAQgNQAcgQAcgWQAXgPAQgVQAQgZAKgbIATgyIAIgVQgXgBgYADQgqAGgoAOIgGACQAJAIACAKQADAMgFALQgPAagYgCQgLgBgKgJIgFgEIgDACgACPj/QhCAVgOAwQAMBGgKA/IgEATIAYAOQAyAbAhAeIAVgJIAhgJIAsgOIA5gXIA7gbQAUgHgDgOQgKgMgPABQgcACgaAHQgqAYghgTQgagWAIgaIAYgkQALgUgDgWIgDgSIgPg6QgTgEgSAAQghAAgcAOgAhFk3IgQAeQgJAQgEASQgDAQAAAQIABBuQAgAKAuAVQgFg9AMg7QAHghAPghIgJgIIgbgdQgOgQgPAAQgGAAgFACg");
	this.shape_1133.setTransform(896.6924,128.7182);

	this.shape_1134 = new cjs.Shape();
	this.shape_1134.graphics.f("rgba(255,255,255,0.067)").s().p("ABjEhIAPgTQAMgRADgVQAJgZAOgYIABgDQAEgNABgRQAJAQAFARQAGAWgDAWQgEAcgVAWQgOAOgTAKQgRAJgYABgAiMEnQgegFgdgOIAWgKQATgLARgMIAUgMQAIgGAFgKQAJgKALgIIAIgPQADgHAFgHIATgZQAEgLgBgOQADgQAJgPQAGgRgHgVQAAgJACgJIAJgPIAAAAQAjANAhAPQAbANAVAQIgGALIgNAYIgKAPIgIAPIgRAZQgGAJgFALIgFAJIgPAXIgaAXIgeAWQgaAPgXASIgFAGgAljClQgXgXgQgaQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgHAVIgTAyQgLAbgPAZQgRAVgWAPIg5AoQgKAGgFAHgABVgUIgZgNIAEgUQAJg+gIhEQAPgwA7gYQAtgYA1AMIAPA6IAEASQADAWgLAUIgXAlQgIAZAbAWQAhATApgZQAbgIAcgCQAPgBAKAMQAEAOgVAHIg7AbIg4AYIgsAPIghAKIgUAJQgjgdgxgbgAhhhmIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_1134.setTransform(869.8701,140.0915);

	this.shape_1135 = new cjs.Shape();
	this.shape_1135.graphics.f("#232323").s().p("AgnGFIhZgNQgngGgngNQgogPglgXQhWg1hFhLIgHgHQgMgOgIgQQgLgZgBgUQgDggAGggQANgtAngfQAXgYAagVQAhgWAogIQA9gPA+ACIAAhzQAAgXAEgWQADgMAGgMIAXgtQAJgQAMgQQAVgRAfAEQAYAAAYAFQAdALAUAbQAQAPAPAPIABACQASgMATgKQARgJARgGQAfgJAwALQAcABAcAJQAeANAQAjQAJAQAEARQAPAwgIAxQA/gBA2AdQArAlgWBAQgVAsg0ATQg8AihCAYIguAPIABACQAUAkAGArQAEAhgHAgQgMA9gyArQgvAng9ACQgZADgaAAQghAAgjgFgACYCxIgBAEQgOAYgJAYQgDAWgMARIgPASIgXAXQAYgCARgJQATgJAOgPQAVgWAEgcQADgVgGgWQgFgRgJgQQgBARgEAMgAgdAOIgJAOQgCAKAAAJQAHAUgGARQgJAQgDAPQABAOgEALIgTAaQgFAGgDAIIgIAOQgLAIgJALQgFAJgIAHIgUALQgRANgTAKIgWAKQAdAOAeAFIAhAEIAFgGQAXgSAagPIAegWIAagXIAPgWIAFgKQAFgLAGgIIARgZIAIgQIAKgPIANgYIAGgKQgVgRgbgNQghgPgjgNgAl1AnIgNAMQgTAfAKAgQAQAaAXAXIANALQAFgHAKgGIA5gpQAWgPARgVQAPgZALgbIATgxIAHgVQgWgCgYADQgqAGgoAOIgGADQAIAHACAKQAEANgGALQgOAagYgDQgMgBgKgIIgEgFIgDADgACKkCQg7AYgPAwQAIBFgJA+IgEATIAZAOQAxAbAjAdIAUgKIAhgJIAsgPIA4gYIA7gbQAVgHgEgPQgKgLgPAAQgcADgbAIQgpAYghgTQgbgVAIgaIAXglQALgUgDgWIgEgRIgPg6QgSgFgRAAQgiAAgdAQgAhEk2IgPAdQgKAQgEASQgCARAAAPIABBuQAgAKAtAVQgEg8AMg8QAGghAQggIgJgIIgbgeQgOgPgPAAQgGAAgGACg");
	this.shape_1135.setTransform(869.9723,140.3226);

	this.shape_1136 = new cjs.Shape();
	this.shape_1136.graphics.f("rgba(255,255,255,0.067)").s().p("ABmEeIAPgSQAMgRADgWQAJgZANgYIABgDQAEgNAAgRQAJAQAGARQAHAWgDAVQgEAcgVAWQgNAPgTAKQgRAJgZAEgAiKEoQgegFgdgOIAXgKQATgKARgNIATgMQAIgHAFgJQAJgLALgIIAIgOIAHgOIATgaQAEgLgBgOQADgQAJgPQAFgRgFgUQAAgJACgKIAJgOIAAgBQAjANAfANQAbANAVAQIgGALIgMAYIgKAPIgIAQIgQAZQgHAJgEAKIgFAKQgGAMgJALQgLANgOALIgfAWQgaAQgXARIgEAGgAlhCoQgYgXgPgcQgKggATgfIANgMIADgDIAEAFQAKAIAMABQAYADAOgaQAGgLgEgNQgCgKgIgHIAGgDQAogOAqgGQAYgDAWACIgHAVIgTAxQgLAbgPAZQgRAVgWAPIg5AqQgKAHgFAHgABUgWIgZgNIAEgTQAHg/gDhCQAPgwA0gbQAtgYA1ALIAQA6IAFARQADAWgLAUIgWAlQgIAbAbAUQAiATAogZQAbgIAcgDQAPgCAKAMQAEAPgVAHIg6AcIg4AaQgVAHgWAHIgiAKIgUAKQgigdgygagAhfhmIgBhuQAAgPACgRQAEgSAKgQIAPgdQAVgIAUAVIAaAeIAKAIQgQAggGAhQgMA8AEA8QgtgVgggKg");
	this.shape_1136.setTransform(843.1208,151.6915);

	this.shape_1137 = new cjs.Shape();
	this.shape_1137.graphics.f("#232323").s().p("AgjGFIhZgMQgogGgngMQgogOglgYQhXg0hFhKIgHgIQgMgOgJgQQgKgYgBgYQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAoAHQAcAAAcAJQAfANAQAiQAIAQAGASQAPAvgHAyQA+gCA3AbQAsAkgVBBQgVAsg0AVQg7AihCAZIguAQIABACQAVAjAHArQAEAhgGAgQgMA9gxAtQguAng+AEQgbAEgcAAQgfAAghgFgACaCuIgBAEQgNAXgJAaQgDAVgMARIgPATIgXAYQAZgDARgJQATgKANgPQAVgWAEgcQADgWgHgWQgGgQgJgQQAAARgEAMgAgbAOIgJAPQgCAJAAAJQAFAUgFARQgJAQgDAPQABAOgEALIgTAaIgHAOIgIAPQgLAIgJAKQgFAKgIAGIgTAMQgRAOgTAJIgXALQAdAOAeAEIAiAEIAEgGQAXgSAagQIAfgWQAOgKALgOQAJgKAGgMIAFgKQAEgLAHgJIAQgZIAIgPIAKgQIAMgYIAGgKQgVgQgbgNQgfgNgjgNgAlzAnIgNAMQgTAgAKAfQAPAdAYAWIANALQAFgGAKgHIA5gqQAWgPARgVQAPgZALgbIATgyIAHgVQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACFkEQg0AbgPAwQADBBgHA/IgEAUIAZANQAyAaAiAdIAUgLIAigKQAWgGAVgIIA4gaIA6gcQAVgHgEgPQgKgLgPABQgcADgbAIQgoAagigTQgbgVAIgaIAWglQALgUgDgWIgFgSIgQg5QgRgEgQAAQgiAAgfARgAhCk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_1137.setTransform(843.2169,151.9446);

	this.shape_1138 = new cjs.Shape();
	this.shape_1138.graphics.f("rgba(255,255,255,0.067)").s().p("ABqEcQAIgJAHgKQAKgSAEgVQAIgZANgYIABgEQAEgMAAgRQAKAQAFAQQAHAWgCAWQgEAcgUAWQgOAPgSAKQgRAKgaAFgAiHEpQgegFgdgNIAWgLQATgKARgNIAUgMQAHgHAGgJQAJgLAKgIIAIgPIAHgOIATgaQAEgMgCgNQADgQAJgPQAEgRgDgUQAAgJACgJIAJgPIAAAAIBAAYQAbAMAWAQIgGALIgMAYIgKAQIgHAPQgHAOgJAMQgHAJgEAKIgEAKQgHANgIAKQgLAOgPALQgPAMgPAKQgaAQgXASIgEAGgAlfCqQgYgWgPgfQgKgfATggIANgMIADgCIAEAEQAKAJAMABQAYACAOgaQAGgLgEgMQgCgKgIgIIAGgCQAogOAqgGQAYgDAWABIgHAVIgTAyQgLAbgPAZQgRAVgWAPIg5AsQgKAHgFAGgABSgYIgZgMIAEgUQAHg/ABg/QAPgwAtgfQAtgZA1ALIARA5IAFASQAEAWgLAUIgWAlQgHAbAbAUQAiASAogaQAbgJAbgDQAPgBALALQAEAPgVAHIg5AdIg4AbIgrAPIghAKIgUALQgjgdgzgZgAhdhlIgBhuQAAgQACgQQAEgSAKgQIAPgeQAVgIAUAWIAaAdIAKAIQgQAhgGAhQgMA7AEA9QgtgVgggKg");
	this.shape_1138.setTransform(816.3708,163.2915);

	this.shape_1139 = new cjs.Shape();
	this.shape_1139.graphics.f("#232323").s().p("AggGFIhZgMQgngGgngLQgpgOglgXQhXg0hGhKIgHgIQgMgNgJgQQgKgYgBgbQgDggAGggQANgtAngfQAXgYAagUQAhgXAogHQA9gQA+ACIAAhzQAAgWAEgWQADgMAGgMIAXgtQAJgRAMgPQAVgRAfAEQAYgBAYAFQAdAMAUAbQAQAOAPAQIABACQASgNATgJQARgJARgHQAfgJAgADQAcAAAcAIQAfANAQAhQAJAQAGASQAQAugGAyQA9gDA4AbQAsAkgUBBQgUAugzATQg7AkhBAZIguARIABACQAWAjAHArQAEAhgFAgQgLA9gwAtQguAohAAHQgcAFgdAAQgeAAgggFgACcCqIgBAEQgNAYgIAZQgEAVgKASQgHAKgIAJIgYAaQAagFARgKQASgKAOgPQAUgWAEgcQACgWgHgWQgFgQgKgQQAAARgEAMgAgZAOIgJAPQgCAJAAAJQADAUgEARQgJAPgDAQQACANgEAMIgTAaIgHAOIgIAPQgKAIgJALQgGAJgHAHIgUAMQgRANgTAKIgWALQAdANAeAFIAiADIAEgGQAXgSAagQQAPgKAPgMQAPgLALgOQAIgKAHgNIAEgKQAEgKAHgJQAJgMAHgOIAHgPIAKgQIAMgYIAGgLQgWgQgbgMIhAgYgAlxAnIgNAMQgTAgAKAfQAPAfAYAWIANALQAFgGAKgHIA5gsQAWgPARgVQAPgZALgbIATgyIAHgVQgWgBgYADQgqAGgoAOIgGACQAIAIACAKQAEAMgGALQgOAagYgCQgMgBgKgJIgEgEIgDACgACAkIQgtAfgPAwQgBA/gHA/IgEAUIAZAMQAzAaAjAcIAUgLIAhgKIArgPIA4gbIA5gdQAVgHgEgPQgLgLgPABQgbADgbAJQgoAagigSQgbgUAHgbIAWglQALgUgEgWIgFgSIgRg5QgQgDgPAAQgjAAggARgAhAk2IgPAeQgKAQgEASQgCAQAAAQIABBuQAgAKAtAVQgEg9AMg7QAGghAQghIgKgIIgagdQgOgQgPAAQgGAAgGACg");
	this.shape_1139.setTransform(816.4518,163.5558);

	this.shape_1140 = new cjs.Shape();
	this.shape_1140.graphics.f("rgba(255,255,255,0.067)").s().p("ABtEaIAPgTQAKgSADgVQAIgaAMgYIABgEQAEgMAAgRQAKAQAGAQQAHAVgCAXQgDAcgUAWQgOAQgSAKQgRAKgaAGgAiEEpQgegDgdgOIAWgLQATgKAQgOIAUgMQAHgGAGgKQAJgKAKgJIAIgPIAHgOIASgaQAEgMgCgNQADgQAIgQQAEgRgCgSQAAgJADgKIAJgOIAAgBIA9AXQAbALAXAQIgGALIgLAYIgKAQIgHAQIgQAZQgGAJgEALIgEAKQgHANgIAKQgKAOgQAMIgeAWQgZAQgXATIgEAGgAldCtQgYgXgPggQgKggASgfIAOgMIACgDIAFAFQAJAIAMABQAYADAPgaQAGgLgEgNQgCgKgIgHIAGgDQAogOApgGQAYgDAXACIgHAVIgTAxQgLAbgPAZQgRAVgXAPIg5AuQgJAHgGAGgABRgZIgZgNIADgUIAMh8QAOgvAogiQArgaA2AKIASA5IAFASQAEAWgKAUIgVAlQgHAbAbAUQAiARAogaQAbgJAbgEQAPgBALALQAEAOgUAIIg5AeQgbAOgcANQgVAKgXAGIghALIgTALQgkgbgzgZgAhbhlIgChuIADggQAEgSAJgQIAQgdQAVgIAUAVIAZAeIAKAIQgPAggHAhQgMA7AFA9QgugVgfgKg");
	this.shape_1140.setTransform(789.6254,174.8665);

	this.shape_1141 = new cjs.Shape();
	this.shape_1141.graphics.f("#232323").s().p("AgcGFIhZgLQgogFgngMQgogOglgWQhYg0hGhJIgHgHQgMgOgKgQQgKgYAAgdQgEggAGggQANguAogeQAWgYAagVQAhgWAogIQA+gPA9ACIAAhzQABgXADgWQADgMAGgMIAYgtQAIgQANgQQATgRAgAEQAYAAAZAFQAcALAUAbQARAPAOAPIABACQASgMAUgKQAQgJARgGQAfgJAYgCQAdAAAcAHQAfANARAhQAJAQAGASQAQAugFAyQA9gEA5AaQAsAjgTBBQgTAugzAVQg7AkhBAbIgtARIABACQAWAjAIArQAGAggGAhQgKA9gwAuQgtAohBAJQgeAGgfAAQgdAAgdgFgACeCnIgBAEQgNAYgHAaQgDAVgLASIgOATIgZAbQAbgGARgKQASgKANgQQAUgWAEgcQACgXgIgVQgFgQgLgQQABARgEAMgAgXAPIgJAOQgCAKAAAJQACASgEARQgJAQgCAQQABANgEAMIgSAaIgHAOIgHAPQgLAJgJAKQgFAKgIAGIgTAMQgRAOgTAKIgWALQAdAOAeADIAiAEIAEgGQAXgTAagQIAegWQAPgMAKgOQAJgKAGgNIAFgKQADgLAHgJIAPgZIAIgQIAJgQIALgYIAGgLQgWgQgbgLIg9gXgAlvAoIgNAMQgTAfALAgQAOAgAYAXIANAKQAFgGAKgHIA5guQAWgPARgVQAPgZALgbIATgxIAHgVQgWgCgYADQgqAGgoAOIgGADQAIAHACAKQAEANgGALQgOAagYgDQgMgBgJgIIgFgFIgDADgAB8kKQgoAigNAvIgMB8IgDAUIAZANQAyAZAkAbIAUgLIAhgLQAWgGAVgKQAcgNAbgOIA5geQAVgIgFgOQgKgLgPABQgcAEgaAJQgoAagigRQgbgUAGgbIAVglQALgUgEgWIgFgSIgSg5QgPgDgPAAQglAAgfATgAg+k1IgPAdQgJAQgFASIgCAgIABBuQAgAKAtAVQgEg9AMg7QAGghAQggIgKgIIgageQgPgPgPAAQgFAAgGACg");
	this.shape_1141.setTransform(789.6948,175.1515);

	this.shape_1142 = new cjs.Shape();
	this.shape_1142.graphics.f("rgba(255,255,255,0.067)").s().p("ABvEbQAIgJAGgJQALgSADgWQAIgZAMgYIABgEIAEgdQAKAPAGARQAHAWgCAVQgDAcgUAXQgOAPgSALQgRAKgYADgAiAEsQgegDgegNIAWgLQATgLAQgOIATgMQAIgHAFgKQAJgKAKgJIAIgPIAHgOIASgaQADgMgBgOQADgPAIgQQAEgRgGgUQgBgJACgKIAIgPIABAAQAjAMAgAMQAbAMAWAQIgFALIgMAYIgJAQIgIAPQgGAOgJAMQgHAKgDAKIgFAKQgGANgIAKQgMAOgNAKIgeAXQgZARgWATIgEAGgAlcCzQgYgVgQgcQgMgfASggIAMgMIADgDIAFAEQAKAJAMAAQAYABANgaQAGgLgEgMQgDgLgIgHIAFgCQAogQAqgHQAYgEAWABIgHAVIgRAyQgJAbgPAaQgQAVgWAQIg3AsIgPAOgABTgYIgZgMIADgUQAGg/gHhCQANgxA1gbQAtgaA1AKIASA5IAFARQAEAWgLAUQgJAUgLASQgIAbAcATQAiASAogaQAbgJAbgEQAPgCALAMQAEAOgVAIIg5AeIg3AbIgrAQIghALIgUAKQgjgbgzgZgAhkhjIgFhtQAAgQACgQQADgTAJgQIAOgeQAVgJAUAVIAcAdIAKAHQgPAhgFAiQgKA7AHA9QgvgUgggJg");
	this.shape_1142.setTransform(778.0927,164.215);

	this.shape_1143 = new cjs.Shape();
	this.shape_1143.graphics.f("#232323").s().p("AgXGFIhZgJQgogFgngLQgpgNgmgWQhXgxhJhIIgHgIQgMgNgKgQQgLgXgCgXQgDggAEggQAMgvAlgfQAWgZAagVQAfgYAogJQA9gSA+AAIgEhzQgBgWADgWQADgMAGgNIAVgtQAJgRALgQQAUgSAfADQAYgBAZAEQAeAKAUAbQAQANAQAQIABABQASgMASgLQARgJAQgHQAfgLArAIQAdgBAcAIQAfAMARAhQAJAQAGASQAQAugFAyQA+gEA4AaQAsAjgSBBQgUAvgzAUQg7AlhAAaIguASIABABQAXAjAHArQAGAhgFAgQgLA9gvAuQgtAog+AGQghAGgiAAQgbAAgZgDgACfCpIgBADQgMAYgIAaQgDAVgLASQgGAKgIAJIgWAZQAYgEARgKQASgKAOgPQAUgXADgcQACgWgHgWQgGgRgKgPgAgcAOIgIAPQgCAJABAJQAGAVgEARQgIAPgDAQQABANgDAMIgSAbIgHAOIgIAOQgKAJgJALQgFAKgIAGIgTANQgQANgTALIgWALQAeANAeAEIAiACIAEgGQAWgTAZgQIAegXQAOgKALgPQAIgKAGgNIAFgKQADgKAHgKQAJgMAGgNIAIgQIAJgQIAMgYIAFgLQgWgPgbgMQgggNgjgMgAlzAzIgMAMQgSAgAMAgQAQAbAYAWIANAKIAPgOIA3grQAWgQAQgVQAPgaAJgbIARgyIAHgWQgWAAgYADQgqAIgoAPIgFADQAIAGADALQAEANgGALQgNAagYgBQgMgBgKgIIgFgFIgDADgAB9kJQg1AcgNAwQAHBDgGA/IgDATIAZANQAzAZAjAbIAUgLIAhgLIArgPIA3gcIA5geQAVgHgEgPQgLgLgPABQgbAEgbAJQgoAbgigSQgcgUAIgaQALgTAJgTQALgUgEgWIgFgSIgSg5QgOgCgPAAQgkAAghASgAhOk0IgOAeQgJAQgDASQgCARAAAPIAFBuQAgAJAvATQgHg8AKg8QAFghAPghIgKgIIgcgcQgOgPgOAAQgGAAgHADg");
	this.shape_1143.setTransform(778.1619,164.5695);

	this.shape_1144 = new cjs.Shape();
	this.shape_1144.graphics.f("rgba(255,255,255,0.067)").s().p("ABwEdIAPgTQAKgSADgVQAIgZAMgZIABgDQAEgNAAgRQAKAQAGARQAHAVgCAWQgDAcgUAXQgOAPgSAKQgRALgWAAgAh9EvQgegDgegNIAWgLQASgLARgOIATgNIAMgQQAJgLAKgJIAHgPIAHgOIASgaQAEgMgCgOQADgQAIgPQAEgRgLgWIABgSIAIgPIAAgBQAjAKAmAQQAbAMAXAPIgGAMIgLAYIgKAPIgHAQQgHAOgJAMQgGAJgEALIgEAJQgHANgIALQgLANgNAKQgOANgPALQgZAQgWAUIgEAGgAlaC6QgZgWgSgVQgMgeAQghIAMgNIADgDIAFAEQAKAIAMAAQAZABAMgbQAEgMgEgLQgDgLgJgHIAGgDQAngQApgJQAYgEAXgBIgGAWIgQAzQgIAcgOAZQgPAXgVAQQgbAYgbARQgJAHgFAHgABUgWIgZgNIADgTQAGg/gUhHQAKgxBGgXQArgaA2AKIASA6IAFARQAEAVgKAVIgVAmQgHAbAbATQAiASAogbQAbgJAbgDQAPgCALALQAEAPgUAIIg5AdIg4AcQgUAIgXAHIghALIgTALQgkgbgzgZgAhthgIgIhtQgCgQACgQQADgTAIgQIANgfQAVgJAVAUIAdAbIAKAIQgOAhgEAiQgIA8AJA8QgvgSghgIg");
	this.shape_1144.setTransform(766.5889,153.572);

	this.shape_1145 = new cjs.Shape();
	this.shape_1145.graphics.f("#232323").s().p("AgSGFIhZgIQgogEgngKQgpgMgmgWQhZgwhJhGIgIgIQgMgNgKgQQgMgXgDgQQgFgfAEghQAKguAkghQAVgaAZgWQAegYAogLQA8gUA+gCIgIhzQgCgWADgWQACgNAGgMIATgvQAJgQAKgRQATgSAgABQAXgCAZADQAfAKAVAZIAgAcIACACQARgOASgLQAQgJARgIQAegLA/AOQAdAAAcAHQAfANAQAhQAKAQAFARQARAvgFAyQA9gEA5AaQAsAjgTBBQgTAugzAVQg7AkhBAbIgtARIABACQAWAjAIArQAFAggFAhQgKA9gwAuQgtAog6ADQglAHglAAQgXAAgWgCgAChCpIgBAEQgNAYgHAaQgEAVgKASIgPATIgTAVQAWAAARgKQASgLANgPQAUgWADgdQADgWgIgVQgGgQgKgQQABARgEAMgAggANIgHAPIgCATQAMAVgFARQgIAPgDARQACANgEAMIgSAaIgHAOIgHAPQgKAJgJALIgMARIgTAMQgRAOgSALIgVAMQAdAMAeADIAiACIAEgGQAXgTAYgRQAQgLAOgNQAMgJALgOQAJgKAGgNIAFgKQADgLAHgJQAJgLAGgPIAHgPIAKgQIALgYIAGgLQgWgQgbgLQgmgQgjgKgAl1A+IgMANQgRAhANAfQASAVAYAVIANALQAFgHAKgHQAagSAbgYQAWgQAPgWQAOgaAIgcIAPgzIAGgVQgWAAgYAFQgqAJgmAPIgGADQAJAHADALQAEAMgFAMQgMAbgZgBQgLgBgLgHIgEgEIgDACgAB/kIQhFAWgLAyQAVBGgGA/IgDAUIAZANQAyAZAkAbIAUgLIAhgLQAXgHAUgJIA3gbIA5geQAUgIgEgOQgKgLgPABQgcAEgaAJQgoAagjgRQgagUAGgbIAVglQALgVgEgVIgFgSIgSg5QgPgDgPAAQgkAAggATgAhdkzIgOAeQgIARgDASQgBARABAPIAJBuQAgAHAvASQgIg8AHg8QAFgiAOghIgLgHIgdgcQgOgNgOAAQgHAAgGADg");
	this.shape_1145.setTransform(766.6372,154.0174);

	this.shape_1146 = new cjs.Shape();
	this.shape_1146.graphics.f("rgba(255,255,255,0.067)").s().p("Ah6EwQgegCgegMIAWgMQASgMAQgNIATgOQAHgGAFgKQAIgLAKgJIAHgPIAHgOIASgbQADgMgBgNQADgQAIgPQAFgRgRgXIABgTIAHgPIAAgBQAkAJArATQAcAMAWAPIgGALIgLAYIgKAQIgHAQQgGANgKAMQgGAJgEALIgEAKQgHANgIAKQgMAOgLAIQgOAOgPALQgYARgWAUIgEAGgABfExIASgTQAJgJAGgKQAKgSADgVQAJgaAMgYIAAgDQAEgNAAgRQAKAPAGARQAHAVgCAXQgDAcgUAXQgNAPgTAKQgNAIgQAAIgIAAgAlZC/IgsgkQgOgeAQghIALgOIADgCIAFAEQALAHALAAQAYgBAMgbQAEgMgEgLQgEgLgJgHIAGgDQAmgRApgKQAYgFAXgCIgGAVIgNA0QgIAcgNAbQgOAWgVASQgZAYgbAOIgOAPgABVgVIgZgNQADgIAAgLQAGg/ghhLQAJgyBUgSQAsgaA2AKIARA5IAFASQAEAWgKAUQgKATgLATQgHAaAbAUQAiASApgbQAZgJAcgEQAPgBALALQAEAOgUAIIg5AeIg3AbIgsAQIggALIgUALQgkgcgzgYgAh1hdIgNhuQgCgPABgRQACgSAIgRIAMgfQAUgLAWAUIAeAbIALAGQgOAigCAiQgGA8ALA8QgvgQghgGg");
	this.shape_1146.setTransform(755.0763,143.0193);

	this.shape_1147 = new cjs.Shape();
	this.shape_1147.graphics.f("#232323").s().p("AgNGEIhZgGQgogDgogJQgpgMgmgVQhaguhKhFIgIgIQgMgMgKgQIgRggQgGgfADghQAHguAkgkQAUgZAYgXQAegaAngMQA8gVA9gFIgMhyQgCgXABgWQACgMAFgNIASgvQAHgRALgRQASgUAfABQAYgDAZADQAfAIAXAZIAgAaIACACQARgPASgLIAfgTQAegMBTAWQAdAAAcAHQAfAMARAiQAJAQAGARQAQAvgFAyQA+gFA4AbQAsAigSBCQgUAugzAUQg7AlhBAaIgtASIABABQAXAkAHAqQAGAhgGAhQgJA9gwAtQgtApg3AAQgoAIgqAAQgTAAgSgCgAglANIgHAPIAAATQAQAWgEARQgJAQgCAPQABAOgDAMIgTAaIgGAOIgHAPQgKAJgJALQgFAKgHAHIgSANQgRAOgSAMIgVALQAeANAeACIAiABIADgGQAWgTAZgSQAPgLAOgNQALgJAMgNQAIgKAGgNIAFgKQADgLAHgJQAJgMAGgOIAIgPIAJgQIAMgYIAFgLQgVgQgcgMQgrgSgkgJgACiCqIgBAEQgMAYgIAZQgDAWgLASQgGAJgIAJIgSATQAUADARgKQATgLAMgPQAUgXAEgcQACgWgHgVQgGgRgKgPQAAARgEAMgAl4BKIgMANQgPAiANAeIAtAkIANAKIAOgOQAagPAagYQAVgRAOgXQANgaAHgcIAOg0IAFgVQgWABgYAFQgqALglARIgGADQAJAGADALQAFAMgEAMQgMAbgYAAQgMAAgKgHIgFgEIgDADgACAkHQhUASgJAxQAiBLgGA/QgBAMgCAIIAZAMQAyAaAkAaIAUgKIAhgLIArgQIA3gbIA5geQAVgJgFgNQgKgMgPACQgcADgaAKQgoAagigSQgbgTAGgbQAMgSAJgUQALgUgEgWIgFgRIgSg5QgPgDgOAAQglAAggATgAhtkyIgNAfQgHARgDATQAAAQABAQIANBtQAhAGAvARQgLg8AGg8QADgiANgiIgLgHIgegaQgOgNgOAAQgHAAgGADg");
	this.shape_1147.setTransform(755.1349,143.4546);

	this.shape_1148 = new cjs.Shape();
	this.shape_1148.graphics.f("rgba(255,255,255,0.067)").s().p("Ah3EwQgegCgegLIAVgMQASgMAQgOIASgOQAIgHAEgKQAJgLAJgJIAHgPIAHgOIASgbQAEgMgCgNQADgQAIgPQAEgRgVgYQgBgJABgJIAGgQIABAAQAlAHAwAVQAbAMAXAPIgGALIgLAZIgKAPIgHAQIgQAaQgGAJgEALIgFAJQgGANgIALQgMANgKAHQgOAOgPALQgYASgVAUIgEAGgABiEtIAQgQIAPgTQAKgSADgVQAIgZAMgZIABgDQAEgNAAgRQAKAQAGARQAHAVgCAWQgDAcgUAXQgOAPgSAKQgKAHgMAAQgGAAgHgCgAlYDDQgZgUgUgJQgPgeAOgiIALgNIADgDIAFADQALAHAMAAQAYgBALgcQADgMgFgLQgDgLgKgGIAGgEQAlgTApgLQAYgGAWgCIgFAVIgLA0QgHAdgMAbQgNAXgUASQgZAZgaALIgNAOgABWgWIgZgNIADgTQAGg/gvhPQAHgxBkgPQArgaA2AKIASA6IAFARQAEAWgKAUIgVAmQgIAaAcAUQAiASAogbQAbgJAbgDQAPgCALALQAEAPgUAHIg6AeIg3AcQgUAIgXAHIghALIgUALQgjgbgzgZgAh/hcIgQhtQgCgQAAgQQABgSAHgSIALgfQAUgLAWASIAfAaIALAGQgMAjgBAhQgEA9ANA7QgwgOghgFg");
	this.shape_1148.setTransform(743.602,132.6199);

	this.shape_1149 = new cjs.Shape();
	this.shape_1149.graphics.f("#232323").s().p("AgIGEQgtgBgsgEQgpgDgngIQgqgLgmgUQhagthMhDIgHgHQgOgNgKgPQgMgXgFgCQgIgfACggQAGgvAiglQATgaAYgYQAcgbAngNQA7gYA9gHIgQhxQgDgXAAgWIAGgZIARgwQAHgSAJgRQASgTAfgBQAYgEAZACQAfAHAYAYQASAMAQANIABACQAQgPARgMIAfgUQAPgHAzALQArAIAZADQAcgBAcAIQAfANARAhQAJAQAGARQAQAugFAyQA+gDA4AZQAtAkgTBBQgUAugzAUQg6AkhBAbIguASIABABQAXAjAHArQAGAhgFAgQgLA9gvAuQgtApg0gEQgrAKgtAAIgegBgAgqAMIgGAQQgBAJABAJQAVAYgEARQgIAPgDAQQACANgEAMIgSAbIgHAOIgHAPQgJAJgJALQgEAKgIAHIgSAOQgQAOgSAMIgVAMQAeALAeACIAiABIAEgGQAVgUAYgSQAPgLAOgOQAKgHAMgNQAIgLAGgNIAFgJQAEgLAGgJIAQgaIAHgQIAKgPIALgZIAGgLQgXgPgbgMQgwgVglgHgACjCrIgBADQgMAZgIAZQgDAVgKASIgPATIgQAQQASAFARgKQASgKAOgPQAUgXADgcQACgWgHgVQgGgRgKgQQAAARgEANgAl7BWIgLANQgOAiAPAeQAUAJAZAUIAOAKIANgOQAagLAZgZQAUgSANgXQAMgbAHgdIALg0IAFgVQgWACgYAGQgpALglATIgGAEQAKAGADALQAFALgDAMQgLAcgYABQgMAAgLgHIgFgDIgDADgACCkHQhkAPgHAxQAvBPgGA/IgDATIAZANQAzAZAjAbIAUgLIAhgLQAXgGAUgJIA3gcIA6geQAUgHgEgPQgLgLgPACQgbADgbAJQgoAbgigSQgcgUAIgaIAVgmQAKgUgEgWIgFgRIgSg6QgPgDgOAAQglAAgfATgAh+kvIgLAfQgHASgBASQAAAQACAQIAQBtQAhAFAwAOQgNg7AEg9QABghAMgjIgLgGIgfgaQgOgLgNAAQgHAAgIAEg");
	this.shape_1149.setTransform(743.6218,132.9255);

	this.shape_1150 = new cjs.Shape();
	this.shape_1150.graphics.f("rgba(255,255,255,0.067)").s().p("Ah0EwQgegBgegLIAVgMQASgNAPgOIATgOQAHgHAEgKQAIgLAKgKIAGgPIAHgOIASgaQAEgMgCgOQADgPAIgQQAEgSgagXQgBgJABgKIAFgQIABAAQAlAHA2AWQAcAMAWAQIgGALIgLAYIgKAPIgHAQIgQAaQgGAJgEALIgEAKIgPAXQgMANgJAHIgcAZQgYASgVAUIgDAGgABlEpIAOgNIAPgSQAKgTADgVQAIgZAMgYIABgEQAEgNAAgRQAKAQAGARQAHAVgCAWQgDAcgUAXQgNAPgTAKQgJAGgJAAQgIAAgHgEgAlWDIQgagUgVgEQgPgcANgjIAKgOIADgDIAFADQALAHAMgBQAYgCAKgcQADgMgGgLQgDgLgKgGIAFgDQAlgVAogMQAYgIAWgCIgEAVIgJA1QgGAcgLAcQgMAXgUATQgYAbgZAGQgJAJgEAGgABXgXIgZgMQADgIAAgMQADgggegoQgXgngFgiQADgYAwgMIBGgYQArgaA2AKIASA5IAFARQAEAWgKAUIgVAmQgHAbAbATQAiASAogaQAbgKAbgDQAPgCALALQAEAPgUAIIg5AeIg3AbIgsAQIggALIgUAKQgkgbgzgZgAiIhbIgUhsQgDgPAAgRQABgSAGgSIAKggQATgMAXASIAgAZIALAGQgKAigBAiQgBA9APA7QgwgNgigEg");
	this.shape_1150.setTransform(732.144,122.21);

	this.shape_1151 = new cjs.Shape();
	this.shape_1151.graphics.f("#232323").s().p("AgDGCIhagDQgngCgogIQgpgJgogUQhagrhNhCIgIgHQgNgNgLgPQgMgXgGAHQgIgggBggQAFgvAhgmQASgbAWgYQAcgdAmgOQA6gaA9gJIgUhxQgEgWAAgXQABgMAEgNIAPgwQAGgSAJgRQAQgVAggBQAYgFAZABQAfAFAZAYIAjAYIACACIAfgdQAPgMAQgJQAOgHA+ANIBNANQAcAAAcAIQAfAMARAhQAJAQAGASQARAugFAyQA9gEA4AaQAtAjgTBBQgUAugzAVQg6AkhBAbIgtARIABACQAWAjAIArQAFAggFAhQgKA9gwAuQgtAogwgHQguAMgxAAIgXgBgAgvALIgFAQQgBAJABAJQAaAYgEASQgIAPgDAQQACANgEAMIgSAaIgHAPIgGAPQgKAJgIALQgEAKgHAIIgTANQgPAPgSAMIgVANQAeAKAeACIAjAAIADgGQAVgVAYgSIAcgZQAJgGAMgOIAPgXIAEgKQAEgLAGgJIAQgZIAHgQIAKgQIALgYIAGgLQgWgPgcgMQg2gXglgHgACkCrIgBADQgMAYgIAaQgDAVgKASIgPATIgOAMQAQAJARgKQATgKANgPQAUgXADgcQACgXgHgVQgGgQgKgQQAAAQgEAOgAl9BgIgKAOQgNAjAPAdQAVADAaAUIAOAKQAEgHAJgIQAZgHAYgaQAUgTAMgYQALgbAGgdIAJg1IAEgVQgWADgYAHQgoAMglAVIgFAEQAKAFADALQAGAMgDAMQgKAcgYACQgMABgLgHIgFgEgACDkHIhGAZQgwALgDAZQAFAiAXAmQAeApgDAgQAAALgDAIIAZANQAzAZAkAbIAUgLIAggLIAsgQIA3gbIA5geQAUgIgEgOQgLgLgPABQgbAEgbAJQgoAagigRQgbgUAHgaIAVgmQAKgUgEgWIgFgSIgSg5QgPgCgOAAQglAAgfASgAiOktIgKAgQgGARgBASQAAARADAPIAUBtQAiAEAwAMQgPg6ABg9QABgiAKgjIgLgGIgggYQgNgLgNAAQgIAAgIAFg");
	this.shape_1151.setTransform(732.1093,122.4507);

	this.shape_1152 = new cjs.Shape();
	this.shape_1152.graphics.f("rgba(255,255,255,0.067)").s().p("AitEkIAVgNQARgMAPgPIASgOQAHgIAEgKIASgVIAGgPIAHgOIASgaQAEgMgCgOQADgPAIgQQAEgRgfgYQgCgJABgKIAFgQIAAgBQAmAGA8AZQAbALAXAQIgGALIgLAYIgKAQIgHAPIgQAaQgGAJgEALIgFAKQgGANgIAKQgMAOgJAFIgbAZQgXATgVAUIgEAHIgiAAQgegBgegKgABnEkIANgJIAPgTQAKgSADgVQAIgaAMgYIABgEQAEgMAAgRQAKAQAGAQQAHAWgCAVQgDAcgUAXQgOAPgSALQgIAFgHAAQgJAAgIgHgAlVDLQgagUgVADQgRgcAMgjIAKgPIACgDIAGAEQALAGAMgCQAYgDAJgcQACgMgGgLQgEgLgKgFIAGgEQAkgWAogPQAWgGAXgEIgDAVIgIA2QgFAcgJAcQgMAYgTATQgXAcgZADQgJAIgEAHgABYgZIgZgMIADgUQADgfglgqQgbgngHgjQACgZA2gKQAtgMAggLQAtgaA1AKIASA5IAFARQAEAWgLAVQgJATgLASQgIAbAcAUQAiARAogaQAbgJAbgEQAPgCALAMQAEAOgVAIIg5AeIg3AbQgVAJgWAHIghALIgUALQgjgcgzgZgAiRhaIgYhsQgDgPgBgQQAAgTAGgRIAJghQATgMAXARIAhAXIALAGQgJAjAAAiQACA9ARA6QgygLghgDg");
	this.shape_1152.setTransform(720.6965,111.9017);

	this.shape_1153 = new cjs.Shape();
	this.shape_1153.graphics.f("#232323").s().p("AAAGCQgsABgsgCQgngBgogHQgqgKgngSQhcgphOhBIgHgHQgOgMgLgPQgMgXgHAOQgJgggBggQACgvAggnQARgcAWgZQAagcAmgQQA5gdA8gLIgYhwQgFgWAAgWQAAgNAEgNIANgxQAFgSAJgRQAQgWAfgCQAYgFAYgBQAhAFAYAWQATALASAMIACACQAOgRARgNQANgMAPgKQAPgIBHAQIBYAPQAcAAAdAHQAfANAQAhQAJAPAGASQARAvgFAyQA9gEA5AaQArAigSBCQgTAugzAVQg7AkhBAaIgtASIABACQAWAiAIAsQAFAggFAhQgKA9gwAuQgtAogtgLQgwAOg0AAIgTgBgAg0AMIgFAQQAAAKACAJQAfAYgFARQgIAQgDAPQACAOgEAMIgSAaIgHAOIgGAPIgRAVQgEAKgHAIIgSAOQgPAPgSAMIgUANQAeAKAeABIAiAAIADgHQAVgUAXgTIAcgZQAIgFAMgOQAJgKAGgNIAFgKQADgLAGgJIAQgaIAHgPIAKgQIALgYIAGgLQgWgQgbgLQg9gZglgGgACmCsIgBAEQgMAYgJAaQgDAVgKASIgPATIgMAJQAPAMARgKQASgLANgPQAUgXADgcQADgVgIgWQgGgQgKgQQABARgEAMgAlUDMIAOAJQAEgHAJgIQAZgDAXgcQASgTAMgYQAKgcAEgcIAIg2IADgVQgWAEgXAGQgoAPgkAWIgFAEQAJAFAFALQAGALgDAMQgJAcgYADQgLACgMgGIgFgEIgCADIgLAPQgLAjAQAcIAGAAQATAAAXARgACEkFQghALgsAMQg3AKgCAZQAHAjAbAnQAlAqgCAfIgEAUIAaAMQAzAYAjAdIAUgLIAhgLQAWgHAVgJIA3gbIA5geQAUgIgEgOQgLgMgPACQgbAEgaAJQgpAagigRQgbgUAHgbQALgSAKgTQALgVgFgWIgEgRIgSg5QgPgDgOAAQglAAggATgAiekpIgJAhQgGARAAATQABAQADAPIAZBsQAhADAxALQgRg6gBg9QgBgiAKgjIgMgGIghgXQgNgKgMAAQgJAAgIAFg");
	this.shape_1153.setTransform(720.6384,111.8404);

	this.shape_1154 = new cjs.Shape();
	this.shape_1154.graphics.f("rgba(255,255,255,0.067)").s().p("AiqEkIAUgNQASgMAPgQIARgOIALgRQAHgMAKgKIAFgPIAHgOIASgaQAEgMgBgOQACgPAJgQQAEgRgkgZQgCgIAAgLIAFgQIAAAAQAlAEBCAaQAcAMAWAQIgGALIgLAYIgJAPIgIAQIgQAaQgGAJgDALIgFAKIgOAXQgNANgHAEQgOAOgNAMQgXATgVAVIgDAGIgiABQgeAAgegKgABqEfIALgGIAOgTQALgSADgVQAHgZAMgYIACgEQAEgNgBgRQALAQAFARQAIAVgDAWQgDAcgUAXQgMAQgTAJQgHAFgHAAQgJAAgHgKgAlTDOQgbgTgVAJQgSgbALgkIAJgPIADgDIAFADQAMAGALgCQAYgDAIgdQACgMgGgLQgFgLgKgFIAFgEQAkgXAngQQAWgIAXgEIgCAVIgGA2QgEAcgJAdQgLAYgSAUQgWAcgZAAQgHAIgFAHgABZgaIgZgMIADgUQADgggsgrQgfgogLgiQACgZA9gJQAzgMAigLQAsgZA2AJIASA6IAFARQAEAWgLAUIgVAmQgGAbAaATQAjASAogaQAagKAcgDQAPgCAKALQAEAPgUAIIg5AeIg3AbIgsAQIggALIgUAKQgkgagygagAiahZIgchqQgDgPgCgRQgBgSAFgSIAIggQASgOAYARIAiAWIALAFQgHAkACAhQADA8ATA6QgygJghgCg");
	this.shape_1154.setTransform(709.2497,101.5713);

	this.shape_1155 = new cjs.Shape();
	this.shape_1155.graphics.f("#232323").s().p("AijF8QgpgJgogRQhcgnhPhAIgIgHQgOgMgLgOQgNgXgGAVQgLgegCghQABgvAegoQAQgdAVgaQAZgdAmgRQA3gfA9gNIgdhvQgFgWgCgWIADgaIAMgxQAEgSAIgSQAPgWAggEQAXgGAZgBQAgAEAaAVQATAKASALIACACQAOgRAQgOQAOgMAOgLQAOgIBSARIBiARQAcAAAcAIQAfAMARAhQAKAQAFASQAQAugFAyQA+gEA4AaQAtAjgTBBQgUAugzAVQg6AkhBAbIgtARIABACQAWAjAIArQAFAggFAhQgLA9gvAuQgtAogqgOQg5AQg9gBIhYAAQgpAAgngHgAg5AOIgFAQQABAKACAIQAjAZgEARQgIAQgDAQQACANgEAMIgSAaIgHAPIgGAPQgJAJgIAMIgKARIgSAPQgPAPgRANIgVANQAfAKAeAAIAigBIADgHQAUgUAXgTQAOgMANgPQAIgDAMgOIAPgXIAEgKQAEgLAGgJIAQgZIAHgQIAKgQIALgYIAGgLQgXgPgbgMQhCgbgmgEgACmCuIgBAEQgMAYgIAaQgDAVgKASIgPATIgLAGQANAPARgKQATgKANgQQAUgWADgcQACgXgHgVQgGgQgKgQQAAARgEAMgAlSDTIANAJQAFgIAIgHQAYAAAXgcQASgVALgYQAJgcADgdIAGg1IACgWQgWADgXAJQgnARgjAXIgFAEQAKAFAEAKQAHALgDAMQgHAdgYAEQgMACgLgGIgGgDIgCADIgKAPQgLAjASAcQAHgDAIAAQAQAAASANgACFkDQgjALgyALQg+AJgBAZQALAjAfAoQArArgDAfIgDAUIAZANQAzAYAkAcIATgLIAhgLIAsgQIA3gbIA5geQAUgIgEgOQgLgLgPABQgbAEgbAJQgoAagigRQgbgUAHgaIAVgmQAKgUgEgWIgFgSIgSg5QgOgDgOAAQgmAAgfATgAiukjIgIAhQgFASAAASQACAQAEAQIAcBqQAhACAxAJQgTg6gDg8QgCgiAIgjIgLgGIgigWQgNgJgMAAQgJAAgIAGg");
	this.shape_1155.setTransform(709.1843,101.122);

	this.shape_1156 = new cjs.Shape();
	this.shape_1156.graphics.f("rgba(255,255,255,0.067)").s().p("AioEkIAUgOQAQgNAQgPIARgPQAHgIADgJQAIgMAJgKIAFgPIAHgOIASgbQAEgMgCgNQADgQAIgPQAFgRgpgaQgCgIgBgKIAEgQIAAgBQAmADBJAcQAbAMAWAPIgGALIgLAZIgKAPIgHAQIgQAaQgGAJgEAKIgEAKQgHANgIAKQgMAPgHABQgMAPgOAMQgXATgUAVIgDAHIgiACQgeAAgegJgABrEaIAJgDQAJgJAGgKQAKgSADgVQAJgaAMgYIABgDIADgeQAKAQAGAQQAHAWgCAWQgDAcgUAXQgNAPgTAKQgFAEgGAAQgJAAgIgMgAlSDRQgbgTgWAPQgSgbAJgkIAJgPIACgDIAGADQALAFAMgCQAYgEAGgdQADgMgHgLQgFgLgLgEIAFgEQAjgZAngRQAWgKAWgEIgCAVIgEA2QgCAdgIAcQgKAZgRAVQgVAdgZgEQgIAIgEAIgABZgcIgagNIAEgTQACgggxgsQgkgogNgjQAAgZBFgIQA3gLAlgLQAsgaA2AKIARA5IAFASQAEAWgKAUQgKAUgLASQgHAaAbAUQAiASApgbQAZgJAcgEQAPgBALALQAEAPgUAHIg5AeIg3AcIgrAPIghALIgUALQgjgbgzgZgAikhYIgfhpQgFgPgCgQQgCgTAFgSIAHggQASgOAZAPIAiAVIAMAFQgHAjADAiQAFA8AVA5QgxgHgigBg");
	this.shape_1156.setTransform(697.8604,91.3178);

	this.shape_1157 = new cjs.Shape();
	this.shape_1157.graphics.f("#232323").s().p("AifF/QgqgIgogRQhdgmhPg+IgIgGQgOgMgLgOQgOgXgGAcQgMgegDggQAAgvAcgpQAPgdAUgcQAYgdAlgTQA3ghA7gOIgghvQgGgVgCgXQgBgMADgNIAJgyQAFgSAHgTQAOgVAfgFQAYgIAYgCQAgADAbAUQATAJATALIACACQANgRAQgPIAcgYQAMgIBdASIBsATQAcgBAcAIQAgAMAQAiQAJAPAGASQARAugFAyQA9gDA4AZQAtAjgTBBQgTAvgzAUQg7AkhBAbIgtASIABABQAWAjAIArQAFAhgFAgQgKA9gwAuQgtAogngSQg4ASg+gBIhYACQgnAAgogFgAg/APIgEAQQABAKACAIQApAagFARQgIAPgDAQQACANgEAMIgSAbIgHAOIgFAPQgJAKgIAMQgDAJgHAIIgRAPQgQAPgQANIgUAOQAeAJAeAAIAigCIADgHQAUgVAXgTQAOgMAMgPQAHgBAMgPQAIgKAHgNIAEgKQAEgKAGgJIAQgaIAHgQIAKgPIALgZIAGgLQgWgPgbgMQhJgcgmgDgACnCwIgBADQgMAYgJAaQgDAVgKASQgGAKgJAJIgJADQAMASAQgKQATgKANgPQAUgXADgcQACgWgHgWQgGgQgKgQgAlRDZIAOAJQAEgIAIgIQAZAEAVgdQARgVAKgZQAIgcACgdIAEg2IACgWQgWAFgWAKQgnARgjAZIgFAEQALAEAFALQAHALgDAMQgGAdgYAEQgMACgLgFIgGgDIgCADIgJAPQgJAkASAbQAKgGALAAQANAAAPAKgACFkCQglALg3ALQhFAIAAAZQANAjAkAoQAxAsgCAgIgEATIAaANQAzAYAjAcIAUgLIAhgLIArgPIA3gcIA5geQAUgHgEgPQgLgLgPABQgcAEgZAJQgpAbgigSQgbgUAHgaQALgSAKgUQAKgUgEgWIgFgSIgRg5QgPgCgOAAQglAAggASgAi/kdIgHAgQgFASACATQACAQAFAPIAfBpQAiABAxAHQgVg5gFg8QgDgiAHgjIgMgFIgigVQgNgIgMAAQgKAAgIAHg");
	this.shape_1157.setTransform(697.7712,90.5162);

	this.shape_1158 = new cjs.Shape();
	this.shape_1158.graphics.f("rgba(255,255,255,0.067)").s().p("AilEjIATgOQARgNAPgQIARgPQAGgHAEgKQAHgMAJgKIAFgQIAHgOIASgaQAEgMgCgNQADgQAIgQQAEgRgtgZQgDgJgBgJIAEgRIAAAAQAmABBOAeQAbALAXAQIgGALIgLAYIgKAQIgHAPQgHAPgJALQgGAJgEALIgEAKQgHANgIAKQgLAOgIABQgMAOgOANQgVATgUAWIgDAGIgiADIgGAAQgbAAgbgIgABtEUIAIABIAPgTQAKgSADgVQAIgaAMgYIABgEQAEgMAAgRQAKAQAGAQQAHAVgCAXQgDAcgUAWQgOAQgSAKQgFADgFAAQgKAAgHgPgAlQDTQgbgSgWAVQgUgbAIgjIAJgQIACgDIAGADQAMAEALgCQAYgFAFgdQACgNgHgKQgFgLgLgEIAFgEQAigaAmgTQAWgKAVgGIAAAXIgDA2QgBAcgHAdQgJAZgRAWQgUAdgYgHQgIAJgEAHgABZgeIgZgNIADgUQADgfg4gtQgpgpgQgjQAAgYBMgIQA9gLAngKQArgaA2AKIASA5IAFASQAEAWgKAUIgVAlQgIAbAcAUQAiARAogaQAbgJAbgEQAPgBALALQAEAOgUAIIg5AeIg4AbQgUAKgXAGIghALIgTALQgkgbgzgZgAishWIgkhpQgFgOgCgRQgCgSAEgSIAFghQASgOAZAOIAjAUIAMAEQgGAkAEAhQAIA8AXA5QgygGghABg");
	this.shape_1158.setTransform(686.444,81.0611);

	this.shape_1159 = new cjs.Shape();
	this.shape_1159.graphics.f("#232323").s().p("AibGBQgqgHgogQQhdgkhRg9IgIgGQgOgLgLgPQgOgVgGAjQgMgegFggQgCgvAbgrQAOgdATgcQAXggAkgSQA2gjA7gRIgkhtQgIgVgDgXIACgZIAIgyQADgTAGgSQAPgXAegGQAXgIAZgDQAgACAbATQAUAJATAKIACABQANgRAPgPIAbgZQANgJBmATIB2AUQAcAAAdAHQAfANAQAhQAJAQAGARQARAugFAyQA9gDA5AaQAsAigTBCQgTAugzAUQg7AkhBAbIgtASIABABQAWAkAIAqQAGAhgGAgQgKA9gwAuQgtApgkgXQg4ATg9ABIhYADIgMAAQghAAgigEgAhFAQIgDAQQAAAKADAJQAuAZgFARQgIAQgDAPQACAOgEAMIgSAaIgHAOIgFAPQgJAKgHAMQgEAKgGAIIgRAPQgPAQgQAMIgUAOQAfAJAegBIAhgCIADgHQAUgVAWgUQAOgMAMgPQAHgBALgNQAJgKAGgOIAFgJQADgLAHgJQAJgMAGgOIAHgQIAKgPIALgYIAGgMQgWgPgbgMQhPgeglgBgACJErQASgJANgQQAUgXAEgcQACgWgIgVQgGgRgKgQQABARgEANIgBADQgNAZgHAZQgDAVgLASIgOATIgJAAQALAWARgLgAlQDfIAOAIQAFgHAIgIQAYAHAUgeQARgVAJgZQAGgdACgdIACg2IABgWQgWAFgWALQgmATgiAaIgEAEQAKAEAFAKQAHALgBAMQgGAdgXAFQgMADgMgFIgFgDIgDAEIgIAPQgIAkAUAbQAMgMANAAQALAAAMAJgACFkBQgmALg9AKQhNAIABAZQAQAjApApQA4AsgDAgIgDATIAZANQAyAZAkAbIAUgLIAhgLQAXgGAUgJIA3gcIA5gdQAUgIgEgPQgKgLgPACQgcADgaAKQgoAagjgSQgbgTAHgbIAVgmQALgUgFgWIgEgRIgSg6QgPgDgOAAQglAAggATgAhZhGQgXg4gHg8QgFgiAGgjIgMgFIgjgTQgZgPgRAOIgGAhQgEATACASQADARAFAOIAjBoIAKAAQAfAAAqAFg");
	this.shape_1159.setTransform(686.3525,79.9406);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1109},{t:this.shape_1108}]},188).to({state:[{t:this.shape_1111},{t:this.shape_1110}]},1).to({state:[{t:this.shape_1113},{t:this.shape_1112}]},1).to({state:[{t:this.shape_1115},{t:this.shape_1114}]},1).to({state:[{t:this.shape_1117},{t:this.shape_1116}]},1).to({state:[{t:this.shape_1119},{t:this.shape_1118}]},1).to({state:[{t:this.shape_1121},{t:this.shape_1120}]},1).to({state:[{t:this.shape_1123},{t:this.shape_1122}]},1).to({state:[{t:this.shape_1125},{t:this.shape_1124}]},1).to({state:[{t:this.shape_1127},{t:this.shape_1126}]},1).to({state:[{t:this.shape_1129},{t:this.shape_1128}]},1).to({state:[{t:this.shape_1131},{t:this.shape_1130}]},1).to({state:[{t:this.shape_1133},{t:this.shape_1132}]},1).to({state:[{t:this.shape_1135},{t:this.shape_1134}]},1).to({state:[{t:this.shape_1137},{t:this.shape_1136}]},1).to({state:[{t:this.shape_1139},{t:this.shape_1138}]},1).to({state:[{t:this.shape_1141},{t:this.shape_1140}]},1).to({state:[{t:this.shape_1143},{t:this.shape_1142}]},1).to({state:[{t:this.shape_1145},{t:this.shape_1144}]},1).to({state:[{t:this.shape_1147},{t:this.shape_1146}]},1).to({state:[{t:this.shape_1149},{t:this.shape_1148}]},1).to({state:[{t:this.shape_1151},{t:this.shape_1150}]},1).to({state:[{t:this.shape_1153},{t:this.shape_1152}]},1).to({state:[{t:this.shape_1155},{t:this.shape_1154}]},1).to({state:[{t:this.shape_1157},{t:this.shape_1156}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[{t:this.shape_1159},{t:this.shape_1158}]},1).to({state:[]},1).wait(1070));

	// Каркас_13
	this.shape_1160 = new cjs.Shape();
	this.shape_1160.graphics.f("rgba(255,255,255,0.067)").s().p("Ag4FtQgvgTgHg7QADgaAkglIAIgIIAGADQAmAQAmACIASAsQARAugLAxIgLABQgsAAgsgMgAD6BtIAPgaQAMgUAJgVIAJAAQBDgBAOADQAQAFALANQAHALgDAOQgHA6gvArIgTAQgAlrDCQgPgBgPgHQgPgMACgWQgBg+BAglQAngSAuAGQAVAAAVAFIAPAGQABAVAFANQAHAUARAXIgWAUQgSARgQAJQgpAYgxAAQgWAAgYgFgAjwiBQgDg/AMg+QAQg9AxgsQASgOAYgDQAbABAUAYQAcAbAQAkIACAEIgOACQg8ANgtAxQgaAcgNAkQgFAPgCAXQgggDgMgIgAEEiqQgjgjgpgcQgbgSgdgPIAehMQAGgPAMgMQAMgHAPABQA9gBAyAkQATAcgFAkQgBAsgEArQgDAbgPAXIgNAKQgJgSgXgXg");
	this.shape_1160.setTransform(551.5466,82.208);

	this.shape_1161 = new cjs.Shape();
	this.shape_1161.graphics.f("#232323").s().p("EATxAtxIhkshQg4mpg+moIhKoPQgXihgdihIgPhCQg4j6hkjtQh6kjinkOQjomXi9kiIhqifQjnlPjvkHIgEABQg8AOg/gIQgGBEgqA2QggAXgqgCQhfAFhagpQhUgugbhmQhvgNhugKQhXgzAMh9QAPiNCZhDQgGhoARhmQAXhkBPhLQBQhBByAcQBAAZAtA7QANg4A8gaQA0gXA8AGQBJAEBCAmQBWA9AEB7QAHBrgkBnQA6AKAgA8QAaA0gKA+QgHA9giA3QgeAxgsAhQEwFpEAGKQD5F6DYGMQCMD8B0EGQBjDoA9D4IANA6QA2DzAeD4IC1UQQAzFvAaFwQADBGhAAjQg2gGABhPgEgOPgjjQgkAkgDAaQAHA7AvAUQAxAMAzgBQALgygRguIgSgsQgngCgmgQIgGgCgEgI+glxIgPAbIBUBeIATgQQAvgqAHg6QADgOgHgMQgLgNgQgEQgOgDhDAAIgJAAQgJAWgMATgEgSfgmOQhAAkABA+QgCAXAPAMQAPAHAPAAQBMAQA8giQAQgJASgSIAWgUQgRgXgHgTQgFgOgBgUIgPgHQgVgFgVAAIgVgBQgiAAgeAOgEgPugssQgxAsgQA+QgMA+ADA/QAMAHAgAEQACgYAFgPQANgkAagcQAtgwA8gNIAOgCIgCgFQgQgkgcgbQgUgXgbgBQgYACgSAOgEgKXgs1QgMAMgGAPIgeBLQAdAPAbATQApAcAjAiQAXAXAJASIANgKQAPgXADgbQAEgrABgrQAFglgTgcQgygkg9ACIgFgBQgMAAgKAHg");
	this.shape_1161.setTransform(635.5093,332.2784);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1161},{t:this.shape_1160}]},188).to({state:[]},50).wait(1070));

	// ЦВЕТОК
	this.instance_65 = new lib.городскиежильцыперсонажи47();
	this.instance_65.setTransform(527,248,0.3822,0.3822);
	this.instance_65._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_65).wait(188).to({_off:false},0).to({_off:true},43).wait(1077));

	// ВАЗА
	this.instance_66 = new lib.городскиежильцыперсонажи46();
	this.instance_66.setTransform(354,41,0.3965,0.3965);
	this.instance_66._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_66).wait(188).to({_off:false},0).to({_off:true},50).wait(1070));

	// СТОЛ
	this.instance_67 = new lib.фоны_фонстол();
	this.instance_67.setTransform(-21,-115,0.3444,0.3444);

	this.shape_1162 = new cjs.Shape();
	this.shape_1162.graphics.f().s("#232323").ss(8,1,1).p("Eh/whCDMD/hAAAMAAACEHMj/hAAAg");
	this.shape_1162.setTransform(795.9,404.175);

	this.shape_1163 = new cjs.Shape();
	this.shape_1163.graphics.f("#FFFFFF").s().p("Eh/wBCEMAAAiEHMD/gAAAMAAACEHg");
	this.shape_1163.setTransform(795.9,404.175);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1163},{t:this.shape_1162},{t:this.instance_67}]},188).to({state:[{t:this.shape_1163},{t:this.shape_1162},{t:this.instance_67}]},56).to({state:[]},30).wait(1034));

	// ВОПРОС
	this.instance_68 = new lib.Анимация11("synched",0);
	this.instance_68.setTransform(958.9,179.05);
	this.instance_68._off = true;

	this.instance_69 = new lib.Анимация12("synched",0);
	this.instance_69.setTransform(958.95,179.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_68}]},172).to({state:[{t:this.instance_69}]},12).to({state:[]},5).wait(1119));
	this.timeline.addTween(cjs.Tween.get(this.instance_68).wait(172).to({_off:false},0).to({_off:true,x:958.95},12).wait(1124));

	// глаза
	this.shape_1164 = new cjs.Shape();
	this.shape_1164.graphics.f("#232323").s().p("AC7CNQg0g0gFhGIgBgTIAAgFIAAgKIACgMQAIhBAwgxQA5g5BQgBIAFAAQBTAAA6A6QA7A7AABSQAABSg7A7Qg6A7hTAAQhTAAg7g7gAnVCNQg0g0gGhGIgBgTIAAgFIABgKIABgMQAJhBAwgxQA5g5BPgBIAFAAQBTAAA7A6QA6A7AABSQAABSg6A7Qg7A7hTAAQhSAAg7g7g");
	this.shape_1164.setTransform(497.975,275.25);

	this.shape_1165 = new cjs.Shape();
	this.shape_1165.graphics.f("#232323").s().p("ACxCNQg0g0gGhGIAAgTIAAgFIAAgKIABgMQAJhBAwgxQA5g5BQgBIAEAAQBTAAA7A6QA7A7gBBSQABBSg7A7Qg7A7hTAAQhSAAg7g7gAnLCNQg0g0gGhGIgBgTIAAgFIABgKIABgMQAJhBAwgxQA5g5BQgBIAEAAQBTAAA7A6QA7A7AABSQAABSg7A7Qg7A7hTAAQhSAAg7g7g");
	this.shape_1165.setTransform(505.1,275.25);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1164}]},129).to({state:[{t:this.shape_1165}]},27).to({state:[]},33).wait(1119));

	// Каркас_11
	this.shape_1166 = new cjs.Shape();
	this.shape_1166.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQgBBkhGBFQhFBIhkgBQhjABhGhIQhGhFAAhkQAAhiBGhHQBGhFBjgBQBjABBGBFQBGBHABBig");
	this.shape_1166.setTransform(464.55,275.1007);

	this.shape_1167 = new cjs.Shape();
	this.shape_1167.graphics.f("#FFFFFF").s().p("ADRDRQgbgQgYgXQhGhHAAhjQAAhiBGhHQBGhFBkgBQBjAABHBGQBGBGAABjIAAAEQgCBhhEBFQhHBGhjAAQhCAAg1gfgAlHDwQhkABhGhIQhGhFAAhkQAAhiBGhHQBGhFBkgBQBjABBGBFQBGBHABBiQgBBkhGBFQhEBHhjAAIgCAAg");
	this.shape_1167.setTransform(497.375,275.125);

	this.shape_1168 = new cjs.Shape();
	this.shape_1168.graphics.f("#232323").s().p("EAGpAkBQihgnicg3QhUgfhXAUQg0ANg1AHQjCAbjBAXQkeAlkhASIgSABQnBAcm5hRQi8gjimhfIgegTQhTg2g3hSQgshAgJhNIgHhFQgYlEBDk9QBCk2DVjkQAkgmAfgsQCCi2C3iFIDDiNQBZg9Bbg3QGnkGHkh1QBpgaBqgUQCMgZCNgQQAvgHAvgBQATjHAsjCIAGgXQBtnNCCnHQBCjkB+jGQBSiACMAsQAzAQAiAqQBGBVAOBuQAYC7AqC3QAyDbCHCwQCuiZDTBFIAiAMQAeAMAbAQQAVgtAYgrQBqjDCaikQBUhYBLhfQBpiDCfAdQAtAJAdAkQBbBzgOCVQgCAVAAAVIAAAGQAHFIgZFIQgHBYgXBXQBcBbAvB1IAJAWQAWA9AQBDQA0DwgJD2QgJDRhdC+QhUCsiYB2IgZAQQAzCaAMCiIAUD0QAVDfgODiQgLDDhWCpQgVAogeAdQguAsg1AkQguAhgzAUQgdAMgdAJQjaAwjRhSIgNgHQhmByiJBDQhKAkhVACIg2ABQlCAAk4hOgAbCpzQhkABhGBFQhGBHAABjQAABjBGBHQAYAXAbAQQA1AfBCAAQBjAABHhGQBEhFAChhIAAgEQAAhkhGhGQhGhGhiAAIgCAAgATbjaQBGhFABhkQgBhjhGhHQhGhFhjgBQhkABhGBFQhGBHAABjQAABkBGBFQBGBIBkgBQBkABBFhIg");
	this.shape_1168.setTransform(357.1698,313.9028);

	this.shape_1169 = new cjs.Shape();
	this.shape_1169.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhFBGhkAAQhjAAhGhGQhFhGgBhkQAAhjBGhGQBHhGBiAAQBkABBGBFQBGBHAABig");
	this.shape_1169.setTransform(464.5,275);

	this.shape_1170 = new cjs.Shape();
	this.shape_1170.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhGAAhkQAAhiBFhHQBHhFBjgBQBlAABEBGQBHBHAABiIAAAFQgCBhhFBEQhFBGhkAAQhCAAg1gfgAnyCpQhFhFAAhkQAAhjBGhGQBGhGBkAAQBkABBFBFQBHBHAABiQAABkhHBFQhGBHhkAAQhjAAhHhHg");
	this.shape_1170.setTransform(497.3,275.025);

	this.shape_1171 = new cjs.Shape();
	this.shape_1171.graphics.f("#232323").s().p("EAGoAkCQihgnicg3QhUgghXAUQg0AOg0AGQjDAbjCAWQkdAlkgARIgSABQnBAcm6hSQi8gjimhfIgdgTQhTg3g3hRQgshBgJhNIgHhFQgYlEBDk8QBDk3DVjjQAlgmAfgsQCCi2C2iFIDEiMQBZg9BYg3QGnkFHnhzQBpgaBrgVQCLgaCNgQQAwgHAvgCQASjGArjCIAGgYQBsnMB+nGQBAjmB8jGQBSiACMArQAzAQAjApQBGBVAOBtQAaC7ArC3QA0DbCICvQCsibDVBHIAjANQAeALAcAUIArhcQBqjECXioQBShZBMhgQBniECfAdQAtAIAeAkQBbBzgMCVQgCAUADAcIAAAGQAIFIgZFOQgHBagXBVQBcBcAvB1IAJAWQAWA9APBCQA2DxgLD2QgIDShdC8QhUCtiYB2IgZAQQAzCaAMChIAUD0QAVDggODrQgMDBhVCqQgUAoggAdQguAsg1AkQgtAgg0AVQgcAMgeAIQjbAwjQhTIgNgHQhmByiJBDQhLAkhVABIguABQlGAAk7hQgAYYovQhGBGAABkQAABkBGBFQAYAYAbAQQA1AfBCAAQBkAABFhHQBFhEAChhIAAgEQAAhkhHhGQhFhGhkAAQhjAAhHBGgAOIowQhGBHAABjQAABkBFBGQBHBGBjAAQBkAABGhGQBHhFAAhlQAAhihHhIQhFhFhkgBQhkABhGBFg");
	this.shape_1171.setTransform(357.1196,314.0541);

	this.shape_1172 = new cjs.Shape();
	this.shape_1172.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABlhHBFQhGBGhjAAQhjAAhHhHQhFhFAAhkQAAhjBGhGQBGhGBjAAQBkAABFBGQBHBHAABig");
	this.shape_1172.setTransform(464.45,274.9);

	this.shape_1173 = new cjs.Shape();
	this.shape_1173.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhGgBhkQABhiBGhHQBGhFBkAAQBjAABFBFQBHBHAABiIAAAFQgCBhhFBEQhFBGhkAAQhCAAg1gfgAnxCpQhFhGgBhjQAAhjBGhHQBHhFBkAAQBjAABGBGQBGBHAABiQAABkhHBFQhGBHhjAAQhkAAhGhHg");
	this.shape_1173.setTransform(497.25,274.925);

	this.shape_1174 = new cjs.Shape();
	this.shape_1174.graphics.f("#232323").s().p("EAGnAkEQihgnicg4QhUgghXAUQg0ANg0AHQjDAZjCAXQkdAkkfARIgSABQnBAbm6hSQi8gjimhgIgdgTQhTg3g3hRQgshBgIhNIgHhFQgYlEBDk8QBDk3DWjjQAlgmAegsQCCi2C3iEIDEiMQBZg9BWg2QGnkGHqhxQBpgbBrgUQCLgaCNgRQAugHAwgCQASjGArjDIAFgXQBrnNB5nFQA/jmB7jHQBRiBCMAqQAzAPAjAqQBHBUAPBuQAbC6AsC3QA2DaCJCuQCribDXBIIAjANQAdAMAeAXQAVguAVgzQBpjDCTiuQBThaBKhgQBniECfAbQAtAIAeAkQBcBzgLCUQgCAVAFAiIABAGQAIFIgYFVQgHBZgXBWQBcBbAvB1IAJAXQAWA9APBCQA2DxgLD1QgIDShdC9QhVCtiYB1IgYAQQAyCbANChIAUD0QAUDggMDzQgNDChWCpQgVAogfAdQgtAsg2AkQgtAgg0AUQgcAMgeAJQjbAvjQhUIgNgHQhmByiKBDQhLAjhUACIgqAAQlJAAk8hRgAYYoyQhGBHAABjQAABkBGBGQAYAYAbAPQA1AfBCAAQBkAABFhGQBFhEAChhIAAgFQAAhjhHhHQhFhFhjAAQhkAAhHBFgAOIozQhGBHAABjQAABkBFBGQBHBHBjAAQBkAABGhHQBHhFAAhkQAAhjhHhHQhFhGhkAAQhkAAhGBFg");
	this.shape_1174.setTransform(357.0964,314.2149);

	this.shape_1175 = new cjs.Shape();
	this.shape_1175.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABlhHBFQhGBGhjAAQhjAAhHhHQhFhFAAhkQAAhjBGhHQBHhFBiAAQBkABBGBFQBGBHAABig");
	this.shape_1175.setTransform(464.4002,274.7502);

	this.shape_1176 = new cjs.Shape();
	this.shape_1176.graphics.f("#FFFFFF").s().p("ADRDRQgbgPgYgYQhFhFgBhlQABhiBGhHQBGhFBkAAQBkAABFBFQBGBHAABiIAAAFQgCBhhEBEQhGBHhkAAQhCAAg1gggAlIDwQhjAAhHhHQhFhFAAhkQAAhjBGhHQBHhFBjgBQBkACBGBFQBGBGAABjQAABlhHBFQhFBGhjAAIgCAAg");
	this.shape_1176.setTransform(497.2,274.8);

	this.shape_1177 = new cjs.Shape();
	this.shape_1177.graphics.f("#232323").s().p("EAGlAkGQiggoicg4QhVgghXATQgzAOg1AGQjCAZjCAWQkfAkkdAQIgSABQnBAbm6hTQi7gkimhfIgegTQhSg3g4hRQgshBgIhNIgHhFQgXlEBEk8QBDk3DWjiQAlgmAegtQCDi2C3iEIDEiMQBYg9BUg0QGnkHHthuQBpgbBrgVQCLgbCNgRQAugHAwgCQARjGAqjDIAGgXQBpnOB2nEQA8jmB6jIQBRiCCMAqQAzAPAjApQBIBTAQBuQAcC7AtC2QA3DZCLCuQCqidDYBLIAjAMQAeAMAeAaQAVgtAUg3QBojDCRi0QBRhaBKhgQBniGCeAbQAtAHAeAkQBdBygKCVQgCAUAJAqIAAAGQAKFIgYFbQgIBZgXBWQBdBbAuB1IAJAWQAXA+APBCQA1DxgKD1QgJDRhdC+QhUCsiYB2IgZAQQAzCaAMCiIAUD0QAUDfgLD9QgODBhWCpQgVAngfAeQguAsg1AkQguAfgzAVQgdAMgdAIQjbAvjRhUIgNgHQhmBxiJBDQhMAjhUABIgjAAQlMAAlAhSgAYYo0QhGBGAABkQAABkBFBFQAYAYAbAQQA1AfBCAAQBkAABGhHQBEhEAChhIAAgEQAAhkhGhGQhFhGhkAAQhjABhHBFgAOIo2QhHBHAABjQABBlBFBFQBGBHBkAAQBkAABFhGQBHhFAAhlQABhjhHhHQhFhFhkgBQhkAAhGBFg");
	this.shape_1177.setTransform(357.0689,314.3825);

	this.shape_1178 = new cjs.Shape();
	this.shape_1178.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwAAQAABkhHBGQhGBGhjAAQhjAAhHhHQhFhGAAhjQABhjBFhHQBHhFBjAAQBkABBFBFQBGBHAABig");
	this.shape_1178.setTransform(464.3502,274.6502);

	this.shape_1179 = new cjs.Shape();
	this.shape_1179.graphics.f("#FFFFFF").s().p("ADRDSQgcgQgXgYQhGhGABhkQABhiBFhGQBGhFBlgBQBiAABFBFQBHBHAABjIAAAEQgDBhhEBEQhFBHhlAAQhBAAg1gfgAlHDwQhkAAhGhHQhGhGAAhjQABhkBGhGQBGhFBkgBQBkABBFBGQBGBHAABiQAABkhHBGQhFBGhjAAIgBAAg");
	this.shape_1179.setTransform(497.15,274.7);

	this.shape_1180 = new cjs.Shape();
	this.shape_1180.graphics.f("#232323").s().p("EAGkAkHQihgoibg5QhVgfhXATQgzANg1AGQjCAYjCAWQkfAjkcAQIgSABQnBAam6hTQi8gkilhfIgegTQhSg4g4hRQgrhAgIhOIgHhFQgXlEBEk8QBDk2DWjjQAlgmAfgsQCCi2C4iEIDEiLQBYg9BSg0QGnkHHwhsQBpgbBqgVQCLgcCNgRQAvgIAvgCQARjGAqjDIAFgXQBonOBxnDQA8jnB4jJQBPiBCNAoQAzAPAkAoQBIBTARBuQAcC6AwC2QA4DZCMCtQCpieDaBMIAjANQAdALAgAeQAVgtASg6QBojFCNi4QBRhaBJhhQBmiGCfAZQAtAHAeAjQBeBygJCVQgCAUALAxIAAAGQALFIgXFhQgIBZgXBWQBdBbAuB1IAJAXQAXA9APBCQA1DxgLD1QgIDShdC9QhUCtiZB1IgYAQQAyCbANChIAUD0QATDggKEFQgODBhWCpQgVAogfAdQgvArg1AkQgtAgg0AUQgdAMgdAIQjbAujRhUIgNgHQhmBwiKBDQhLAjhVABIgeABQlOAAlChVgAYYo3QhFBGgBBkQgBBkBGBFQAYAYAbAQQA1AfBCAAQBkAABFhHQBEhEADhhIAAgEQAAhkhGhGQhFhFhjAAQhkAAhHBFgAOIo5QhGBHgBBjQABBkBFBGQBGBHBkAAQBkAABFhGQBHhGAAhkQABhjhHhHQhFhFhkgBQhkAAhGBFg");
	this.shape_1180.setTransform(357.0281,314.5617);

	this.shape_1181 = new cjs.Shape();
	this.shape_1181.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQAABkhHBFQhGBHhjgBQhjAAhHhHQhFhGAAhjQABhjBGhHQBGhFBjAAQBkABBFBGQBGBGAABjg");
	this.shape_1181.setTransform(464.3002,274.5007);

	this.shape_1182 = new cjs.Shape();
	this.shape_1182.graphics.f("#FFFFFF").s().p("ADRDSQgbgQgYgYQhGhFABhkQABhiBGhHQBGhFBkAAQBkABBEBEQBGBHAABiIAAAFQgCBhhFBEQhFBGhkAAQhCAAg1gfgAlHDvQhkAAhGhHQhFhFgBhjQABhkBGhGQBHhFBjgBQBkABBGBGQBGBHgBBiQAABkhHBGQhEBFhiAAIgDAAg");
	this.shape_1182.setTransform(497.0752,274.575);

	this.shape_1183 = new cjs.Shape();
	this.shape_1183.graphics.f("#232323").s().p("EAGiAkJQifgpicg5QhVgfhXASQgzANg1AGQjCAYjDAWQkdAikdAPIgRABQnBAam6hTQi8gkilhgIgegTQhSg4g3hRQgshBgIhNIgHhFQgXlEBFk8QBDk2DXjjQAlglAegtQCDi1C3iEIDFiMQBYg8BQgzQGnkHHzhqQBpgcBqgVQCLgcCNgSQAugIAwgCQAQjGApjDIAFgYQBmnOBunCQA6jnB3jJQBPiDCMAoQAzANAkApQBJBTARBtQAfC6AwC2QA6DZCNCrQCoieDbBOIAjAMQAeALAhAiQAVgtARg+QBnjFCKi9QBQhcBIhhQBliGCfAYQAtAGAfAjQBeBxgICVQgBAVAOA3IAAAGQAMFHgXFpQgIBYgXBXQBdBbAuB1IAJAWQAXA9APBDQA0DxgKD1QgIDRhdC+QhVCsiYB2IgYAQQAyCaAMChIAUD1QAVDfgLEOQgODChXCoQgVAogfAdQgvArg1AkQgtAfg0AVQgdALgdAJQjbAujRhWIgMgHQhnBxiKBCQhLAjhVABIgUAAQlUAAlHhWgAYZo5QhGBGgBBkQgBBjBGBGQAYAXAbARQA1AeBCAAQBkAABFhGQBFhEAChhIAAgEQAAhkhGhGQhEhFhkgBQhkABhGBFgAOIo8QhGBHgBBjQABBkBFBGQBGBHBkAAQBkABBFhHQBHhFAAhkQABhkhGhGQhGhGhkgBQhjAAhHBFg");
	this.shape_1183.setTransform(356.9909,314.7356);

	this.shape_1184 = new cjs.Shape();
	this.shape_1184.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQAABkhHBFQhGBGhjAAQhkAAhGhHQhFhGAAhjQAAhkBHhGQBGhFBjAAQBkABBFBGQBHBGgBBjg");
	this.shape_1184.setTransform(464.3,274.4002);

	this.shape_1185 = new cjs.Shape();
	this.shape_1185.graphics.f("#FFFFFF").s().p("ADRDSQgbgRgZgXQhFhFABhkQAAhiBHhHQBGhFBkAAQBkAABDBFQBGBHABBiIAAAEQgCBihFBEQhFBGhlAAQhCAAg0gfgAlIDvQhjAAhGhHQhGhGABhjQAAhjBGhHQBGhFBlAAQBjABBFBGQBHBHgBBiQAABkhHBGQhFBFhkAAIgBAAg");
	this.shape_1185.setTransform(497.0498,274.5);

	this.shape_1186 = new cjs.Shape();
	this.shape_1186.graphics.f("#232323").s().p("EAGhAkKQiggpicg5QhUgghXASQg0ANg1AGQjCAYjCAVQkfAgkaAQIgSABQnBAZm5hTQi8glimhgIgdgTQhTg3g3hSQgshAgHhNIgHhFQgXlEBFk9QBFk1DWjjQAlgmAegsQCEi1C3iEIDEiLQBZg9BNgyQGnkHH2hoQBpgdBqgVQCLgcCNgTQAvgHAvgCQAQjIAojCIAFgYQBlnOBpnBQA5jnB1jLQBOiDCNAnQAzANAkApQBKBSASBtQAfC6AyC2QA7DYCOCqQCnifDeBPIAiAMQAeAMAiAlQAWgtAPhCQBmjFCHjCQBPhcBIhiQBjiHCgAXQAtAGAfAjQBfBwgHCVQgBAVAQA+IABAGQANFIgXFuQgHBZgXBWQBcBbAvB1IAIAXQAYA9AOBCQA1DxgKD1QgJDShdC9QhUCtiZB1IgYAQQAyCaANCiIATD0QAVDfgKEXQgPDBhXCpQgVAngfAdQgvArg1AkQguAgg0AUQgcALgeAJQjaAtjRhWIgNgHQhmBwiLBCQhLAjhVABIgMAAQlYAAlKhYgAYYo8QhGBGAABkQgBBjBFBGQAYAXAbARQA1AeBCABQBkAABGhHQBEhEAChhIAAgEQAAhkhGhGQhDhFhkAAQhkAAhHBFgAOIo/QhHBGAABkQAABkBFBGQBGBHBkAAQBkAABGhGQBHhFAAhkQABhkhHhGQhFhGhkgBQhkAAhGBFg");
	this.shape_1186.setTransform(356.9534,314.914);

	this.shape_1187 = new cjs.Shape();
	this.shape_1187.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQAABkhHBFQhHBGhiAAQhkgBhGhHQhFhFAAhkQAAhjBHhGQBHhFBiAAQBkABBFBFQBHBIgBBig");
	this.shape_1187.setTransform(464.25,274.3002);

	this.shape_1188 = new cjs.Shape();
	this.shape_1188.graphics.f("#FFFFFF").s().p("ADRDSQgcgQgXgYQhGhFABhkQAAhiBHhGQBHhGBjAAQBkAABDBFQBGBHAABiIAAAEQgCBhhEBFQhGBGhkAAQhCAAg0gfgAlIDvQhjgBhGhHQhGhFAAhkQAAhjBHhGQBIhFBjAAQBkABBFBGQBGBHAABiQgBBkhHBFQhGBGhjAAIgBAAg");
	this.shape_1188.setTransform(496.9998,274.4);

	this.shape_1189 = new cjs.Shape();
	this.shape_1189.graphics.f("#232323").s().p("EAGfAkMQifgqicg6QhUgghXASQg0ANg1AGImEAsQkfAfkaAQIgRABQnBAZm6hVQi7gkimhgIgdgTQhTg4g3hRQgrhBgIhNIgHhFQgWlEBFk8QBFk2DXjiQAkgmAfgsQCDi2C4iDIDEiLQBZg9BLgxQGnkHH5hmQBpgdBqgVQCKgdCNgTQAwgIAugCQAPjHAojDIAFgXQBknPBlnAQA2jnB1jMQBMiECOAmQAzANAlAoQBKBSATBtQAhC6AyC1QA9DYCPCqQCmihDfBRIAjAMQAeAMAjAoQAVgtAOhGQBmjECDjIQBPhcBHhjQBjiICgAWQAtAGAfAjQBgBvgHCVQAAAVATBFIAAAGQAOFIgWF0QgHBZgXBWQBcBbAvB2IAIAWQAYA9AOBCQA1DxgLD2QgIDRhdC9QhVCtiYB1IgYAQQAxCbANChIAUD0QAUDggIEfQgPDBhYCoQgVAoggAdQgvArg1AjQguAgg0AUQgcALgeAJQjbAsjQhWIgNgHQhnBwiKBBQhMAjhUABIgIAAQlbAAlMhZgAYYo/QhGBGAABkQgBBjBFBGQAYAXAbARQA1AfBCAAQBjAABHhHQBEhEAChhIAAgEQAAhkhGhGQhDhFhkAAIgCAAQhiAAhHBFgAOIpCQhHBGAABjQAABlBFBFQBGBHBkABQBjAABHhGQBHhFAAhkQABhjhHhIQhFhFhkgBQhjAAhHBFg");
	this.shape_1189.setTransform(356.9187,315.1008);

	this.shape_1190 = new cjs.Shape();
	this.shape_1190.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQAABkhHBFQhHBHhigBQhkAAhGhIQhFhFAAhkQABhjBGhGQBHhFBjAAQBkABBFBGQBGBHgBBig");
	this.shape_1190.setTransform(464.2,274.1507);

	this.shape_1191 = new cjs.Shape();
	this.shape_1191.graphics.f("#FFFFFF").s().p("ADRDSQgcgPgYgZQhFhFABhkQABhiBGhGQBGhFBlAAQBkABBCBDQBHBHAABjIAAAEQgCBhhFBEQhGBGhkAAQhCAAg0gfgAlIDvQhjAAhHhIQhFhFABhkQAAhjBHhGQBGhFBkAAQBkABBFBGQBGBHAABiQgBBkhHBFQhGBGhhAAIgDAAg");
	this.shape_1191.setTransform(496.9498,274.275);

	this.shape_1192 = new cjs.Shape();
	this.shape_1192.graphics.f("#232323").s().p("EAGeAkNQifgqicg6QhUgghXASQg0AMg1AHQjCAWjCAUQkfAfkZAPIgRABQnCAYm5hUQi8glilhgIgdgTQhTg4g2hRQgshBgIhNIgGhFQgXlEBGk8QBFk2DXjiQAkgmAggsQCDi1C4iDIDEiLQBZg9BJgwQGnkHH8hlQBpgcBqgWQCLgeCMgTQAvgIAvgCQAOjIAnjCIAFgYQBjnOBhm/QA0jpB0jMQBMiECOAlQAzANAlAoQBKBRATBtQAjC5AzC1QA/DYCQCoQCliiDhBUIAjALQAdAMAlAsQAVgtANhKQBkjFCAjNQBPhdBGhjQBiiICgAVQAuAFAeAjQBhBvgFCVQgBAVAWBLIAAAGQAPFIgVF7QgHBZgXBWQBcBbAvB1IAIAXQAXA9APBCQA1DxgLD1QgIDShdC9QhVCtiYB1IgZAQQAzCaAMCiIAUD0QAcFAgQDHQgPDChZCoQgVAnggAdQguAqg2AkQguAgg0ATQgcAMgeAIQjbAsjQhXIgNgHQhnBwiLBBQhLAjhVAAQleAAlQhbgAYZpBQhGBGgBBjQgCBkBGBFQAYAZAbAPQA1AfBCAAQBkAABFhGQBFhEAChhIAAgEQAAhkhGhHQhDhDhkgBQhkAAhGBFgAOIpFQhGBGgBBjQAABlBFBFQBGBIBkAAQBjABBHhHQBHhFAAhkQABhjhGhHQhFhGhkgBQhkAAhHBFg");
	this.shape_1192.setTransform(356.8951,315.2712);

	this.shape_1193 = new cjs.Shape();
	this.shape_1193.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwABQgBBkhHBFQhGBHhjgBQhjgBhGhHQhGhGABhjQABhjBGhHQBHhEBiAAQBkABBFBGQBHBHgBBig");
	this.shape_1193.setTransform(464.1505,274.0507);

	this.shape_1194 = new cjs.Shape();
	this.shape_1194.graphics.f("#FFFFFF").s().p("ADQDSQgbgPgYgYQhFhHABhjQABhiBGhGQBIhFBjAAQBjABBDBEQBGBGAABjIAAAEQgCBhhFBEQhFBGhkAAQhCAAg1gfgAlIDvQhjgBhGhHQhGhGAAhjQAChjBGhHQBHhEBjAAQBkABBFBGQBHBHgBBiQgBBkhHBFQhGBGhhAAIgDAAg");
	this.shape_1194.setTransform(496.8998,274.175);

	this.shape_1195 = new cjs.Shape();
	this.shape_1195.graphics.f("#232323").s().p("EAGcAkPQifgqicg7QhUgghXASQgzAMg1AGQjCAWjDAUQkfAekYAOIgRABQnBAYm5hVQi8gkilhhIgegTQhSg4g3hRQgrhBgIhNIgGhFQgXlEBHk8QBFk2DXjiQAkgmAggsQCDi0C4iEIDFiLICfhrQGnkHIAhjQBogdBqgXQCKgdCNgUQAvgIAvgDQANjGAnjEIAFgXIC+uNQAzjoByjNQBLiGCOAlQAzANAmAnQBKBRAVBtQAjC4A1C1QBADYCRCnQClijDiBVIAjAMQAdALAmAwQAWguAKhNQBljFB8jSQBOheBGhjQBhiJCfATQAuAGAfAiQBiBvgECVQgCAUAaBTIAAAGQAQFHgUGBQgIBagXBVQBdBcAuB1IAJAWQAWA9APBDQA2DwgLD2QgJDRhdC+QhVCsiYB2IgYAQQAxCaANChIAUD0QAdFLgQDGQgRDBhYCoQgVAnggAdQgvAqg1AkQgvAfgzAUQgdALgeAJQjbArjPhXIgNgHQhoBwiLBAQhLAihVAAQleAAlQhcgAYYpEQhGBHgBBjQgBBjBFBGQAYAYAbAQQA1AfBCAAQBkAABGhGQBEhEAChhIABgFQAAhjhHhHQhChDhkgBIgCAAQhiAAhHBEgAOIpIQhGBGgBBkQgBBjBGBHQBGBHBjAAQBkABBGhGQBHhFABhkQABhjhHhIQhFhGhkgBQhjABhHBEg");
	this.shape_1195.setTransform(356.8716,315.4332);

	this.shape_1196 = new cjs.Shape();
	this.shape_1196.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhGBGhjgBQhjAAhGhIQhGhFABhkQABhjBGhGQBHhFBjAAQBkABBFBGQBGBIgBBig");
	this.shape_1196.setTransform(464.1005,273.9007);

	this.shape_1197 = new cjs.Shape();
	this.shape_1197.graphics.f("#FFFFFF").s().p("AFHDyQhCgBg1gfQgbgPgYgYQhFhFABhkQABhjBHhGQBGhFBkAAQBkACBCBDQBHBGgBBjIAAAEQgCBihEBEQhFBGhjAAIgCAAgAlIDuQhjAAhGhHQhGhGABhjQABhjBGhGQBHhGBkAAQBkACBFBGQBGBHgBBjQgBBjhHBGQhFBFhiAAIgDgBg");
	this.shape_1197.setTransform(496.825,274.0502);

	this.shape_1198 = new cjs.Shape();
	this.shape_1198.graphics.f("#232323").s().p("EARJAluQlegBlQhdQifgqicg7QhUgghXARQgzAMg1AGQjDAWjCASQkfAekXAOIgRABQnCAYm5hWQi7glilhgIgegTQhSg4g3hSQgrhBgIhNIgGhFQgVlEBGk8QBFk2DYjhQAkgmAfgsQCEi1C4iDIDFiKICdhrQGnkHIDhhQBogdBqgXQCKgeCMgVQAwgHAvgDQANjIAmjCIAEgYQBgnPBZm9QAxjoBxjOQBKiGCOAjQA0AMAlAoQBLBQAWBtQAlC4A2C1QBADWCTCnQCjilDkBYIAjALQAeAMAnAzQAVguAKhQQBkjGB4jXQBOheBFhkQBfiKChATQAtAFAfAiQBjBtgDCWQgBAKAOAsQAKAkAEAUIABAGQAUGXgXE4QgIBYgXBXQBdBbAuB1IAJAXQAWA9APBCQA1DxgLD1QgIDShdC9QhVCsiYB2IgZAQQAzCaAMChIATD0QAfFTgRDHQgRDBhZCnQgVAoggAdQguAqg2AjQgvAggzATQgdALgeAJQjbArjPhYIgNgHQhoBviLBAQhLAihTAAIgCAAgAYZpGQhHBGgBBjQgBBkBFBFQAYAYAbAQQA1AfBCAAQBkAABGhGQBEhEAChhIAAgFQABhjhHhHQhChDhkgBIgBAAQhjAAhGBFgAOIpLQhGBGgBBjQgBBlBGBFQBGBIBjAAQBkABBGhGQBHhFABhkQABhjhGhIQhFhGhkgBQhkAAhHBFg");
	this.shape_1198.setTransform(356.8202,315.6369);

	this.shape_1199 = new cjs.Shape();
	this.shape_1199.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhGBGhjgBQhjgBhGhHQhGhGABhjQABhjBGhHQBIhFBiABQBkABBFBGQBGBIgBBig");
	this.shape_1199.setTransform(464.0505,273.8005);

	this.shape_1200 = new cjs.Shape();
	this.shape_1200.graphics.f("#FFFFFF").s().p("ADQDTQgbgRgYgXQhFhGABhjQABhjBHhGQBHhFBjABQBkABBCBDQBGBGAABjIAAAEQgCBhhFBEQhFBHhkAAQhCgBg1gegAlIDuQhjAAhGhIQhGhFABhkQABhjBGhGQBIhFBjAAQBkABBFBHQBGBHgBBiQgBBkhHBFQhFBFhiAAIgDAAg");
	this.shape_1200.setTransform(496.7748,273.9748);

	this.shape_1201 = new cjs.Shape();
	this.shape_1201.graphics.f("#232323").s().p("EARHAlxQlegClPhdQifgsicg7QhUghhXASQgzAMg1AGQjDAVjCASQkfAekWANIgSABQnBAXm5hWQi7glilhhIgegTQhSg4g3hSQgrhAgHhOIgHhFQgVlEBHk8QBGk1DXjhQAkgmAggsQCEi1C4iDIDFiKICbhqQGmkIIHheQBogeBqgXQCKgeCMgVQAvgIAvgDQAMjHAmjDIAFgYQBenPBVm8QAwjpBvjOQBJiGCPAiQAzAMAmAnQBMBPAVBtQAnC4A3C1QBDDWCTClQCiilDmBZIAjALQAdALApA3QAVgtAIhVQBkjGB1jcQBMhfBEhkQBgiKCgARQAtAFAgAiQBjBsgCCWQgBAKAQAwQALAnAEAUIABAGQAWGbgXE6QgIBZgXBWQBdBbAuB2IAJAWQAWA9APBCQA1DwgLD3QgJDRhcC9QhWCtiXB1IgZAQQAyCaAMCiIAUD0QAfFcgRDGQgRDBhZCnQgVAnghAdQguAqg2AkQgvAfg0ATQgcAMgeAHQjbArjPhYIgNgIQhoBwiLBAQhMAhhTAAIgCAAgAYZpJQhHBGgBBjQgBBkBFBFQAYAYAbAQQA1AfBCAAQBkAABFhGQBFhEAChhIAAgFQAAhjhGhHQhChDhkgBIgBAAQhiAAhHBFgAOIpPQhGBHgBBjQgBBkBGBGQBGBHBjABQBkABBGhGQBHhFABhkQABhjhGhIQhFhGhkgBIgCAAQhiAAhHBEg");
	this.shape_1201.setTransform(356.7965,315.8313);

	this.shape_1202 = new cjs.Shape();
	this.shape_1202.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhGBGhjgBQhkgBhFhHQhGhHABhjQABhjBHhGQBGhFBjABQBkABBFBGQBGBIgBBig");
	this.shape_1202.setTransform(464.05,273.7005);

	this.shape_1203 = new cjs.Shape();
	this.shape_1203.graphics.f("#FFFFFF").s().p("ADQDTQgbgRgYgXQhGhGADhjQABhjBGhGQBHhFBkABQBkABBBBDQBGBGAABjIAAAEQgCBhhFBEQhFBHhkAAQhCgBg1gegAlIDuQhkAAhFhIQhGhGABhjQABhjBHhGQBGhFBkAAQBkABBFBHQBGBHgBBiQgBBkhHBFQhGBFhiAAIgCAAg");
	this.shape_1203.setTransform(496.7493,273.8748);

	this.shape_1204 = new cjs.Shape();
	this.shape_1204.graphics.f("#232323").s().p("EARFAl0QlegDlPheQifgsibg7QhTghhYARQg0AMg1AFQjDAVjCASQkfAdkVANIgRABQnBAWm5hWQi8glilhhIgdgTQhTg4g2hSQgrhBgIhNIgGhFQgVlEBHk8QBGk2DYjhQAkglAggsQCEi1C4iDIDFiKQBag7A/guQGnkIIJhcQBpgeBpgYQCKgeCMgWQAwgIAugDQAMjHAljDIAFgYQBcnPBRm7QAvjpBtjPQBIiHCPAhQA0AMAmAnQBMBPAXBsQAnC5A5CzQBDDWCWCkQCgimDoBaIAjAMQAeALApA6QAWgtAGhYIDUmoQBMhfBEhlQBeiLCgARQAtAEAgAiQBlBsgCCVQAAAKARA0QAMApAFAVIAAAGQAZGsgYEvQgHBZgXBWQBcBbAuB2IAJAWQAXA9APBCQA0DxgKD2QgJDShdC8QhVCtiYB1IgZAQQAyCbANChIATD0QAgFsgRC/QgRDBhaCnQgWAnggAdQgvAqg2AjQguAfg0ATQgdAMgeAHQjbAqjPhYIgNgIQhoBviLBAQhMAhhSAAIgDAAgAYZpMQhHBGgBBjQgCBkBFBFQAYAYAbAQQA1AfBCAAQBkAABGhGQBFhEAChhIAAgEQAAhkhGhHQhChChkgCIgBAAQhjAAhGBFgAOIpSQhGBGgBBjQgBBkBFBHQBGBHBjABQBkABBHhGQBGhFAChkQABhjhGhIQhFhGhkgBIgCAAQhjAAhGBEg");
	this.shape_1204.setTransform(356.7728,316.0174);

	this.shape_1205 = new cjs.Shape();
	this.shape_1205.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhGBGhjgBQhkgBhGhHQhFhHABhiQABhkBHhGQBHhFBiABQBkABBFBHQBGBHgBBig");
	this.shape_1205.setTransform(464,273.5514);

	this.shape_1206 = new cjs.Shape();
	this.shape_1206.graphics.f("#FFFFFF").s().p("ADQDTQgbgQgYgYQhGhFADhkQABhiBGhGQBIhFBjAAQBkACBBBDQBGBGAABjIAAAEQgDBhhEBEQhFBGhkAAQhCAAg1gfgAlIDuQhkAAhGhIQhFhGABhjQABhjBHhGQBHhFBjAAQBkACBFBGQBGBIgBBhQgBBlhHBEQhFBFhhAAIgEAAg");
	this.shape_1206.setTransform(496.6993,273.7498);

	this.shape_1207 = new cjs.Shape();
	this.shape_1207.graphics.f("#232323").s().p("EAREAl3QlfgElOhfQifgsibg8QhTghhYARQg0AMg1AFQjDAVjCARQkfAckUANIgSABQnBAWm5hXQi7gmilhhIgdgTQhTg4g2hSQgrhBgHhNIgGhFQgVlEBHk8QBGk1DZjhQAlgmAfgsQCEi0C4iDIDFiJICXhoQGmkIINhbQBpgfBpgXQCKggCMgVQAvgIAvgEQALjGAkjEIAFgYQBbnPBNm6QAtjpBsjQQBHiHCPAgQA0ALAmAnQBOBOAXBtQAoC4A6CzQBGDVCVCkQCfioDqBcIAjAMQAeAKArA+QAWgtAEhcQBijGBujnQBLhfBDhmQBdiLChAPQAuAEAgAiQBkBrAACWQAAAKASA2QAOAsAFAWIABAGQAaGzgYEuQgHBagXBVQBcBcAuB1IAJAWQAXA9APBDQA0DwgLD2QgIDRhdC9QhWCuiYB0IgYAQQAyCbAMChIAUD0QAgF2gRC+QgSDBhaCmQgVAnghAdQgvAqg2AjQguAfg0ATQgdAMgeAHQjbAqjPhZIgNgIQhpBviLA/QhKAhhSAAIgEAAgAYZpPQhHBGgBBjQgCBkBFBFQAYAYAbAQQA1AfBCAAQBkAABGhGQBEhEADhhIAAgEQAAhkhHhGQhBhDhkgBIgBAAQhiAAhHBEgAOIpVQhGBGgBBjQgBBkBFBGQBGBIBjAAQBlACBFhGQBHhFAChkQABhjhGhIQhFhGhkgCIgCAAQhiAAhHBFg");
	this.shape_1207.setTransform(356.7319,316.2198);

	this.shape_1208 = new cjs.Shape();
	this.shape_1208.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhHBGhigBQhkgBhGhIQhFhFABhkQABhjBHhGQBHhEBjAAQBkABBEBGQBGBIgBBig");
	this.shape_1208.setTransform(463.95,273.4516);

	this.shape_1209 = new cjs.Shape();
	this.shape_1209.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgQgXgYQhGhGADhiQABhjBGhGQBIhFBjABQBkABBBBDQBGBGAABjIAAAEQgCBhhFBEQhGBGhiAAIgCAAgAlIDuQhkgBhGhHQhFhGABhjQABhkBHhGQBHhEBkAAQBkABBEBGQBGBJgBBhQgBBkhHBFQhFBFhhAAIgEAAg");
	this.shape_1209.setTransform(496.6245,273.6502);

	this.shape_1210 = new cjs.Shape();
	this.shape_1210.graphics.f("#232323").s().p("EARCAl6QlegFlPhfQifgtiag8QhTghhYAQQg1AMg0AFQjDAUjCARQkfAbkTAMIgSABQnBAWm5hXQi7gmilhhIgdgTQhSg4g3hSQgqhBgIhOIgGhFQgUlEBHk7QBHk2DYjgQAlgmAfgsQCFi0C4iCIDFiKQBag8A7grQGmkIIQhZQBpgfBpgYQCKggCMgWQAugIAwgEQAKjGAkjEIAEgYQBanPBJm4QArjqBrjRQBGiICQAgQA0AKAmAnQBNBOAYBsQAqC4A7CzQBHDUCXCjQCeipDrBeIAkALQAdAMAtBBQAVguADhfQBijIBqjrQBLhgBChlQBciNChAPQAuAEAgAhQBlBqABCWQAAAKAUA6QAPAuAFAXIABAGQAKCjAEDQQACDFgMCvQgHBagXBVQBcBcAuB1IAJAXQAXA9AOBCQA1DxgLD1QgJDShdC9QhUCsiZB2IgYAQQAxCaANChIATD0QAiGBgSC8QgSDBhbCmQgVAnghAdQguAqg3AiQguAfg0ATQgdAMgeAHQjcApjOhaIgNgHQhpBviLA+QhLAhhSAAIgEAAgAYZpSQhHBGgBBkQgCBjBFBFQAYAYAbAQQA1AfBCAAQBjABBHhHQBEhEAChhIAAgEQABhkhHhGQhAhDhkgBIgDAAQhiAAhGBEgAOIpZQhGBGgBBkQgBBkBFBGQBGBIBjAAQBkACBGhHQBHhEAChkQABhjhGhIQhFhGhkgCQhjAAhIBEg");
	this.shape_1210.setTransform(356.6939,316.4293);

	this.shape_1211 = new cjs.Shape();
	this.shape_1211.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhIBEQhGBGhjgBQhjgBhGhHQhFhHABhjQABhjBHhGQBHhFBiABQBkABBFBHQBGBIgBBig");
	this.shape_1211.setTransform(463.9009,273.3014);

	this.shape_1212 = new cjs.Shape();
	this.shape_1212.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgPgYgZQhFhFADhjQABhjBHhGQBHhFBjABQBkACBBBCQBGBGAABjIAAAEQgCBhhFBEQhFBGhjAAIgCAAgAlIDuQhkgBhGhHQhFhHABhjQAChjBGhGQBIhFBjABQBkABBFBHQBGBIgCBiQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1212.setTransform(496.5745,273.525);

	this.shape_1213 = new cjs.Shape();
	this.shape_1213.graphics.f("#232323").s().p("EARAAl9QlegFlOhhQifgtibg9QhUghhXAQQg0AMg0AFQjDATjDARQkfAbkSALIgRABQnCAVm4hXQi8gmikhhIgegUQhRg4g3hSQgrhBgHhNIgGhFQgUlEBIk8QBGk1DZjhQAlglAfgsQCFi0C5iCIDFiKQBag7A4grQGmkIIUhYQBogeBpgZQCKggCMgWQAugJAwgDQAKjIAjjDIAEgXQBZnQBEm3QAqjqBpjSQBGiICPAeQA0ALAnAmQBOBNAZBsQArC4A8CyQBIDVCYChQCeiqDsBgIAkALQAdALAuBFQAWguABhjQBhjHBnjwQBJhhBChmQBbiNChANQAtAEAhAhQBmBqACCVQAAALAVA9QARAxAGAXIAAAGQALCjAEDUQADDHgLCwQgIBZgXBWQBdBbAuB1IAIAXQAXA9APBCQA0DwgKD3QgJDRhdC9QhWCtiYB1IgYAQQAyCaAMChIATD0QAKBwAJCzQAHChgJCBQgTDChbCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgdAMgeAHQjbAojPhaIgMgHQhqBuiLA/QhLAghRAAIgFAAgAYZpVQhHBGgBBkQgDBjBFBFQAYAZAbAPQA1AfBCAAQBkABBGhHQBFhEAChhIAAgEQAAhkhGhGQhBhChkgCIgDAAQhhAAhGBEgAOIpcQhGBGgCBjQgBBkBFBHQBGBHBkABQBjABBHhGQBIhEAAhkQAChjhGhIQhFhHhkgBIgCAAQhiAAhHBEg");
	this.shape_1213.setTransform(356.6786,316.6046);

	this.shape_1214 = new cjs.Shape();
	this.shape_1214.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgPgYgZQhFhFADhjQABhjBHhGQBHhEBjAAQBkACBBBCQBGBGAABjIAAAEQgCBhhFBEQhFBGhjAAIgCAAgAlIDuQhkgBhGhHQhFhHABhjQAChjBGhGQBIhFBjABQBkABBFBHQBGBIgCBiQAABkhIBEQhGBFhhAAIgDAAg");
	this.shape_1214.setTransform(496.5745,273.525);

	this.shape_1215 = new cjs.Shape();
	this.shape_1215.graphics.f("#232323").s().p("EARAAl9QlegFlOhhQifgtibg9QhUghhXAQQg0AMg0AFQjDATjDARQkfAbkSALIgRABQnCAVm4hXQi8gmikhhIgegUQhRg4g3hSQgrhBgHhNIgGhFQgUlEBIk8QBGk1DZjhQAlglAfgsQCFi0C5iCIDFiKQBag7A4grQGmkIIVhWQBogeBpgZQCKggCMgXQAvgIAvgEQAJjIAjjDIAFgYQBYnQBCm2QAqjqBojSQBFiJCQAeQA0ALAmAmQBOBNAaBsQArC3A9CzQBJDTCZCiQCciqDuBgIAjALQAeALAuBGQAWguAAhkQBhjIBljyQBKhgBBhnQBbiNChANQAtADAhAhQBnBpACCWQgBAKAXA/QAQAxAHAYIAAAGQAfHKgXEnQgHBZgYBWQBdBbAuB1IAIAXQAYA9AOBCQA0DxgKD2QgJDRhdC9QhWCtiYB1IgYAQQAyCaAMChIATD1QAKBwAJCyQAHChgJCBQgTDChbCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgdAMgeAHQjbAojPhaIgMgHQhqBuiLA/QhLAghRAAIgFAAgAYZpVQhHBGgBBkQgDBjBFBFQAYAZAcAPQA0AfBCAAQBkABBGhHQBFhEAChhIAAgEQAAhkhGhGQhBhChkgCQhjAAhHBEgAOIpcQhGBGgCBjQgBBkBFBHQBGBHBkABQBjABBHhGQBIhEAAhkQAChjhGhIQhFhHhkgBIgCAAQhiAAhHBEg");
	this.shape_1215.setTransform(356.6786,316.6062);

	this.shape_1216 = new cjs.Shape();
	this.shape_1216.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhIBFQhGBGhjgBQhjgChGhHQhEhGAAhjQABhjBHhGQBHhFBjABQBjABBFBGQBGBIgBBig");
	this.shape_1216.setTransform(463.9016,273.3508);

	this.shape_1217 = new cjs.Shape();
	this.shape_1217.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgPgYgYQhFhHADhiQABhjBHhFQBHhFBkAAQBjACBBBCQBGBGAABjIAAAFQgCBhhFBDQhGBGhiAAIgCAAgAlIDuQhkgBhGhHQhEhHAAhjQAChjBGhGQBIhFBjABQBjABBGBHQBGBIgCBiQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1217.setTransform(496.5752,273.5495);

	this.shape_1218 = new cjs.Shape();
	this.shape_1218.graphics.f("#232323").s().p("EARAAl9QlegFlOhhQifgtibg9QhUghhXAQQg0AMg0AFQjDATjDARQkfAbkSALIgRABQnCAVm4hXQi8gmikhiIgegTQhRg4g3hSQgrhBgHhNIgGhFQgUlEBIk8QBGk1DZjhQAlglAfgsQCFi0C5iCIDFiKQBag7A4grQGmkIIXhUQBngfBqgZQCJggCMgXQAvgJAvgEQAJjGAjjEIAEgYQBXnQBBm2QApjqBojSQBEiJCQAeQA0AKAnAmQBOBMAaBtQArC3A+CyQBKDUCZCgQCciqDuBhIAkALQAdAKAvBIQAWguAAhmQAwhjAoiAQAsh3BAhhQBJhhBBhnQBaiNChAMQAuAEAgAgQBnBpADCWQAAAKAXBAQARAzAGAYIABAGQAgHNgXEmQgHBZgYBWQBdBbAuB2IAIAWQAYA9AOBCQA0DxgKD2QgJDShdC8QhWCtiYB1IgYAQQAyCaAMCiIATD0QAKBwAJCyQAHChgJCBQgTDChbCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgdAMgeAHQjbAojPhaIgMgHQhqBuiLA/QhLAghRAAIgFAAgAYZpUQhHBFgBBkQgDBiBFBHQAYAYAcAPQA0AfBCAAQBkABBGhHQBFhDAChhIAAgFQAAhkhGhGQhBhChjgCIgCAAQhiAAhHBFgAOIpcQhGBGgCBjQAABkBEBHQBGBHBkABQBjACBHhHQBIhEAAhkQAChjhGhIQhGhHhjgBIgDAAQhhAAhHBEg");
	this.shape_1218.setTransform(356.6786,316.6393);

	this.shape_1219 = new cjs.Shape();
	this.shape_1219.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhIBFQhGBGhjgBQhjgBhGhIQhEhGAAhjQABhjBHhGQBHhFBjABQBkABBEBHQBGBHgBBig");
	this.shape_1219.setTransform(463.9016,273.3509);

	this.shape_1220 = new cjs.Shape();
	this.shape_1220.graphics.f("#FFFFFF").s().p("ADQDTQgcgQgXgYQhGhGADhjQABhiBHhGQBHhFBkABQBjABBBBCQBGBIAABiIAAAEQgCBhhFBEQhGBGhkAAQhCAAg0gfgAlIDuQhkgBhGhIQhEhGAAhjQAChjBGhGQBIhFBjABQBkABBFBHQBGBHgCBiQAABkhIBFQhFBFhhAAIgEAAg");
	this.shape_1220.setTransform(496.5752,273.5743);

	this.shape_1221 = new cjs.Shape();
	this.shape_1221.graphics.f("#232323").s().p("EARAAl9QlegFlOhhQifgtibg9QhUghhXAQQg0AMg0AFQjDATjDARQkfAbkSALIgRABQnCAVm4hXQi8gmikhiIgegTQhRg4g3hSQgrhBgHhNIgGhFQgUlEBIk8QBGk1DZjhQAlglAggsQCEi0C5iCIDFiKQBag7A4grQGmkIIYhSQBnggBqgYQCJghCMgXQAvgJAvgEQAJjGAijEIAEgYQBXnQA/m1QAojrBnjTQBFiICPAdQA0AKAnAmQBPBMAaBsQAsC3A+CyQBLDUCZCgQCcirDvBhIAjALQAeALAvBJQAVgtAAhoQAwhkAniAQAsh4A/hiQBJhhBBhnQBaiOChAMQAuADAgAhQBnBpADCWQAAAKAYBBQASA0AGAYIABAGQALCjAGDYQAEDKgLCxQgHBZgYBWQBdBbAuB2IAJAWQAWA9APBCQA0DxgKD2QgJDShdC8QhWCtiYB1IgYAQQAyCaAMCiIATD0QAKBwAJCyQAHChgJCBQgTDChbCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgdAMgeAHQjbAojPhaIgMgHQhqBuiLA/QhLAghRAAIgFAAgAYZpUQhHBFgBBkQgDBiBGBHQAXAYAcAPQA0AfBCABQBkAABGhHQBFhDAChhIAAgFQAAhjhGhHQhBhChjgBIgDAAQhiAAhGBEgAOIpcQhGBGgCBjQAABkBEBHQBGBIBkAAQBjACBHhGQBIhFAAhkQAChjhGhIQhFhGhkgCIgDAAQhhAAhHBEg");
	this.shape_1221.setTransform(356.6786,316.6474);

	this.shape_1222 = new cjs.Shape();
	this.shape_1222.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhHBGhjgBQhjgBhGhIQhFhGABhjQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBig");
	this.shape_1222.setTransform(463.9014,273.3516);

	this.shape_1223 = new cjs.Shape();
	this.shape_1223.graphics.f("#FFFFFF").s().p("ADQDTQgcgQgYgYQhFhFADhkQABhiBHhGQBHhFBkABQBjABBBBDQBGBGAABjIAAAEQgCBhhFBEQhHBGhjAAQhCAAg0gfgAlJDuQhjgBhFhIQhGhGABhjQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBiQAABkhIBFQhFBFhhAAIgFAAg");
	this.shape_1223.setTransform(496.5998,273.575);

	this.shape_1224 = new cjs.Shape();
	this.shape_1224.graphics.f("#232323").s().p("EARAAl8QlegGlOhgQifgtibg8QhUgihXARQg0AMg0AFQjDATjDARQkfAakSAMIgSABQnBAVm4hYQi8gmikhhIgegTQhRg4g3hSQgrhBgHhOIgGhFQgUlEBIk7QBGk2DZjgQAlgmAggsQCEi0C5iCIDFiJQBag8A5gqQGlkJIZhQQBogfBpgZQCJghCMgXQAvgJAvgEQAJjHAijEIAEgXQBVnRA+m1QAnjqBnjTQBDiJCRAdQA0AKAnAlQBPBMAaBsQAtC3A+CyQBLDTCaCgQCbirDwBiIAjALQAeAKAwBKQAVgtgBhpQAwhkAniBQArh4A/hjQBJhhBAhnQBZiPChAMQAuAEAhAgQBnBoAECWQAAAKAYBDQASA0AHAZIAAAGQAMCjAGDZQAFDLgLCxQgHBagYBVQBdBcAuB1IAJAXQAWA9APBCQA1DxgLD1QgJDShdC9QhWCsiYB2IgYAQQAyCaAMChIATD0QAKBwAJCyQAHCigJCBQgTDBhbCmQgVAnghAdQgvAqg2AiQgvAfg0ATIg7ATQjbAojPhaIgMgIQhqBviLA+QhLAghRAAIgFAAgAYZpVQhHBGgBBjQgDBkBGBFQAXAYAcAQQA0AfBCAAQBkAABGhGQBFhEAChhIAAgEQAAhkhGhGQhAhDhkgBIgDAAQhiAAhGBEgAOIpcQhGBGgCBjQAABkBFBGQBFBIBkABQBkABBGhGQBIhFAAhkQAChjhGhHQhFhHhkgBQhjAAhIBEg");
	this.shape_1224.setTransform(356.6863,316.6803);

	this.shape_1225 = new cjs.Shape();
	this.shape_1225.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBlhHBEQhHBGhjgBQhjgBhGhIQhFhGABhjQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBig");
	this.shape_1225.setTransform(463.9014,273.3516);

	this.shape_1226 = new cjs.Shape();
	this.shape_1226.graphics.f("#FFFFFF").s().p("ADQDTQgbgQgZgYQhFhFADhkQABhiBHhGQBHhFBkABQBjABBBBDQBGBGAABjIAAAEQgDBhhEBEQhHBGhjAAQhCAAg0gfgAlJDuQhjgBhFhIQhGhGABhjQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBiQAABlhIBEQhFBFhhAAIgFAAg");
	this.shape_1226.setTransform(496.5998,273.575);

	this.shape_1227 = new cjs.Shape();
	this.shape_1227.graphics.f("#232323").s().p("EARAAl8QlegGlOhgQifgtibg8QhUgihXARQg0AMg0AFQjDATjDARQkfAakSAMIgSABQnBAVm4hYQi8gmikhhIgegTQhRg4g3hSQgrhBgHhOIgGhFQgUlEBIk7QBGk2DZjgQAlgmAggsQCEi0C5iCIDFiJQBag8A5gqQDTiFD/hFQD4hOD1g/QBoggBpgZQCKghCLgXQAvgJAvgEQAIjHAijEIAEgYQBVnQA8m0QAnjrBmjTQBDiJCQAcQA0AKAnAlQBPBMAbBsQAuC3A+CxQBMDUCbCfQCaisDxBiIAjALQAeALAwBLQAVgtgBhqQAvhkAmiCQArh6A+hiQBIhiBBhnQBZiPChALQAuADAgAhQBoBoAECWQAAAKAZBEQATA1AHAZIAAAHQAjHagWEhQgHBYgYBWQBdBcAuB1IAJAXQAWA9APBCQA1DxgLD2QgJDRhdC9QhWCsiXB2IgZAQQAyCaAMChIAUD0QAiGIgSC9QgTDBhbCmQgVAnghAdQgvAqg2AiQgvAfg0ATIg7ATQjbAojPhaIgMgIQhqBviLA+QhLAghRAAIgFAAgAYZpVQhHBGgBBjQgDBkBGBFQAYAYAbAQQA0AfBCAAQBkAABGhGQBEhEADhhIAAgEQAAhkhGhGQhAhDhkgBIgDAAQhiAAhGBEgAOIpcQhGBGgCBjQAABkBFBGQBFBIBkABQBkABBGhGQBIhEAAhlQAChjhGhHQhFhHhkgBQhjAAhIBEg");
	this.shape_1227.setTransform(356.6863,316.6889);

	this.shape_1228 = new cjs.Shape();
	this.shape_1228.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBlhHBEQhHBGhjgBQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBig");
	this.shape_1228.setTransform(463.9259,273.3516);

	this.shape_1229 = new cjs.Shape();
	this.shape_1229.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhFAChkQAChiBGhGQBIhFBjABQBkABBBBDQBGBGAABjIAAAEQgDBhhEBEQhHBGhjAAQhCAAg1gfgAlJDuQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBkAAQBkABBEBHQBGBHgBBiQgBBlhHBEQhFBFhiAAIgEAAg");
	this.shape_1229.setTransform(496.6243,273.575);

	this.shape_1230 = new cjs.Shape();
	this.shape_1230.graphics.f("#232323").s().p("EARAAl8QlegGlOhgQifgtibg9QhUghhXAQQg0AMg0AFQjDATjDARQkfAbkSALIgSABQnBAVm4hXQi8gmikhiIgegTQhRg4g3hSQgrhBgHhNIgGhFQgUlEBIk8QBGk1DZjhQAlglAggsQCEi0C5iCIDFiKQBag7A5grQDTiEEAhFQD4hMD2hAQBnggBpgZQCKghCLgYQAvgJAvgEQAIjHAhjDIAFgYQBUnRA6m0QAmjqBljUQBDiJCQAcQA0AJAoAmQBPBMAbBrQAuC3A/CxQBNDTCbCfQCaitDxBkIAjALQAeAKAxBNQALgXgBg2QABguAIgeQAwhkAliDQAqh6A+hjQBIhiBAhoQBYiOChAKQAtADAiAgQBoBpAECVQAAAKAaBFQATA3AIAZIAAAGQAkHigWEcQgHBZgXBWQBbBcAvB1IAJAWQAWA9APBCQA1DxgLD2QgJDRhdC9QhWCtiXB1IgZAQQAyCaAMCiIAUD0QAiGIgSC8QgTDBhbCnQgVAnghAcQgvAqg2AjQgvAfg0ASIg7ATQjbAojPhaIgMgHQhqBuiLA/QhLAghRAAIgFAAgAYZpVQhHBGgBBjQgDBjBGBGQAYAXAbARQA0AfBCAAQBkAABGhGQBEhEADhhIAAgFQAAhjhGhHQhAhChkgBIgDAAQhiAAhGBEgAOIpdQhGBGgBBkQgBBkBFBGQBFBIBkAAQBkACBGhGQBIhFAAhkQAChjhGhIQhFhGhkgCQhjAAhIBEg");
	this.shape_1230.setTransform(356.6863,316.7216);

	this.shape_1231 = new cjs.Shape();
	this.shape_1231.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhHBEQhHBGhjgBQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBjg");
	this.shape_1231.setTransform(463.95,273.3516);

	this.shape_1232 = new cjs.Shape();
	this.shape_1232.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhjQABhjBGhGQBIhFBjABQBkABBBBDQBGBGAABjIAAAEQgDBhhEBEQhFBGhkAAIgBAAgAlJDuQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBkAAQBkABBEBHQBGBHgBBjQgBBkhHBEQhFBFhiAAIgEAAg");
	this.shape_1232.setTransform(496.6243,273.5752);

	this.shape_1233 = new cjs.Shape();
	this.shape_1233.graphics.f("#232323").s().p("EARAAl8QlegGlOhgQifgtibg9QhUghhXAQQg0AMg0AFQjDATjDARQkfAbkSALIgSABQnBAVm4hXQi8gmikhiIgegTQhRg4g3hSQgrhBgHhNIgGhFQgUlFBIk7QBGk1DZjhQAlglAggsQCEi0C5iCIDFiKQBag7A5grQDTiEEBhDQD4hND2g/QBnggBpgZQCKgiCLgYQAvgJAvgEQAHjHAijEIAEgXQBUnRA4mzQAljrBljUQBDiJCQAbQA0AKAnAkQBQBMAbBsQAuC3BBCxQBMDSCcCfQCaitDxBkIAkAKQAeALAxBOQALgXgCg3QACguAHgfQAwhkAkiEQAqh6A9hkQBIhiA/hoQBZiOCgAJQAuADAhAhQBpBnAFCWQAAAKAaBGQAUA4AHAaIABAGQAlHqgWEWQgHBagXBVQBbBcAvB1IAJAWQAWA9APBDQA1DwgLD2QgJDRhdC9QhWCtiXB1IgZAQQAyCbAMChIAUD0QAiGIgSC8QgTDBhbCnQgVAnghAcQgvAqg2AjQgvAfg0ASIg7ATQjbAojPhaIgMgHQhqBuiLA/QhLAghRAAIgFAAgAYZpVQhHBGgBBjQgDBjBGBGQAYAXAbARQA0AfBCAAQBlAABFhGQBEhEADhhIAAgFQAAhjhGhHQhAhChkgBIgDAAQhiAAhGBEgAOIpdQhGBGgBBkQgBBkBFBGQBFBIBkAAQBkACBGhGQBHhFAChkQABhjhGhIQhFhGhkgCQhjAAhIBEg");
	this.shape_1233.setTransform(356.6863,316.7292);

	this.shape_1234 = new cjs.Shape();
	this.shape_1234.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhHBEQhHBGhjgBQhjgBhGhIQhFhFABhkQABhjBHhGQBIhEBiAAQBkABBEBHQBGBHgBBjg");
	this.shape_1234.setTransform(463.95,273.3516);

	this.shape_1235 = new cjs.Shape();
	this.shape_1235.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhjQABhjBGhGQBIhFBjABQBkACBBBCQBGBGAABjIAAAEQgDBhhEBEQhFBGhjAAIgCAAgAlJDuQhjgBhGhIQhFhFABhkQABhjBHhGQBIhEBjAAQBkABBEBHQBGBHgBBjQgBBkhHBEQhFBFhiAAIgEAAg");
	this.shape_1235.setTransform(496.6243,273.5752);

	this.shape_1236 = new cjs.Shape();
	this.shape_1236.graphics.f("#232323").s().p("EARAAl7QlegGlOhgQifgtibg8QhUgihXARQg0ALg0AFQjDAUjDARQkfAakSAMIgSABQnBAVm4hYQi8gmikhhIgegTQhRg4g3hTQgrhAgHhOIgGhFQgUlEBIk8QBGk1DZjgQAlgmAggsQCEi0C5iCIDFiJQBag8A5grQDTiEEBhCQD5hLD2hAQBoggBpgZQCJgjCLgXQAvgJAvgFQAGjGAijEIAFgYQBSnRA3myQAkjsBljUQBBiJCRAbQA0AJAnAlQBRBMAbBrQAvC3BBCwQBNDTCcCeQCZitDzBkIAjALQAeAKAyBQQALgXgCg4QABgvAIgfQAvhkAjiEQAph8A9hkQBIhiA/hoQBYiQChAKQAuADAhAgQBpBoAFCVQAAAKAbBIQAVA5AHAaIABAGQAmHqgWEZQgHBZgXBWQBbBbAvB1IAJAXQAWA9APBCQA1DxgLD2QgJDRhdC9QhWCtiXB1IgZAQQAyCaAMChIAUD0QAiGJgSC8QgTDBhbCmQgVAnghAdQgvAqg2AiQgvAfg0ATIg7ATQjbAojPhaIgMgIQhqBviLA+QhLAghRAAIgFAAgAYZpWQhHBGgBBkQgDBjBGBFQAYAYAbAQQA1AfBCAAQBkABBFhHQBEhEADhhIAAgEQAAhkhGhGQhAhChkgCIgDAAQhiAAhGBEgAOIpdQhGBGgBBjQgBBlBFBFQBFBIBkABQBkABBGhGQBHhEAChkQABhkhGhHQhFhHhkgBQhjAAhIBEg");
	this.shape_1236.setTransform(356.6863,316.7617);

	this.shape_1237 = new cjs.Shape();
	this.shape_1237.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhHBEQhHBGhjgBQhjgBhGhIQhFhFABhkQABhjBHhGQBIhEBiAAQBkABBFBHQBFBHgBBjg");
	this.shape_1237.setTransform(463.9495,273.3516);

	this.shape_1238 = new cjs.Shape();
	this.shape_1238.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhjQABhjBHhGQBGhFBkABQBkACBBBCQBGBGAABjIAAAEQgDBhhEBEQhFBGhjAAIgCAAgAlJDuQhjgBhGhIQhFhFABhkQABhjBHhGQBIhEBjAAQBkABBFBHQBFBHgBBjQgBBkhHBEQhFBFhiAAIgEAAg");
	this.shape_1238.setTransform(496.6243,273.5752);

	this.shape_1239 = new cjs.Shape();
	this.shape_1239.graphics.f("#232323").s().p("EARAAl7QlegGlOhgQifgtibg8QhUgihXARQg0ALg0AFQjDAUjDARQkfAakSAMIgSABQnBAVm4hYQi8gmikhhIgegTQhRg4g3hTQgrhAgHhOIgGhFQgUlEBIk8QBGk1DZjgQAlgmAggsQCEi0C5iCIDFiJQBag8A5grQDTiEEChBQD6hLD2g/QBnggBpgaQCJgiCLgYQAwgJAugFQAGjGAijEIAEgYQBSnRA1myQAkjrBjjVQBCiKCQAbQA0AJAoAlQBQBMAcBrQAwC2BBCxQBODSCcCdQCZiuDzBmIAkAKQAPAGAaAnQAXAfAQAQQALgXgCg5QABgwAHgeQAvhkAjiGQAoh8A9hkQBHhjA/hoQBXiQChAKQAuACAhAgQBpBnAGCWQAAAKAcBJQAVA6AIAaIAAAGQAoHugWEYQgHBZgXBWQBbBbAvB2IAJAWQAWA9APBCQA1DxgLD2QgJDShdC8QhVCtiYB1IgZAQQAyCaAMChIAUD1QAiGIgSC8QgTDBhbCmQgVAnghAdQgvAqg2AiQgvAeg0AUQgdAKgeAIQjbApjPhaIgMgIQhqBviLA+QhLAghRAAIgFAAgAYZpWQhHBGgBBkQgDBjBGBFQAYAYAbAQQA1AfBCAAQBkABBFhHQBEhEADhhIAAgEQAAhkhGhGQhAhChkgCIgDAAQhiAAhGBEgAOJpdQhHBGgBBjQgBBlBFBFQBFBIBkABQBkABBGhGQBHhEAChkQAAhkhFhHQhFhHhkgBQhjAAhHBEg");
	this.shape_1239.setTransform(356.6863,316.763);

	this.shape_1240 = new cjs.Shape();
	this.shape_1240.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgCBkhHBEQhGBGhjgBQhkgBhFhHQhFhHABhjQABhjBHhGQBHhFBiABQBkABBFBHQBGBIgBBig");
	this.shape_1240.setTransform(463.9509,273.3514);

	this.shape_1241 = new cjs.Shape();
	this.shape_1241.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgPgYgZQhFhFADhjQABhjBHhGQBHhEBjAAQBkACBBBCQBGBGAABjIAAAFQgCBhhFBDQhFBGhjAAIgCAAgAlJDuQhjgBhGhHQhFhHABhjQABhjBHhGQBIhFBjABQBkABBFBHQBGBIgCBiQgBBkhHBEQhFBFhiAAIgEAAg");
	this.shape_1241.setTransform(496.6245,273.575);

	this.shape_1242 = new cjs.Shape();
	this.shape_1242.graphics.f("#232323").s().p("EARAAl7QlegGlOhgQifgtibg8QhUgihXARQg0ALg0AFQjDAUjDARQkfAakSAMIgSABQnBAVm4hYQi8gmikhhIgegTQhRg4g3hTQgrhAgHhOIgGhFQgUlEBIk8QBGk1DZjgQAlgmAggsQCEi0C5iCIDFiJQBag8A5grQDTiEEDhAQD6hKD2g/QBnghBpgaQCJghCMgZQAugKAvgEQAGjGAhjEIAEgYQBSnRAzmyQAjjrBjjVQBBiKCRAaQA0AJAnAlQBRBLAcBrQAwC3BCCwQBPDSCcCdQCZiuD0BlIAjALQAPAFAaAoQAYAgAQAQQALgXgDg5QABgxAHgeQAvhlAiiGQAoh9A8hlQBIhjA+hoQBXiQChAJQAuADAhAfQBqBnAGCWQAAAKAcBKQAWA7AHAbIABAGQApHxgWEXQgHBZgXBWQBbBbAvB2IAJAWQAWA9APBCQA1DxgLD2QgIDSheC8QhVCtiYB1IgZAQQAyCaAMCiIAUD0QAiGIgSC8QgTDBhbCmQgVAnghAdQgvAqg2AiQgvAeg0AUQgdAKgeAIQjbApjPhaIgNgIQhpBviLA+QhLAghRAAIgFAAgAYZpWQhHBGgBBkQgDBjBGBFQAYAZAbAPQA1AfBCAAQBkABBFhHQBFhDAChhIAAgFQABhkhHhGQhAhChkgCQhjAAhIBEgAOJpdQhHBGgBBjQgBBkBFBHQBFBHBkABQBkABBGhGQBHhEAChkQABhjhGhIQhFhHhkgBIgBAAQhiAAhHBEg");
	this.shape_1242.setTransform(356.6863,316.7954);

	this.shape_1243 = new cjs.Shape();
	this.shape_1243.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgCBkhHBFQhGBGhjgBQhjgChGhHQhFhGABhjQABhjBHhGQBHhFBiABQBkABBFBGQBGBIgBBig");
	this.shape_1243.setTransform(463.9509,273.4008);

	this.shape_1244 = new cjs.Shape();
	this.shape_1244.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhGADhjQABhiBHhGQBHhFBjABQBkABBBBCQBGBIAABiIAAAEQgCBhhFBEQhGBGhkAAQhCAAg1gfgAlJDuQhjgChGhHQhFhGABhjQABhjBHhGQBIhFBjABQBkABBFBGQBGBIgCBiQgBBkhHBFQhFBFhiAAIgEAAg");
	this.shape_1244.setTransform(496.6245,273.6243);

	this.shape_1245 = new cjs.Shape();
	this.shape_1245.graphics.f("#232323").s().p("EAQ/Al7QlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhFQgTlFBHk7QBHk1DZjhQAlglAfgsQCEi0C5iCIDGiKQBZg7A5grQDTiEEEg/QD7hKD2g/QBnggBpgbQCJgiCLgZQAvgJAvgEQAGjIAgjDIAEgYQBRnRAymxQAijrBijVQBBiLCQAaQA0AJAoAlQBRBKAcBsQAxC1BCCxQBQDSCdCcQCXiuD2BmIAjAKQAPAGAbAoQAXAgARAQQALgWgDg6QAAgxAHgfQAvhlAhiHQAnh9A8hmQBHhjA+hoQBXiQChAIQAuACAhAgQBqBmAGCWQABAKAdBMQAWA7AIAbIAAAGQAqH5gVESQgHBagYBVQBdBcAuB1IAIAXQAXA9APBCQA0DxgKD1QgJDSheC9QhUCsiZB2IgYAPQAxCbANChIATD0QAiGIgSC8QgSDBhbCnQgWAnggAcQgvAqg3AjQguAeg1ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA/QhKAghSAAIgFAAgAYZpWQhHBGgBBjQgDBjBFBGQAYAYAbAQQA1AfBCAAQBkAABGhGQBFhEAChhIAAgEQAAhjhGhIQhBhChkgBIgBAAQhiAAhHBEgAOIpdQhHBGgBBjQgBBkBFBGQBGBHBjACQBkABBHhGQBHhFABhkQAChjhGhIQhFhGhkgBIgDAAQhhAAhHBEg");
	this.shape_1245.setTransform(356.7036,316.8032);

	this.shape_1246 = new cjs.Shape();
	this.shape_1246.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhGADhjQABhiBHhGQBHhFBjABQBkABBBBDQBGBGAABjIAAAEQgCBhhFBEQhGBGhkAAQhCAAg1gfgAlIDuQhkgChGhHQhFhGABhjQAChjBGhGQBIhFBjABQBkABBFBGQBGBIgCBiQgBBkhHBFQhFBFhhAAIgEAAg");
	this.shape_1246.setTransform(496.6245,273.6243);

	this.shape_1247 = new cjs.Shape();
	this.shape_1247.graphics.f("#232323").s().p("EAQ/Al7QlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhFQgTlFBHk7QBHk1DZjhQAlglAfgsQCEi0C5iCIDGiKQBZg7A5grQDTiEEFg+QD7hJD2g/QBnghBpgaQCJgjCLgZQAvgJAvgFQAFjGAhjEIAEgYQBQnRAwmxQAhjrBijVQBAiLCRAZQA0AJAoAlQBRBKAcBrQAyC3BCCvQBRDSCdCcQCXiwD2BoIAjAKQAPAFAbApQAYAhARAQQALgWgEg7QAAgyAHgfQAvhkAhiIQAmh/A8hlQBGhjA+hpQBWiQChAHQAtADAiAfQBqBmAHCWQABAKAeBNQAWA9AIAbIABAGQArH8gVERQgHBagYBVQBdBcAuB1IAIAXQAYA9AOBCQA0DxgKD2QgJDRheC9QhUCsiZB2IgYAQQAxCaANChIATD0QAiGIgSC8QgSDBhbCmQgWAnggAdQgvAqg3AjQgvAeg0ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA/QhKAghSAAIgFAAgAYZpWQhHBGgBBjQgDBjBFBGQAYAYAbAQQA1AfBCAAQBkAABGhGQBFhEAChhIAAgEQAAhkhGhGQhBhDhkgBIgCAAQhiAAhGBEgAOIpdQhGBGgCBjQgBBkBFBGQBGBHBkACQBjABBHhGQBHhFABhkQAChjhGhIQhFhGhkgBIgDAAQhhAAhHBEg");
	this.shape_1247.setTransform(356.7036,316.8353);

	this.shape_1248 = new cjs.Shape();
	this.shape_1248.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhIBFQhGBGhjgBQhjgBhGhIQhFhGABhjQABhjBHhGQBHhFBiABQBkABBFBHQBGBHgBBig");
	this.shape_1248.setTransform(463.9509,273.4009);

	this.shape_1249 = new cjs.Shape();
	this.shape_1249.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhFADhkQABhiBHhGQBHhFBjABQBkABBBBDQBGBGAABjIAAAEQgCBhhFBEQhGBGhkAAQhCAAg1gfgAlIDuQhkgBhGhIQhFhGABhjQAChjBGhGQBIhFBjABQBkABBFBHQBGBHgCBiQAABkhIBFQhFBFhhAAIgEAAg");
	this.shape_1249.setTransform(496.6245,273.6243);

	this.shape_1250 = new cjs.Shape();
	this.shape_1250.graphics.f("#232323").s().p("EAQ/Al6QlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCARQkfAakSAMIgSABQnBAVm5hYQi7gmilhhIgdgTQhSg4g2hTQgshBgHhNIgGhFQgTlEBHk8QBIk1DYjgQAlgmAfgsQCEi0C5iCIDGiJQBZg8A5grQDTiEEFg9QD8hHD2hAQBoghBogaQCJgjCLgZQAvgKAvgEQAFjHAgjEIAEgYQBQnRAumwQAgjrBhjWQBAiKCRAYQA0AJAoAkQBRBLAdBrQAzC1BDCwQBQDSCeCbQCXiwD2BoIAkAKQAPAGAbApQAYAhARARQALgXgEg7QAAgyAHggQAuhkAgiJQAmh/A7hmQBGhjA+hpQBViRChAHQAuACAiAgQBqBmAICVQAAAKAfBPQAXA9AIAcIABAGQAsIDgVENQgHBZgYBWQBdBcAuB1IAIAWQAYA9AOBCQA0DxgKD2QgJDRheC9QhUCtiZB1IgYAQQAxCaANCiIATD0QAiGIgSC8QgSDBhcCmQgVAnggAdQgvApg3AjQgvAeg0ATQgcAMgeAHQjcApjOhaIgNgIQhpBviMA+QhJAghQAAIgIAAgAYZpWQhHBFgBBkQgDBjBFBGQAYAXAbARQA1AeBCABQBkAABGhGQBFhEAChhIAAgFQAAhjhGhHQhBhChkgBIgCAAQhiAAhGBEgAOIpeQhGBGgCBjQgBBkBFBHQBGBIBkAAQBjACBHhGQBIhFAAhkQAChjhGhIQhFhGhkgCIgDAAQhhAAhHBEg");
	this.shape_1250.setTransform(356.7036,316.8685);

	this.shape_1251 = new cjs.Shape();
	this.shape_1251.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhIBFQhGBGhjgBQhjgBhGhIQhFhGABhjQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBig");
	this.shape_1251.setTransform(463.9509,273.4016);

	this.shape_1252 = new cjs.Shape();
	this.shape_1252.graphics.f("#FFFFFF").s().p("ADQDTQgcgQgYgYQhFhFADhkQABhiBHhGQBHhFBkABQBjABBBBDQBGBGAABjIAAAEQgCBhhFBEQhGBGhkAAQhCAAg0gfgAlIDuQhkgBhGhIQhFhGABhjQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBiQAABkhIBFQhFBFhhAAIgEAAg");
	this.shape_1252.setTransform(496.6245,273.625);

	this.shape_1253 = new cjs.Shape();
	this.shape_1253.graphics.f("#232323").s().p("EAQ/Al6QlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCARQkfAakSAMIgSABQnBAVm5hYQi7gmilhhIgdgTQhSg4g2hTQgshBgHhNIgGhFQgTlEBHk8QBIk1DYjgQAlgmAfgsQCEi0C5iCIDGiJQBZg8A5grQDTiEEGg8QD9hHD2g/QBnghBogbQCKgjCKgZQAvgKAvgEQAFjHAgjEIAEgYQBPnRAsmvQAfjsBhjWQA/iLCRAYQA0AJApAkQBRBKAdBrQAzC2BECwQBRDQCfCcQCViwD4BoIAjAKQAPAFAcArQAYAhARARQALgXgEg8QgBgzAHgfQAuhkAgiLQAlh/A6hnQBGhjA9hpQBWiRChAHQAuABAhAgQBrBmAICVQAAAKAfBQQAYA+AJAcIAAAGQAuIHgVEMQgHBagYBVQBdBcAuB1IAJAWQAWA9APBDQA0DwgKD2QgJDRheC9QhUCtiZB1IgYAQQAxCaANCiIATD0QAiGIgSC8QgSDBhcCmQgVAnggAdQgvApg3AjQgvAfg0ASQgcAMgeAHQjcApjOhaIgNgIQhpBviMA+QhJAghQAAIgIAAgAYZpWQhHBFgBBkQgDBjBFBGQAYAXAcARQA0AfBCAAQBkAABGhGQBFhEAChhIAAgFQAAhjhGhHQhBhChjgBIgDAAQhiAAhGBEgAOIpeQhGBGgCBjQgBBkBFBHQBGBIBkAAQBjACBHhGQBIhFAAhkQAChjhGhIQhFhGhkgCQhjAAhIBEg");
	this.shape_1253.setTransform(356.7036,316.8759);

	this.shape_1254 = new cjs.Shape();
	this.shape_1254.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBlhIBEQhGBGhjgBQhjgBhGhIQhEhGAAhjQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBig");
	this.shape_1254.setTransform(463.9516,273.4016);

	this.shape_1255 = new cjs.Shape();
	this.shape_1255.graphics.f("#FFFFFF").s().p("ADQDTQgcgQgYgYQhFhFADhkQABhiBHhGQBHhFBkABQBjABBBBDQBGBGAABjIAAAEQgCBhhFBEQhGBGhkAAQhCAAg0gfgAlIDuQhkgBhGhIQhEhGAAhjQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBiQAABlhIBEQhFBFhhAAIgEAAg");
	this.shape_1255.setTransform(496.6252,273.625);

	this.shape_1256 = new cjs.Shape();
	this.shape_1256.graphics.f("#232323").s().p("EAQ/Al6QlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhFQgTlFBHk7QBIk1DYjhQAlglAfgsQCEi0C5iCIDGiKQBZg7A5grQDTiEEHg7QD9hGD2hAQBnghBpgbQCIgjCMgaQAugJAugFQAGjHAfjEIAEgXQBOnSArmvQAfjrBgjXQA/iKCRAXQA0AJAoAkQBRBJAeBsQAzC1BFCwQBSDQCfCbQCViwD4BoIAkAKQAPAFAcArQAYAiARASQALgXgFg9QAAgzAGggQAuhkAfiLQAkiBA7hnQBGhjA8hqQBViQChAGQAuABAiAgQBqBlAJCVQABAKAgBRQAYBAAIAcIABAGQAvIKgVEMQgHBZgYBWQBdBbAuB1IAJAXQAWA9APBCQA0DxgKD2QgJDRhdC9QhWCtiYB1IgYAQQAxCaANChIATD0QAiGJgSC7QgSDBhcCmQgVAnggAdQgvAqg3AiQgvAfg0ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA+QhJAhhQAAIgIAAgAYZpXQhHBGgBBjQgDBkBFBFQAYAYAcAQQA0AfBCAAQBkAABGhGQBFhEAChhIAAgEQAAhkhGhGQhBhDhjgBIgDAAQhiAAhGBEgAOIpeQhGBGgCBjQAABkBEBGQBGBIBkABQBjABBHhGQBIhEAAhlQAChjhGhHQhFhHhkgBQhjAAhIBEg");
	this.shape_1256.setTransform(356.7036,316.9077);

	this.shape_1257 = new cjs.Shape();
	this.shape_1257.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhIBEQhGBGhjgBQhjgBhGhIQhEhFAAhkQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBjg");
	this.shape_1257.setTransform(463.9516,273.4016);

	this.shape_1258 = new cjs.Shape();
	this.shape_1258.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgQgXgYQhGhFADhjQABhjBHhGQBHhFBkABQBkABBABDQBGBGAABjIAAAEQgCBhhFBEQhGBGhiAAIgCAAgAlIDuQhkgBhGhIQhEhFAAhkQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBjQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1258.setTransform(496.6252,273.6252);

	this.shape_1259 = new cjs.Shape();
	this.shape_1259.graphics.f("#232323").s().p("EAQ/Al6QlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhFQgTlFBHk7QBIk1DYjhQAlglAfgsQCEi0C5iCIDGiKQBZg7A5grQDTiEEIg6QD9hGD3g/QBmgiBpgbQCJgjCLgaQAugJAugFQAFjHAgjEIAEgXQBMnSAqmuQAejsBfjXQA/iKCRAXQA0AIApAkQBRBJAeBrQA0C2BFCvQBSDQCgCbQCUiyD6BqIAjAKQAPAFAcAsQAZAiARASQALgXgFg+QgBgzAHggQAuhlAdiMQAkiBA6hnQBFhkA9hpQBViSCgAGQAuABAiAgQBsBlAICVQABAKAgBTQAZBAAJAdIABAGQAwITgVEFQgHBZgXBWQBbBbAvB2IAJAWQAWA9APBCQA1DxgLD2QgJDShdC8QhWCtiYB1IgYAQQAxCaANChIATD0QAiGJgSC7QgSDBhcCmQgVAnggAdQgvAqg3AiQgvAfg0ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA+QhJAhhQAAIgIAAgAYZpXQhHBGgBBkQgDBjBGBFQAXAYAcAQQA0AfBCAAQBkABBGhHQBFhEAChhIAAgEQAAhkhGhGQhAhDhkgBIgDAAQhiAAhGBEgAOIpeQhGBGgCBjQAABlBEBFQBGBIBkABQBjABBHhGQBIhEAAhkQAChkhGhHQhFhHhkgBQhjAAhIBEg");
	this.shape_1259.setTransform(356.7113,316.9394);

	this.shape_1260 = new cjs.Shape();
	this.shape_1260.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgQgXgYQhGhFAChjQAChjBGhGQBIhFBjABQBlACBABCQBGBGAABjIgBAEQgCBhhEBEQhGBGhjAAIgBAAgAlIDuQhkgBhFhIQhFhFAAhkQAChjBGhGQBIhEBjAAQBkABBEBHQBGBHgBBjQAABkhIBEQhGBFhgAAIgEAAg");
	this.shape_1260.setTransform(496.6498,273.6252);

	this.shape_1261 = new cjs.Shape();
	this.shape_1261.graphics.f("#232323").s().p("EAQ/Al8QlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhFQgTlFBHk7QBIk1DYjhQAlglAfgsQCEi0C5iCIDGiKQBZg7A5grQDTiEEIg5QD+hFD3hAQBnghBogbQCJgjCLgaQAugLAugEQAFjHAfjEIAEgYQBMnRAomuQAdjsBfjXQA+iLCRAXQA0AIApAkQBSBJAeBrQA0C1BGCvQBTDRCgCZQCUixD6BqIAjAKQAPAFAdAsQAZAjARASQALgXgFg+QgBg1AGggQAuhkAdiNQAjiCA5hoQBFhjA9hqQBUiSChAFQAuACAiAfQBrBlAJCVQABAKAhBUQAaBBAJAdIAAAGQAyIXgVEEQgHBZgXBWQBbBbAvB2IAJAWQAWA9APBCQA1DxgLD2QgJDShdC8QhWCtiYB1IgYAQQAxCaANChIATD1QAiGHgSC8QgSDBhcCmQgVAnggAdQgwAqg2AiQgvAfg0ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA+QhJAhhQAAIgIAAgAYZpVQhHBGgBBkQgDBjBGBFQAXAYAcAQQA0AfBCAAQBkABBGhHQBFhEAChhIAAgEQAAhkhGhGQhAhChkgCIgDAAQhiAAhGBEgAOIpcQhGBGgCBjQAABlBFBFQBFBIBkABQBjABBHhGQBIhEAAhkQAChkhGhHQhFhHhkgBQhjAAhIBEg");
	this.shape_1261.setTransform(356.7113,316.7199);

	this.shape_1262 = new cjs.Shape();
	this.shape_1262.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgQgXgYQhGhFAChjQAChjBGhGQBIhEBjAAQBlACBABCQBGBGAABjIAAAEQgDBhhEBEQhGBGhjAAIgBAAgAlIDuQhkgBhFhIQhFhFAAhkQAChjBGhGQBIhEBjAAQBkABBEBHQBGBHgBBjQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1262.setTransform(496.6498,273.6252);

	this.shape_1263 = new cjs.Shape();
	this.shape_1263.graphics.f("#232323").s().p("EAQ/Al+QlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCARQkfAakSAMIgSABQnBAVm5hYQi7gmilhhIgdgTQhSg4g2hTQgshBgHhNIgGhFQgTlEBHk8QBIk1DYjgQAlgmAfgsQCEi0C5iCIDGiJQBZg8A6grQDTiEEIg4QD/hED2hAQBnghBogbQCJgkCLgaQAugKAugFQAFjGAfjEIADgYQBMnSAmmtQAdjsBejXQA9iMCSAXQA0AIAoAkQBTBJAeBqQA1C1BGCvQBUDQCgCZQCUixD6BqIAkAKQAPAFAdAtQAZAkARARQALgXgGg+QgBg1AGghQAuhkAciOQAjiCA5hoQBEhlA8hpQBUiSChAEQAuACAiAfQBsBkAKCVQAAAKAiBVQAaBDAJAdIABAGQAyIdgUEAQgHBagXBVQBbBcAvB1IAJAXQAWA9APBCQA1DxgLD1QgJDShdC9QhWCsiYB1IgYAQQAxCbANChIATD0QAiGHgSC9QgSDBhcCmQgVAnggAcQgwAqg2AjQgvAfg0ASQgcAMgeAHQjcApjOhaIgNgIQhpBviMA+QhJAghQAAIgIAAgAYZpSQhHBGgBBjQgDBjBGBGQAXAXAcARQA0AfBCAAQBkAABGhGQBEhEADhhIAAgEQAAhkhGhHQhAhChkgBQhkAAhHBEgAOIpaQhGBGgCBkQAABkBFBGQBFBIBkAAQBkACBGhGQBIhFAAhkQAChjhGhIQhFhGhkgCQhjAAhIBEg");
	this.shape_1263.setTransform(356.7113,316.4964);

	this.shape_1264 = new cjs.Shape();
	this.shape_1264.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhHBEQhHBGhjgBQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBjAAQBkABBEBHQBGBIgBBig");
	this.shape_1264.setTransform(464,273.4016);

	this.shape_1265 = new cjs.Shape();
	this.shape_1265.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgPgYgZQhFhFAChjQAChjBGhGQBIhEBjAAQBkACBBBCQBGBHAABiIAAAFQgDBhhEBDQhGBGhjAAIgBAAgAlJDuQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBkAAQBkABBEBHQBGBIgBBiQgBBkhHBEQhFBFhiAAIgEAAg");
	this.shape_1265.setTransform(496.6743,273.6252);

	this.shape_1266 = new cjs.Shape();
	this.shape_1266.graphics.f("#232323").s().p("EAQ/AmAQlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCARQkfAakSAMIgSABQnBAVm5hYQi7gmilhhIgdgTQhSg4g2hTQgshBgHhNIgGhFQgTlEBHk8QBIk1DYjgQAlgmAfgsQCEi0C5iCIDGiJQBZg8A6grQDTiEEJg3IH2iDQBmghBpgcQCIgkCLgaQAugKAugFQAFjGAejFIAEgXQBLnSAkmtQAcjsBdjXQA+iMCRAWQA0AIApAkQBSBJAfBqQA2C1BGCvQBUDQChCYQCTiyD8BrIAjAKQAPAFAeAuQAZAkARARQALgXgGg/QgCg1AHghQAthlAciOQAiiDA4hpQBFhkA7hqQBTiSChAEQAuABAiAfQBsBkALCVQAAAKAjBXQAbBDAJAdIABAHQAzIfgUEAQgHBagXBVQBbBcAvB1IAJAXQAWA9APBCQA1DxgLD1QgJDShdC9QhWCsiYB2IgYAPQAxCbANChIATD0QAiGHgSC9QgSDBhcCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgcAMgeAHQjcApjOhaIgNgIQhpBviMA+QhJAghQAAIgIAAgAYZpQQhHBGgBBjQgDBjBGBGQAYAYAbAQQA0AfBCAAQBkAABGhGQBEhEADhhIAAgEQAAhjhGhIQhAhChkgBQhkAAhHBEgAOIpYQhGBGgBBkQgBBkBFBGQBFBIBkAAQBkACBGhGQBHhFAChkQABhjhGhIQhFhGhkgCQhjAAhIBEg");
	this.shape_1266.setTransform(356.7113,316.2728);

	this.shape_1267 = new cjs.Shape();
	this.shape_1267.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhHBEQhHBGhjgBQhjgBhGhHQhFhHABhjQABhjBHhGQBIhFBiABQBkABBEBHQBGBIgBBig");
	this.shape_1267.setTransform(464,273.4014);

	this.shape_1268 = new cjs.Shape();
	this.shape_1268.graphics.f("#FFFFFF").s().p("ADPDTQgbgPgYgZQhFhGADhiQABhjBGhFQBIhFBjAAQBkACBBBCQBGBHAABiIAAAFQgDBhhEBDQhHBGhjAAQhCAAg1gfgAlJDuQhjgBhGhHQhFhHABhjQABhjBHhGQBIhFBjAAQBkACBEBGQBGBJgBBhQgBBlhHBEQhFBFhiAAIgEAAg");
	this.shape_1268.setTransform(496.6743,273.6498);

	this.shape_1269 = new cjs.Shape();
	this.shape_1269.graphics.f("#232323").s().p("EAQ/AmDQlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhFQgTlFBHk7QBIk1DYjhQAlglAfgsQCEi0C5iCIDGiKQBZg7A6grQDTiEEKg2IH2iDQBnghBogcQCIgkCLgaQAvgLAtgFQAEjGAfjEIADgYQBLnSAimsQAcjsBcjYQA9iLCRAVQA1AIAoAjQBTBJAfBqQA2C1BHCvQBVDPCiCYQCSizD8BsIAkAKQAPAFAdAvQAaAkARASQALgXgGhAQgCg2AGghQAthlAbiPQAhiEA4hpQBFhkA7hrQBSiSCiAEQAuABAiAfQBsBkALCVQABAKAjBXQAbBEAKAeIAAAGQA1IjgUEAQgHBZgXBWQBbBbAvB2IAJAWQAWA9APBCQA1DxgLD2QgJDRhdC9QhWCtiYB1IgYAQQAxCaANCiIATD0QAiGHgSC8QgSDBhcCmQgVAnghAdQgvAqg2AiQgvAfg0ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA+QhJAhhQAAIgIAAgAYZpNQhHBFgBBkQgDBiBGBHQAYAYAbAPQA0AfBCABQBkAABGhHQBEhDADhhIAAgFQAAhjhGhHQhAhChkgCIgCAAQhiAAhHBFgAOJpVQhHBGgBBjQgBBkBFBHQBFBHBkABQBkABBGhGQBHhEAChkQABhjhGhIQhFhHhkgBIgBAAQhigBhHBFg");
	this.shape_1269.setTransform(356.7113,316.0491);

	this.shape_1270 = new cjs.Shape();
	this.shape_1270.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgBBkhHBFQhHBGhjgBQhjgChGhHQhFhGABhjQABhjBHhGQBIhFBiABQBkABBFBGQBFBIgBBig");
	this.shape_1270.setTransform(463.9995,273.4508);

	this.shape_1271 = new cjs.Shape();
	this.shape_1271.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhGADhjQABhiBHhGQBGhFBkABQBkABBBBDQBGBGAABjIAAAEQgDBhhEBEQhGBGhkAAQhCAAg1gfgAlJDuQhjgChGhHQhFhGABhjQABhjBHhGQBIhFBjABQBkABBFBGQBFBIgBBiQgBBkhHBFQhFBFhiAAIgEAAg");
	this.shape_1271.setTransform(496.6743,273.6743);

	this.shape_1272 = new cjs.Shape();
	this.shape_1272.graphics.f("#232323").s().p("EAQ/AmFQlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhGQgTlEBHk7QBIk1DYjhQAlglAfgsQCFi0C4iCIDGiKQBZg7A6grQDTiEELg1IH2iCQBngiBogbQCJglCKgaQAvgLAugFQADjGAejEIAEgYQBJnSAhmrQAbjsBcjZQA9iLCRAVQA0AHApAjQBSBJAgBqQA2C0BICvQBVDQCjCXQCRizD+BsIAjAKQAPAFAeAvQAaAlARASQALgXgHhBQgCg2AGghQAthlAaiQQAhiFA4hpQBDhlA8hqQBSiTChADQAuABAiAfQBsBjAMCVQABALAkBZQAbBFAKAeIABAGQA2IlgUEAQgGBagYBVQBcBcAuB1IAJAWQAWA9APBDQA1DwgLD2QgJDRhdC9QhWCtiYB1IgYAQQAxCaANCiIATD0QAiGIgSC7QgSDBhcCmQgVAnghAdQgvAqg2AiQgvAfg0ATQgcALgeAIQjcAojOhaIgNgHQhpBuiMA+QhJAhhQAAIgIAAgAYZpLQhHBFgBBkQgDBiBGBHQAYAYAbAPQA0AfBCABQBlAABFhGQBEhEADhhIAAgFQAAhjhGhHQhAhChkgBIgDAAQhiAAhGBEgAOJpTQhHBGgBBjQgBBkBFBHQBFBHBkABQBkACBGhHQBHhEAChkQAAhjhFhIQhFhGhkgCIgCAAQhiAAhGBEg");
	this.shape_1272.setTransform(356.7113,315.8241);

	this.shape_1273 = new cjs.Shape();
	this.shape_1273.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgCBkhHBFQhGBGhjgBQhkgChFhHQhFhGABhjQABhjBHhGQBHhFBiABQBkABBFBHQBGBHgBBig");
	this.shape_1273.setTransform(464.0009,273.4509);

	this.shape_1274 = new cjs.Shape();
	this.shape_1274.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhFADhkQABhiBHhGQBHhFBjABQBkABBBBDQBGBGAABjIAAAEQgDBhhEBEQhGBGhkAAQhCAAg1gfgAlJDuQhjgChGhHQhFhGABhjQABhjBHhGQBIhFBjABQBkABBFBHQBGBHgCBiQgBBkhHBFQhFBFhiAAIgEAAg");
	this.shape_1274.setTransform(496.6745,273.6743);

	this.shape_1275 = new cjs.Shape();
	this.shape_1275.graphics.f("#232323").s().p("EAQ/AmHQlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSAMIgSABQnBAUm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhGQgTlEBHk7QBIk1DYjhQAlglAfgsQCFi0C4iCIDGiKQBZg8A6gqQDTiEELg0QEBhBD3hAQBmgjBogbQCJglCKgaQAvgKAugGQADjGAejFIADgXQBJnSAfmqQAajuBbjXQA8iNCSAVQA0AIApAjQBUBIAfBqQA3C1BICtQBWDPCjCYQCRi0D+BtIAjAKQAPAFAfAwQAaAlASASQAKgWgHhCQgDg3AGgiQAthkAZiSQAhiFA3hqQBDhkA7hrQBSiTChADQAuABAiAeQBtBjAMCVQABAKAlBbQAcBGAKAfIABAFQA3ItgUD7QgGBagYBWQBcBbAuB1IAJAWQAWA9APBDQA1DxgLD2QgJDQhdC9QhWCtiYB1IgYAQQAyCaAMCiIATD0QAiGIgSC7QgSDBhcCmQgVAnghAdQgvAqg2AiQgvAgg0ASQgcALgeAIQjcAojOhaIgNgHQhpBuiMA/QhJAghQAAIgIAAgAYZpJQhHBFgBBkQgDBjBGBGQAYAYAbAQQA1AeBCABQBkAABFhGQBEhEADhhIAAgFQABhjhHhHQhAhChkgBIgDAAQhhAAhHBEgAOJpRQhHBHgBBiQgBBkBFBHQBFBHBkABQBkACBGhGQBHhFAChkQABhjhGhIQhFhGhkgCIgCAAQhiAAhGBEg");
	this.shape_1275.setTransform(356.7113,315.6002);

	this.shape_1276 = new cjs.Shape();
	this.shape_1276.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgCBkhHBFQhGBGhjgBQhkgBhFhIQhFhGABhjQABhjBHhGQBHhEBiAAQBkABBFBHQBGBHgBBig");
	this.shape_1276.setTransform(464.0009,273.4516);

	this.shape_1277 = new cjs.Shape();
	this.shape_1277.graphics.f("#FFFFFF").s().p("ADPDTQgbgQgYgYQhFhFADhkQABhiBHhGQBHhFBjABQBkABBBBDQBGBGAABjIAAAEQgCBhhFBEQhGBGhkAAQhCAAg1gfgAlJDuQhjgBhGhIQhFhGABhjQABhjBHhGQBIhEBjAAQBkABBFBHQBGBHgCBiQgBBkhHBFQhFBFhiAAIgEAAg");
	this.shape_1277.setTransform(496.6745,273.675);

	this.shape_1278 = new cjs.Shape();
	this.shape_1278.graphics.f("#232323").s().p("EAQ/AmJQlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCARQkfAakSAMIgSABQnBAVm5hYQi7gmilhhIgdgTQhSg4g2hTQgshBgHhNIgGhFQgTlEBHk8QBIk1DYjgQAlgmAfgsQCFi0C4iCIDGiJQBZg9A6gqQDTiEEMgzQEBhAD3hAQBmgiBpgcQCIglCLgbQAugKAugFQADjHAdjEIAEgYQBInSAdmqQAZjtBbjYQA8iNCRAVQA1AHApAjQBTBIAgBqQA4C0BICuQBXDPCjCXQCRi0D+BtIAkAKQAPAFAeAwQAbAmASATQAKgXgHhDQgDg3AGghQAshlAZiSQAfiGA3hqQBDhmA7hqQBRiTChACQAuABAjAeQBtBjAMCVQABAKAmBbQAcBHALAfIAAAGQA5IugUD9QgGBZgYBWQBcBbAuB2IAJAWQAWA9APBCQA1DxgLD2QgJDShdC8QhWCtiYB1IgYAQQAyCaAMChIATD0QAiGIgSC7QgSDChcCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgcAMgeAHQjcAojOhaIgNgHQhpBviMA+QhJAghQAAIgIAAgAYZpHQhHBGgBBjQgDBkBGBFQAYAYAbAQQA1AfBCAAQBkAABFhGQBFhEAChhIAAgEQABhkhHhGQhAhDhkgBIgDAAQhhAAhHBEgAOJpOQhHBGgBBjQgBBkBFBGQBFBIBkABQBkABBGhGQBHhFAChkQABhjhGhHQhFhHhkgBQhjAAhHBEg");
	this.shape_1278.setTransform(356.7113,315.3768);

	this.shape_1279 = new cjs.Shape();
	this.shape_1279.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgCBlhHBEQhGBGhjgBQhjgBhGhIQhFhGABhjQABhjBHhGQBHhEBiAAQBkABBFBHQBGBHgBBig");
	this.shape_1279.setTransform(464.0009,273.4516);

	this.shape_1280 = new cjs.Shape();
	this.shape_1280.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhkQABhiBHhGQBHhFBjABQBkABBBBDQBGBGAABjIAAAEQgCBhhFBEQhFBGhjAAIgCAAgAlJDuQhjgBhGhIQhFhGABhjQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBiQgBBlhHBEQhFBFhiAAIgEAAg");
	this.shape_1280.setTransform(496.6745,273.6752);

	this.shape_1281 = new cjs.Shape();
	this.shape_1281.graphics.f("#232323").s().p("EAQ/AmLQlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCARQkfAakSAMIgSABQnBAVm5hYQi7gmilhhIgdgTQhSg5g2hSQgshBgHhNIgGhFQgTlEBHk8QBIk1DYjgQAkgmAggsQCFi0C4iCIDGiJQBZg9A6gqQDTiEENgxQEChAD3hAQBmgjBogcQCIglCLgbQAugLAugFQADjGAdjEIADgYQBInSAbmqQAZjsBajZQA7iNCSAUQA0AHApAjQBUBIAgBqQA4C0BJCuQBXDOCkCXQCQi1EABuIAjAKQAPAFAfAxQAbAmASATQAKgXgIhDQgDg4AGgiQAshlAYiTQAfiHA3hqQBDhmA5hqQBRiTChABQAuABAjAeQBtBjANCVQABAKAmBdQAeBIAKAfIABAGQA6IwgUD9QgGBZgYBWQBcBbAuB2IAJAWQAXA9AOBCQA1DxgLD2QgJDShdC8QhWCtiYB1IgYAQQAyCaAMChIATD0QAiGIgSC7QgSDChcCmQgVAnghAcQgvAqg2AjQgvAfg0ASQgcAMgeAHQjcAojOhaIgNgHQhpBviMA+QhJAhhQAAIgIgBgAYZpFQhHBGgBBjQgDBkBGBFQAYAYAbAQQA1AfBCAAQBkABBFhHQBFhEAChhIAAgEQABhkhHhGQhAhDhkgBIgDAAQhhAAhHBEgAOJpMQhHBGgBBjQgBBkBFBGQBGBIBjABQBkABBGhGQBHhEAChlQABhjhGhHQhFhHhkgBQhjAAhHBEg");
	this.shape_1281.setTransform(356.7113,315.1524);

	this.shape_1282 = new cjs.Shape();
	this.shape_1282.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwACQgCBlhHBEQhGBGhjgBQhjgBhGhIQhFhGABhjQABhjBHhGQBHhEBjAAQBjABBFBHQBGBHgBBig");
	this.shape_1282.setTransform(464.0009,273.4516);

	this.shape_1283 = new cjs.Shape();
	this.shape_1283.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhjQABhjBHhGQBHhFBjABQBkACBBBCQBGBGAABjIAAAEQgCBhhFBEQhFBGhjAAIgCAAgAlIDuQhkgBhGhIQhFhGABhjQAChjBGhGQBIhEBjAAQBjABBGBHQBGBHgCBiQgBBlhHBEQhFBFhhAAIgEAAg");
	this.shape_1283.setTransform(496.6745,273.6752);

	this.shape_1284 = new cjs.Shape();
	this.shape_1284.graphics.f("#232323").s().p("EAQ/AmOQlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gmilhiIgdgTQhSg5g2hRQgshBgHhNIgGhGQgTlEBHk7QBIk1DYjhQAkglAggsQCFi0C4iCIDGiKQBZg8A6gqQDTiEEOgxQECg/D3hAQBmgjBogcQCIglCLgcQAugKAugFQACjHAdjEIAEgYQBGnRAamqQAZjsBZjZQA6iNCSATQA0AHAqAjQBTBIAhBpQA5C0BJCuQBYDOCkCWQCQi2EABvIAkAKQAPAFAfAxQAbAnASATQALgXgJhDQgDg5AFgiQAthlAWiUQAfiHA2hrQBDhlA5hrQBRiUChABQAuABAiAeQBuBiANCVQABAKAnBeQAeBJALAgIAAAGQA8I8gTDzQgIBagXBVQBcBcAuB1IAJAXQAXA9AOBCQA1DxgLD1QgJDShdC9QhWCsiYB1IgYAQQAyCbAMChIATD0QAiGHgSC8QgSDBhcCmQgVAnghAdQgvAqg2AiQgvAfg0ATQgcALgeAIQjcAojOhaIgNgIQhpBviMA+QhJAhhQAAIgIAAgAYZpCQhHBGgBBjQgDBjBGBGQAYAXAbARQA1AfBCAAQBkAABFhGQBFhEAChhIAAgEQABhkhHhHQhAhChkgBIgDAAQhhAAhHBEgAOJpKQhHBGgBBjQgBBkBFBHQBGBIBjAAQBkACBGhGQBHhFAChkQABhjhGhIQhFhGhjgCQhkAAhHBEg");
	this.shape_1284.setTransform(356.7113,314.9278);

	this.shape_1285 = new cjs.Shape();
	this.shape_1285.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhIBEQhGBGhjgBQhjgBhGhIQhFhFABhkQABhjBHhGQBHhEBjAAQBkABBEBHQBGBHgBBjg");
	this.shape_1285.setTransform(464.0009,273.4516);

	this.shape_1286 = new cjs.Shape();
	this.shape_1286.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhjQABhjBHhGQBHhFBkABQBjACBBBCQBGBGAABjIAAAEQgCBhhFBEQhFBGhjAAIgCAAgAlIDuQhkgBhGhIQhFhFABhkQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBjQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1286.setTransform(496.6745,273.6752);

	this.shape_1287 = new cjs.Shape();
	this.shape_1287.graphics.f("#232323").s().p("EAQ/AmQQlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDATjCARQkfAbkSAMIgSABQnBAUm5hXQi7gmilhiIgdgTQhSg5g2hRQgshBgHhNIgGhGQgTlEBHk7QBIk1DYjhQAkglAggsQCFi0C4iCIDGiKQBZg8A6gqQDTiEEOgwQEDg+D3hAQBmgjBpgcQCIglCKgdQAugKAugFQACjHAdjEIADgYQBGnSAYmoQAYjtBYjZQA7iNCRATQA1AHApAiQBUBIAhBpQA5C0BKCtQBZDOCkCVQCQi1EABvIAkAKQAPAFAfAzQAcAmASATQALgXgJhEQgEg5AFgiQAthlAWiVQAdiIA2hrQBChmA6hrQBPiUCiABQAuABAjAeQBtBhAOCVQABAKAoBgQAeBKALAfIABAGQA8JDgSDvQgIBagXBWQBcBbAuB1IAJAXQAXA9AOBCQA1DxgLD2QgJDRhdC9QhWCsiYB1IgYAQQAyCbAMChIATD0QAiGHgSC8QgSDBhcCmQgVAnghAdQgvAqg2AiQgvAgg0ASQgcALgeAIQjcAojOhaIgNgHQhpBuiMA+QhLAhhTAAIgDAAgAYZpAQhHBGgBBjQgCBjBFBGQAYAXAbARQA1AfBCAAQBkAABFhGQBFhEAChhIAAgEQABhkhHhHQhBhChjgBIgDAAQhhAAhHBEgAOJpIQhHBGgBBkQgBBkBFBGQBGBIBjAAQBkACBGhGQBIhFABhkQABhjhGhIQhEhGhkgCQhkAAhHBEg");
	this.shape_1287.setTransform(356.7286,314.7003);

	this.shape_1288 = new cjs.Shape();
	this.shape_1288.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg1gfQgbgQgYgYQhFhFADhjQABhjBHhGQBHhEBkAAQBjACBBBCQBGBHAABiIAAAFQgCBhhFBDQhFBGhjAAIgCAAgAlIDuQhkgBhGhIQhFhFABhkQAChjBGhGQBIhEBjAAQBkABBFBHQBGBHgCBjQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1288.setTransform(496.6745,273.6752);

	this.shape_1289 = new cjs.Shape();
	this.shape_1289.graphics.f("#232323").s().p("EAQ/AmSQlegGlOhgQifgtiag9QhUghhXAQQg1AMg0AFQjDAUjCAQQkfAbkSAMIgSABQnBAUm5hXQi7gmilhiIgdgTQhSg4g2hSQgshBgHhNIgGhGQgTlEBIk7QBGk2DZjfQAkgmAggsQCFi0C4iDIDGiJQBZg8A6gqQDTiEEPguQEEg+D3hAQBmgkBogcQCIglCKgdQAugKAugFQACjHAcjEIAEgYQBFnRAWmpQAXjsBYjaQA6iNCSASQA0AIAqAiQBUBHAhBpQA5C0BLCtQBaDNCkCWQCQi3EBBwIAjAKQAPAFAgAyQAcApASATQALgYgJhEQgEg6AFgiQAshlAViWQAdiJA1hrQBChmA5hsQBQiUChABQAuAAAjAeQBuBiAOCVQABAJApBhQAfBLALAgIABAGQA9JFgSDwQgIBYgXBXQBcBbAuB2IAJAWQAXA9AOBCQA1DxgLD2QgJDRhdC9QhWCsiYB2IgYAQQAyCaAMCiIATDzQAiGHgSC8QgSDBhcCmQgVAnghAdQgvAqg2AiQgvAgg0ASQgcAMgeAHQjcAojOhaIgNgHQhpBuiMA/QhLAghTAAIgDAAgAYZo+QhGBGgCBjQgCBjBFBGQAYAYAbAQQA1AfBCAAQBkABBFhHQBFhEAChgIAAgFQABhjhHhIQhBhChjgBQhjAAhIBEgAOJpGQhHBHgBBjQgBBlBFBFQBGBIBjAAQBkACBGhGQBIhFABhjQABhkhGhHQhEhHhkgBQhkgBhHBEg");
	this.shape_1289.setTransform(356.7297,314.5);

	this.shape_1290 = new cjs.Shape();
	this.shape_1290.graphics.f().s("#FFFFFF").ss(1,1,1).p("ADwADQgBBkhIBEQhGBGhjgBQhjgBhGhIQhEhFAAhkQABhjBHhGQBHhEBjAAQBkABBEBHQBGBIgBBig");
	this.shape_1290.setTransform(464.0016,273.4516);

	this.shape_1291 = new cjs.Shape();
	this.shape_1291.graphics.f("#FFFFFF").s().p("AFGDyQhCAAg0gfQgcgPgYgZQhFhFADhjQABhjBHhGQBHhEBkAAQBkACBABCQBGBHAABiIAAAFQgCBhhFBDQhFBGhjAAIgCAAgAlIDuQhkgBhGhIQhEhFAAhkQAChjBGhGQBIhEBjAAQBkABBFBHQBGBIgCBiQAABkhIBEQhFBFhhAAIgEAAg");
	this.shape_1291.setTransform(496.6752,273.6752);

	this.shape_1292 = new cjs.Shape();
	this.shape_1292.graphics.f("#232323").s().p("EAQ/AmUQlegGlOhgQifgtiag8QhUgihXARQg1ALg0AFQjDAUjCAQQkfAbkSAMIgSABQnBAVm5hYQi7gmilhhIgdgUQhSg4g2hSQgshBgHhNIgGhFQgTlEBIk8QBGk1DZjgQAkgmAggsQCFi0C4iCIDGiJQBZg9A6gqQDTiEEQgtQEEg9D3hBQBmgjBogcQCIgmCKgcQAvgLAtgFQACjHAcjEIADgYQBFnRAUmoQAWjtBYjaQA5iNCSASQA0AGAqAjQBUBHAiBpQA6C0BLCtQBaDNCmCUQCOi2ECBwIAkAKQAPAFAgAzQAbApATATQALgXgKhGQgEg6AFgiQAshlAUiXQAdiJA1hsQBBhmA5hsQBPiUChAAQAugBAjAfQBvBhAOCUQABALAqBiQAfBLAMAhIAAAGQBAJGgTDxQgIBZgXBWQBcBcAuB1IAJAWQAXA9APBDQA0DwgLD2QgJDRhdC9QhWCtiXB1IgZAQQAyCaAMCiIATD0QAiGHgSC7QgSDBhcCnQgVAnghAcQgvAqg2AjQgvAfg0ASQgcAMgeAHQjcAojOhaIgNgHQhpBuiMA/QhLAghTAAIgDAAgAYZo8QhGBGgCBkQgCBjBFBFQAYAZAbAPQA1AfBCAAQBkABBFhHQBFhDAChhIAAgFQABhjhHhHQhAhChkgCQhjAAhIBEgAOJpDQhHBGgBBjQAABlBEBFQBGBIBjABQBkABBGhGQBIhEABhkQABhjhGhIQhEhHhkgBQhkAAhHBEg");
	this.shape_1292.setTransform(356.7304,314.275);

	this.shape_1293 = new cjs.Shape();
	this.shape_1293.graphics.f("#FFFFFF").s().p("ADPDTQgbgPgYgYQhFhHAChjQAChiBGhGQBIhEBkABQBjABBBBCQBGBGAABjIgBAFQgCBhhFBDQhFBGhkABQhCgBg1gfgAlJDtQhjAAhGhIQhEhFAAhkQABhjBHhHQBHhEBkABQBkABBFBHQBFBIgBBiQAABjhJBFQhFBFhgAAIgFgBg");
	this.shape_1293.setTransform(496.7,273.7);

	this.shape_1294 = new cjs.Shape();
	this.shape_1294.graphics.f("#232323").s().p("EAQ/AmXQlegHlOhfQifguiag8QhUghhXAQQg1ALg0AGQjDATjCARQkfAbkSALIgSABQnBAVm5hXQi7gnilhhIgdgTQhSg5g2hSQgshAgHhOIgGhFQgTlEBIk7QBGk2DZjgQAkgmAggsQCFizC4iDIDGiJQBZg8A6grQDTiEERgsQEEg8D4hAQBlgjBogdQCIgmCKgdQAvgLAtgFQACjGAbjFIAEgXQBDnTATmmQAVjtBXjaQA5iNCSARQA1AGAqAiQBUBHAiBqQA7CzBLCtQBbDMCmCUQCNi2EDBwIAkAKQAPAEAhA1QAcApASATQALgXgKhGQgFg7AFgiQAshmAUiXQAciKA0hsQBBhnA5hrQBOiVChgBQAuAAAjAfQBvBgAPCVQABAKAqBjQAgBNAMAgIABAHQBBJIgTDyQgIBZgXBVQBcBcAvB1IAIAXQAXA8APBDQA0DwgLD2QgJDShdC8QhVCtiYB2IgZAPQAyCbAMChIATD0QAiGHgSC8QgSDAhcCnQgVAnghAcQgvArg2AiQgvAfg0ASIg6ATQjcApjOhaIgNgIQhpBuiMA/QhLAhhTAAIgDAAgAYZo5QhGBFgCBkQgCBiBFBHQAYAYAbAQQA1AfBCAAQBkAABFhGQBFhEAChhIABgEQAAhkhGhGQhBhDhkgBIgDAAQhhAAhHBEgAOJpBQhHBGgBBkQAABkBEBGQBGBHBjABQBkABBGhGQBIhEABhkQABhjhGhIQhEhGhkgCQhkAAhHBEg");
	this.shape_1294.setTransform(356.7375,314.05);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1168},{t:this.shape_1167},{t:this.shape_1166}]},129).to({state:[{t:this.shape_1171},{t:this.shape_1170},{t:this.shape_1169}]},1).to({state:[{t:this.shape_1174},{t:this.shape_1173},{t:this.shape_1172}]},1).to({state:[{t:this.shape_1177},{t:this.shape_1176},{t:this.shape_1175}]},1).to({state:[{t:this.shape_1180},{t:this.shape_1179},{t:this.shape_1178}]},1).to({state:[{t:this.shape_1183},{t:this.shape_1182},{t:this.shape_1181}]},1).to({state:[{t:this.shape_1186},{t:this.shape_1185},{t:this.shape_1184}]},1).to({state:[{t:this.shape_1189},{t:this.shape_1188},{t:this.shape_1187}]},1).to({state:[{t:this.shape_1192},{t:this.shape_1191},{t:this.shape_1190}]},1).to({state:[{t:this.shape_1195},{t:this.shape_1194},{t:this.shape_1193}]},1).to({state:[{t:this.shape_1198},{t:this.shape_1197},{t:this.shape_1196}]},1).to({state:[{t:this.shape_1201},{t:this.shape_1200},{t:this.shape_1199}]},1).to({state:[{t:this.shape_1204},{t:this.shape_1203},{t:this.shape_1202}]},1).to({state:[{t:this.shape_1207},{t:this.shape_1206},{t:this.shape_1205}]},1).to({state:[{t:this.shape_1210},{t:this.shape_1209},{t:this.shape_1208}]},1).to({state:[{t:this.shape_1213},{t:this.shape_1212},{t:this.shape_1211,p:{y:273.3014}}]},1).to({state:[{t:this.shape_1215},{t:this.shape_1214},{t:this.shape_1211,p:{y:273.3255}}]},1).to({state:[{t:this.shape_1218},{t:this.shape_1217},{t:this.shape_1216}]},1).to({state:[{t:this.shape_1221},{t:this.shape_1220},{t:this.shape_1219}]},1).to({state:[{t:this.shape_1224},{t:this.shape_1223},{t:this.shape_1222}]},1).to({state:[{t:this.shape_1227},{t:this.shape_1226},{t:this.shape_1225}]},1).to({state:[{t:this.shape_1230},{t:this.shape_1229},{t:this.shape_1228}]},1).to({state:[{t:this.shape_1233},{t:this.shape_1232},{t:this.shape_1231,p:{x:463.95,y:273.3516}}]},1).to({state:[{t:this.shape_1236},{t:this.shape_1235},{t:this.shape_1234}]},1).to({state:[{t:this.shape_1239},{t:this.shape_1238},{t:this.shape_1237}]},1).to({state:[{t:this.shape_1242},{t:this.shape_1241},{t:this.shape_1240}]},1).to({state:[{t:this.shape_1245},{t:this.shape_1244},{t:this.shape_1243}]},1).to({state:[{t:this.shape_1247},{t:this.shape_1246},{t:this.shape_1243}]},1).to({state:[{t:this.shape_1250},{t:this.shape_1249},{t:this.shape_1248}]},1).to({state:[{t:this.shape_1253},{t:this.shape_1252},{t:this.shape_1251}]},1).to({state:[{t:this.shape_1256},{t:this.shape_1255},{t:this.shape_1254}]},1).to({state:[{t:this.shape_1259},{t:this.shape_1258},{t:this.shape_1257}]},1).to({state:[{t:this.shape_1261},{t:this.shape_1260},{t:this.shape_1231,p:{x:463.9514,y:273.4016}}]},1).to({state:[{t:this.shape_1263},{t:this.shape_1262},{t:this.shape_1231,p:{x:463.9514,y:273.4016}}]},1).to({state:[{t:this.shape_1266},{t:this.shape_1265},{t:this.shape_1264}]},1).to({state:[{t:this.shape_1269},{t:this.shape_1268},{t:this.shape_1267}]},1).to({state:[{t:this.shape_1272},{t:this.shape_1271},{t:this.shape_1270}]},1).to({state:[{t:this.shape_1275},{t:this.shape_1274},{t:this.shape_1273}]},1).to({state:[{t:this.shape_1278},{t:this.shape_1277},{t:this.shape_1276}]},1).to({state:[{t:this.shape_1281},{t:this.shape_1280},{t:this.shape_1279}]},1).to({state:[{t:this.shape_1284},{t:this.shape_1283},{t:this.shape_1282}]},1).to({state:[{t:this.shape_1287},{t:this.shape_1286},{t:this.shape_1285}]},1).to({state:[{t:this.shape_1289},{t:this.shape_1288},{t:this.shape_1285}]},1).to({state:[{t:this.shape_1292},{t:this.shape_1291},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[{t:this.shape_1294},{t:this.shape_1293},{t:this.shape_1290}]},1).to({state:[]},1).wait(1119));

	// кот1
	this.shape_1295 = new cjs.Shape();
	this.shape_1295.graphics.f("#232323").s().p("ACHI3QjLnnjIoRQgbhKAdgdQARgQAaACQAaACATAQQAQAOAMAYQAIAPALAeQC+IADfIIg");
	this.shape_1295.setTransform(134.9991,932.5139);
	this.shape_1295._off = true;

	this.timeline.addTween(cjs.Tween.get(this.shape_1295).wait(129).to({_off:false},0).to({_off:true},46).wait(1133));

	// фон2
	this.instance_70 = new lib.Анимация9("synched",0);
	this.instance_70.setTransform(2459.35,336.75);
	this.instance_70._off = true;

	this.instance_71 = new lib.Анимация10("synched",0);
	this.instance_71.setTransform(808.7,336.75);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.instance_70}]},125).to({state:[{t:this.instance_71}]},4).to({state:[{t:this.instance_71}]},44).to({state:[]},16).wait(1119));
	this.timeline.addTween(cjs.Tween.get(this.instance_70).wait(125).to({_off:false},0).to({_off:true,x:808.7},4).wait(1179));

	// name_f_movie
	this.shape_1296 = new cjs.Shape();
	this.shape_1296.graphics.f("#232323").s().p("AD0E2IAAprICBAAIAAJrgAl0E2IAAprICAAAIAAD7IC9AAQBYABAyAeQAxAdAUAqQAUArAAAmQAAAxgXAqQgYAqgxAaQgzAahQAAgAj0DNIDCAAQAugBAYgUQAZgVAAgmQAAglgagVQgYgUgvgBIjAAAg");
	this.shape_1296.setTransform(1016.275,495.775);

	this.shape_1297 = new cjs.Shape();
	this.shape_1297.graphics.f("#232323").s().p("ADQGxIAAj2IoaAAIAAprIB7AAIAAICIE2AAIAAoCIB6AAIAAICIBqAAIAAFfg");
	this.shape_1297.setTransform(932.8,508.075);

	this.shape_1298 = new cjs.Shape();
	this.shape_1298.graphics.f("#232323").s().p("AkQE2IAAprICBAAIAAD7IC7AAQBZABAyAeQAyAdAUAqQAUArgBAmQAAAxgXAqQgXAqgyAaQgyAahSAAgAiPDNIDAAAQAvgBAYgUQAZgVAAgmQAAglgZgVQgZgUgvgBIi/AAg");
	this.shape_1298.setTransform(859.4506,495.775);

	this.shape_1299 = new cjs.Shape();
	this.shape_1299.graphics.f("#232323").s().p("ADjE2IjinmIjjHmIiEAAIEmprICBAAIEnJrg");
	this.shape_1299.setTransform(785.65,495.775);

	this.shape_1300 = new cjs.Shape();
	this.shape_1300.graphics.f("#232323").s().p("ACfE2IAAnDIk2HDIiJAAIAAprICCAAIAAHCIE1nCICKAAIAAJrg");
	this.shape_1300.setTransform(707.85,495.775);

	this.shape_1301 = new cjs.Shape();
	this.shape_1301.graphics.f("#232323").s().p("AEDE2IjIkvIAAEvIh1AAIAAkvIjIEvIiPAAIDolUIjokXICPAAIDIEDIAAkDIB1AAIAAEDIDIkDICPAAIjoEXIDoFUg");
	this.shape_1301.setTransform(623.425,495.775);

	this.shape_1302 = new cjs.Shape();
	this.shape_1302.graphics.f("#232323").s().p("AiYEbQhMgtgohKQgohKgBhaQABheArhJQAshKBLgrQBLgqBggBQBbABA/ArQA/AqAiBEQAhBEABBNIAAA7InvAAQAHAwAaApQAaAqAuAZQAvAZBFABQBNgBA2gQQA3gPAegQIAegQIAAB0QABABgZAPQgZAQg3APQg2APhaABQhtgBhNgsgAC0hFQgBgTgJgZQgIgagTgYQgTgagggQQghgQgzgBQgyABgiAQQgjAQgWAaQgWAYgLAaQgLAZgCATIFnAAIAAAAg");
	this.shape_1302.setTransform(1126.225,393.775);

	this.shape_1303 = new cjs.Shape();
	this.shape_1303.graphics.f("#232323").s().p("ACfE2IAAnDIk2HDIiJAAIAAprICCAAIAAHCIE1nCICJAAIAAJrg");
	this.shape_1303.setTransform(1051,393.775);

	this.shape_1304 = new cjs.Shape();
	this.shape_1304.graphics.f("#232323").s().p("ABtE2Ij5kPIAAEPIiBAAIAAprICBAAIAADjIDjjjICiAAIknEXIE9FUg");
	this.shape_1304.setTransform(982.1,393.775);

	this.shape_1305 = new cjs.Shape();
	this.shape_1305.graphics.f("#232323").s().p("AiAEbQhPgsgnhKQgohKAAhbQABhbArhKQAqhKBMgsQBMgrBlgBQAnAAAoAIQApAHAlARQAlAQAcAaIAACGQAAgCgOgNQgOgOgbgSQgcgSgqgPQgpgOg4AAQg9AAgwAdQgwAdgcAwQgbAwgBA7QABBhA8A6QA8A6BoABQBJgBAxgQQAygPAZgQQAZgPAAgBIAAB3QgdAXgoAMQgnANgpAGQgoAFghAAQhzgBhOgsg");
	this.shape_1305.setTransform(911.575,393.775);

	this.shape_1306 = new cjs.Shape();
	this.shape_1306.graphics.f("#232323").s().p("ADjGBIAAiWInFAAIAACWIiBAAIAAj/IBRAAQAMgrAQhMQAQhMAMhlQAMhlABh1IHQAAIAAICIBhAAIAAD/gAhhisQgGAygJA3QgIA3gKAyQgJAzgJApIEUAAIAAmIIjZAAQgCAngGAzg");
	this.shape_1306.setTransform(835.425,401.275);

	this.shape_1307 = new cjs.Shape();
	this.shape_1307.graphics.f("#232323").s().p("AirEcQhMgsgthKQguhKgBhbQABhbAuhLQAthJBMgsQBNgsBegBQBfABBNAsQBMAsAuBJQAsBLACBbQgCBbgsBKQguBKhMAsQhNArhfABQhegBhNgrgAhti2QgwAdgcAvQgcAwgBA7QABA6AcAwQAcAwAwAcQAxAcA8ABQA+gBAwgcQAwgcAcgwQAcgwABg6QgBg7gcgwQgcgvgwgdQgwgcg+gBQg8ABgxAcg");
	this.shape_1307.setTransform(755.25,393.775);

	this.shape_1308 = new cjs.Shape();
	this.shape_1308.graphics.f("#232323").s().p("AlKG/IAAtqICBAAIAAA7QAighA1gWQA2gVBDgBQBgAABIAtQBJAsAqBJQAoBLABBbQgBBcgoBJQgqBJhJAtQhIArhgABQhLgBgzgYQgzgZgfgiIAAFBgAhhkxQgyAZgeAvQgeAwAABEQAABEAeAwQAeAtAyAaQAxAZA6AAQA6gBAsgcQAsgcAZgvQAYgwAAg8QAAg7gYgwQgZgwgsgdQgsgcg6gBQg6AAgxAZg");
	this.shape_1308.setTransform(677.55,405.6);

	this.shape_1309 = new cjs.Shape();
	this.shape_1309.graphics.f("#232323").s().p("AirEcQhMgsgthKQguhKgBhbQABhbAuhLQAthJBMgsQBNgsBfgBQBfABBMAsQBMAsAtBJQAuBLAABbQAABbguBKQgtBKhMAsQhMArhfABQhfgBhNgrgAhti2QgxAdgbAvQgcAwAAA7QAAA6AcAwQAbAwAxAcQAxAcA9ABQA9gBAwgcQAxgcAbgwQAcgwABg6QgBg7gcgwQgbgvgxgdQgwgcg9gBQg9ABgxAcg");
	this.shape_1309.setTransform(595.1,393.775);

	this.shape_1310 = new cjs.Shape();
	this.shape_1310.graphics.f("#232323").s().p("AktGXIAAsuIJbAAIAAB7InaAAIAAKzg");
	this.shape_1310.setTransform(520.675,384.05);

	this.instance_72 = new lib.Анимация4("synched",0);
	this.instance_72.setTransform(821.3,433.8);

	this.instance_73 = new lib.Анимация5("synched",0);
	this.instance_73.setTransform(-633.7,433.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1310},{t:this.shape_1309},{t:this.shape_1308},{t:this.shape_1307},{t:this.shape_1306},{t:this.shape_1305},{t:this.shape_1304},{t:this.shape_1303},{t:this.shape_1302},{t:this.shape_1301},{t:this.shape_1300},{t:this.shape_1299},{t:this.shape_1298},{t:this.shape_1297},{t:this.shape_1296}]},64).to({state:[{t:this.instance_72}]},32).to({state:[{t:this.instance_73}]},15).to({state:[]},15).wait(1182));

	// cloud
	this.shape_1311 = new cjs.Shape();
	this.shape_1311.graphics.f("#FFFFFF").s().p("AntH8QiQiQgoi6QgRhKC1CkQC1CkgmpNQgnpPFYAqQFWAqDJDJQDKDJAAEcQAAEdjKDJIgQARQjFC5kQAAQkcAAjKjKg");
	this.shape_1311.setTransform(877.0266,427.0617);

	this.shape_1312 = new cjs.Shape();
	this.shape_1312.graphics.f("#FFFFFF").s().p("AnxELQkGlwALi5QAehfE3ELQE2EJAJmvQAKmwERBaQETBbB5DJQCfCjgBDkQgoEJjXChQhAAHgogbQi/Bzi9AzQgUAFgXAAQi8AAkUlzg");
	this.shape_1312.setTransform(865.7516,433.2105);

	this.shape_1313 = new cjs.Shape();
	this.shape_1313.graphics.f("#FFFFFF").s().p("AnvCEQl9pSA/i4QBNh0G4FxQG2FxA5kSQA6kSDOCMQDOCLAoDJQB1B7gDCuQhPD1jmB5Qh3AFhHg9Qi5AthqBlQgQAOgUAAQiGAAlmofg");
	this.shape_1313.setTransform(853.9818,428.8705);

	this.shape_1314 = new cjs.Shape();
	this.shape_1314.graphics.f("#FFFFFF").s().p("AnsCfQn0szBzi2QB8iKI5HYQI3HYBph0QBqhzCJC7QCKC7gpDJQBMBWgFB3Qh2Dhj0BQQiuAEhohgQizgZgXCXQgEAXgQAAQhWAAm7rMg");
	this.shape_1314.setTransform(842.0144,408.1854);

	this.shape_1315 = new cjs.Shape();
	this.shape_1315.graphics.f("#FFFFFF").s().p("AoBC7QpqwVCmi1QCsifK5I+QK5I/CZAqQCZAqBFDtQBFDsh5DJQAhAvgGBAQidDNkDAoQjlACiIiDQirhfA7DKQAJAggIAAQgsAAoQt4g");
	this.shape_1315.setTransform(832.4712,387.5392);

	this.shape_1316 = new cjs.Shape();
	this.shape_1316.graphics.f("#FFFFFF").s().p("AAXRoQimikCPD7QCPD8rgz4Qrhz2Dbi0QDbi0M6KlQM5KlDKDIQDJDKAAEdQAAEcjJDKIgRAQQjEC5kRAAQkdAAinilg");
	this.shape_1316.setTransform(828.7979,368.7018);

	this.shape_1317 = new cjs.Shape();
	this.shape_1317.graphics.f("#FFFFFF").s().p("AtEDaQxIxFG/j6QHAj6KnGNQKmGOEuCZQEuCaBwFXQBxFYBqBdQEPhIBZCBQhJEZldCLQlmCLkMgEQkLgEgUBjQgBAIgJAAQhkAAvuvsg");
	this.shape_1317.setTransform(823.2753,403.0729);

	this.shape_1318 = new cjs.Shape();
	this.shape_1318.graphics.f("#FFFFFF").s().p("AHES+Qi4g32vuVQ2wuTKklAQKklBIUB2QIUB2GRBqQGSBqDiGTQDhGTGegPQIniYC5D5QAzF4moEWQmxEWlwCdQkRB1irAAQg8AAgvgOg");
	this.shape_1318.setTransform(828.6456,437.2724);

	this.shape_1319 = new cjs.Shape();
	this.shape_1319.graphics.f("#FFFFFF").s().p("AJfU1QlbjQ8XrkQ8YriOJmGQOJmHGAiiQGBiiH3A7QH1A7FSHOQFTHNLRh6QM/jpEaFzQCuHWn0GhQn7GhnUE/QkcDCjvAAQibAAiJhTg");
	this.shape_1319.setTransform(835.6555,459.6037);

	this.shape_1320 = new cjs.Shape();
	this.shape_1320.graphics.f("#FFFFFF").s().p("ALyYaUgH+gFqgh/gIyUgiAgIyARugHLQRtnNDum5QDum6JbALQJbAMHCIIQHCIIQFjlQRXk5F7HrQEpI3o/IrQpFIso5HgQlEESkxAAQjmAAjcibg");
	this.shape_1320.setTransform(843.458,470.9875);

	this.shape_1321 = new cjs.Shape();
	this.shape_1321.graphics.f("#FFFFFF").s().p("AOCcHUgKhgIEgnngGAUgnogGBAVSgIRQVToTBarRQBbrSK/gkQLAgkIyJEQI0JDU4lSQVumJHcJkQGlKWqLK2QqPK3qdKCQl0Fkl0AAQkrAAksjlg");
	this.shape_1321.setTransform(851.6151,481.5364);

	this.shape_1322 = new cjs.Shape();
	this.shape_1322.graphics.f("#FFFFFF").s().p("AQQf2UgNFgKdgtOgDPUgtQgDPAY3gJZQY3pYg4voQg5vqMkhTQMjhUKlJ/QKjJ+Zrm+QaHnZI8LcQIhL2rXNBQrZNCsBMjQmkG3m4AAQlvAAl8kwg");
	this.shape_1322.setTransform(859.9541,491.8145);

	this.shape_1323 = new cjs.Shape();
	this.shape_1323.graphics.f("#FFFFFF").s().p("EASdAjnUgPogM2gy3gAdUgy3gAeAccgKfQccqfjM0AQjM0BOIiDQOIiDMVK6QMUK5efoqQefoqKdNWQKdNVskPMQsjPNtmPFQnWIIn7AAQmxAAnMl6g");
	this.shape_1323.setTransform(868.4096,501.9247);

	this.shape_1324 = new cjs.Shape();
	this.shape_1324.graphics.f("#FFFFFF").s().p("EAXzAnYUgTBgHhgy/gDnUgzBgDnAajgLgQajrhi20QQi10SPLiYQPLiXM+HBQM+HBdZk2QdZk2JzMSQJ0MSqoP1QqnP2qaO+Qm8J/qwAAQlZAAmXihg");
	this.shape_1324.setTransform(864.013,502.0611);

	this.shape_1325 = new cjs.Shape();
	this.shape_1325.graphics.f("#FFFFFF").s().p("EAdKAqvUgWagCNgzJgGvUgzKgGwAYqgMiQYqshif0iQif0kQOirQQOisNoDJQNmDJcUhCQcThCJKLOQJKLPosQeQosQdnOO5QmSM/x1AAQioAAi5gSg");
	this.shape_1325.setTransform(859.612,504.7547);

	this.shape_1326 = new cjs.Shape();
	this.shape_1326.graphics.f("#FFFFFF").s().p("EgqkAnAUgzUgJ5AWxgNjQWxtjiJ0zQiI00RRjAQRRjAORgvQOPgwbPCyQbNCyIhKLQIgKLmwRHQmwRGkCOzQkCOz5zDIQmOAwnrAAUgYPAAAgm9gHgg");
	this.shape_1326.setTransform(855.2152,509.6282);

	this.shape_1327 = new cjs.Shape();
	this.shape_1327.graphics.f("#FFFFFF").s().p("EgoxAszUgzcgNCAU3gOjQU4ulhy1EQhy1GSUjUQSUjUO6koQO5koaIGmQaJGmH3JHQH2JHk0RwQk0Rvg2OtQg3Ot9MIeQrfDUu8AAQ3AAA/Mn5g");
	this.shape_1327.setTransform(850.9213,510.6997);

	this.shape_1328 = new cjs.Shape();
	this.shape_1328.graphics.f("#FFFFFF").s().p("EgnBAydUgzlgQKAS+gPmQS/vmhb1VQhc1XTXjoQTXjpPjogQPiohZDKbQZDKaHNIDQHOIEi5SYQi5SYCWOnUACWAOngglANzQvAGWzBAAQ2TAA72ovg");
	this.shape_1328.setTransform(846.941,512.6543);

	this.shape_1329 = new cjs.Shape();
	this.shape_1329.graphics.f("#FFFFFF").s().p("Egn/A4DUgzugTTARFgQnQRGwnhF1nQhG1oUbj8QUaj9QMsZQQLsYX9OOQX+OOGkHAQGjHAg9TBQg9TAFiOiUAFiAOhgj+ATHQx5Jg1yAAQ2BAB6Apug");
	this.shape_1329.setTransform(860.3835,515.0057);

	this.shape_1330 = new cjs.Shape();
	this.shape_1330.graphics.f("#FFFFFF").s().p("EgpqA9oUgz4gWcAPNgRpQPNxogv14Qgv16VdkQQVdkRQ2wRQQ0wRW4SCQW3SCF7F8QF6F9A/TqQA+ToIuOcUAIuAOcgnXAYcQ0hMv36AAQ19AA42qwg");
	this.shape_1330.setTransform(878.3142,517.5525);

	this.shape_1331 = new cjs.Shape();
	this.shape_1331.graphics.f("#FFFFFF").s().p("EgpmA5nUgzkgaZAPDgPwQPDvvg5z1Qg6z1VekAQVdkBQvv0QQuv0W+RVQW+RVF6F8QF7F9A+TqQA/ToIuOcUAIuAOcgnXAYcQy7Lv1wAAQ3eAA6xttg");
	this.shape_1331.setTransform(879.9826,517.9863);

	this.shape_1332 = new cjs.Shape();
	this.shape_1332.graphics.f("#FFFFFF").s().p("EgpjA1hUgzQgeWAO6gN3QO5t3hDxwQhExxVdjwQVdjxQqvXQQovXXEQoQXDQoF7F8QF6F9A/TqQA+ToIuOcUAIuAOcgnXAYcQxjK5z7AAQ4vAA8Zw0g");
	this.shape_1332.setTransform(881.6468,518.8645);

	this.shape_1333 = new cjs.Shape();
	this.shape_1333.graphics.f("#FFFFFF").s().p("EgpfAxYUgy8giTAOwgL/QOwr+hPvsQhOvsVdjhQVdjgQju6QQju6XKP7QXJP6F7F9QF6F8A/TqQA+TpIuOcUAIuAObgnXAYcQwYKLyYAAQ5yAA9v0Cg");
	this.shape_1333.setTransform(883.3359,520.1351);

	this.shape_1334 = new cjs.Shape();
	this.shape_1334.graphics.f("#FFFFFF").s().p("EgpcAtMUgyogmQAOngKGQOmqHhZtnQhZtoVdjQQVdjRQeudQQcudXQPOQXQPOF6F8QF7F9A+TqQA/ToIuOcUAItAOcgnWAYcQvWJhxEAAQ6rAA+53Vg");
	this.shape_1334.setTransform(884.9997,521.6695);

	this.shape_1335 = new cjs.Shape();
	this.shape_1335.graphics.f("#FFFFFF").s().p("EgpZAo9UgyUgqLAOdgIPQOdoOhjrjQhkrjVdjBQVdjAQYuAQQWuAXWOgQXWOhF6F9QF7F8A+TqQA/TpIuObUAIuAOcgnXAYcQucI9v6AAQ7dAA/36ug");
	this.shape_1335.setTransform(886.6654,523.4375);

	this.shape_1336 = new cjs.Shape();
	this.shape_1336.graphics.f("#FFFFFF").s().p("EgqvAoDUgy0glbAPUgHoQPUnqg8sCQg7sCVdjAQVcjBQYuAQQXuAXpOZQXpOXGLF2QGLF1BkR9QBlR7HHODUAHHAODgn5AV6QuvIGwOAAUgbsAAAggCgXng");
	this.shape_1336.setTransform(879.543,497.4642);

	this.shape_1337 = new cjs.Shape();
	this.shape_1337.graphics.f("#FFFFFF").s().p("EgsJAnJUgzSggpAQKgHEQQLnFgUsgQgUshVdjAQVdjBQYuAQQWuAX9OQQX8OPGbFuQGbFuCLQQQCLQNFgNrUAFhANqgobATYQvEHOwlAAUgb5AAAggMgUfg");
	this.shape_1337.setTransform(872.6685,471.4861);

	this.shape_1338 = new cjs.Shape();
	this.shape_1338.graphics.f("#FFFFFF").s().p("EgtkAmPUgzzgb4ARCgGgQRBmfAUs/QAUs/VdjBQVdjAQYuAQQWuAYQOHQYQOGGrFnQGsFnCwOiQCyOhD5NRUAD6ANRgo+AQ3QvcGWw/AAUgcCAABggRgRYg");
	this.shape_1338.setTransform(866.0826,445.5232);

	this.shape_1339 = new cjs.Shape();
	this.shape_1339.graphics.f("#FFFFFF").s().p("EgvDAlVUg0SgXHAR4gF7QR4l7A9tdQA7teVdjAQVdjBQYuAQQWuAYkN+QYjN/G7FfQG8FgDXM0QDXM0CTM4UACTAM5gpgAOVQv5FfxeAAUgcJAAAggQgOQg");
	this.shape_1339.setTransform(859.785,419.5551);

	this.shape_1340 = new cjs.Shape();
	this.shape_1340.graphics.f("#FFFFFF").s().p("EgwmAkaUg0xgSUASvgFXQSvlWBkt7QBkt9VcjAQVdjBQYuAQQXuAY2N2QY3N1HMFZQHMFYD9LHQD9LGAsMgUAAsAMfgqCAL0QwdEnyIABUgcHAAAggGgLKg");
	this.shape_1340.setTransform(853.8254,393.5882);

	this.shape_1341 = new cjs.Shape();
	this.shape_1341.graphics.f("#FFFFFF").s().p("EgxfAkXUg3VgRlAVBgFSQVAlUB3uVQB3uWVKkUQVJkURSsHQRSsHXYMxQXXMyFzG3QFzG3GZKSQGZKRAtMrUAAtAMqgqPALDQwUERyRAAUgdBAAAgh9gKxg");
	this.shape_1341.setTransform(841.8745,388.4889);

	this.shape_1342 = new cjs.Shape();
	this.shape_1342.graphics.f("#FFFFFF").s().p("EgyYAkTUg55gQzAXSgFQQXTlQCJuvQCKuwU3lnQU3lnSMqPQSNqOV5LtQV4LuEaIWQEZIWI1JdQI1JbAuM2UAAuAM2gqcAKTQwID6yWAAUgd9AAAgj5gKbg");
	this.shape_1342.setTransform(829.8596,383.3386);

	this.shape_1343 = new cjs.Shape();
	this.shape_1343.graphics.f("#FFFFFF").s().p("EgzQAkRUg8dgQEAZkgFMQZklNCdvJQCcvJUkm6QUkm7THoWQTIoWUaKqQUaKpDAJ1QDAJ1LRInQLRInAuNBUAAvANAgqpAJjQv6DkyZAAUge4AAAgl6gKDg");
	this.shape_1343.setTransform(817.7801,378.1068);

	this.shape_1344 = new cjs.Shape();
	this.shape_1344.graphics.f("#FFFFFF").s().p("Eg0HAkPUg/CgPSAb2gFKQb1lKCwviQCvvjUSoNQUQoOUCmeQUCmdS8JmQS7JlBmLUQBnLUNtHyQNtHxAwNMUAAvANMgq2AIzQvpDNyVAAUgf3AAAgoAgJtg");
	this.shape_1344.setTransform(805.6512,372.7743);

	this.shape_1345 = new cjs.Shape();
	this.shape_1345.graphics.f("#FFFFFF").s().p("Eg0+AkPUhBlgOhAeHgFHQeHlHDCv7QDDv8T+phQT+phU8klQU9klRdIhQRcIiANMzQAOMyQJG8QQIG9AxNXUAAwANXgrDAICQvVC4yNAAUgg3AAAgqNgJXg");
	this.shape_1345.setTransform(793.4614,367.2385);

	this.shape_1346 = new cjs.Shape();
	this.shape_1346.graphics.f("#FFFFFF").s().p("Eg0uAkGUhBlgOiAeHgFHQeHlGCzwjQCywkUmoEQUloEUllbQUmlaRcIiQRcIhAOMzQANMyP7G5QP6G6AsNWUAAsANWgqwAIHQvTC5yQAAUggrAAAgqGgJUg");
	this.shape_1346.setTransform(791.8062,368.2321);

	this.shape_1347 = new cjs.Shape();
	this.shape_1347.graphics.f("#FFFFFF").s().p("Eg0dAj9UhBmgOiAeIgFGQeHlHCjxKQCixLVNmoQVMmnUOmQQUPmQRcIiQRcIiAOMyQANMzPtG2QPsG3AnNVUAAoANUgqeAILQvSC8yRAAUgggAAAgp+gJTg");
	this.shape_1347.setTransform(790.1497,369.0944);

	this.shape_1348 = new cjs.Shape();
	this.shape_1348.graphics.f("#FFFFFF").s().p("Eg0MAj1UhBmgOiAeIgFGQeHlHCSxxQCSxzV0lKQV0lLT3nFQT3nGRdIiQRcIiANMyQAOMzPeGzQPeGzAjNVUAAjANTgqLAIPQvQC/yUAAUggTAAAgp3gJSg");
	this.shape_1348.setTransform(788.4938,369.8561);

	this.shape_1349 = new cjs.Shape();
	this.shape_1349.graphics.f("#FFFFFF").s().p("Egz8AjvUhBmgOiAeIgFHQeHlGCCyZQCCyaWbjuQWbjtTgn7QTgn7RdIiQRcIhANMzQAOMyPQGwQPQGxAeNTUAAeANTgp4AITQvNDAyWAAUggIAAAgpwgJPg");
	this.shape_1349.setTransform(786.863,370.5325);

	this.shape_1350 = new cjs.Shape();
	this.shape_1350.graphics.f("#FFFFFF").s().p("EgzsAjpUhBlgOiAeHgFHQeHlGByzBQByzBXDiRQXCiQTJoxQTJowRcIiQRcIhAOMzQANMyPCGtQPCGuAaNSUAAZANSgplAIXQvLDDyZAAUgf8AAAgppgJOg");
	this.shape_1350.setTransform(785.2085,371.1361);

	this.shape_1351 = new cjs.Shape();
	this.shape_1351.graphics.f("#FFFFFF").s().p("EgzbAjjUhBmgOiAeIgFGQeHlHBizoQBizoXpg0QXqg0SxpmQSypmRdIiQRcIiANMyQAOMzO0GqQOzGqAVNRUAAVANRgpSAIbQvJDGybAAUgfxAAAgphgJNg");
	this.shape_1351.setTransform(783.5547,371.677);

	this.shape_1352 = new cjs.Shape();
	this.shape_1352.graphics.f("#FFFFFF").s().p("EgzLAjeUhBlgOiAeHgFGQeHlHBS0PQBS0QYRApQYQApSbqbQSbqcRcIiQRcIiAOMyQANMzOmGnQOlGnARNQUAARANQgpAAIfQvIDIydAAUgflAAAgpagJLg");
	this.shape_1352.setTransform(781.9018,372.1535);

	this.shape_1353 = new cjs.Shape();
	this.shape_1353.graphics.f("#FFFFFF").s().p("Egy6AjaUhBlgOiAeHgFGQeHlHBC02QBC04Y4CGQY4CGSDrRQSErRRcIiQRcIiAOMyQANMzOYGkQOXGkAMNPUAAMANPgotAIjQvGDKyfAAUgfaAAAgpSgJJg");
	this.shape_1353.setTransform(780.2494,372.5927);

	this.shape_1354 = new cjs.Shape();
	this.shape_1354.graphics.f("#FFFFFF").s().p("EgypAjWUhBmgOiAeIgFGQeGlHAz1eQAx1fZgDjQZfDjRssGQRssHRdIiQRcIiANMyQAOMzOJGhQOJGhAHNOUAAIANOgoaAInQvDDNyiAAUgfPAAAgpKgJIg");
	this.shape_1354.setTransform(778.5976,372.9903);

	this.shape_1355 = new cjs.Shape();
	this.shape_1355.graphics.f("#FFFFFF").s().p("EgyZAjSUhBmgOiAeIgFGQeGlHAi2FQAi2GaHE/QaGFARVs8QRVs8RdIiQRcIiANMyQAOMzN7GeQN6GeAENNUAADANNgoIAIrQvADPykAAUgfEAABgpDgJHg");
	this.shape_1355.setTransform(776.9716,373.3512);

	this.shape_1356 = new cjs.Shape();
	this.shape_1356.graphics.f("#FFFFFF").s().p("EgyJAjPUhBlgOiAeHgFGQeHlHAS2sQAR2uauGdQauGcQ9txQQ/tyRcIiQRcIiAOMyQANMzNtGbQNtGagCNNUgABANMgn1AIvQu+DSylAAUge5AAAgo9gJFg");
	this.shape_1356.setTransform(775.3215,373.6796);

	this.shape_1357 = new cjs.Shape();
	this.shape_1357.graphics.f("#FFFFFF").s().p("Egx4AjMUhBmgOiAeIgFGQeGlHAC3UQAB3VbWH6QbUH5QnunQQnunRdIiQRcIiANMyQAOMzNeGYQNfGXgGNMUgAGANLgnjAIzQu6DUyoAAUgeuAAAgo1gJDg");
	this.shape_1357.setTransform(773.6735,373.979);

	this.shape_1358 = new cjs.Shape();
	this.shape_1358.graphics.f("#FFFFFF").s().p("EgxoAjJUhBlgOhAeHgFHQeHlHgP37QgO38b8JWQb7JWQQvcQQRvcRcIhQRcIiAOMzQANMyNQGVQNRGVgLNKUgAKANKgnQAI3Qu3DXypAAUgekAAAgovgJCg");
	this.shape_1358.setTransform(772.026,374.2445);

	this.shape_1359 = new cjs.Shape();
	this.shape_1359.graphics.f("#FFFFFF").s().p("Egy5AjsUhC5gOGAexgFrQevlrAM38QAL38cGJJQcFJIQQvNQQQvNRdIiQRcIiANMyQAOMzPFGfQPFGehrNCUgBqANCgneAI9QvUDezcAAUgepAAAgo7gIog");
	this.shape_1359.setTransform(773.1521,374.9644);

	this.shape_1360 = new cjs.Shape();
	this.shape_1360.graphics.f("#FFFFFF").s().p("Eg0PAkPUhEMgNqAfZgGQQfZmQAl37QAl38cQI6QcPI7QQu9QQQu+RcIiQRcIiAOMyQANMzQ6GpQQ6GojLM6UgDKAM5gnrAJCQvzDm0UAAUgetAAAgpCgIOg");
	this.shape_1360.setTransform(774.8247,375.6902);

	this.shape_1361 = new cjs.Shape();
	this.shape_1361.graphics.f("#FFFFFF").s().p("Eg1pAkyUhFfgNOAgCgG1UAgCgG1AA/gX7QA/38caItQcZIsQPuuQQQutRcIiQRcIhAOMzQANMySvGzQSvGykrMyUgErAMxgn5AJIQwRDu1NAAUgewAAAgpJgH1g");
	this.shape_1361.setTransform(776.8074,376.4218);

	this.shape_1362 = new cjs.Shape();
	this.shape_1362.graphics.f("#FFFFFF").s().p("Eg3EAlVUhGzgMzAgrgHZUAgrgHaABagX7QBX38ckIfQckIeQPueQQPueRcIiQRcIiAOMyQANMzUkG9QUjG7mKMqUgGLAMpgoHAJNQwyD22LAAUgexAAAgpKgHbg");
	this.shape_1362.setTransform(779.0003,377.1772);

	this.shape_1363 = new cjs.Shape();
	this.shape_1363.graphics.f("#FFFFFF").s().p("Eg4hAl3UhIGgMXAhVgH+UAhUgH+ABygX7QBy37cuIQQcuIQQOuOQQPuORdIiQRcIhANMzQAOMyWYHHQWYHFnqMhUgHrAMigoVAJSQxUD/3KAAUgeyAAAgpKgHDg");
	this.shape_1363.setTransform(781.2933,377.938);

	this.shape_1364 = new cjs.Shape();
	this.shape_1364.graphics.f("#FFFFFF").s().p("Eg5/AmZUhJagL7Ah+gIjUAh+gIjACMgX6QCM38c3IDQc4ICQOt+QQPt/RcIiQRcIhAOMzQANMyYOHRQYNHPpLMZUgJLAMZgojAJYQx2EI4OAAUgexAAAgpGgGrg");
	this.shape_1364.setTransform(783.7028,378.7046);

	this.shape_1365 = new cjs.Shape();
	this.shape_1365.graphics.f("#FFFFFF").s().p("Eg7dAm7UhKtgLfAingJHUAimgJIACmgX6QCm38dBH1QdBH0QPtvQQOtvRdIiQRcIhANMzQAOMyaCHaQaCHZqrMRUgKrAMRgowAJeQybER5VAAUgevAAAgo+gGTg");
	this.shape_1365.setTransform(786.165,379.5025);

	this.shape_1366 = new cjs.Shape();
	this.shape_1366.graphics.f("#FFFFFF").s().p("Eg88AndUhMAgLCAjQgJtUAjPgJsADAgX7QC/37dMHmQdLHnQOtgQQOtfRdIiQRcIiANMyQAOMzb3HjQb2HjsLMJUgMLAMJgo+AJiQy/Ec6iAAUgerAAAgoygF8g");
	this.shape_1366.setTransform(788.671,380.289);

	this.shape_1367 = new cjs.Shape();
	this.shape_1367.graphics.f("#FFFFFF").s().p("Eg8kAnNUhK0gLRAiJgJbUAiJgJbAC9gX6QC+38dMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzbuHkQbtHisEMJUgMEAMJgo/AJfQywEW50AAUgepAAAgongGHg");
	this.shape_1367.setTransform(793.1777,379.8523);

	this.shape_1368 = new cjs.Shape();
	this.shape_1368.graphics.f("#FFFFFF").s().p("Eg8MAm8UhJogLfAhCgJJUAhCgJKAC8gX6QC837dMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMybkHkQbkHjr9MJUgL9AMIgpAAJcQygER5JAAUgelAAAgobgGUg");
	this.shape_1368.setTransform(797.6745,379.4101);

	this.shape_1369 = new cjs.Shape();
	this.shape_1369.graphics.f("#FFFFFF").s().p("Eg70AmsUhIcgLtAf7gI4Qf7o4C736QC638dMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzbbHkQbbHir2MJUgL2AMJgpCAJYQyQEL4eAAUgeiAAAgoOgGfg");
	this.shape_1369.setTransform(802.1524,378.9606);

	this.shape_1370 = new cjs.Shape();
	this.shape_1370.graphics.f("#FFFFFF").s().p("Eg7bAmbUhHRgL7Ae1gImQe0onC536QC537dLHmQdLHmQOtfQQPtfRcIiQRcIhAOMzQANMybSHkQbSHjrvMJUgLvAMIgpDAJVQyBEG31AAUgeeAAAgn/gGsg");
	this.shape_1370.setTransform(806.6204,378.5284);

	this.shape_1371 = new cjs.Shape();
	this.shape_1371.graphics.f("#FFFFFF").s().p("Eg7CAmLUhGFgMJAdtgIVQduoVC336QC338dMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzbJHkQbIHiroMJUgLoAMJgpEAJRQxzEA3PAAUgeYAAAgnugG3g");
	this.shape_1371.setTransform(811.0776,378.093);

	this.shape_1372 = new cjs.Shape();
	this.shape_1372.graphics.f("#FFFFFF").s().p("Eg6qAl6UhE5gMXAcngIEQcmoDC236QC238dLHnQdLHmQOtfQQPtgRcIiQRcIiAOMyQANMzbAHjQa/HjrhMJUgLhAMJgpFAJNQxkD82pAAUgeUAAAgndgHEg");
	this.shape_1372.setTransform(815.5336,377.6703);

	this.shape_1373 = new cjs.Shape();
	this.shape_1373.graphics.f("#FFFFFF").s().p("Eg6RAlpUhDtgMlAbggHyQbfnyC036QC038dMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMza2HjQa2HjraMJUgLaAMJgpGAJKQxWD32DAAUgeQAAAgnKgHRg");
	this.shape_1373.setTransform(819.9673,377.2521);

	this.shape_1374 = new cjs.Shape();
	this.shape_1374.graphics.f("#FFFFFF").s().p("Eg54AlYUhChgMyAaZgHhQaZnhCy36QCy37dMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMyatHjQasHkrSMJUgLTAMIgpIAJHQxHDy1gAAUgeLAAAgm2gHeg");
	this.shape_1374.setTransform(824.3979,376.8385);

	this.shape_1375 = new cjs.Shape();
	this.shape_1375.graphics.f("#FFFFFF").s().p("Eg5gAlHUhBVgNAAZSgHPQZSnQCx36QCx37dLHmQdLHmQOtfQQPtfRcIiQRcIhAOMzQANMyakHjQajHkrLMJUgLMAMIgpJAJDQw4Du09AAUgeGAAAgmjgHrg");
	this.shape_1375.setTransform(828.8042,376.413);

	this.shape_1376 = new cjs.Shape();
	this.shape_1376.graphics.f("#FFFFFF").s().p("Eg5HAk2UhAJgNOAYMgG+QYLm+Cv36QCv37dLHmQdLHmQOtfQQPtfRcIiQRcIhAOMzQANMyabHjQaaHkrFMJUgLEAMIgpLAJAQwqDp0bAAUgeCAAAgmMgH4g");
	this.shape_1376.setTransform(833.2061,376.0083);

	this.shape_1377 = new cjs.Shape();
	this.shape_1377.graphics.f("#FFFFFF").s().p("Eg4tAklUg+9gNcAXEgGsQXEmtCu36QCt37dMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMyaRHjQaRHkq+MJUgK9AMIgpMAI8QwcDlz7AAUgd9AAAgl0gIFg");
	this.shape_1377.setTransform(837.5807,375.6078);

	this.shape_1378 = new cjs.Shape();
	this.shape_1378.graphics.f("#FFFFFF").s().p("Eg4TAkUUg9ygNqAV+gGbQV9mbCs36QCs37dLHmQdLHmQOtfQQPtfRcIiQRcIhAOMzQANMyaIHjQaIHkq3MJUgK2AMIgpNAI5QwPDgzbAAUgd4AAAglbgISg");
	this.shape_1378.setTransform(841.937,375.2114);

	this.shape_1379 = new cjs.Shape();
	this.shape_1379.graphics.f("#FFFFFF").s().p("Eg36AkDUg8lgN4AU2gGJQU3mKCq36QCq37dMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMyZ/HjQZ+HkqwMJUgKvAMIgpOAI1QwCDcy+AAUgdyAAAglBgIfg");
	this.shape_1379.setTransform(846.2741,374.8098);

	this.shape_1380 = new cjs.Shape();
	this.shape_1380.graphics.f("#FFFFFF").s().p("Eg3gAjyUg7agOGATwgF4QTwl4Co36QCp37dLHmQdLHmQOtfQQPtfRcIiQRcIhAOMzQANMyZ2HjQZ1HkqpMJUgKoAMIgpPAIxQv1DYyfAAUgdtAAAgkngIsg");
	this.shape_1380.setTransform(850.6021,374.4095);

	this.shape_1381 = new cjs.Shape();
	this.shape_1381.graphics.f("#FFFFFF").s().p("Eg3GAjhUg6NgOUASpgFmQSolnCo36QCm37dMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMyZsHjQZsHkqiMJUgKhAMIgpRAIuQvoDTyCAAUgdoAAAgkLgI5g");
	this.shape_1381.setTransform(854.8952,374.0249);

	this.shape_1382 = new cjs.Shape();
	this.shape_1382.graphics.f("#FFFFFF").s().p("Eg2sAjPUg5BgOhARigFVQRilVCl36QCm37dLHmQdLHmQOtfQQPtfRcIhQRcIiANMzQAOMyZjHjQZiHkqaMIUgKaAMJgpSAIqQvbDPxnAAUgdiAAAgjvgJHg");
	this.shape_1382.setTransform(859.1592,373.6332);

	this.shape_1383 = new cjs.Shape();
	this.shape_1383.graphics.f("#FFFFFF").s().p("Eg2PAjaUg6FgOYASXgFcQSXldC139QCz39dMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMyYoHPQYnHPpyMZUgJxAMYgo/AIuQvhDUx9AAUgdfAAAgkIgI8g");
	this.shape_1383.setTransform(849.4699,373.6208);

	this.shape_1384 = new cjs.Shape();
	this.shape_1384.graphics.f("#FFFFFF").s().p("Eg1yAjkUg7JgONATMgFlQTNllDD3+QDC4AdMHmQdLHmQOtfQQOtfRdIiQRcIhANMzQAOMyXsG7QXtG6pJMoUgJIAMogouAI0QvlDYySAAUgdeAAAgkhgIyg");
	this.shape_1384.setTransform(839.7804,373.6068);

	this.shape_1385 = new cjs.Shape();
	this.shape_1385.graphics.f("#FFFFFF").s().p("Eg1VAjvUg8OgODAUDgFsQUCluDR4BQDR4CdMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzWxGnQWxGlofM4UgIgAM3gobAI4QvrDcypAAUgdcAAAgk4gImg");
	this.shape_1385.setTransform(830.072,373.5902);

	this.shape_1386 = new cjs.Shape();
	this.shape_1386.graphics.f("#FFFFFF").s().p("Eg04Aj6Ug9SgN5AU4gF1QU4l1Dg4DQDf4FdMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzV2GSQV2GSn3NGUgH2ANHgoJAI9QvwDhzBAAUgdaAAAglPgIbg");
	this.shape_1386.setTransform(820.3676,373.577);

	this.shape_1387 = new cjs.Shape();
	this.shape_1387.graphics.f("#FFFFFF").s().p("Eg0bAkEUg+WgNuAVtgF9QVtl+Dv4FQDu4HdMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzU7F+QU7F9nONWUgHOANWgn2AJCQv2DmzZAAUgdZAAAglkgIRg");
	this.shape_1387.setTransform(810.6669,373.5673);

	this.shape_1388 = new cjs.Shape();
	this.shape_1388.graphics.f("#FFFFFF").s().p("Egz+AkOUg/agNkAWjgGFQWimGD94HQD94JdMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzUAFqQUAFomlNmUgGlANlgnlAJIQv6DqzwAAUgdZAAAgl6gIHg");
	this.shape_1388.setTransform(800.9935,373.566);

	this.shape_1389 = new cjs.Shape();
	this.shape_1389.graphics.f("#FFFFFF").s().p("EgzhAkZUhAegNaAXYgGNQXYmOEM4KQEL4LdMHnQdLHmQOtfQQOtgRdIiQRcIiANMyQAOMzTFFVQTEFVl8N1UgF8AN1gnSAJMQv/Dv0KAAUgdYAAAgmOgH8g");
	this.shape_1389.setTransform(791.2918,373.5632);

	this.shape_1390 = new cjs.Shape();
	this.shape_1390.graphics.f("#FFFFFF").s().p("EgzFAkjUhBhgNPAYNgGWQYNmWEb4MQEa4NdLHnQdLHmQOtfQQPtgRcIiQRcIiAOMyQANMzSKFBQSKFAlUOFUgFTAOEgnAAJRQwED00lAAUgdWAAAgmigHyg");
	this.shape_1390.setTransform(781.6228,373.564);

	this.shape_1391 = new cjs.Shape();
	this.shape_1391.graphics.f("#FFFFFF").s().p("EgyoAktUhCmgNEAZCgGeQZDmeEp4OQEp4QdMHnQdKHmQPtfQQOtgRdIiQRcIiANMyQAOMzROEtQRPErkqOUUgEqAOUgmuAJWQwJD50+AAUgdWAAAgm2gHog");
	this.shape_1391.setTransform(771.9509,373.5727);

	this.shape_1392 = new cjs.Shape();
	this.shape_1392.graphics.f("#FFFFFF").s().p("EgyMAk4UhDqgM7AZ4gGlQZ4mnE44QQE44SdLHnQdKHmQPtfQQPtgRcIiQRcIiAOMyQANMzQUEYQQTEXkBOkUgEBAOjgmcAJbQwOD+1aAAUgdVAAAgnIgHdg");
	this.shape_1392.setTransform(762.317,373.5806);

	this.shape_1393 = new cjs.Shape();
	this.shape_1393.graphics.f("#FFFFFF").s().p("EgxvAlCUhEugMwAatgGuQaumuFG4TQFG4UdMHnQdKHmQPtfQQOtgRdIiQRcIiANMyQAOMzPYEEQPYEDjYOzUgDYAOzgmKAJfQwSED13AAUgdVAAAgnYgHTg");
	this.shape_1393.setTransform(752.6896,373.5923);

	this.shape_1394 = new cjs.Shape();
	this.shape_1394.graphics.f("#FFFFFF").s().p("EgxUAlMUhFygMmAbjgG2Qbjm2FV4VQFV4WdLHmQdKHmQPtfQQPtfRcIiQRcIhAOMzQANMyOdDwQOeDviwPCUgCvAPCgl4AJlQwWEJ2TAAUgdVAAAgnqgHKg");
	this.shape_1394.setTransform(743.1367,373.6112);

	this.shape_1395 = new cjs.Shape();
	this.shape_1395.graphics.f("#FFFFFF").s().p("Egw5AlWUhG2gMbAcYgG+QcYm/Fk4XQFk4YdLHmQdKHmQPtfQQPtfRcIiQRcIhAOMzQANMyNiDcQNiDbiGPRUgCHAPSgllAJpQwbEO2xAAUgdVAAAgn5gHAg");
	this.shape_1395.setTransform(733.6096,373.6302);

	this.shape_1396 = new cjs.Shape();
	this.shape_1396.graphics.f("#FFFFFF").s().p("EgweAlgUhH6gMRAdNgHGQdOnHFz4ZQFy4bdLHnQdKHmQPtfQQPtgRcIiQRcIiAOMyQANMzMnDHQMnDHhePgUgBdAPhglTAJvQwgET3RAAUgdUAAAgoHgG2g");
	this.shape_1396.setTransform(724.1474,373.6532);

	this.shape_1397 = new cjs.Shape();
	this.shape_1397.graphics.f("#FFFFFF").s().p("EgwFAlrUhI+gMHAeDgHOQeDnQGC4bQGA4ddMHnQdKHmQPtfQQOtgRdIiQRcIiANMyQAOMzLsCyQLrCzg1PwUgA0APxglBAJzQwkEY3xAAUgdVAAAgoUgGrg");
	this.shape_1397.setTransform(714.7811,373.6801);

	this.shape_1398 = new cjs.Shape();
	this.shape_1398.graphics.f("#FFFFFF").s().p("EgvtAl0UhKCgL8Ae4gHWQe5nYGQ4dQGP4fdMHmQdKHmQPtfQQOtfRdIiQRcIhANMzQAOMyKwCfQKxCegMP/UgAMAQAgkuAJ5QwoEe4QAAUgdWAAAgoigGjg");
	this.shape_1398.setTransform(705.5824,373.7133);

	this.shape_1399 = new cjs.Shape();
	this.shape_1399.graphics.f("#FFFFFF").s().p("EgvWAl+UhLHgLxAfugHfQfunfGe4gQGf4hdLHmQdKHmQPtfQQPtfRcIhQRcIiAOMzQANMyJ2CKQJ1CKAdQPUAAdAQQgkcAJ8QwsEk4zAAUgdVAAAgotgGZg");
	this.shape_1399.setTransform(696.5346,373.7308);

	this.shape_1400 = new cjs.Shape();
	this.shape_1400.graphics.f("#FFFFFF").s().p("EgueAlsUhL2gNTAfsgHiQftnjGe4gQGe4hdGFJQdEFHOeppQOdppS2GsQS2GrATNfQATNfJ8CEQJ8CFAtQJUAAuAQJgjqALeQwiFU5KAAUgdHAAAgosgHHg");
	this.shape_1400.setTransform(554.1012,385.976);

	this.shape_1401 = new cjs.Shape();
	this.shape_1401.graphics.f("#FFFFFF").s().p("EgtmAlaUhMmgOzAfrgHmQfsnmGe4gQGe4hdACqQc+CqMsl0QMsl0UQE2QUPE2AZOLQAYOLKDCAQKDB/A+QCUAA9AQDgi3ANAQwUGF5dAAUgc7AAAgoxgH3g");
	this.shape_1401.setTransform(411.7065,398.103);

	this.shape_1402 = new cjs.Shape();
	this.shape_1402.graphics.f("#FFFFFF").s().p("EgsuAlMUhNWgQSAfqgHqQfqnqGf4gQGe4hc6AMQc4AMK7h+QK7h+VpDAQVoC/AeO4QAfO3KJB7QKKB6BOP8UABOAP8giGAOiQwEG25rAAUgcyAAAgo5gIog");
	this.shape_1402.setTransform(269.3125,409.7667);

	this.shape_1403 = new cjs.Shape();
	this.shape_1403.graphics.f("#FFFFFF").s().p("Egr2AmOUhOFgRzAfogHtQfpnuGe4gQGe4hc1iSQcyiSJKB4QJJB3XDBKQXCBKAjPjQAkPkKRB1QKQB2BfP1UABeAP2ghUAQDQvzHm53AAUgcqAABgpEgJXg");
	this.shape_1403.setTransform(126.9374,413.5957);

	this.shape_1404 = new cjs.Shape();
	this.shape_1404.graphics.f("#FFFFFF").s().p("Egq+AoVUhO1gTTAfngHxQfonxGe4gQGe4hcukwQctkwHYFtQHYFuYcgsQYcgtApQQQAqQQKXBwQKXBwBvPvUABuAPvgghARlQvgIY6BAAUgckAAAgpRgKHg");
	this.shape_1404.setTransform(-15.4599,410.3584);

	this.shape_1405 = new cjs.Shape();
	this.shape_1405.graphics.f("#FFFFFF").s().p("EgqGAqfUhPlgU0AfmgH0Qfmn0Gf4gQGe4hconPQcnnOFnJjQFmJkZ2ijQZ1iiAvQ8QAvQ8KeBrQKeBrB/PpQB/Po/wTHQvMJI6JAAUgcfAAAgpfgK2g");
	this.shape_1405.setTransform(-157.8578,406.9441);

	this.shape_1406 = new cjs.Shape();
	this.shape_1406.graphics.f("#FFFFFF").s().p("EgpPAspUhQVgWVAflgH3Qfln4Ge4gQGe4hcjptQchpsD1NZQD2NZbPkZQbPkYA0RpQA0RoKmBmQKkBmCPPiQCPPi+9UoQu3J56RAAUgcaAABgpvgLmg");
	this.shape_1406.setTransform(-300.1982,403.5361);

	this.shape_1407 = new cjs.Shape();
	this.shape_1407.graphics.f("#FFFFFF").s().p("EgoYAuyUhREgX0AfjgH7Qfkn8Ge4gQGe4hcdsKQcbsLCFRPQCERPcomPQcpmOA5SVQA6SUKsBhQKsBhCfPbQCgPc+MWJQuiKr6XAAUgcWAAAgqAgMWg");
	this.shape_1407.setTransform(-442.5323,400.0889);

	this.shape_1408 = new cjs.Shape();
	this.shape_1408.graphics.f("#FFFFFF").s().p("EgnhAw8UhR0gZVAfigH/Qfjn/Ge4gQGe4hcXupQcVuoATVEQATVFeCoFQeCoEA/TBQBATBKzBcQKyBbCwPVQCvPW9ZXrQuMLb6cAAUgcTAAAgqSgNFg");
	this.shape_1408.setTransform(-584.8457,396.6662);

	this.shape_1409 = new cjs.Shape();
	this.shape_1409.graphics.f("#FFFFFF").s().p("EgmpAzGUhSkga1AfhgIDQfhoCGe4gQGe4hcRxHQcQxHhfY6QheY7fbp7Qfcp6BFTtQBFTtK5BXQK5BWDAPPQDAPP8nZMQt3MN6gAAUgcPAAAgqkgN1g");
	this.shape_1409.setTransform(-727.1789,393.2187);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1311}]},25).to({state:[{t:this.shape_1312}]},1).to({state:[{t:this.shape_1313}]},1).to({state:[{t:this.shape_1314}]},1).to({state:[{t:this.shape_1315}]},1).to({state:[{t:this.shape_1316}]},1).to({state:[{t:this.shape_1317}]},1).to({state:[{t:this.shape_1318}]},1).to({state:[{t:this.shape_1319}]},1).to({state:[{t:this.shape_1320}]},1).to({state:[{t:this.shape_1321}]},1).to({state:[{t:this.shape_1322}]},1).to({state:[{t:this.shape_1323}]},1).to({state:[{t:this.shape_1324}]},1).to({state:[{t:this.shape_1325}]},1).to({state:[{t:this.shape_1326}]},1).to({state:[{t:this.shape_1327}]},1).to({state:[{t:this.shape_1328}]},1).to({state:[{t:this.shape_1329}]},1).to({state:[{t:this.shape_1330}]},1).to({state:[{t:this.shape_1331}]},1).to({state:[{t:this.shape_1332}]},1).to({state:[{t:this.shape_1333}]},1).to({state:[{t:this.shape_1334}]},1).to({state:[{t:this.shape_1335}]},1).to({state:[{t:this.shape_1336}]},1).to({state:[{t:this.shape_1337}]},1).to({state:[{t:this.shape_1338}]},1).to({state:[{t:this.shape_1339}]},1).to({state:[{t:this.shape_1340}]},1).to({state:[{t:this.shape_1341}]},1).to({state:[{t:this.shape_1342}]},1).to({state:[{t:this.shape_1343}]},1).to({state:[{t:this.shape_1344}]},1).to({state:[{t:this.shape_1345}]},1).to({state:[{t:this.shape_1346}]},1).to({state:[{t:this.shape_1347}]},1).to({state:[{t:this.shape_1348}]},1).to({state:[{t:this.shape_1349}]},1).to({state:[{t:this.shape_1350}]},1).to({state:[{t:this.shape_1351}]},1).to({state:[{t:this.shape_1352}]},1).to({state:[{t:this.shape_1353}]},1).to({state:[{t:this.shape_1354}]},1).to({state:[{t:this.shape_1355}]},1).to({state:[{t:this.shape_1356}]},1).to({state:[{t:this.shape_1357}]},1).to({state:[{t:this.shape_1358}]},1).to({state:[{t:this.shape_1359}]},1).to({state:[{t:this.shape_1360}]},1).to({state:[{t:this.shape_1361}]},1).to({state:[{t:this.shape_1362}]},1).to({state:[{t:this.shape_1363}]},1).to({state:[{t:this.shape_1364}]},1).to({state:[{t:this.shape_1365}]},1).to({state:[{t:this.shape_1366}]},1).to({state:[{t:this.shape_1367}]},1).to({state:[{t:this.shape_1368}]},1).to({state:[{t:this.shape_1369}]},1).to({state:[{t:this.shape_1370}]},1).to({state:[{t:this.shape_1371}]},1).to({state:[{t:this.shape_1372}]},1).to({state:[{t:this.shape_1373}]},1).to({state:[{t:this.shape_1374}]},1).to({state:[{t:this.shape_1375}]},1).to({state:[{t:this.shape_1376}]},1).to({state:[{t:this.shape_1377}]},1).to({state:[{t:this.shape_1378}]},1).to({state:[{t:this.shape_1379}]},1).to({state:[{t:this.shape_1380}]},1).to({state:[{t:this.shape_1381}]},1).to({state:[{t:this.shape_1382}]},1).to({state:[{t:this.shape_1382}]},1).to({state:[{t:this.shape_1383}]},1).to({state:[{t:this.shape_1384}]},1).to({state:[{t:this.shape_1385}]},1).to({state:[{t:this.shape_1386}]},1).to({state:[{t:this.shape_1387}]},1).to({state:[{t:this.shape_1388}]},1).to({state:[{t:this.shape_1389}]},1).to({state:[{t:this.shape_1390}]},1).to({state:[{t:this.shape_1391}]},1).to({state:[{t:this.shape_1392}]},1).to({state:[{t:this.shape_1393}]},1).to({state:[{t:this.shape_1394}]},1).to({state:[{t:this.shape_1395}]},1).to({state:[{t:this.shape_1396}]},1).to({state:[{t:this.shape_1397}]},1).to({state:[{t:this.shape_1398}]},1).to({state:[{t:this.shape_1399}]},1).to({state:[{t:this.shape_1400}]},1).to({state:[{t:this.shape_1401}]},1).to({state:[{t:this.shape_1402}]},1).to({state:[{t:this.shape_1403}]},1).to({state:[{t:this.shape_1404}]},1).to({state:[{t:this.shape_1405}]},1).to({state:[{t:this.shape_1406}]},1).to({state:[{t:this.shape_1407}]},1).to({state:[{t:this.shape_1408}]},1).to({state:[{t:this.shape_1409}]},1).to({state:[]},2).wait(1182));

	// Каркас_9
	this.shape_1410 = new cjs.Shape();
	this.shape_1410.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABxAgQgMAvgrAYQgrAYgugOQgvgMgYgrQgYgqANgvQANguArgZQArgYAtAOQAwAMAYArQAYArgOAug");
	this.shape_1410.setTransform(734.8,306.5);

	this.shape_1411 = new cjs.Shape();
	this.shape_1411.graphics.f().s("#232323").ss(7,1,1).p("ACijbQgiAlgjAcIgSAeQg3CHhgBnQgmApgvAeQAOATAJAQIATgJQCjj2B2i4g");
	this.shape_1411.setTransform(961.65,499.15);

	this.shape_1412 = new cjs.Shape();
	this.shape_1412.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACTApQgRA+g3AeQg3Afg9gRQg8gRggg3Qgeg3AQg8QASg+A2gfQA4geA8ARQA9AQAfA3QAfA4gRA8g");
	this.shape_1412.setTransform(990.7083,337.7218);

	this.shape_1413 = new cjs.Shape();
	this.shape_1413.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGRBwQgvCmiWBVQiWBVilgvQingvhUiWQhViWAvilQAuinCWhUQCXhVClAvQCmAuBVCWQBVCXgvClg");
	this.shape_1413.setTransform(856.9615,423.8615);

	this.shape_1414 = new cjs.Shape();
	this.shape_1414.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB5AiQgNAygvAaQgtAZgxgOQgygNgaguQgZgtANgyQAPgyAtgaQAugZAxAOQAxANAaAuQAaAtgOAyg");
	this.shape_1414.setTransform(823.55,260.375);

	this.shape_1415 = new cjs.Shape();
	this.shape_1415.graphics.f().s("#232323").ss(8,1,1).p("Aikr6QASgTAMgfIAXhIICRjQQAggZAlgUIEjg5QAUACAUADQBsARBdA4QBQAvBEBMQAwA3ArBQIAtBaIAZglQgthkhPhgQjVkCk6ArQkGA8hkCIQhVCdgKBlgArITIQAJgJAMgHQgggvgVg8Qgah2gMh5QhGmog2m2QgTgXgSggQATCIATBkIASBdIBCGRIArEIQAEAvALAvIAUB+g");
	this.shape_1415.setTransform(788.75,333.5995);

	this.shape_1416 = new cjs.Shape();
	this.shape_1416.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABuAeQgNAugpAXQgpAYgtgNQgtgNgXgpQgXgqAMgsQANgtApgYQAqgXAsANQAuANAWApQAYAqgNArg");
	this.shape_1416.setTransform(925.3364,271.2583);

	this.shape_1417 = new cjs.Shape();
	this.shape_1417.graphics.f().s("#232323").ss(0.1,1,1).p("EAF7gpUQAdgnApgqQBxhvCYg4QCVgwChAqQCrA2BgCqQBTCfg2C9IgQAqIgFANIAOgJQB0hEB+ADQD+AHCREGQBQC1haDHQgKA8gOA5QgoCrg9ClQg8CbhPCTQhPCdhcCXQg+BihRBUIgcAjIgNAOA0WoMQgLg2AkgkIAPAfQA5BpBNBiIATAYQEfFgGzCYIAQAFQBIAYBLARQG3BiIMiXQChgtB8g7QAYAzgRAoQjwI4g2MJQg4MhC6KEMgslgAFQgdvjCisLQCgsDGHt8gATXkzQhHB8hRBzA3l9mQgihAgOhOQgJhIANhNQgTiZBdiZQB8izD1gPQBSAABNAfQAgAJAYAKQA6AZAuAnQACgBABAAQAagFAWgQIAKgHA1DvPQgmmvhXmv");
	this.shape_1417.setTransform(845.3311,517.4076);

	this.shape_1418 = new cjs.Shape();
	this.shape_1418.graphics.f("rgba(255,255,255,0.067)").s().p("ARGXqQAvgeAmgoQBhhoA3iIIASgdQAigcAjglQh2C4ikD2IgTAKQgJgRgOgTgAzANBIgVh+QAIAiAMAiQgMgigIgiQgKgvgFgvQgDgiAAghIAAgKIAAAKQAAAhADAiIgqkIIhCmQIgShdQgThkgUiJQATAgATAYQA2G1BGGoQAMB5AaB2QAVA8AgAvQgMAHgJAJgAzVLDIAAAAgAoe1CQBkiIEHg8QE4grDWECQBPBgAtBkIgZAlIgthaQgrhQgwg3QhEhMhQgvQhdg4hrgRIgpgFIkiA5QglAUggAZIiTDQIgWBIQgNAfgSATQALhlBVidg");
	this.shape_1418.setTransform(836.075,366.1995);

	this.shape_1419 = new cjs.Shape();
	this.shape_1419.graphics.f("#FFFFFF").s().p("Ai7QxQimgvhViWQhUiWAuimQAvinCWhUQCXhVCkAvQCnAuBUCWQBVCXgvCmQguCmiWBVQhhA2hmAAQg5AAg8gQgATEgpQg8gRggg4Qgeg2AQg+QASg9A2gfQA4gfA9ARQA9ARAfA3QAfA3gRA+QgRA9g3AfQgjAUgnAAQgVAAgWgGgA0wmDQgvgNgYgrQgYgqANgwQANguArgZQArgYAuAOQAwANAYAqQAYArgOAvQgMAvgrAYQgbAPgeAAQgQAAgRgEgAJBrnQgtgNgXgpQgXgqAMgtQANgtApgYQAqgXAtANQAuANAWApQAYAqgNAsQgNAugpAXQgbAPgcAAQgQAAgQgEgAm7tJQgxgNgaguQgagtAOgzQAOgyAtgaQAugZAyAOQAyANAaAuQAZAtgNAzQgOAyguAaQgdAQgfAAQgSAAgSgFg");
	this.shape_1419.setTransform(864.5049,356.6886);

	this.shape_1420 = new cjs.Shape();
	this.shape_1420.graphics.f("#232323").s().p("EgfCAuaQgdvjCisKQCgsDGHt8QgLg3AkgjIAPAeQA5BpBNBiIATAZQEfFfGzCYIAQAGQBIAYBLARIALACQCoAkCzAAIAAAAIAAAAQEeAAE8hbIADAAQChgtB8g7QAYAzgRAoQjwI3g2MKQg4MhC6KEgACGEiQizAAiogkIgLgCQhLgRhIgYIgQgGQmziYkflfIgTgZQhNhig5hpIgPgeQAJgJALgHQgfgvgWg8Qgah2gLh5QgmmvhXmvQgSgYgTggQgihBgOhNQgJhIANhOQgTiZBdiYQB8izD1gPQBSAABNAeQAgAJAYALQA6AZAuAmIADAAQAagFAWgQIAKgIQASgTANgfIAWhIICSjQQAggZAlgUIEjg5IAoAFQBtASBbA3QBQAvBEBMQAwA3ArBQIAtBaIAaglQAdgoApgqQBxhvCYg3QCVgxChArQCrA1BgCrQBTCfg2C8IgQArIgFAMIAOgJQB0hEB+ADQD+AICREGQBQC1haDGQgKA8gOA5QgoCrg9CmQg8CahPCTQhPCehcCXQg+BhhRBVIgcAiIgNAPQgiAlgjAcIgRAdQhHB8hRB0QgmAngwAeQAPATAIARQh8A7ihAtIgDAAQk8BbkeAAIAAAAIAAAAgAhXzYQiWBUgvCnQguCmBUCWQBVCWClAvQCmAvCXhVQCWhVAuimQAvimhViXQhUiWinguQg7gRg4AAQhoAAhgA3gAVi9QQg2AfgSA9QgQA+AeA2QAgA4A8ARQA+ARA3gfQA3gfARg9QARg+gfg3Qgfg3g9gRQgWgGgVAAQgmAAgkAUgEgSKghqQgrAZgNAuQgNAwAYAqQAYArAvANQAvANArgYQArgYAMgvQAOgvgYgrQgYgqgwgNQgRgFgQAAQgdAAgbAPgEALognHQgpAYgNAtQgMAtAXAqQAXApAtANQAuANApgYQApgXANguQANgsgYgqQgWgpgugNQgQgFgQAAQgcAAgbAPgEgEXgo+QgtAagOAyQgOAzAaAtQAaAuAxANQAzAOAtgZQAugaAOgyQANgzgZgtQgagugygNQgSgFgRAAQgfAAgeAQgAQABfIAAAAg");
	this.shape_1420.setTransform(845.3311,511.675);

	this.shape_1421 = new cjs.Shape();
	this.shape_1421.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB0AXQgKAvgoAcQgpAbgvgJQgwgJgbgpQgbgpAJgvQAJgwApgbQApgbAvAJQAwAKAbAoQAcAogKAwg");
	this.shape_1421.setTransform(708.2329,311.4);

	this.shape_1422 = new cjs.Shape();
	this.shape_1422.graphics.f().s("#232323").ss(7,1,1).p("ACSjmQggAoggAfIgPAeQgtCKhXBvQgjAtgtAhQAQAQAKARIASgLQCQkCBnjAg");
	this.shape_1422.setTransform(949.375,485.575);

	this.shape_1423 = new cjs.Shape();
	this.shape_1423.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACWAeQgMA+g1AjQg0Akg9gNQg/gMgjg1QgjgzAMg+QANg/A0gjQA0gjA+AMQA+ANAjAzQAkA2gNA9g");
	this.shape_1423.setTransform(965.7829,322.4423);

	this.shape_1424 = new cjs.Shape();
	this.shape_1424.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGZBQQgiCqiPBgQiQBginghQiqgihgiPQhgiQAhioQAhioCQhhQCPhgCoAhQCqAhBgCQQBgCPghCog");
	this.shape_1424.setTransform(839.2155,418.8138);

	this.shape_1425 = new cjs.Shape();
	this.shape_1425.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABwAWQgJAvgnAaQgoAbgtgKQgugJgagnQgbgoAJgtQAJguAogaQAogbAsAJQAvAJAaAoQAbAogKAsg");
	this.shape_1425.setTransform(895.4,261.3);

	this.shape_1426 = new cjs.Shape();
	this.shape_1426.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB8AYQgLAzgrAdQgrAegygKQgzgLgdgrQgdgrAJgyQALgzArgeQArgcAyAJQAzAKAeAsQAcArgJAyg");
	this.shape_1426.setTransform(793.0765,258.4828);

	this.shape_1427 = new cjs.Shape();
	this.shape_1427.graphics.f().s("#232323").ss(8,1,1).p("Ai+r3QAQgUALghIAQhJICIjgQAagYAggVIEwhPQALABALAAIDjBDQBIAoBBA9QA0A0AxBLQAVAgAeA3IAXgnQg1hhhWhZQjpjwk1BDQkABQhZCPQhJClgDBlgApETvQAJgJALgIQgkgtgZg6QgkhzgVh3QhnmhhZmxQgVgXgUgfQAeCIAcBiIAZBbIBgGLQAhCGAgCGQAIAoAMAnQAQBBAPBBg");
	this.shape_1427.setTransform(760.75,335.4036);

	this.shape_1428 = new cjs.Shape();
	this.shape_1428.graphics.f().s("#232323").ss(0.1,1,1).p("EADBgphQAbgqAlgtQBnh3CUhDQCRg9CkAeQCuAnBuCjQBeCZgmDAIgNArIgDANIANgKQBthNB+gHQD/gMClD6QBdCthJDOQgGA9gJA5QgbCugwCqQgwCehDCZQhCCjhQCeQg2BnhKBaIgaAkIgLAQATSmLQg8CBhJB5A0kmcQgOg1AggmIARAdQBCBkBUBcIAVAXQE6FHG9B2IARAEQBKATBMALQG+A+H9i/QCdg5B3hEQAbAwgMApQiiJ8gYMOQgZMmCPK0MgslgAGQgJupCDsUQCDsMEitogA5e7hQgng9gThNQgQhGAHhPQgeiXBRigQBti8DzgiQBSgGBPAYQAgAGAZAJQA8AVAxAiQACAAABgBQAZgGAVgSIAJgJA10taQhImrh4mn");
	this.shape_1428.setTransform(832.6263,512.1528);

	this.shape_1429 = new cjs.Shape();
	this.shape_1429.graphics.f("#FFFFFF").s().p("AhLQpQipgihgiPQhhiQAiipQAhioCPhhQCQhgCoAhQCpAhBgCQQBgCPghCpQghCqiPBgQhrBHh5AAQgpAAgrgIgATZidQg/gMgjg1QgjgzAMg/QANg/A0gjQA0gjA/AMQA+ANAjAzQAkA2gNA+QgMA+g1AjQgnAbgsAAQgPAAgQgEgA0vktQgwgKgcgoQgbgpAKgwQAJgwApgbQAogbAwAJQAwAKAbAoQAcAogKAxQgJAvgpAcQgeAUgjAAQgLAAgMgCgAIgsmQgugJgagoQgbgnAJguQAJgvAogaQAogbAtAKQAvAJAaAnQAbAogKAuQgJAugnAaQgdAUghAAQgMAAgMgCgAngs3QgzgKgdgrQgdgsAJgzQALgzArgdQArgdAzAKQAzAKAeArQAcArgJA0QgLAzgrAdQggAWglAAQgMAAgNgDg");
	this.shape_1429.setTransform(838.7625,353.2033);

	this.shape_1430 = new cjs.Shape();
	this.shape_1430.graphics.f("rgba(255,255,255,0.067)").s().p("ASdW5QAsghAjgtQBYhvAtiLIAPgeQAggfAggoQhnDAiQEDIgTALQgKgRgPgQgAyXPHIggiCQALAlAOAjQgOgjgLglQgMgngIgoQgHgpgDgrQADArAHApIhBkMIhhmLIgZhaQgahhgfiIQAVAeAVAXQBYGwBoGhQAUB4AjBzQAaA5AkAtQgLAIgIAKgAy3NFIAAAAgAqjzrQBaiPEBhRQE0hCDpDwQBWBYA1BhIgXAoQgfg4gUgfQgyhMg0g0QhAg9hIgnIjihDIgWgCIkwBPQggAWgbAYIiHDgIgRBJQgKAggRAUQADhlBIikg");
	this.shape_1430.setTransform(816.75,358.8786);

	this.shape_1431 = new cjs.Shape();
	this.shape_1431.graphics.f("#232323").s().p("EgdDAukQgJupCDsUQCDsMEitoQgOg1AggmIARAdQBCBkBUBcIAVAXQE6FHG9B2IARAEQBKATBMALIAHABQBqAOBuAAIAAAAIAAAAQFVAAF2iJIANgFIAEgCQCdg5B3hEQAbAwgMApQiiJ8gYMOQgZMmCPK0gAAnD6QhuAAhqgOIgHgBQhMgLhKgTIgRgEQm9h2k6lHIgVgXQhUhchChkIgRgdQAIgKALgIQgkgtgZg5QgkhzgUh4QhImrh4mnQgVgXgVgeQgng9gThNQgQhGAHhPQgeiXBRigQBti8DzgiQBSgGBPAYQAgAGAZAJQA8AVAxAiIADgBQAZgGAVgSIAJgJQARgUAKggIARhJICHjgQAbgYAggWIEwhOIAWABIDjBDQBIAnBAA9QA0A0AxBMQAVAfAfA4IAWgoQAbgqAlgtQBnh3CUhDQCRg9CkAeQCuAnBuCjQBeCZgmDAIgNArIgDANIANgKQBthNB+gHQD/gMClD6QBdCthJDOQgGA9gJA5QgbCugwCqQgwCehDCZQhCCjhQCeQg2BnhKBaIgaAkIgLAQQgfAoghAfIgPAeQg8CBhJB5QgiAtgtAhQAQAQAJARQh3BEidA5IgEACIgNAFQl2CJlVAAIAAAAIAAAAgAilzwQiQBhghCpQghCpBgCQQBgCPCqAhQCnAhCQhgQCPhgAiipQAhiphgiQQhgiPiqghQgrgJgqAAQh4AAhqBHgATe/ZQg0AjgNA/QgMA/AjA0QAjA1A/AMQA+AMA1gkQA0giANg/QAMg+gkg1Qgig0g/gNQgPgCgPAAQgtAAgoAZgEgUdggqQgpAcgJAwQgJAwAbAoQAbApAwAJQAwAJApgbQAogbAKgwQAKgwgcgpQgbgogwgKQgMgCgMAAQgiAAgfAUgEAI0gobQgnAagJAuQgKAuAbAoQAaAnAvAJQAuAKAngbQAogaAJgvQAJgtgbgoQgagogugJQgMgCgMAAQggAAgeAUgEgHRgpCQgrAegKAzQgKAzAdArQAdArAzALQAzAKAsgeQArgdAKgzQAKgzgdgrQgdgsgzgKQgNgCgMAAQglAAghAVgAQXgTIAAAAg");
	this.shape_1431.setTransform(832.6263,510.6625);

	this.shape_1432 = new cjs.Shape();
	this.shape_1432.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB1AOQgGAxgmAeQgmAegwgGQgwgFgfgnQgegmAGgvQAFgxAngeQAmgfAvAGQAxAGAeAmQAfAmgGAwg");
	this.shape_1432.setTransform(682.131,318.3756);

	this.shape_1433 = new cjs.Shape();
	this.shape_1433.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB9AOQgGA0gpAgQgpAhgzgGQgzgGghgpQgggpAGgzQAGgzApghQAoggAzAGQA0AGAgApQAhAogGAzg");
	this.shape_1433.setTransform(762.5564,258.9564);

	this.shape_1434 = new cjs.Shape();
	this.shape_1434.graphics.f().s("#232323").ss(7,1,1).p("ACAjwQgcAsgeAgIgNAgQghCNhOB2QgfAugqAlQARAPALAQIARgMQB7kNBXjIg");
	this.shape_1434.setTransform(936.075,472.95);

	this.shape_1435 = new cjs.Shape();
	this.shape_1435.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGeAwQgUCsiHBrQiIBriqgUQirgUhriHQhriIATiqQAVirCHhsQCHhrCqAUQCrAUBsCHQBrCIgUCqg");
	this.shape_1435.setTransform(821.1389,415.1817);

	this.shape_1436 = new cjs.Shape();
	this.shape_1436.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABxANQgFAwglAcQgmAegtgGQgvgFgdglQgdgmAFgtQAFgvAlgdQAmgdAtAFQAvAGAdAkQAeAmgGAtg");
	this.shape_1436.setTransform(864.7882,253.7382);

	this.shape_1437 = new cjs.Shape();
	this.shape_1437.graphics.f().s("#232323").ss(8,1,1).p("AjXrtQAPgWAIghIALhKIB8jxQAXgWAagVIEMhkQAYgDAaAAIDfAuQBPAiBKA7QA3AvA4BIIA5BSIAUgpQg8hchdhSQj8jdkvBbQj5BkhNCWQg8CpAFBmgAm8URQAHgKALgJQgngpgeg4Qgthwgdh2QiImXh7mpQgWgVgXgdQApCFAiBgQAUA0AMAkICAGCQArCDArCDQALApAPAnQAVA+AUA/g");
	this.shape_1437.setTransform(732.9,338.9626);

	this.shape_1438 = new cjs.Shape();
	this.shape_1438.graphics.f().s("#232323").ss(0.1,1,1).p("EABFgphQAXgsAigvQBdiACPhOQCLhICmARQCxAaB6CZQBqCRgXDCQgEAXgGAWIgCANIAMgMQBnhVB+gQQD8ghC5DsQBqCmg5DTQgBA9gFA6QgMCvgjCtQgjCig3CeQg1CohDCjQguBqhDBgIgXAnIgKAQAUEnkQgxCFg/B/ANdAlQisBRj2BGQDxg9CxhaQCZhEBxhOQAfAvgKAqQhOK4AHMRQAHMpBmLnMgslgAIQAPtxBlsaQBksTDAtLQgTg0AegpIATAcQBJBfBbBVIAXAVQFTEuHFBSIARADQBLAMBNAGAG7C8QjyA8kagHQEVAQD3hFgA6O5VQgrg5gahMQgVhEABhPQgqiVBEilQBejEDvg1QBRgNBSASQAgAEAZAHQA9APA1AfIACgBQAZgJATgTIAJgJA1erjQhpmkiZmc");
	this.shape_1438.setTransform(813.3554,508.0539);

	this.shape_1439 = new cjs.Shape();
	this.shape_1439.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACYASQgIBAgxAmQgyAng+gHQg/gHgogyQgmgxAHg+QAHhAAxgnQAzgnA9AHQBAAIAmAxQAoAygHA+g");
	this.shape_1439.setTransform(939.7617,309.15);

	this.shape_1440 = new cjs.Shape();
	this.shape_1440.graphics.f("rgba(255,255,255,0.067)").s().p("ATsWAQArglAeguQBQh2AhiOIANggQAdggAdgsQhXDJh8ENIgSAMQgKgQgSgPgAxnRJIgqh9QAOAiARAiQgRgigOgiQgPgngLgoQgLgpgGgqQAGAqALApIhWkGIh/mCQgMglgVgzQgihggpiEQAXAdAXAVQB6GnCIGYQAdB2AtBwQAeA4AnApQgKAIgIALgAyRPMIAAAAgAsjyJQBOiWD5hkQEvhcD7DeQBdBSA8BcIgTApIg7hTQg3hHg3gwQhJg7hPgiIjfgtQgaAAgYACIkNBlQgaAUgXAWIh8DyIgLBJQgHAigPAVQgFhlA7ipg");
	this.shape_1440.setTransform(797.2,353.1376);

	this.shape_1441 = new cjs.Shape();
	this.shape_1441.graphics.f("#FFFFFF").s().p("AAlQtQirgThriIQhriHAUisQAUirCHhrQCHhrCrAUQCrATBrCIQBsCIgVCqQgTCsiIBrQhyBbiLAAQgaAAgbgEgA0mjCQgwgFgfgnQgegmAFgxQAGgwAmgfQAngeAwAFQAxAGAeAmQAfAngGAwQgGAxgmAeQghAagoAAIgOgBgATlj8Qg/gHgogyQgmgxAHg/QAHhAAxgnQAzgnA+AHQBAAIAmAxQAoAygHA/QgIBAgxAmQgqAig0AAIgTgCgAoDsNQgzgGghgpQgggoAGg0QAGg0ApggQAoggA0AFQA0AGAgApQAhApgGA0QgGA0gpAgQgjAbgqAAIgQgBgAH8tNQgvgFgdglQgdgmAFguQAFgvAlgdQAmgdAuAFQAvAGAdAkQAeAmgGAuQgFAwglAcQggAZglAAIgPgBg");
	this.shape_1441.setTransform(812.6916,349.6024);

	this.shape_1442 = new cjs.Shape();
	this.shape_1442.graphics.f("#232323").s().p("EgaDAu9QAPtxBlsaQBksTDAtLQgTg0AegpIATAcQBJBfBbBVIAXAVQFTEuHFBSIARADQBLAMBNAGQhNgGhLgMIgRgDQnFhSlTkuIgXgVQhbhVhJhfIgTgcQAHgKAKgJQgngpgeg4Qgshwgeh2QhpmkiZmcQgXgVgXgdQgrg5gahMQgVhEABhPQgqiVBEilQBejEDvg1QBRgNBSASQAgAEAZAHQA9APA1AfIACgBQAZgJATgTIAJgJQAPgWAIghIAKhKIB9jxQAWgWAagVIENhkQAZgCAZgBIDfAuQBQAiBJA7QA3AvA4BIIA5BSIATgpQAXgsAigvQBdiACPhOQCLhICmARQCxAaB6CZQBqCRgXDCQgEAXgGAWIgCANIAMgMQBnhVB+gQQD8ghC5DsQBqCmg5DTQgBA9gFA6QgMCvgjCtQgjCig3CeQg1CohDCjQguBqhDBgIgXAnIgKAQQgcArgeAhIgNAfQgxCFg/B/QgfAvgqAlQARAPALAQQAfAvgKAqQhOK4AHMRQAHMpBmLngAG7C8QjyA8kagHQEVAQD3hFgAG7C8QDxg9CxhaQCZhEBxhOQhxBOiZBEQisBRj2BGIAAAAgAi0znQiHBsgUCrQgUCrBrCIQBrCHCrAUQCrAUCHhrQCIhrATisQAVirhsiIQhriHirgUQgbgDgaAAQiLAAhyBagA1p/EQgmAegGAxQgFAwAeAmQAfAnAwAFQAxAGAmgeQAmgeAGgxQAGgxgfgmQgegmgxgGIgOgBQgoAAghAagEASQgg8QgxAngHA/QgHA/AmAyQAoAxA/AIQA/AHAygnQAxgnAIhAQAHg+gogzQgmgxhAgHIgSgBQg0AAgrAhgEgJJgodQgpAhgGAzQgGA0AgApQAhApAzAGQA0AGApghQApggAGg0QAGg0ghgoQgggpg0gGIgPgBQgqAAgjAbgEAG7gpIQglAegFAvQgFAuAdAlQAdAmAvAFQAuAGAmgeQAlgdAFgvQAGgvgeglQgdglgvgGIgNAAQgnAAggAYg");
	this.shape_1442.setTransform(813.3554,508.0539);

	this.shape_1443 = new cjs.Shape();
	this.shape_1443.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB2AEQgCAxgjAhQgkAigwgCQgxgCghgkQgigkACgwQACgwAkgiQAkghAvACQAxACAiAjQAhAkgCAwg");
	this.shape_1443.setTransform(656.6476,327.4053);

	this.shape_1444 = new cjs.Shape();
	this.shape_1444.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB+AFQgCA0gnAjQglAkg0gCQgzgCgkgmQgjgmABg0QACgzAmgkQAngjAyABQA0ACAkAmQAkAngCAzg");
	this.shape_1444.setTransform(732.1539,261.85);

	this.shape_1445 = new cjs.Shape();
	this.shape_1445.graphics.f().s("#232323").ss(7,1,1).p("ABuj4QgYAtgcAjIgKAgQgWCQhFB7QgbAxgnAoQATAOALAPIARgOQBlkWBHjNg");
	this.shape_1445.setTransform(921.825,461.475);

	this.shape_1446 = new cjs.Shape();
	this.shape_1446.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGgAPQgGCth+B1Qh/B2irgHQitgGh1h/Qh2h+AHirQAHitB+h1QB/h2CqAHQCtAGB1B+QB2B/gHCrg");
	this.shape_1446.setTransform(802.8276,412.9776);

	this.shape_1447 = new cjs.Shape();
	this.shape_1447.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACZAGQgCBAgvAqQguArg/gCQg/gCgsgvQgqguACg/QACg/AugrQAvgrA+ACQBAADArAtQArAwgCA+g");
	this.shape_1447.setTransform(912.7523,297.9773);

	this.shape_1448 = new cjs.Shape();
	this.shape_1448.graphics.f().s("#232323").ss(8,1,1).p("AjtreQANgWAFgiIAFhKIBijyQAXgdAdgaIEeh9QALgCAMgBQBlgHBgAbIC8BZQA8ArA8BDQAaAcAnAyIAQgrQhDhXhkhKQkLjJkoBzQjwB3hBCbQguCuANBkgAkxUtQAGgLAKgKQgqgmgjg1Qg1hsgmhzQipmMiamdQgYgUgagbQA0CCAqBdIAmBVICeF3QA0B9A1B+QAPAqATAoQAZA8AZA8g");
	this.shape_1448.setTransform(705.35,344.269);

	this.shape_1449 = new cjs.Shape();
	this.shape_1449.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("AByAEQgCAwgjAfQgiAhgugCQgvgCghgjQgggiACguQACgvAighQAkggAtACQAwACAfAiQAhAkgCAtg");
	this.shape_1449.setTransform(833.6524,248.6024);

	this.shape_1450 = new cjs.Shape();
	this.shape_1450.graphics.f().s("#232323").ss(0.1,1,1).p("EAAWgpTQAUguAegyQBTiGCHhaQCHhTCmAFQCyAMCGCPQB1CIgIDDIgGAtIgBANIALgMQBghdB8gaQD5g1DKDeQB4CdgpDWQAEA9AAA6QABCwgVCvQgWClgrChQgnCsg2CnQgmBvg7BkIgUAoIgIARAxdi9QgXgyAbgsIAVAbQBRBYBhBOIAZATQFpESHKAvIASABQBLAHBMgBQHEgIHYkMQCThRBrhWQAiArgGArQALLvAlMSQAmMpBDMdMgslgAJQArs6BGsfQBFsYBgsmgAV9o9QgoCKg0CDA5m3BQgwg2gfhJQgbhDgFhPQg2iQA3irQBOjKDrhIQBQgTBTALQAgABAaAFQA+ALA3AbIACgCQAYgLASgUIAHgKAzypqQiKmai4mP");
	this.shape_1450.setTransform(786.175,505.1384);

	this.shape_1451 = new cjs.Shape();
	this.shape_1451.graphics.f("rgba(255,255,255,0.067)").s().p("AU0VAQAngoAcgxQBGh7AWiRIAKggQAbgjAZgtQhHDNhnEXIgQAOQgMgPgTgOgAwxTGIgyh4QAQAgATAfQgTgfgQggQgUgogPgrQgNgmgJgnQAJAnANAmIhoj6Iiel3IgmhVQgrhdgziCQAaAbAYAUQCaGdCoGMQAnBzA1BsQAjA1AqAmQgKAKgGALgAxjROIAAAAgAufwgQBCibDxh3QEnhzEMDJQBjBKBCBXIgQArQgngygZgcQg8hDg7grIi8haQhggbhmAIIgWACIkfB+QgdAagYAcIhiDzIgEBKQgFAigOAWQgMhkAtiug");
	this.shape_1451.setTransform(777.575,349.094);

	this.shape_1452 = new cjs.Shape();
	this.shape_1452.graphics.f("#FFFFFF").s().p("ACUQ/QirgGh2h/Qh1h+AGitQAHisB+h2QB+h1CsAGQCsAGB2B/QB2B/gHCsQgGCsh/B2Qh3BvigAAIgUAAgA0WhCQgwgCgigkQghgkACgxQABgwAkgiQAkghAxACQAxACAhAjQAhAkgBAxQgCAxgkAhQghAggtAAIgHAAgATplGQg/gCgsgvQgqgtAChAQAChAAugrQAvgqA/ACQBAACArAuQArAvgCA/QgCBAgvAqQgrApg8AAIgHAAgAojrKQgzgCgkgmQgjgmABg1QACgzAmgkQAngjAzABQA0ACAkAmQAkAngCA0QgCA0gnAjQgjAigyAAIgFAAgAHUtaQgvgCghgjQgggiACgvQACgvAighQAkggAuACQAwACAfAiQAhAkgCAuQgCAwgjAfQggAfgsAAIgFAAg");
	this.shape_1452.setTransform(786.4512,345.9162);

	this.shape_1453 = new cjs.Shape();
	this.shape_1453.graphics.f("#232323").s().p("EgVzAvaQArs6BGsfQBFsYBgsmQgXgyAbgsIAVAbQBRBYBhBOIAZATQFpESHKAvIASABQAmAEAmABIA4ABIATAAQHEgIHYkMQCThRBrhWQAiArgGArQALLvAlMSQAmMpBDMdgAAYEAQgmgBgmgEIgSgBQnKgvlpkSIgZgTQhhhOhRhYIgVgbQAGgKAKgKQgqgmgjg1Qg1htgnhzQiKmai4mPQgYgTgagbQgwg2gfhJQgbhDgFhPQg2iQA3irQBOjKDrhIQBQgTBTALQAgABAaAFQA+ALA3AbIACgCQAYgLASgUIAHgKQAOgXAFghIAEhLIBijyQAYgcAdgbIEfh9IAWgCQBmgIBgAbIC8BaQA7ArA9BDQAZAcAmAxIAQgqQAUguAegyQBTiGCHhaQCHhTCmAFQCyAMCGCPQB1CIgIDDIgGAtIgBANIALgMQBghdB8gaQD5g1DKDeQB4CdgpDWQAEA9AAA6QABCwgVCvQgWClgrChQgnCsg2CnQgmBvg7BkIgUAoIgIARQgZAtgbAjIgKAgQgoCKg0CDQgcAxgnAnQATAPAMAPQhrBWiTBRQnYEMnEAIIgTAAIg4gBgAh0zKQh+B2gHCsQgGCtB1B+QB2B/CrAGQCtAHB+h2QB/h2AGisQAHish2h/Qh2h/isgGIgSAAQigAAh4BvgA1f9HQgkAigBAwQgCAxAhAkQAiAkAwACQAxACAkgiQAkghACgxQABgxghgkQghgjgxgCIgEAAQguAAgjAfgEASJgiHQguArgCBAQgCBAAqAtQAsAvA/ACQBAADAugsQAvgqAChAQACg/grgvQgrguhAgCIgFAAQg8AAgtAogEgJxgncQgmAkgCAzQgBA1AjAmQAkAmAzACQA1ACAlgkQAngjACg0QACg0gkgnQgkgmg0gCIgEAAQgxAAglAigEAGNgpYQgiAhgCAvQgCAvAgAiQAhAjAvACQAvACAighQAjgfACgwQACgughgkQgfgigwgCIgEAAQgsAAgiAegAT9i6IAAAAg");
	this.shape_1453.setTransform(786.175,505.1384);

	this.shape_1454 = new cjs.Shape();
	this.shape_1454.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB2gEQACAwghAkQghAkgxACQgwACgkghQgkghgCgxQgCgwAhgkQAhgkAxgCQAwgCAkAhQAkAhACAxg");
	this.shape_1454.setTransform(631.9554,338.4054);

	this.shape_1455 = new cjs.Shape();
	this.shape_1455.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB+gFQACAzgjAnQgjAmg1ADQgyACgngkQgmgjgDg0QgCgyAjgnQAkgmA0gDQAzgCAmAjQAnAkACAzg");
	this.shape_1455.setTransform(702.0778,267.1028);

	this.shape_1456 = new cjs.Shape();
	this.shape_1456.graphics.f().s("#232323").ss(8,1,1).p("AkDrHQALgYADgiIgBhLIBVkCQASgZAXgYIEqiYIDnALQBSAVBQAuQA+AnBCA+IBGBIIANgsQhJhRhphCQkbizkeCJQjlCKg2CgQggCwAVBkgAikVCQAFgLAJgLQgtgigngzQg9hogwhvQjGl9i7mQQgagSgbgZQA9B9AyBaIAtBSIC6FpIB7DwQATAqAXAnIA8Bzg");
	this.shape_1456.setTransform(678.3,351.2802);

	this.shape_1457 = new cjs.Shape();
	this.shape_1457.graphics.f().s("#232323").ss(7,1,1).p("ABcj/QgWAvgYAlIgIAhQgKCSg8B/QgXA0gkAqQAUANANAOIAQgQQBOkcA4jTg");
	this.shape_1457.setTransform(906.75,451.1);

	this.shape_1458 = new cjs.Shape();
	this.shape_1458.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGggQQAHCrh1B/Qh1B/isAHQirAIh/h1Qh/h1gHitQgIirB1h/QB1h/CtgHQCrgIB/B1QB/B1AHCtg");
	this.shape_1458.setTransform(784.4222,412.225);

	this.shape_1459 = new cjs.Shape();
	this.shape_1459.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACZgFQACA/grAuQgqAuhAADQg+ADgvgrQgugrgDg/QgCg/AqgvQArgtA/gEQA/gDAuArQAvArADBAg");
	this.shape_1459.setTransform(884.9523,288.9471);

	this.shape_1460 = new cjs.Shape();
	this.shape_1460.graphics.f().s("#232323").ss(0.1,1,1).p("EgAigo5QAQgvAZg1QBIiMCAhkQB/hdCmgJQC0gCCQCFQB/B+AIDDIgCAuIgBANIALgNQBYhkB5gkQD0hIDcDMQCCCTgXDZQAJA9AEA6QAPCvgGCwQgKCmgeCkQgaCvgoCrQgdBxgzBpIgRApIgHASAvShRQgagwAXguIAXAZQBXBSBoBFIAZARQF+D2HMAKIARABQBMAABNgHQHCgsHBkvQCMhdBkheQAlApgCArQBnMfBEMPQBGMnAjNVMgslgAJQBMsHAmshQAmsaADr6gAXiqVQgdCLgqCHA4+0oQg0gyglhGQgghBgLhOQhBiMApiuQA/jRDkhaQBOgYBTAEQAhgBAaADQA+AFA5AXIACgCQAYgNAPgWIAHgKAyInwQipmPjYl/");
	this.shape_1460.setTransform(759.9803,503.4235);

	this.shape_1461 = new cjs.Shape();
	this.shape_1461.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABygEQACAvggAiQggAkgvABQguACgjggQgjghgCguQgCguAggjQAhgjAugCQAvgCAiAgQAkAhABAug");
	this.shape_1461.setTransform(802.2475,245.9475);

	this.shape_1462 = new cjs.Shape();
	this.shape_1462.graphics.f("rgba(255,255,255,0.067)").s().p("Av0UOIg7hzQATAfAVAdQgVgdgTgfQgXgngTgqQgPgkgMgmQAMAmAPAkIh7jwIi6lpIgthSQgyhag9h9QAcAZAZASQC7GQDGF9QAwBvA9BoQAnAzAtAiQgJALgFALgAV0TLQAkgqAXgzQA8iAAKiTIAIghQAYglAWgvQg3DThQEeIgQAPQgNgOgTgNgAwvSbIAAAAgAwUvbQA0igDniKQEdiJEbCzQBpBCBKBRIgMAsIhHhIQhCg+g+gnQhQguhSgVIjngLIkrCYQgXAYgSAZIhVECIABBLQgCAigMAYQgVhkAhiwg");
	this.shape_1462.setTransform(758,351.2802);

	this.shape_1463 = new cjs.Shape();
	this.shape_1463.graphics.f("#FFFFFF").s().p("AgnPbQh/h1gHitQgIisB1h/QB0h/CtgHQCsgIB/B1QB/B1AHCtQAHCsh1B/Qh1B/isAHIgUABQigAAh2hugA1SAdQgkgggCgxQgBgxAggkQAhgkAxgCQAxgCAkAhQAkAhACAxQADAxgiAjQghAkgxACIgGAAQgtAAgigfgAR3m3QgtgrgEg/QgChAAqgvQAsgtA/gEQBAgDAuArQAuArADBAQADBAgrAuQgqAuhAADIgHAAQg7AAgtgogAqaqmQgmgjgCg0QgCgzAjgnQAjgmA0gDQA0gCAnAjQAmAkACAzQADA0gkAnQgjAmg0ADIgHAAQgvAAglgigAFXuCQgjghgCguQgCgvAggjQAhgjAugCQAwgCAiAgQAkAhABAuQACAwggAiQggAkgvABIgEAAQgtAAghgeg");
	this.shape_1463.setTransform(760.2036,344.2167);

	this.shape_1464 = new cjs.Shape();
	this.shape_1464.graphics.f("#232323").s().p("EgRtAvrQBMsHAmshQAmsaADr6QgagwAXguQAFgLAJgKQgtgjgmgyQg+hogwhvQipmPjYl/QgZgSgcgYQg0gyglhGQgghBgLhOQhBiMApiuQA/jRDkhaQBOgYBTAEQAhgBAaADQA+AFA5AXIACgCQAYgNAPgWIAHgKQAMgYACghIgBhLIBVkCQATgZAWgZIEriXIDnALQBSAVBQAuQA+AmBCA+IBHBIIAMgrQAQgvAZg1QBIiMCAhkQB/hdCmgJQC0gCCQCFQB/B+AIDDIgCAuIgBANIALgNQBYhkB5gkQD0hIDcDMQCCCTgXDZQAJA9AEA6QAPCvgGCwQgKCmgeCkQgaCvgoCrQgdBxgzBpIgRApIgHASQgVAugYAmIgIAhQgdCLgqCHQgXAzgkArQAUANANAOQhkBeiMBdQnBEvnCAsQhNAHhMAAIgRgBQnMgKl+j2IgZgRQhohFhXhSIgXgZIAXAZQBXBSBoBFIAZARQF+D2HMAKIARABQBMAABNgHQHCgsHBkvQCMhdBkheQAlApgCArQBnMfBEMPQBGMnAjNVgADj0vQisAHh0B/Qh1B/AHCsQAICtB+B1QB+B1CtgIQCsgHB1h/QB1h/gHisQgHitiAh1Qh3huifAAIgVABgA0E7nQgxACghAkQghAkACAxQACAxAkAhQAkAhAxgCQAxgCAhgkQAhgkgCgxQgCgxgkghQgjgfguAAIgEAAgEATbgj5Qg/AEgrAtQgqAvACBAQADA/AuArQAvArA/gDQBAgDAqguQArgugChAQgDhAgvgrQgrgog7AAIgIAAgEgJHgm4Qg0ADgkAmQgjAnACAzQADA0AmAjQAnAkAzgCQA1gDAjgmQAjgngCg0QgCgzgngkQgkghgxAAIgFAAgEAGigqAQgvACggAjQggAjACAvQACAuAjAhQAiAgAvgCQAvgBAggkQAggigBgwQgCgugjghQghgegsAAIgFAAg");
	this.shape_1464.setTransform(759.9803,503.4235);

	this.shape_1465 = new cjs.Shape();
	this.shape_1465.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB1gNQAGAvgeAnQgeAmgxAGQgvAGgngeQgmgegGgxQgGgvAegnQAegmAxgGQAvgGAnAeQAmAeAGAxg");
	this.shape_1465.setTransform(608.2,351.3176);

	this.shape_1466 = new cjs.Shape();
	this.shape_1466.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB9gOQAGAzggApQggAog0AHQgyAGgqggQgogggHg0QgGgyAggqQAggpA0gGQAzgGApAgQAoAgAHA0g");
	this.shape_1466.setTransform(672.525,274.7244);

	this.shape_1467 = new cjs.Shape();
	this.shape_1467.graphics.f().s("#232323").ss(8,1,1).p("AkXqrQAKgZgBgiIgHhKIA2j1QAUglAcgjIDziiQAVgHAVgFIDugGQBQAPBQAmQBBAhBGA5QAeAXAuArIAKgtQhRhLhtg6QkoickRCfQjbCcgoCkQgTCyAdBigAgYVQIANgXQgvgegrgwQhFhig4hsQjklsjamAQgbgQgdgXQBGB4A5BVIA0BPIDWFZICQDpQAUAmAZAjIBFBwg");
	this.shape_1467.setTransform(651.925,359.9746);

	this.shape_1468 = new cjs.Shape();
	this.shape_1468.graphics.f().s("#232323").ss(7,1,1).p("ABIkEQgRAwgWAnIgFAiQABCSgwCEQgUA1ggAtQAUAMAPAMIAOgQQA4kiAmjXg");
	this.shape_1468.setTransform(890.875,441.95);

	this.shape_1469 = new cjs.Shape();
	this.shape_1469.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGegxQAUCrhqCHQhrCIirAVQiqAUiIhqQiIhrgUirQgViqBqiIQBsiICqgVQCqgUCIBqQCIBrAVCrg");
	this.shape_1469.setTransform(765.9925,412.9317);

	this.shape_1470 = new cjs.Shape();
	this.shape_1470.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACYgRQAIA+goAxQgmAzg/AHQg/AIgygoQgwgmgJhAQgHg+AmgyQAogxA/gIQA+gIAxAnQAzAoAHA/g");
	this.shape_1470.setTransform(856.5487,282.1314);

	this.shape_1471 = new cjs.Shape();
	this.shape_1471.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABxgNQAGAugdAlQgeAmgvAFQgtAGglgeQgmgdgFguQgGguAdglQAegmAugFQAugGAlAdQAmAeAFAug");
	this.shape_1471.setTransform(770.7,245.7675);

	this.shape_1472 = new cjs.Shape();
	this.shape_1472.graphics.f().s("#232323").ss(0.1,1,1).p("EgDKgoTQALgwAXg2QA9iSB2htQB4hoCkgVQCygQCbB4QCJB0AXDCQACAYgBAWIABANIAJgOQBQhrB2gtQDuhaDrC6QCOCIgGDaQANA8AJA6QAcCtAICwQAECmgSCmQgMCwgbCuQgUBygqBtIgNArIgGASAuwAWQgfgsATgvIAaAWQBdBKBtA9IAbAPQGQDYHLgaIARgBQBMgFBMgNQG9hPGolSQCEhoBchmQApAnABAqQDGNIBjMKQBlMjAJOPMgslgAJQBvrWAHshQAIsZhWrJgAXOruQgRCNggCKA58yLQg4gugqhDQglg+gRhNQhMiGAbixQAujUDchsQBMggBUgBQAggEAaABQA/ABA6ARQACgBABgBQAWgOAOgXIAGgLAyGl4QjJmAj1lt");
	this.shape_1472.setTransform(745.1194,503.0363);

	this.shape_1473 = new cjs.Shape();
	this.shape_1473.graphics.f("rgba(255,255,255,0.067)").s().p("AuwUhIhEhwQAVAeAYAcQgYgcgVgeQgZgjgVgmQgTgkgQgnQAQAnATAkIiQjpIjWlZIgzhPQg5hVhGh4QAdAXAbAQQDZGADkFsQA5BsBFBiQArAwAvAeIgNAXgAv0SxIAAAAgAWrQhQAgguAUg0QAxiFgBiTIAFghQAWgnARgwQgmDWg5EjIgOARQgPgNgUgLgAyEu/QAoikDcicQESifEnCcQBuA6BQBLIgJAtQgvgrgdgXQhGg5hCghQhQgmhPgPIjuAGQgWAFgUAHIj1CiQgcAjgUAlIg1D1IAHBKQAAAigKAZQgchiASiyg");
	this.shape_1473.setTransform(738.575,359.9746);

	this.shape_1474 = new cjs.Shape();
	this.shape_1474.graphics.f("#FFFFFF").s().p("AA+P0QiIhqgUirQgVisBriIQBqiHCrgVQCrgUCIBqQCIBqAUCrQAVCshrCIQhqCIirAUQgcADgbAAQiKAAhyhZgA0zChQgmgegGgwQgGgxAegmQAegmAxgGQAwgGAnAeQAmAdAGAxQAGAwgeAnQgeAngxAGIgPAAQgnAAghgZgARpn2QgwgmgJhAQgHg/AmgyQAogyA/gHQA/gIAxAnQAzAoAHA+QAIA/goAyQgmAyg/AHIgWACQgzAAgpghgAq1pWQgogfgHg0QgGg0AggpQAggpA0gHQA0gGApAgQAoAhAHAzQAGA0ggApQggApg0AHIgQABQgqAAgjgcgAEouBQgmgdgFguQgGgvAdglQAegmAugFQAvgGAlAdQAmAeAFAuQAGAvgeAlQgdAmgvAFIgOABQgmAAgfgZg");
	this.shape_1474.setTransform(734.1348,344.4897);

	this.shape_1475 = new cjs.Shape();
	this.shape_1475.graphics.f("#232323").s().p("EgPYAvvQBvrWAHshQAIsZhWrJQgfgsATgvIANgXQgvgfgrgvQhFhjg4hrQjJmAj1ltQgbgPgdgXQg4gugqhDQglg+gRhNQhMiGAbixQAujUDchsQBMggBUgBQAggEAaABQA/ABA6ARIADgCQAWgOAOgXIAGgLQAKgYgBgjIgHhKIA2j1QAUgkAcgjID0ijQAVgHAVgFIDugGQBQAPBQAmQBBAhBGA5QAeAYAuAqIAKgsQALgwAXg2QA9iSB2htQB4hoCkgVQCygQCbB4QCJB0AXDCQACAYgBAWIABANIAJgOQBQhrB2gtQDuhaDrC6QCOCIgGDaQANA8AJA6QAcCtAICwQAECmgSCmQgMCwgbCuQgUBygqBtIgNArIgGASQgRAwgWAnIgFAiQgRCNggCKQgTA1ghAtQAVAMAOAMQhcBmiEBoQmoFSm9BPQhMANhMAFIgRABIgFAAIgCABQgtACgtAAIAAAAIAAAAQmLAAlei4IgRgJIgbgPQhtg9hdhKIgagWIAaAWQBdBKBtA9IAbAPIARAJQFeC4GLAAIAAAAIAAAAQAtAAAtgCIACgBIAFAAIARgBQBMgFBMgNQG9hPGolSQCEhoBchmQApAnABAqQDGNIBjMKQBlMjAJOPgACf0iQiqAVhrCIQhrCIAVCrQAUCrCJBrQCHBqCrgUQCrgVBqiIQBriHgVisQgUiriIhrQhzhZiLAAQgaAAgbADgA1m5hQgxAGgeAmQgeAnAGAwQAGAxAmAeQAnAeAwgGQAxgGAegmQAegngGgwQgGgxgmgeQghgZgmAAIgQABgEARIgk4Qg/AIgoAxQgmAyAHA/QAJBAAwAmQAyAoBAgIQA/gHAmgzQAogxgIg/QgHg/gzgoQgpgggyAAIgVABgEgLkglnQg0AGggApQggAqAGAzQAHA0AoAgQAqAgAzgGQA0gHAggoQAggpgGg0QgHg0goggQgjgbgqAAIgQABgEADygp9QguAGgeAlQgdAlAGAvQAFAvAmAdQAlAdAugFQAvgGAdglQAegmgGguQgFgvgmgdQgfgZglAAIgQABg");
	this.shape_1475.setTransform(745.1194,503.0363);

	this.shape_1476 = new cjs.Shape();
	this.shape_1476.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB0gWQAKAvgbApQgbAogxAKQguAKgpgbQgpgbgKgxQgJguAbgpQAbgpAwgKQAvgJApAbQAoAbAKAwg");
	this.shape_1476.setTransform(585.5461,366.0461);

	this.shape_1477 = new cjs.Shape();
	this.shape_1477.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABwgWQAJAugaAnQgbAoguAJQgtAJgngaQgogagJgvQgJgtAagnQAbgoAtgJQAugJAnAaQAoAbAJAtg");
	this.shape_1477.setTransform(739.2636,248.0636);

	this.shape_1478 = new cjs.Shape();
	this.shape_1478.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB7gYQALAygdAsQgdArgzALQgyAKgsgdQgrgdgLgzQgKgxAdgtQAdgqAzgLQAygLArAdQAsAdAKAzg");
	this.shape_1478.setTransform(643.65,284.6386);

	this.shape_1479 = new cjs.Shape();
	this.shape_1479.graphics.f().s("#232323").ss(8,1,1).p("AkpqKQAHgYgDgjIgMhJIAkj+QARgkAXgiID8i+QAJgDAKgDIDmgaQBUAIBWAhQBDAcBLAzIBRA9IAGguQhWhEhygxQkziFkDC0QjPCtgbCmQgECzAkBfgAB1VYQAEgNAHgLQgygbgugsQhMhdhAhnQkAlZj3luQgcgNgfgUQBQByA/BQIA6BKIDwFHQBQBuBRBtQAYAnAeAjQAkAzAmA0g");
	this.shape_1479.setTransform(626.325,370.291);

	this.shape_1480 = new cjs.Shape();
	this.shape_1480.graphics.f().s("#232323").ss(7,1,1).p("AA0kIQgNAygSAoQgDATAAAPQAMCRgmCJQgPA2gcAwQAVAJAPAMIANgSQAhkmAVjZg");
	this.shape_1480.setTransform(874.375,434.05);

	this.shape_1481 = new cjs.Shape();
	this.shape_1481.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGYhRQAjCohgCQQhgCQipAhQinAjiQhgQiQhfgiiqQgiinBfiRQBgiQCpghQCogjCQBgQCQBgAhCpg");
	this.shape_1481.setTransform(747.6961,415.075);

	this.shape_1482 = new cjs.Shape();
	this.shape_1482.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACWgdQAMA9gjA0QgiA2g/AMQg9ANg1gkQg0gigNg/QgMg9Aig1QAkg0A+gNQA9gMA0AiQA2AkAMA+g");
	this.shape_1482.setTransform(827.687,277.5694);

	this.shape_1483 = new cjs.Shape();
	this.shape_1483.graphics.f().s("#232323").ss(0.1,1,1).p("EgGPgnhQAJgwARg4QAyiWBuh3QBvhvCigjQCwgeCjBsQCTBoAlDAIAFAuIACANIAIgPQBIhxByg2QDlhtD5CnQCZB9ALDaQASA6ANA5QAqCrAVCvQARClgECnQABCwgNCwQgLBzgiBwIgJAsIgFASAWUtGQgGCOgVCMAumB7QghgrAPgwIAbAUQBjBDBxA1IAcANQGfC3HIg+IARgCQBLgLBLgTQG2hyGMlyQB8hyBThtQAsAkAEAqQEpNoCBMEQCEMbgOPMMgslgAKQCYqogYseQgYsWirqPgA7MvqQg8gqgvg/Qgqg7gXhMQhWiAANiyQAdjYDTh8QBKglBTgIQAfgHAbgBQA+gEA8ANQABgBABgBQAVgQAMgYIAFgMAybkCQjllukSlZ");
	this.shape_1483.setTransform(733.3753,503.8989);

	this.shape_1484 = new cjs.Shape();
	this.shape_1484.graphics.f("rgba(255,255,255,0.067)").s().p("AtmUsIhMhnQAXAbAZAZQgZgZgXgbQgdgjgZgnQgVghgSglQASAlAVAhIigjbIjwlHIg6hKQg/hQhQhyQAfAUAcANQD3FuEAFZQBABnBNBdQAuAsAyAbQgHALgEANgAuyTFIAAAAgAXZNxQAdgwAPg2QAniIgMiSQgBgQADgSQASgoAOgyQgVDZgjEnIgMARQgQgMgVgJgAzsucQAbimDPitQEEi0EzCFQByAxBWBEIgGAuIhRg9QhLgzhDgcQhWghhUgIIjmAaIgTAGIj9C+QgXAigRAkIgkD+IAMBJQADAjgHAYQgkhfAEizg");
	this.shape_1484.setTransform(719.425,370.291);

	this.shape_1485 = new cjs.Shape();
	this.shape_1485.graphics.f("#FFFFFF").s().p("ACjQGQiQhfghipQgiipBeiQQBgiQCpgiQCpgiCQBgQCQBfAhCpQAjCphgCQQhgCQipAiQgsAJgrAAQh3AAhqhHgA0NEkQgogbgKgxQgJgvAagpQAbgpAwgKQAwgJApAbQApAbAJAwQAKAwgbApQgbAogwAKQgNACgMAAQghAAgfgTgArMoDQgrgdgLgzQgKgyAdgtQAdgqAzgLQAzgLArAdQAsAdAKAzQALAzgdAsQgdArgzALQgNACgNAAQgkAAghgVgARUozQg0gjgNg+QgMg+Aig1QAkg1A+gNQA+gMA0AjQA2AjAMA+QAMA/gjA0QgiA1g/AMQgQAEgQAAQgsAAgngagAD2t7QgogagJguQgJgvAagnQAbgnAtgJQAvgKAnAaQAoAbAJAuQAJAugaAnQgbAoguAJQgMADgLAAQghAAgdgUg");
	this.shape_1485.setTransform(708.3641,346.7289);

	this.shape_1486 = new cjs.Shape();
	this.shape_1486.graphics.f("#232323").s().p("EgNjAvmQCYqogYseQgYsWirqPQghgrAPgwIAbAUQBjBDBxA1IAcANIADABIACABIAJAEQEwCCFHAAIAAAAIAAAAQBsAABvgOIAHgBIARgCQBLgLBLgTQG2hyGMlyQB8hyBThtQhTBth8ByQmMFym2ByQhLAThLALIgRACIgHABQhvAOhsAAIAAAAIAAAAQlHAAkwiCIgJgEIgCgBIgDgBIgcgNQhxg1hjhDIgbgUQAEgNAHgLQgygagugsQhNhdhBhnQjllukSlZQgbgNgfgUQg8gqgvg/Qgqg7gXhMQhWiAANiyQAdjYDTh8QBKglBTgIQAfgHAbgBQA+gEA8ANIACgCQAVgQAMgYIAFgMQAIgYgDgjIgNhJIAlj+QARgkAXgiID9i+IASgGIDmgaQBUAIBWAhQBEAcBLAzIBRA9IAFguQAJgwARg4QAyiWBuh3QBvhvCigjQCwgeCjBsQCTBoAlDAIAFAuIACANIAIgPQBIhxByg2QDlhtD5CnQCZB9ALDaQASA6ANA5QAqCrAVCvQARClgECnQABCwgNCwQgLBzgiBwIgJAsIgFASQgNAygSAoQgDASAAAQQgGCOgVCMQgPA2gcAwQAVAJAPAMQAsAkAEAqQEpNoCBMEQCEMbgOPMgAA90PQioAhhgCQQhfCRAiCoQAiCqCQBfQCPBgCogjQCpghBgiQQBgiQgjipQghipiQhgQhqhHh4AAQgrAAgsAKgA3d3VQgwAKgbAoQgaAqAJAvQAKAwAoAbQAqAbAvgKQAwgJAbgpQAbgpgKgwQgJgwgpgbQgegUgjAAQgMAAgMADgEgOZgkLQgzALgdArQgdAsAKAyQALA0ArAcQAsAdAzgKQAzgKAdgsQAdgsgLgyQgKg0gsgcQgggWgkAAQgNAAgNADgEAORglsQg+ANgkA0QgiA1AMA+QANA/A0AiQA1AkA+gNQA/gMAig2QAjg0gMg+QgMg+g2gkQgmgagtAAQgPAAgQAEgEAAkgptQgsAJgbAoQgaAnAJAuQAJAvAoAaQAmAaAugJQAugJAbgoQAagngJgvQgJgtgogbQgdgUggAAQgMAAgNADg");
	this.shape_1486.setTransform(733.3753,503.8989);

	this.shape_1487 = new cjs.Shape();
	this.shape_1487.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGQhxQAwClhUCWQhUCYimAuQilAwiXhUQiWhUgwimQgvilBUiXQBUiWCmgwQClgvCWBUQCXBUAvCmg");
	this.shape_1487.setTransform(729.6115,418.6615);

	this.shape_1488 = new cjs.Shape();
	this.shape_1488.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABxgfQAOAtgYArQgYArgvANQguAOgrgYQgqgYgOgvQgNguAYgrQAXgqAvgOQAvgNAqAYQArAXANAwg");
	this.shape_1488.setTransform(564.1033,382.5033);

	this.shape_1489 = new cjs.Shape();
	this.shape_1489.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABugeQANAtgXAoQgXAqguANQgsANgpgYQgqgXgNgtQgMgsAXgpQAXgqAtgNQAtgMAoAWQAqAYANAtg");
	this.shape_1489.setTransform(708.0897,252.8333);

	this.shape_1490 = new cjs.Shape();
	this.shape_1490.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB5giQAOAxgZAuQgaAugyAOQgwAOgvgZQgtgagPgyQgNgwAZgvQAZgtAygPQAxgNAuAZQAuAZAOAyg");
	this.shape_1490.setTransform(615.6511,296.8011);

	this.shape_1491 = new cjs.Shape();
	this.shape_1491.graphics.f().s("#232323").ss(8,1,1).p("Ak6piQAGgagGghIgShJIAPj8QAOgmAWgmIDkjOQANgGAOgGIDtgrQBPADBTAZQBFAWBPAtIBWA2IACgtQhbg+h2goQk9hsjzDIQjBC8gOCoQAKCzArBcgAECVYQADgMAGgMQgzgXgygpQhUhWhIhhQkZlFkUlZQgdgLgggSQBYBrBGBMIA/BFIEJE0QBYBlBWBmQAeAnAiAjQApAvApAwg");
	this.shape_1491.setTransform(601.725,382.1315);

	this.shape_1492 = new cjs.Shape();
	this.shape_1492.graphics.f().s("#232323").ss(6.5,1,1).p("AAgkKQgJAzgQAqIABAiQAYCQgdCKQgKA3gYAyQAWAHAPAMIALgTQALknAEjbg");
	this.shape_1492.setTransform(857.325,427.5);

	this.shape_1493 = new cjs.Shape();
	this.shape_1493.graphics.f().s("#232323").ss(0.1,1,1).p("EgJVgmiQAEgyAOg5QAliZBlh/QBmh4CfgwQCugrCqBeQCZBdA2C9IAIAtIADAMIAHgPQA+h2Bug/QDch/EFCUQCiBwAcDYQAXA5ASA3QA3CoAjCsQAdCkAJCmQAQCwABCwQgCB0gZByIgGAtIgDASAVNudQAFCPgJCNAuaDbQglgpAMgxIAcASQBoA8B1ArIAdALQGtCWHBhhIARgEQBKgRBJgZQGpiTFwmRQByh7BLhzQAuAfAIArQGOOBCeL6QCjMSggQKMgslgALQDEp9g4sYQg2sRj7pPgA8WtIQg/gkg0g8Qgvg3gchKQhgh4gBizQAMjaDJiMQBGgrBSgPQAfgJAagDQA/gJA8AIIACgCQATgSALgZIAEgLAysiNQkClckrlC");
	this.shape_1493.setTransform(722.3557,506.0144);

	this.shape_1494 = new cjs.Shape();
	this.shape_1494.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACTgpQASA9gfA2QgeA4g+ARQg8ASg3gfQg3gegSg+QgSg8Afg3QAfg4A9gRQA9gSA2AfQA4AfARA9g");
	this.shape_1494.setTransform(798.5467,275.2967);

	this.shape_1495 = new cjs.Shape();
	this.shape_1495.graphics.f("rgba(255,255,255,0.067)").s().p("AsXUyIhShfQAYAYAaAVQgagVgYgYQgigjgdgnQgXgfgUghQAUAhAXAfIiwjLIkJk0Ig/hFQhFhMhZhrQAhASAcALQEUFZEaFFQBIBhBUBWQAyApA0AXQgHAMgCAMgAtpTTIAAAAgAX+K+QAZgyAKg3QAdiLgYiRIAAghQAPgqAKgzQgFDbgLEoIgLASQgQgLgWgHgA1NtxQAOioDBi8QD0jIE+BsQB2AoBaA+IgCAtIhWg2QhOgthFgWQhTgZhQgDIjuArIgbAMIjkDOQgWAmgOAmIgPD8IASBJQAHAhgHAaQgrhcgKizg");
	this.shape_1495.setTransform(700.7,382.1315);

	this.shape_1496 = new cjs.Shape();
	this.shape_1496.graphics.f("#FFFFFF").s().p("AEHQRQiXhUgvimQgvilBTiXQBUiXCmgvQCmgvCXBTQCXBUAvCmQAvCmhUCXQhUCXimAvQg8ARg6AAQhmAAhgg2gAzeGjQgrgYgNgvQgOgvAYgrQAYgqAvgOQAvgNArAYQArAXANAwQANAugXArQgYArgvANQgRAFgRAAQgdAAgbgPgArfmuQgtgagPgyQgNgxAZgvQAZgtAygPQAygNAuAZQAuAZAOAyQAOAygZAuQgaAugyAOQgSAFgRAAQgfAAgegQgAQ4puQg2gegSg9QgSg+Afg3QAfg3A9gRQA9gSA3AfQA3AfASA9QASA9ggA3QgeA3g9ASQgXAGgVAAQgmAAgjgUgADDtxQgqgXgNgtQgMgtAXgpQAXgqAtgNQAugMAoAWQAqAYANAtQANAugXAoQgXAqguANQgQAFgQAAQgcAAgagQg");
	this.shape_1496.setTransform(683.0843,350.9097);

	this.shape_1497 = new cjs.Shape();
	this.shape_1497.graphics.f("#232323").s().p("EgL1AvQQDEp9g4sYQg2sRj7pPQglgpAMgxIAcASQBoA8B1ArIAdALIAHACQEBBZEIAAIABAAIAAAAQCoAACsgkIACgBIACAAIAFgBIARgEQBKgRBJgZQGpiTFwmRQByh7BLhzQhLBzhyB7QlwGRmpCTQhJAZhKARIgRAEIgFABIgCAAIgCABQisAkioAAIAAAAIgBAAQkIAAkBhZIgHgCIgdgLQh1grhog8IgcgSQACgMAHgMQg0gXgygpQhUhVhIhhQkClckrlCQgdgLgggSQg/gkg0g8Qgvg3gchKQhgh4gBizQAMjaDJiMQBGgrBSgPQAfgJAagDQA/gJA8AIIACgCQATgSALgZIAEgLQAGgagGghIgThJIAQj8QAOgmAVgmIDljOIAbgMIDugrQBPADBTAZQBFAWBPAtIBVA2IACgtQAEgyAOg5QAliZBlh/QBmh4CfgwQCugrCqBeQCZBdA2C9IAIAtIADAMIAHgPQA+h2Bug/QDch/EFCUQCiBwAcDYQAXA5ASA3QA3CoAjCsQAdCkAJCmQAQCwABCwQgCB0gZByIgGAtIgDASQgKAzgPAqIAAAhQAFCPgJCNQgLA3gZAyQAWAHAQALQAuAfAIArQGOOBCeL6QCjMSggQKgAgpz5QimAvhUCXQhTCXAvClQAvCmCXBUQCWBUClgvQCmgvBUiXQBUiXgvimQgvimiXhUQhgg1hnAAQg6AAg7ARgA5O1EQgvAOgYAqQgYArAOAvQANAvArAYQArAYAvgOQAvgNAYgrQAXgrgNguQgNgwgrgXQgbgQgeAAQgQAAgRAFgEgRNgilQgyAPgZAtQgZAvANAxQAPAyAtAaQAvAZAxgOQAygOAaguQAZgugOgyQgOgygugZQgegQgfAAQgRAAgSAEgEALQgmVQg9ARgfA3QgfA3ASA+QASA9A2AeQA3AgA+gSQA9gSAeg3QAgg3gSg9QgSg9g3gfQgjgUglAAQgVAAgXAHgEgCtgpRQgtANgXAqQgXApAMAtQANAtAqAXQApAYAtgNQAugNAXgqQAXgogNguQgNgtgqgYQgagOgcAAQgQAAgQAEg");
	this.shape_1497.setTransform(722.3557,506.0144);

	this.shape_1498 = new cjs.Shape();
	this.shape_1498.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGGiQQA8CghHCdQhICeiiA7QihA8ichHQiehIg8iiQg8ihBIidQBIicCig9QCgg8CdBIQCdBIA8Cig");
	this.shape_1498.setTransform(711.8552,423.6552);

	this.shape_1499 = new cjs.Shape();
	this.shape_1499.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABugoQASAtgVAsQgUAtguARQgtAQgtgUQgsgUgRguQgRgsAUgtQAVgsAtgSQAtgRAtAVQAsAUARAug");
	this.shape_1499.setTransform(544.0572,400.6126);

	this.shape_1500 = new cjs.Shape();
	this.shape_1500.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB2grQASAwgWAvQgVAwgxASQgvASgwgWQgvgVgTgxQgSgvAWgwQAVgwAxgSQAvgSAwAVQAwAWASAxg");
	this.shape_1500.setTransform(588.675,311.1199);

	this.shape_1501 = new cjs.Shape();
	this.shape_1501.graphics.f().s("#232323").ss(8,1,1).p("AlJo1QAEgagIghIgZhHIgEkAQAMglARgmIDqjrQACgBACgBIDjg9QBSgFBXATQBIARBRAnQAiAQA4AeIgCgtQhfg2h4gfQlFhTjjDbQixDLgBCoQAYCyAyBYgAGMVSQADgMAFgNQg2gTg0gkQhbhQhPhbQkyktkulDQgdgJgigPQBgBkBLBGIBFBAIEhEeQBfBfBgBfQAfAjAjAfQAtAtAtAtg");
	this.shape_1501.setTransform(578.325,395.4344);

	this.shape_1502 = new cjs.Shape();
	this.shape_1502.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABrgnQAQAsgTAqQgUAsgsAQQgrAQgrgUQgsgTgQgsQgQgrATgrQAVgsArgQQAsgQAqATQAsAVAQArg");
	this.shape_1502.setTransform(677.375,260.0198);

	this.shape_1503 = new cjs.Shape();
	this.shape_1503.graphics.f().s("#232323").ss(4.9,1,1).p("AAAkKQgGAzgLArIADAiQAiCNgRCNQgGA3gVA0QAXAGAQAKIAKgUQgMkmgNjbg");
	this.shape_1503.setTransform(841.05,422.275);

	this.shape_1504 = new cjs.Shape();
	this.shape_1504.graphics.f().s("#232323").ss(0.1,1,1).p("EgMaglYQAAgyAJg6QAaicBaiGQBdiACbg8QCpg5CyBRQCgBRBDC3IAMAsIAEANIAGgQQA0h7BphHQDSiPEQB+QCpBjAuDWQAbA3AWA1QBECiAwCqQAqChAXClQAcCuAPCvQAIB1gQBzIgDAtIgBASAT7vxQAQCOACCNAuLE2QgoglAHgyIAeAQQBsAzB5AiIAdAIQG4B1G4iFIARgFQBIgXBGgfQGfi1FNmrQBpiDBBh5QAwAbALAqQH1OSC7LvQDAMFgsRKMgslgAMQDypVhWsRQhVsJlFoJgA9YqjQhCggg4g3QgzgzgihIQhphwgPizQgFjZC9icQBCgwBRgVQAegLAagGQA+gOA9AEIABgDQASgSAJgbIADgLAy4gbQkdlGlEkq");
	this.shape_1504.setTransform(712.0287,509.3728);

	this.shape_1505 = new cjs.Shape();
	this.shape_1505.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACPg0QAXA6gbA6QgaA5g8AWQg6AXg6gbQg5gagWg8QgXg7Abg5QAag5A8gWQA7gXA4AbQA7AaAVA8g");
	this.shape_1505.setTransform(769.3198,275.325);

	this.shape_1506 = new cjs.Shape();
	this.shape_1506.graphics.f("rgba(255,255,255,0.067)").s().p("ArQUxIhZhaQAZAXAdAUQgdgUgZgXQgkgfgggjQgZgdgXghQAXAhAZAdIi/i+IkhkeIhFhAQhLhGhghkQAiAPAdAJQEuFDEzEtQBPBbBbBQQA0AkA2ATQgFANgDAMgAspTXIAAAAgAYNIIQAVg0AGg3QASiNgkiPIgDghQAMgrAGgzQANDaAMEoIgKATQgRgJgWgGgA2xs/QABioCxjLQDkjbFFBTQB4AfBfA2IACAtQg4gegigQQhRgnhIgRQhXgThSAFIjkA9IgEACIjqDrQgRAmgLAlIADEAIAZBHQAIAhgEAaQgyhYgYiyg");
	this.shape_1506.setTransform(683.725,395.4344);

	this.shape_1507 = new cjs.Shape();
	this.shape_1507.graphics.f("#FFFFFF").s().p("AFpQVQidhIg8ihQg8iiBIidQBIidChg8QCig8CdBIQCdBIA8ChQA8CihICdQhICdihA8QhKAbhJAAQhXAAhVgngAyoIfQgsgUgRguQgRgtAUgtQAUgsAugSQAugRAsAVQAtAUARAuQARAugVAsQgUAtguARQgVAHgUAAQgZAAgYgLgArtlYQgvgVgTgxQgSgwAWgwQAVgwAygSQAwgSAwAVQAvAWATAxQASAxgWAvQgVAwgyASQgWAIgVAAQgbAAgagMgAQVqlQg5gagWg8QgXg8Abg5QAag5A8gWQA8gXA4AbQA7AaAVA8QAXA7gbA6QgaA5g8AWQgbALgbAAQggAAgfgPgACOtiQgrgTgQgsQgRgsAUgrQAUgsAsgQQAsgQArATQArAVAQArQARAtgUAqQgUAsgsAQQgUAHgUAAQgXAAgYgLg");
	this.shape_1507.setTransform(658.4458,357.0157);

	this.shape_1508 = new cjs.Shape();
	this.shape_1508.graphics.f("#232323").s().p("EgKNAuuQDypVhWsRQhVsJlFoJQgoglAHgyIAeAQQBsAzB5AiIAdAIQDNA3DOAAIAAAAIAAAAQDpAADnhGIAFgBIARgFQBIgXBGgfQGfi1FNmrQBpiDBBh5QhBB5hpCDQlNGrmfC1QhGAfhIAXIgRAFIgFABQjnBGjpAAIAAAAIAAAAQjOAAjNg3IgdgIQh5gihsgzIgegQQADgNAFgMQg2gUg0gjQhbhQhPhaQkdlGlEkqQgdgJgigPQhCggg4g3QgzgzgihIQhphwgPizQgFjZC9icQBCgwBRgVQAegLAagGQA+gOA9AEIABgDQASgSAJgbIADgLQAEgagIgiIgZhGIgEkAQAMgmARgmIDpjqIAFgCIDkg+QBSgEBXASQBIASBRAmQAiAQA4AfIgCgtQAAgyAJg6QAaicBaiGQBdiACbg8QCpg5CyBRQCgBRBDC3IAMAsIAEANIAGgQQA0h7BphHQDSiPEQB+QCpBjAuDWQAbA3AWA1QBECiAwCqQAqChAXClQAcCuAPCvQAIB1gQBzIgDAtIgBASQgGAzgMArIADAiQAQCOACCNQgGA3gVA0QAWAGARAKQAwAbALAqQH1OSC7LvQDAMFgsRKgAiSzfQihA9hICcQhICdA8CiQA8CiCdBIQCdBHChg8QChg7BIieQBIidg8ihQg8iiidhIQhWgnhWAAQhIAAhKAbgA64ytQguARgUAsQgUAtARAuQARAuAsAUQAtAUAtgRQAugRAUgsQAVgtgRguQgRgtgtgVQgYgLgZAAQgUAAgVAIgEgT8gg0QgyASgVAwQgWAwASAwQATAxAvAWQAwAWAwgSQAygTAVgvQAWgwgSgxQgTgwgvgWQgagMgbAAQgVAAgWAIgEAIIgmzQg8AWgaA6QgbA5AXA8QAWA8A5AaQA6AaA7gWQA8gXAag5QAbg5gXg8QgVg7g7gbQgegOggAAQgbAAgbAKgEgGBgonQgsAQgUArQgUArARAsQAQAsArAUQArAUAsgRQAsgQAUgrQAUgrgRgsQgQgsgrgUQgXgLgYAAQgUAAgUAIg");
	this.shape_1508.setTransform(712.0287,509.3728);

	this.shape_1509 = new cjs.Shape();
	this.shape_1509.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AF6iuQBJCcg8ChQg8CiicBJQicBJihg8Qiig7hJicQhIidA7ihQA7iiCchJQCdhIChA7QCjA7BICdg");
	this.shape_1509.setTransform(694.5874,430.0374);

	this.shape_1510 = new cjs.Shape();
	this.shape_1510.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABrgwQAUAsgQAtQgRAugtAUQgsAVgtgRQgtgRgVgsQgUgsAQgtQAQguAtgVQAsgVAtARQAuARAVAtg");
	this.shape_1510.setTransform(525.4623,420.2376);

	this.shape_1511 = new cjs.Shape();
	this.shape_1511.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AByg0QAWAvgSAwQgSAxgvAWQgvAWgwgSQgxgSgWgvQgWgvASgwQASgxAvgWQAvgWAwASQAxASAWAvg");
	this.shape_1511.setTransform(562.9374,327.5374);

	this.shape_1512 = new cjs.Shape();
	this.shape_1512.graphics.f().s("#232323").ss(8,1,1).p("Al1oDQACgagLggIgehFIgYj9QAIgnAPgoIC8jrQAPgKAPgKIDohQQBNgJBTALQBIALBVAgIBdAoQgEgUgBgZQhkgvh6gVQlJg5jTDsQigDYAMCoQAmCvA5BUgAH2VFQABgMAEgNQg3gPg3ggQhghIhXhVQlJkUlFkqQgfgGgigNQBnBcBQBAIBKA6IE2EGQBmBXBnBXQAiAiAmAcQAxApAwApg");
	this.shape_1512.setTransform(559.3,410.1206);

	this.shape_1513 = new cjs.Shape();
	this.shape_1513.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACLg/QAbA6gXA6QgVA7g6AbQg5Abg7gWQg7gVgbg6Qgbg6AWg7QAWg6A5gcQA6gbA6AWQA8AWAbA6g");
	this.shape_1513.setTransform(740.2098,277.625);

	this.shape_1514 = new cjs.Shape();
	this.shape_1514.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABngvQAVArgRArQgQAtgrATQgqAVgsgRQgsgRgUgqQgUgrAQgrQARgtAqgUQArgTArAQQAtAQATArg");
	this.shape_1514.setTransform(647.345,269.6248);

	this.shape_1515 = new cjs.Shape();
	this.shape_1515.graphics.f().s("#232323").ss(7,1,1).p("AgbkIQgCAzgIAsIAGAhQAtCKgGCOQgCA3gQA2QAWAEARAIIAJgUQgkklgdjYg");
	this.shape_1515.setTransform(823.875,418.475);

	this.shape_1516 = new cjs.Shape();
	this.shape_1516.graphics.f().s("#232323").ss(0.1,1,1).p("EgPdgkDQgEgyAFg6QANidBQiNQBRiHCWhIQClhGC4BDQCmBDBSCyIAPArIAFAMIAEgQQArh+BihQQDGifEZBoQCxBWA+DRQAfA1AaA0QBRCcA9ClQA3CdAjCjQAqCrAdCuQARBzgHB1IABAsIAAATAt5GMQgsgiAEgzIAfAOQBwAqB6AZIAfAGQG/BSGsioIAQgGQBHgdBEgjQGPjVEqnFQBeiLA4h9QAzAXANApQJdOaDWLiQDcL3gzSKMgslgANQEkoxh0sHQhyr/mKm9gASexDQAbCNANCMA+Rn+QhEgag8gzQg3gwgohDQhyhogcixQgWjYCwirQA+g1BPgcQAegNAZgIQA8gSA9gBQABgCABgBQAQgVAGgaIACgMAzBBSQk1kulakP");
	this.shape_1516.setTransform(702.435,513.9176);

	this.shape_1517 = new cjs.Shape();
	this.shape_1517.graphics.f("#FFFFFF").s().p("AHIQRQiig7hIicQhJidA7iiQA8iiCchJQCdhIChA7QCjA8BICcQBJCcg7CiQg8CiicBJQhWAohYAAQhIAAhJgbgAxrKXQgugQgVgtQgUgsAQguQARguAtgUQArgWAvARQAuARAUAtQAVAsgRAuQgRAugsAUQgYAMgZAAQgVAAgUgIgAr3j/QgxgTgWgvQgWgvASgxQASgwAvgXQAvgWAxASQAxASAWAvQAWAwgSAwQgSAxgvAWQgZANgbAAQgWAAgWgIgAPrrZQg7gVgbg6Qgbg6AWg8QAWg6A5gbQA6gcA7AWQA8AWAbA6QAbA6gXA7QgVA7g6AbQgfAPghAAQgaAAgbgKgABYtOQgsgRgUgqQgUgqAQgtQARgtAqgTQArgUAsAQQAtAQATArQAVArgRAsQgQAtgrAUQgXALgYAAQgUAAgUgIg");
	this.shape_1517.setTransform(634.6058,365.0004);

	this.shape_1518 = new cjs.Shape();
	this.shape_1518.graphics.f("rgba(255,255,255,0.067)").s().p("AqLUpIhihSQAdAUAeASQgegSgdgUQgmgcgigiQgcgagZgfQAZAfAcAaIjNiuIk2kGIhKg6QhQhAhohcQAiANAfAGQFFEqFKEUQBXBVBhBIQA3AgA2APQgEANgBAMgArtTXIAAAAgAYKFQQARg1ACg4QAGiNguiLIgGghQAJgsABgzQAfDXAjEnIgIAUQgSgIgXgFgA4VsGQgMioChjYQDSjsFKA5QB7AVBjAvQABAZAEAUIhdgoQhVgghIgLQhTgLhMAJIjpBQIgfAUIi8DrQgOAogIAnIAYD9IAdBFQAMAggDAaQg5hUgmivg");
	this.shape_1518.setTransform(668.15,410.1206);

	this.shape_1519 = new cjs.Shape();
	this.shape_1519.graphics.f("#232323").s().p("EgItAuAQEkoxh0sHQhyr/mKm9QgsgiAEgzQABgMAEgNQg2gPg3ggQhhhIhXhVQk1kulakPQgegGgjgNQhEgag8gzQg3gwgohDQhyhogcixQgWjYCwirQA+g1BPgcQAegNAZgIQA8gSA9gBIACgDQAQgVAGgaIACgMQADgagMggIgdhFIgYj9QAIgnAPgoIC8jrIAegUIDphQQBMgJBTALQBIALBVAgIBdAoQgDgUgCgZQgEgyAFg6QANidBQiNQBRiHCWhIQClhGC4BDQCmBDBSCyIAPArIAFAMIAEgQQArh+BihQQDGifEZBoQCxBWA+DRQAfA1AaA0QBRCcA9ClQA3CdAjCjQAqCrAdCuQARBzgHB1IABAsIAAATQgCAzgIAsIAFAhQAbCNANCMQgCA4gQA1QAWAFASAIQg4B9heCLQkqHFmPDVQhEAjhHAdIgQAGIgIADQkbBukkAAIAAAAIgBAAQiOAAiQgaIgBAAIgEgBIgfgGQh6gZhwgqIgfgOIAfAOQBwAqB6AZIAfAGIAEABIABAAQCQAaCOAAIABAAIAAAAQEkAAEbhuIAIgDIAQgGQBHgdBEgjQGPjVEqnFQBeiLA4h9QAzAXANApQJdOaDWLiQDcL3gzSKgAj9zAQicBJg8CiQg7CiBJCdQBICcCiA7QCjA8CbhJQCchJA8iiQA7iihJicQhIidijg7QhHgbhIAAQhYAAhWAogA8awTQgtAVgRAuQgQAuAUAsQAVAsAuARQAuARAsgVQAsgUARguQARgugVgsQgUgtgugRQgVgHgUAAQgZAAgYALgA2n+5QgvAWgSAxQgSAxAWAvQAWAvAxASQAxASAvgWQAvgWASgxQASgxgWgvQgWgvgxgSQgWgIgWAAQgaAAgaAMgEAE5gnFQg5AcgWA6QgWA8AbA6QAbA6A7AVQA8AWA5gbQA6gbAVg7QAXg7gbg6Qgbg6g8gWQgagKgbAAQggAAggAPgEgJWgnyQgqAUgRAtQgQAsAUArQAUAqAsARQAtARAqgVQArgTAQgtQARgsgVgrQgTgrgtgQQgUgHgTAAQgYAAgYAKg");
	this.shape_1519.setTransform(702.435,513.9176);

	this.shape_1520 = new cjs.Shape();
	this.shape_1520.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGHiQQA8ChhJCdQhICdiiA7QigA8idhIQidhIg8iiQg8igBIidQBIidCig8QChg8CcBIQCeBIA8Cig");
	this.shape_1520.setTransform(712,423.55);

	this.shape_1521 = new cjs.Shape();
	this.shape_1521.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABugoQASAtgVAsQgUAtguARQgtAQgsgUQgtgUgRguQgRgtAUgsQAVgtAugRQAtgRAsAVQAtAUAQAug");
	this.shape_1521.setTransform(544.2124,400.2626);

	this.shape_1522 = new cjs.Shape();
	this.shape_1522.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB2grQASAwgWAwQgVAvgxASQgwASgwgWQgvgVgSgxQgSgwAWgwQAWgvAwgSQAwgSAwAWQAvAWASAwg");
	this.shape_1522.setTransform(588.975,310.825);

	this.shape_1523 = new cjs.Shape();
	this.shape_1523.graphics.f().s("#232323").ss(8,1,1).p("AlIo2QAEgagJghIgYhHIgHjzQAMgsAUgsIDqjrQACgBACgBIDRg7QBagIBiAVQBHARBSAnIBZAvIgBguQhgg2h4gfQlEhTjkDaQiyDKAACpQAYCyAyBYgAGKVSQACgMAFgNQg1gTg0gkQhbhQhPhbQkxkukulDQgdgJgigPQBgBkBLBGIBFBAIEgEeQBgBhBhBgQAcAgAhAdQAuAuAvAvg");
	this.shape_1523.setTransform(578.55,395.1806);

	this.shape_1524 = new cjs.Shape();
	this.shape_1524.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABrgmQARArgUArQgUArgsAQQgrAQgrgUQgsgTgQgsQgQgrAUgsQAUgrAsgQQArgQArAUQArAUAQAsg");
	this.shape_1524.setTransform(677.75,259.85);

	this.shape_1525 = new cjs.Shape();
	this.shape_1525.graphics.f().s("#232323").ss(4.9,1,1).p("AAAkJQgFAzgMAqIADAiQAiCOgRCMQgFA4gWA0QAXAGAQAJIAKgTQgMkogNjZg");
	this.shape_1525.setTransform(841.15,422.35);

	this.shape_1526 = new cjs.Shape();
	this.shape_1526.graphics.f().s("#232323").ss(0.1,1,1).p("EgMXglZQAAgxAJg6QAaicBbiGQBbiACcg7QCpg5CzBRQCfBRBDC3IAMAtIAEAMIAGgPQA1h7BohIQDSiPEQB/QCqBkAtDVIAwBtQBFCiAvCqQAqCgAWClQAeCuAOCwQAHB0gQB0IgDAtIgCASAT8vuQAQCOABCNAuME2QgpgmAIgyIAeAQQBsAzB4AjIAeAIQG3B1G4iEIARgFQBIgXBHgeQGdi0FQmsQBoiDBCh5QAxAcAKAqQHzOQC6LwQDAMGgqRHMgslgAIQDvpXhVsRQhVsKlDoKgA9YqlQhBggg5g3Qgyg0gjhHQhphxgOiyQgFjZC+icQBCgwBRgVQAegLAagGQA9gOA9AEIACgCQASgUAIgZIAEgMAy5gcQkclHlEkq");
	this.shape_1526.setTransform(712.1037,509.1978);

	this.shape_1527 = new cjs.Shape();
	this.shape_1527.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACQg0QAWA7gbA5QgaA5g8AXQg7AWg5gbQg4gagXg8QgXg6Abg6QAbg5A7gWQA7gXA5AbQA6AbAWA7g");
	this.shape_1527.setTransform(769.6773,275.2824);

	this.shape_1528 = new cjs.Shape();
	this.shape_1528.graphics.f("rgba(255,255,255,0.067)").s().p("ArRUxIhdhdQAcAYAeAWQgegWgcgYQghgdgcggQgbgegYgiQAYAiAbAeIjCjBIkgkeIhFhAQhLhGhghkQAiAPAdAJQEuFDEyEuQBPBbBbBQQA0AkA1ATQgFANgCAMgAsuTUIAAAAgAYNILQAVg0AGg3QASiMgjiPIgDgiQALgrAGgzQANDaAMEoIgKATQgRgJgWgGgA2vtAQABipCxjKQDljaFEBTQB4AfBgA2IABAuIhZgvQhSgnhHgRQhhgVhbAIIjSA7IgEACIjpDrQgVAsgMAsIAHDzIAYBHQAJAhgEAaQgyhYgYiyg");
	this.shape_1528.setTransform(683.825,395.1806);

	this.shape_1529 = new cjs.Shape();
	this.shape_1529.graphics.f("#FFFFFF").s().p("AFnQVQidhIg8iiQg8ihBIidQBIidCig8QCig8CcBIQCeBIA7CiQA8CihICdQhICdiiA7QhJAchIAAQhXAAhWgogAypIdQgtgUgRguQgRguAUgsQAVgtAugRQAugRAsAVQAtAUAQAuQASAugVAsQgUAtguARQgVAHgUAAQgZAAgYgLgArtlZQgvgWgTgxQgSgwAWgwQAWgvAxgTQAxgSAvAWQAwAWASAxQASAxgWAvQgWAwgxASQgVAIgWAAQgbAAgagMgAQVqkQg4gagXg8QgWg7Aag6QAbg5A7gWQA8gXA5AbQA6AbAWA7QAWA8gbA5QgZA5g8AXQgbAKgbAAQggAAgggPgACPtiQgsgTgQgtQgQgsAUgrQAUgrAsgQQAsgRArAUQArAVAQArQARAtgUAqQgUAsgsAQQgUAHgUAAQgXAAgYgLg");
	this.shape_1529.setTransform(658.7033,356.8657);

	this.shape_1530 = new cjs.Shape();
	this.shape_1530.graphics.f("#232323").s().p("EgKOAuyQDvpXhVsRQhVsKlDoKQgpgmAIgyIAeAQQBsAzB4AjIAeAIIAGACIAGABIABAAQDHA0DIAAIAAAAIABAAQDpAADphGIARgFQBIgXBHgeQGdi0FQmsQBoiDBCh5QhCB5hoCDQlQGsmdC0QhHAehIAXIgRAFQjpBGjpAAIgBAAIAAAAQjIAAjHg0IgBAAIgGgBIgGgCIgegIQh4gjhsgzIgegQQACgMAFgNQg1gTg0gkQhbhQhPhaQkclHlEkqQgdgJgigPQhBggg5g3Qgyg0gjhHQhphxgOiyQgFjZC+icQBCgwBRgVQAegLAagGQA9gOA9AEIACgCQASgUAIgZIAEgMQAEgagJghIgYhHIgHjzQAMgsAVgsIDpjrIAEgCIDSg7QBbgIBhAVQBHARBSAnIBZAvIgBguQAAgxAJg6QAaicBbiGQBbiACcg7QCpg5CzBRQCfBRBDC3IAMAtIAEAMIAGgPQA1h7BohIQDSiPEQB/QCqBkAtDVIAwBtQBFCiAvCqQAqCgAWClQAeCuAOCwQAHB0gQB0IgDAtIgCASQgGAzgLArIADAiQAQCOABCNQgGA3gVA0QAWAGARAJQAxAcAKAqQHzOQC6LwQDAMGgqRHgAiRzeQiiA8hICdQhICdA8ChQA8CiCdBIQCdBICgg8QCig7BIidQBIidg8iiQg7iiiehIQhVgnhXAAQhHAAhKAbgA63yvQguARgVAtQgUAsARAuQARAuAtAUQAsAUAugQQAugRAUgtQAVgsgSguQgQgugtgUQgYgMgZAAQgUAAgVAIgEgT6gg1QgxATgWAvQgWAwASAwQATAxAvAWQAwAWAwgSQAxgSAWgwQAWgvgSgxQgSgxgwgWQgagMgaAAQgWAAgWAIgEAIKgmxQg7AWgbA5QgaA6AWA7QAXA8A4AaQA6AbA8gWQA8gXAZg5QAbg5gWg8QgWg7g6gbQgegPggAAQgbAAgcALgEgF+gonQgsAQgUArQgUArAQAsQAQAtAsATQArAUAsgQQAsgQAUgsQAUgqgRgtQgQgrgrgVQgXgLgYAAQgUAAgUAIg");
	this.shape_1530.setTransform(712.1037,509.1978);

	this.shape_1531 = new cjs.Shape();
	this.shape_1531.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGRhwQAvClhVCWQhUCYimAuQilAviWhUQiYhVguimQguilBUiWQBViYClguQClgvCXBVQCXBVAuClg");
	this.shape_1531.setTransform(729.898,418.5);

	this.shape_1532 = new cjs.Shape();
	this.shape_1532.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABygfQANAugYArQgYAqgvANQguAOgqgYQgrgYgNgvQgOguAYgrQAYgqAvgOQAvgNAqAYQArAYANAvg");
	this.shape_1532.setTransform(564.5,381.85);

	this.shape_1533 = new cjs.Shape();
	this.shape_1533.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABugeQANAtgYApQgXAqgtAMQgtANgpgXQgqgYgMgtQgMgsAWgpQAYgqAtgNQAtgMAoAXQAqAXANAtg");
	this.shape_1533.setTransform(708.8833,252.5897);

	this.shape_1534 = new cjs.Shape();
	this.shape_1534.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB5ghQAPAxgaAuQgaAtgyAOQgwAPgugaQgugZgOgzQgOgwAZguQAaguAygOQAxgOAuAZQAtAaAOAyg");
	this.shape_1534.setTransform(616.2865,296.2865);

	this.shape_1535 = new cjs.Shape();
	this.shape_1535.graphics.f().s("#232323").ss(8,1,1).p("Ak5pkQAGgZgGgiIgShIIAUkHQANghATghIEAjYIDKgrIDFAcQBGAXBOAtQAhATA0AjIACgtQhag+h2gpQk8htj1DIQjBC8gOCnQAJCzArBcgAD9VYQADgMAGgMQgzgYgygnQhUhXhIhiQkYlFkSlaQgdgLgggSQBYBrBFBMIA/BFIEIE1ICwDOQAcAlAfAhIBUBhg");
	this.shape_1535.setTransform(602.225,381.6244);

	this.shape_1536 = new cjs.Shape();
	this.shape_1536.graphics.f().s("#232323").ss(6.6,1,1).p("AAhkKQgKA0gPApQgBASABAQQAXCPgcCLQgKA3gZAyQAWAJAPAKIALgTQAMknAFjbg");
	this.shape_1536.setTransform(857.55,427.7);

	this.shape_1537 = new cjs.Shape();
	this.shape_1537.graphics.f().s("#232323").ss(0.1,1,1).p("EgJPgmjQAFgyANg4QAmiaBmh+QBlh4CggvQCtgrCrBfQCZBdA0C9QAGAWADAXIACANIAIgPQA+h3Bug+QDdh/EFCVQCgBxAcDYQAXA5ARA3QA3CoAiCtQAeCjAICmQAPCxAACvQgCB1gZByIgGAsIgEASAVPuYQAECPgKCNAucDZQglgoAMgyIAcATQBoA8B1AsIAdAKQGsCXHChgIARgDQBKgRBJgZQGriSFwmPQByh7BLhzQAvAgAHAqQGJN+CeL7QCjMSgcQHMgslgAFQC+qAg3sYQg2sSj3pTgA8VtMQg+glg1g8Qgtg3gehKQhfh4AAi0QAMjYDKiNQBGgqBSgPQAfgJAagDQA/gJA8AJQABgBABgBQATgSALgZIAEgMAytiQQkBlckqlD");
	this.shape_1537.setTransform(722.5308,505.7443);

	this.shape_1538 = new cjs.Shape();
	this.shape_1538.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACTgoQASA8ggA3QgeA3g+ARQg8ASg3gfQg3gfgRg9QgRg9Aeg3QAfg2A9gSQA9gRA2AeQA4AgARA9g");
	this.shape_1538.setTransform(799.2801,275.3365);

	this.shape_1539 = new cjs.Shape();
	this.shape_1539.graphics.f("rgba(255,255,255,0.067)").s().p("AsaUyIhThhQAZAZAbAXQgbgXgZgZQggghgcglQgYgggUgjQAUAjAYAgIiwjOIkJk1Ig/hFQhFhMhYhrQAhASAcALQETFaEZFFQBIBiBUBXQAxAnA0AYQgHAMgDAMgAttTRIAAAAgAX9LFQAZgzALg2QAciLgXiRQgBgPABgSQAPgqAKgzQgFDbgMEoIgLASQgQgKgWgIgA1JtzQAPinDBi8QD1jIE9BtQB2ApBaA+IgCAtQg1gjghgTQhOgthGgXIjEgcIjMArIkADYQgSAhgOAhIgTEHIASBIQAFAigGAZQgqhcgKizg");
	this.shape_1539.setTransform(700.975,381.6244);

	this.shape_1540 = new cjs.Shape();
	this.shape_1540.graphics.f("#FFFFFF").s().p("AEDQRQiXhUguimQgvinBUiWQBViXCmguQCmgvCWBUQCXBVAuCmQAwCmhVCWQhUCXimAvQg8AQg5AAQhnAAhhg2gAzgGeQgqgYgOgvQgNguAYgrQAYgrAvgNQAvgOAqAYQArAYANAvQAOAwgYAqQgYAqgvAOQgRAFgRAAQgdAAgbgQgAremyQgtgYgPgzQgOgyAaguQAZgtAygPQAzgOAtAaQAtAZAPAyQAOAzgaAtQgZAtgyAPQgSAFgRAAQgfAAgegRgAQ5prQg2gfgSg9QgRg+Aeg3QAgg2A9gSQA9gRA3AeQA3AgASA9QARA9gfA3QgfA3g9ARQgXAHgVAAQgmAAgjgUgADFtxQgqgYgMgsQgNguAXgpQAYgqAsgMQAugNApAXQAqAYAMAtQANAugXAoQgXAqguAMQgQAFgQAAQgcAAgagPg");
	this.shape_1540.setTransform(683.6445,350.7084);

	this.shape_1541 = new cjs.Shape();
	this.shape_1541.graphics.f("#232323").s().p("EgL2AvWQC+qAg3sYQg2sSj3pTQglgoAMgyIAcATQBoA8B1AsIAdAKIADABIADABIAGACIAAAAIAEACIABAAIACABQD8BVEFAAIAAAAIAAAAQCrAACvglIARgDQBKgRBJgZQGriSFwmPQByh7BLhzQhLBzhyB7QlwGPmrCSQhJAZhKARIgRADQivAlirAAIAAAAIAAAAQkFAAj8hVIgCgBIgBAAIgEgCIAAAAIgGgCIgDgBIgDgBIgdgKQh1gshog8IgcgTQADgMAGgMQgzgYgygnQhUhWhIhiQkBlckqlDQgdgLgggSQg+glg1g8Qgtg3gehKQhfh4AAi0QAMjYDKiNQBGgqBSgPQAfgJAagDQA/gJA8AJIACgCQATgSALgZIAEgMQAGgZgGgiIgShIIAUkHQANghATghIEAjYIDLgrIDFAcQBGAXBOAtQAhATA0AjIACgtQAFgyANg4QAmiaBmh+QBlh4CggvQCtgrCrBfQCZBdA0C9QAGAWADAXIACANIAIgPQA+h3Bug+QDdh/EFCVQCgBxAcDYQAXA5ARA3QA3CoAiCtQAeCjAICmQAPCxAACvQgCB1gZByIgGAsIgEASQgJAzgPAqQgCASACAPQAECPgKCNQgLA2gZAzQAWAIAQAKQAvAgAHAqQGJN+CeL7QCjMSgcQHgAgmz4QimAuhVCXQhUCWAvCnQAuCmCXBUQCVBUCnguQCmgvBUiXQBViWgwimQguimiXhVQhhg2hnAAQg5AAg6ARgA5L1HQgvANgYArQgYArANAuQAOAvAqAYQArAYAvgNQAvgOAYgqQAYgqgOgwQgNgvgrgYQgbgPgdAAQgQAAgRAFgEgRIginQgyAPgZAtQgaAuAOAyQAPAzAtAYQAuAaAygOQAygPAZgtQAagtgOgzQgPgygtgZQgdgRggAAQgRAAgSAFgEALWgmSQg9ASggA2QgeA3ARA+QASA9A2AfQA3AfA+gSQA9gRAfg3QAfg3gRg9QgSg9g3ggQgjgUgmAAQgVAAgWAHgEgCngpQQgsAMgYAqQgXApANAuQAMAsAqAYQApAXAtgNQAugMAXgqQAXgogNguQgMgtgqgYQgbgPgcAAQgQAAgQAFg");
	this.shape_1541.setTransform(722.5308,505.7443);

	this.shape_1542 = new cjs.Shape();
	this.shape_1542.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB0gWQAJAvgbApQgbApgwAJQgvAJgpgbQgpgbgJgwQgJgvAbgpQAbgpAwgJQAvgJApAbQAoAbAKAwg");
	this.shape_1542.setTransform(586.2139,365.15);

	this.shape_1543 = new cjs.Shape();
	this.shape_1543.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABwgVQAKAtgbAnQgbAoguAJQgtAJgngbQgogagJguQgJguAbgnQAagnAugJQAugJAnAaQAnAbAJAug");
	this.shape_1543.setTransform(740.4461,247.85);

	this.shape_1544 = new cjs.Shape();
	this.shape_1544.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB8gXQAKAygeArQgcArg0AKQgyALgrgeQgrgcgLg0QgJgyAcgrQAegrAzgKQAxgLAsAeQArAdALAzg");
	this.shape_1544.setTransform(644.6828,284);

	this.shape_1545 = new cjs.Shape();
	this.shape_1545.graphics.f().s("#232323").ss(8,1,1).p("AkpqLQAJgagDgiIgNhJIAokCQAQghAWggIEDi/QAGgDAHgCIDigYQBWAIBXAiQBEAcBKAzQAgAWAxAnIAGgtQhVhFhygyQkziGkECzQjPCsgcCmQgFC0AjBfgABtVXQAEgMAHgLQgygcgtgsQhMhdhAhnQj+laj2lvQgbgOgfgUQBPByA+BRIA6BKIDvFJICdDYQAaAqAgAlIBIBmg");
	this.shape_1545.setTransform(627.175,369.6316);

	this.shape_1546 = new cjs.Shape();
	this.shape_1546.graphics.f().s("#232323").ss(7,1,1).p("AA1kHQgOAxgSAoIgDAiQAMCSgnCHQgPA2gdAwQAVAKAPALIANgRQAjklAWjZg");
	this.shape_1546.setTransform(874.75,434.475);

	this.shape_1547 = new cjs.Shape();
	this.shape_1547.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGZhQQAhCphgCPQhgCQipAhQipAhiPhgQiPhggiiqQghioBgiPQBgiPCpgiQCpghCPBgQCQBhAhCog");
	this.shape_1547.setTransform(748.125,414.9138);

	this.shape_1548 = new cjs.Shape();
	this.shape_1548.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACWgdQAMA+gjA0QgjA1g+AMQg+AMg0gjQg1gjgMg/QgMg9Ajg1QAjgzA/gNQA9gMA0AjQA1AjAMA+g");
	this.shape_1548.setTransform(828.7234,277.7734);

	this.shape_1549 = new cjs.Shape();
	this.shape_1549.graphics.f().s("#232323").ss(0.1,1,1).p("EgGGgniQAHgwATg4QAyiVBvh3QBvhvCigiQCxgdCjBsQCRBpAlDBQAEAXABAWIABANIAJgOQBIhxByg2QDnhsD3CpQCYB9AKDaQASA6ANA5QAqCrAUCvQAQCmgFCmQABCxgOCvQgLB0gjBwIgKArIgEATAWVs/QgHCOgVCMAupB4QgigsAQgwIAbAVQBiBDBxA2IAcAMQGfC6HIg8IARgDQBLgKBLgTQG1hvGPlxQB8hxBUhtQAsAkADAqQEjNkCAMEQCEMcgIPGMgsmAAAQCSqtgYseQgYsXikqUgA7LvxQg8gqguhAQgpg7gYhMQhViAAOiyQAejXDUh8QBJglBTgIQAggGAagBQA/gEA7ANQACgBABgBQAUgPANgZIAFgLAyckGQjllwkPla");
	this.shape_1549.setTransform(733.7177,503.5692);

	this.shape_1550 = new cjs.Shape();
	this.shape_1550.graphics.f("rgba(255,255,255,0.067)").s().p("AtqUsIhKhmQAWAaAYAYQgYgYgWgaQggglgagqQgUgggQgjQAQAjAUAgIidjYIjvlJIg5hKQg+hRhQhyQAfAUAcAOQD2FvD+FaQBABnBMBdQAuAsAyAcQgHALgEAMgAu0TGIAAAAgAXXN7QAdgvAPg2QAoiIgMiSIACgiQATgpAOgxQgXDZgjEmIgNASQgPgMgVgKgAznueQAcimDQisQEFizEyCGQByAyBWBFIgGAtQgygngfgWQhLgzhDgcQhYgihVgIIjjAYIgNAFIkDC/QgWAggRAhIgnECIAMBJQADAigIAaQgjhfAEi0g");
	this.shape_1550.setTransform(719.925,369.6316);

	this.shape_1551 = new cjs.Shape();
	this.shape_1551.graphics.f("#FFFFFF").s().p("ACdQGQiPhgghiqQghipBfiPQBgiPCpgiQCqghCPBgQCQBhAhCoQAhCqhgCPQhgCQipAhQgsAIgpAAQh5AAhrhHgA0PEcQgpgbgJgwQgJgwAbgpQAbgoAwgKQAwgJApAbQAoAbAKAwQAJAwgbApQgbApgwAJQgMACgMAAQgjAAgegUgArLoIQgqgcgLg0QgKgzAdgrQAdgsAzgKQAzgKAsAdQArAeAKAyQAKAzgdAsQgdArgzAKQgOADgNAAQgkAAgggWgARWowQg1gigMg/QgMg+Ajg1QAjg0A/gNQA+gMA0AjQA1AkAMA+QAMA/gjA0QgjA0g+ANQgQADgPAAQgtAAgngbgAD5t7QgogagJgvQgJguAbgnQAagoAugJQAvgJAnAbQAnAaAJAuQAKAvgbAnQgbAoguAIQgMACgLAAQghAAgdgTg");
	this.shape_1551.setTransform(709.2279,346.533);

	this.shape_1552 = new cjs.Shape();
	this.shape_1552.graphics.f("#232323").s().p("ArtYjQgYsXikqUQgigsAQgwIAbAVQBiBDBxA2IAcAMIAEACQE3CKFPAAIABAAIAAAAQBqAABtgOIAFAAIARgDQBLgKBLgTQG1hvGPlxQB8hxBUhtQhUBth8BxQmPFxm1BvQhLAThLAKIgRADIgFAAQhtAOhqAAIAAAAIgBAAQlPAAk3iKIgEgCIgcgMQhxg2hihDIgbgVQAEgMAHgMQgygagugsQhMhdhAhnQjllwkPlaQgcgNgfgUQg8gqguhAQgpg7gYhMQhViAAOiyQAejXDUh8QBJglBTgIQAggGAagBQA/gEA7ANIADgCQAUgPANgZIAFgLQAIgZgDgiIgMhKIAnkBQARghAWghIEDi/IANgEIDjgZQBVAIBYAiQBDAcBLA0QAfAWAyAmIAGgtQAHgwATg4QAyiVBvh3QBvhvCigiQCxgdCjBsQCRBpAlDBQAEAXABAWIABANIAJgOQBIhxByg2QDnhsD3CpQCYB9AKDaQASA6ANA5QAqCrAUCvQAQCmgFCmQABCxgOCvQgLB0gjBwIgKArIgEATQgOAxgTAoIgCAiQgHCOgVCMQgPA2gdAwQAVAKAPALQAsAkADAqQEjNkCAMEQCEMcgIPGMgsmAAAQCSqtgYsegAA/0OQioAhhgCPQhgCPAhCqQAiCpCPBgQCOBgCqghQCpghBgiQQBgiPghipQghipiQhhQhqhHh5AAQgqAAgsAJgA3Z3bQgwAJgbApQgbApAJAwQAJAwApAbQApAbAwgJQAwgKAbgoQAbgpgJgwQgKgwgogbQgfgUgjAAQgLAAgMACgEgOSgkOQgzAKgdArQgdAsAKAzQALAzAqAdQAsAdAzgKQAzgKAdgsQAdgrgKgzQgKgzgrgdQghgWgkAAQgMAAgOADgEAOZglnQg/ANgjAzQgjA1AMA+QAMA/A1AjQA0AjA/gMQA+gMAjg1QAjg0gMg/QgMg+g1gjQgmgagtAAQgPAAgQADgEAAtgpsQgtAJgaAnQgbAnAJAvQAJAuAnAaQAnAbAugJQAugJAbgoQAbgngKguQgJgugngbQgdgTgiAAQgLAAgMACg");
	this.shape_1552.setTransform(733.7177,503.5692);

	this.shape_1553 = new cjs.Shape();
	this.shape_1553.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB1gNQAGAwgfAmQgeAngxAFQgvAGgmgfQgmgegGgxQgFgvAdgnQAfgmAwgFQAwgGAmAeQAnAfAFAwg");
	this.shape_1553.setTransform(609.1808,350.2677);

	this.shape_1554 = new cjs.Shape();
	this.shape_1554.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB9gOQAGA0ggAoQggApg0AGQgzAGgpghQgpgggGg0QgGgyAhgpQAggpA0gGQAzgGAoAgQAqAhAFAzg");
	this.shape_1554.setTransform(673.95,274.05);

	this.shape_1555 = new cjs.Shape();
	this.shape_1555.graphics.f().s("#232323").ss(8,1,1).p("AkWquQALgYgBgjIgHhKIA/kCQASgdAXgdIEWirQAEgBAEgBIDrgFQBRAPBSAoQBBAiBGA5QAdAXAvArIAJgsQhQhMhtg6QkoiekQCdQjdCbgqCjQgTCyAcBigAgiVPQAFgMAIgLQgwgfgqgvQhFhjg3hsQjilujYmBQgagQgdgXQBGB4A3BWIA0BOIDUFbQBHB1BHB1QAVAoAaAlQAhA2AiA2g");
	this.shape_1555.setTransform(653.1,359.2687);

	this.shape_1556 = new cjs.Shape();
	this.shape_1556.graphics.f().s("#232323").ss(7,1,1).p("ABKkEQgSAwgWAnIgFAiQAACSgxCEQgUA0ghAuQAVALAOANIAOgQQA6kiAojXg");
	this.shape_1556.setTransform(891.325,442.575);

	this.shape_1557 = new cjs.Shape();
	this.shape_1557.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGegvQAUCrhsCHQhrCIirATQirATiHhrQiHhsgUirQgTiqBriHQBsiHCrgUQCqgUCHBsQCHBrAUCrg");
	this.shape_1557.setTransform(766.5882,412.8184);

	this.shape_1558 = new cjs.Shape();
	this.shape_1558.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACYgRQAHA/gnAxQgnAyhAAHQg+AHgygnQgwgngIg/QgHg/AngyQAogwA+gIQA/gIAxAoQAyAoAHA+g");
	this.shape_1558.setTransform(857.9129,282.55);

	this.shape_1559 = new cjs.Shape();
	this.shape_1559.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABxgMQAGAugeAlQgdAlgvAFQguAGglgeQglgegGguQgFguAeglQAdglAvgFQAugFAlAdQAlAeAFAug");
	this.shape_1559.setTransform(772.3064,245.6814);

	this.shape_1560 = new cjs.Shape();
	this.shape_1560.graphics.f().s("#232323").ss(0.1,1,1).p("EgC/goVQALgwAXg2QA+iSB3hsQB4hmClgVQCygPCaB5QCIB1AWDCIABAuIABANIAJgOQBRhqB2gtQDvhZDpC8QCNCJgHDaQANA8AJA5QAbCuAGCwQADCmgSCmQgOCwgbCuQgVBzgrBsIgNArIgGARAu1AQQgegtAUgvIAZAXQBcBLBtA9IAbAPQGPDaHLgXIARgBQBMgFBMgMQG+hNGqlPQCEhnBdhlQAoAmABArQC9NBBiMMQBmMiAQOIMgslAAEQBnrdAHshQAIsahOrPgAXOrmQgSCNggCKA55yWQg4gugqhDQgkg+gRhOQhLiHAciwQAwjUDchrQBMgeBUgCQAggDAaABQA/ABA6ASIADgCQAWgPAOgWIAGgLAyImAQjHmBjzlu");
	this.shape_1560.setTransform(745.6326,502.8926);

	this.shape_1561 = new cjs.Shape();
	this.shape_1561.graphics.f("rgba(255,255,255,0.067)").s().p("Au1UfIhChsQAUAcAWAbQgWgbgUgcQgaglgVgoQgTglgQgmQAQAmATAlIiPjqIjTlbIg0hOQg4hWhGh4QAeAXAaAQQDYGBDhFuQA4BsBEBjQArAvAvAfQgIALgEAMgAv3SzIAAAAgAWnQuQAhguATg0QAziEAAiTIAFgiQAVgnATgwQgoDXg7EjIgPAQQgOgNgUgLgAx8vCQApijDdibQESidEnCeQBtA6BQBMIgJAsQgvgrgdgXQhFg5hCgiQhRgohSgPIjrAFIgHACIkXCrQgXAdgTAdIg+ECIAHBKQAAAjgKAYQgchiATiyg");
	this.shape_1561.setTransform(739.25,359.2687);

	this.shape_1562 = new cjs.Shape();
	this.shape_1562.graphics.f("#FFFFFF").s().p("AA2PzQiGhsgUirQgTirBriIQBriHCrgTQCrgUCHBrQCHBsAUCrQAUCshsCGQhrCIirATQgbADgZAAQiNAAhyhagA01CXQgmgegGgxQgFgwAdgmQAfgmAwgFQAxgGAmAeQAnAfAFAvQAGAxgfAmQgeAngxAFIgOABQgoAAgggagARrnxQgxgngIhAQgGg/AmgyQAogwA/gIQBAgIAwAoQAzAoAGA+QAIBAgoAxQgnAyg/AHIgUABQgzAAgqghgAqzpcQgogggGg0QgGgzAggpQAhgpAzgGQA0gGApAgQApAhAGAzQAGA0ghApQggApg0AGIgQABQgqAAgjgcgAEruBQgkgegGguQgFgvAdglQAeglAugFQAwgFAkAdQAlAeAGAuQAFAvgeAlQgdAlgvAFIgOABQgnAAgfgZg");
	this.shape_1562.setTransform(735.2986,344.3885);

	this.shape_1563 = new cjs.Shape();
	this.shape_1563.graphics.f("#232323").s().p("AtvX5QAIsahOrPQgegtAUgvQAEgMAJgLQgwgfgqgvQhFhjg3hsQjHmBjzluQgagQgdgXQg4gugqhDQgkg+gRhOQhLiHAciwQAwjUDchrQBMgeBUgCQAggDAaABQA/ABA6ASIADgCQAWgPAOgWIAGgLQAKgYAAgjIgHhKIA/kCQASgdAXgdIEXirIAIgCIDqgFQBSAPBRAoQBCAiBFA5QAeAXAuArIAKgsQALgwAXg2QA+iSB3hsQB4hmClgVQCygPCaB5QCIB1AWDCIABAuIABANIAJgOQBRhqB2gtQDvhZDpC8QCNCJgHDaQANA8AJA5QAbCuAGCwQADCmgSCmQgOCwgbCuQgVBzgrBsIgNArIgGARQgSAwgWAnIgFAiQgSCNggCKQgUA0ghAuQAVALAOANQhdBliEBnQmqFPm+BNQhMAMhMAFIgRABIgEAAIgCAAIgEABQgmABgmAAIAAAAIgBAAQmVAAlmjAIgEgDIgEgCIgbgPQhtg9hchLIgZgXIAZAXQBcBLBtA9IAbAPIAEACIAEADQFmDAGVAAIABAAIAAAAQAmAAAmgBIAEgBIACAAIAEAAIARgBQBMgFBMgMQG+hNGqlPQCEhnBdhlQAoAmABArQC9NBBiMMQBmMiAQOIMgslAAEQBnrdAHshgACi0hQiqAThsCHQhrCIAUCrQATCrCIBsQCGBrCrgUQCsgTBriIQBsiGgVisQgTiriHhsQhzhbiLAAQgaAAgbAEgA1h5qQgwAFgfAmQgeAnAFAwQAGAxAmAeQAnAfAwgGQAxgFAegnQAegmgFgxQgGgwgmgfQgggZgoAAIgPABgEARRgkyQg+AIgoAwQgnAyAHA/QAIBAAwAnQAyAnA/gHQBAgHAngyQAngxgHhAQgHg+gygoQgpgig0AAIgUACgEgLaglsQg0AGggApQghApAGAzQAGA0ApAgQApAhA0gGQA0gGAggpQAggpgGg0QgFgzgqghQgigbgqAAIgQABgEAD+gp8QgvAFgdAlQgeAlAFAvQAGAuAlAeQAlAeAvgGQAvgFAdglQAeglgGgvQgFguglgeQgfgZgoAAIgNABg");
	this.shape_1563.setTransform(745.6326,502.8926);

	this.shape_1564 = new cjs.Shape();
	this.shape_1564.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB2gDQABAwghAkQghAjgxACQgwACgkgiQgkghgBgxQgCgvAiglQAhgjAxgCQAwgCAjAiQAkAhACAxg");
	this.shape_1564.setTransform(633.25,337.2779);

	this.shape_1565 = new cjs.Shape();
	this.shape_1565.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB+gDQACAzgkAmQgjAlg1ADQgyACgngkQgmgjgCg1QgCgyAkgnQAkgmA0gCQAzgCAmAkQAmAjACA1g");
	this.shape_1565.setTransform(703.9277,266.5);

	this.shape_1566 = new cjs.Shape();
	this.shape_1566.graphics.f().s("#232323").ss(8,1,1).p("AkBrKQALgXAEgiIgChLIBLjvQAXgjAgggIEjiVQACAAACAAQACgBACAAIDaAKQBYAVBWAyQA9AnBCA/QAbAZArAvIANgrQhJhShphDQkZi1keCHQjnCIg3CgQghCwAUBjgAiyVAQAGgLAIgKQgrgjgogzQg8hogvhwQjDl+i4mSQgagSgbgZQA8B9AxBaIAtBTIC4FqIB6D0QASApAWAlIA7B1g");
	this.shape_1566.setTransform(679.85,350.5413);

	this.shape_1567 = new cjs.Shape();
	this.shape_1567.graphics.f().s("#232323").ss(7,1,1).p("ABdj+QgVAugZAlIgIAhQgLCRg9CAQgXAzgkAqQATANANAOIAQgPQBQkcA5jSg");
	this.shape_1567.setTransform(907.225,452.025);

	this.shape_1568 = new cjs.Shape();
	this.shape_1568.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGggNQAGCrh2B+Qh1B/itAFQirAGh+h1Qh/h3gFisQgGirB2h+QB2h/CsgFQCrgGB+B2QB+B2AGCsg");
	this.shape_1568.setTransform(785.175,412.2251);

	this.shape_1569 = new cjs.Shape();
	this.shape_1569.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACZgFQACA/grAuQgrAuhAADQg+ACgvgsQgtgqgDhAQgCg+ArgvQArguBAgCQA/gCAtArQAvArACA/g");
	this.shape_1569.setTransform(886.6273,289.7023);

	this.shape_1570 = new cjs.Shape();
	this.shape_1570.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABygDQACAvghAiQggAjgvABQguACgjghQgigggCgvQgBguAggjQAhgiAugCQAvgBAiAgQAjAhABAug");
	this.shape_1570.setTransform(804.25,246.1);

	this.shape_1571 = new cjs.Shape();
	this.shape_1571.graphics.f().s("#232323").ss(0.1,1,1).p("EgAbgo8QAQgvAZg0QBKiMCAhjQCAhcCmgIQCzAACPCFQB/B/AGDEIgDAtIAAANIAKgMQBahlB5giQD0hGDaDOQCCCUgZDZQAJA8AEA6QANCwgICwQgLCmgfCjQgbCugqCsQgeBwgzBpIgRApIgHASAvehbQgagxAXgtIAXAZQBWBTBnBGIAaAQQF8D5HLAOIASABQBMABBMgHQHCgoHFksQCMhcBlheQAlAqgDArQBbMWBEMQQBGMnAtNLMgslAAJQBBsQAnsiQAnsaAOsCgAXaqNQgeCLgrCHA5B03Qg0gzgkhGQgghBgKhOQhBiNAritQBAjQDlhYQBOgZBTAGQAhgCAaAEQA/AGA4AXIACgCQAYgMAQgWIAGgLAyRn8QinmPjVmB");
	this.shape_1571.setTransform(761.3888,503.5249);

	this.shape_1572 = new cjs.Shape();
	this.shape_1572.graphics.f("rgba(255,255,255,0.067)").s().p("Av6UNIg6h1QASAgAWAdQgWgdgSggQgWglgSgpQgQglgMgoQAMAoAQAlIh7j0Ii3lqIgthTQgwhag9h9QAbAZAaASQC4GSDDF+QAvBwA9BoQAnAzArAjQgJAKgFALgAVvTbQAkgqAXgzQA9iAAMiSIAHghQAZglAWguQg5DShSEdIgPAPQgOgOgSgNgAw0SYIAAAAgAwKvdQA2igDpiIQEeiHEZC1QBpBDBJBSIgNArQgrgvgbgZQhCg/g+gnQhVgyhYgVIjagKIgEABIgEAAIkkCVQggAggXAjIhLDvIABBLQgCAigMAXQgUhjAhiwg");
	this.shape_1572.setTransform(758.85,350.5413);

	this.shape_1573 = new cjs.Shape();
	this.shape_1573.graphics.f("#FFFFFF").s().p("AgwPYQh/h2gFisQgGitB2h+QB1h+CsgGQCsgGB+B2QB+B2AGCsQAGCth2B+Qh1B/itAFIgQAAQiiAAh3hwgA1UAQQgkgggBgxQgCgwAiglQAhgjAxgCQAxgCAjAiQAkAhACAxQABAxghAjQghAjgxACIgHAAQgsAAgigggAR5mxQgugrgChAQgCg/AqguQAsgvA/gCQBAgCAuArQAuAsACA/QADBAgsAtQgqAvhAACIgHAAQg7AAgsgpgAqWqtQgmgjgCg0QgCg0AjgnQAkgmA0gCQA0gBAmAjQAnAkABA0QADA0glAmQgjAmg0ACIgEAAQgxAAglgigAFcuCQgjgggBgvQgCgvAggjQAhgiAvgCQAvgBAiAgQAkAhABAuQABAwggAiQggAjgwABIgEAAQgsAAghgfg");
	this.shape_1573.setTransform(761.6786,344.2862);

	this.shape_1574 = new cjs.Shape();
	this.shape_1574.graphics.f("#232323").s().p("AwTXBQAnsaAOsCQgagxAXgtQAFgLAJgKQgsgjgngzQg8hogvhwQinmPjVmBQgZgSgbgZQg0gzgkhGQgghBgKhOQhBiNAritQBAjQDlhYQBOgZBTAGQAhgCAaAEQA/AGA4AXIACgCQAYgMAQgWIAGgLQAMgXADgiIgBhLIBKjvQAYgiAfghIEliVIAEAAIADgBIDbAKQBYAVBVAyQA+AnBCA/QAbAZArAvIANgrQAQgvAZg0QBKiMCAhjQCAhcCmgIQCzAACPCFQB/B/AGDEIgDAtIAAANIAKgMQBahlB5giQD0hGDaDOQCCCUgZDZQAJA8AEA6QANCwgICwQgLCmgfCjQgbCugqCsQgeBwgzBpIgRApIgHASQgWAugZAlIgHAhQgeCLgrCHQgXAzglAqQATANAOAOQhlBeiMBcQnFEsnCAoIgFABQg/AFg/AAIgBAAIAAAAIgRAAIgDAAIgSgBQnLgOl8j5IgagQQhnhGhWhTIgXgZIAXAZQBWBTBnBGIAaAQQF8D5HLAOIASABIADAAIARAAIAAAAIABAAQA/AAA/gFIAFgBQHCgoHFksQCMhcBlheQAlAqgDArQBbMWBEMQQBGMnAtNLMgslAAJQBBsQAnsigADg0wQisAFh1B/Qh2B+AGCsQAFCsB/B3QB9B1CsgGQCtgFB1h/QB2h+gGisQgGish+h2Qh4hxiiAAIgQABgA0E7zQgxACghAjQgiAkACAxQABAxAkAhQAkAiAxgDQAxgBAhgkQAhgkgBgxQgCgxgkghQghgfguAAIgFAAgEATfgjyQg/ACgsAuQgqAvACA/QACBAAuAqQAuAsBAgCQBAgDAqguQAsgugDhAQgCg/gugrQgsgpg8AAIgGAAgEgJCgm/Qg0ACgkAmQgjAnACAzQACA1AmAjQAmAjA0gBQA0gDAjglQAlgngDg0QgBg0gngjQgkgigyAAIgEAAgEAGpgp/QgvABghAjQggAjACAvQABAvAjAgQAiAgAvgBQAwgBAggkQAggigBgvQgBgvgkghQgggegtAAIgEAAg");
	this.shape_1574.setTransform(761.3888,503.5249);

	this.shape_1575 = new cjs.Shape();
	this.shape_1575.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB2AFQgCAxglAhQgkAhgwgCQgwgCghgkQghgkACgwQACgxAkghQAkghAwACQAxADAhAjQAhAkgCAwg");
	this.shape_1575.setTransform(658.3001,326.275);

	this.shape_1576 = new cjs.Shape();
	this.shape_1576.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB+AGQgCA0gnAjQgmAjg0gCQgzgCgkgnQgjgmACg0QADgzAmgkQAngjAzACQA0ADAjAmQAjAngCAzg");
	this.shape_1576.setTransform(734.4051,261.3751);

	this.shape_1577 = new cjs.Shape();
	this.shape_1577.graphics.f().s("#232323").ss(7,1,1).p("ABxj4QgaAugbAjIgLAfQgXCQhGB7QgcAwgoAoQAUAPALAPIARgOQBnkVBKjOg");
	this.shape_1577.setTransform(922.3,462.7);

	this.shape_1578 = new cjs.Shape();
	this.shape_1578.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGgATQgICsh/B0QiAB1irgIQisgIh1iAQh0h/AIirQAIitB/h0QCBh0CqAIQCtAHB0CAQB0CAgICrg");
	this.shape_1578.setTransform(803.7499,413.153);

	this.shape_1579 = new cjs.Shape();
	this.shape_1579.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACZAHQgDBAgvAqQguArg/gDQhAgDgqgvQgrguADg/QADg/AvgrQAugqA/ACQBAADAqAvQArAugDA/g");
	this.shape_1579.setTransform(914.6749,299.131);

	this.shape_1580 = new cjs.Shape();
	this.shape_1580.graphics.f().s("#232323").ss(8,1,1).p("AjrrgQAOgWAFgiIAFhKIBoj1QAXgaAagYIEuh9QAEAAAEAAIDkAeQBQAdBMA1QA8ArA7BEQAaAcAmAyIARgqQhDhYhihLQkLjMknBxQjyB1hCCbQgwCtAMBkgAlBUqQAGgLAKgJQgpgmgig2Qg1htglhzQikmNiYmfQgYgUgZgbQAyCCAqBdIAmBWICaF4QAzB9AzB+QAPArAUAqQAYA7AYA7g");
	this.shape_1580.setTransform(707.275,343.5724);

	this.shape_1581 = new cjs.Shape();
	this.shape_1581.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("AByAFQgCAwgjAfQgjAggugCQgvgCgggjQgggjACguQADgvAiggQAkggAtACQAwACAfAjQAhAkgDAtg");
	this.shape_1581.setTransform(836.0286,249.0719);

	this.shape_1582 = new cjs.Shape();
	this.shape_1582.graphics.f().s("#232323").ss(0.1,1,1).p("EAAcgpXQATgtAfgyQBUiGCJhYQCGhRCmAFQCzAOCECQQB0CJgKDEQgBAWgFAXIgBANIALgMQBhhcB8gaQD6gyDIDfQB1CegpDWQADA9gBA6QAACwgWCvQgZClgrCgQgqCsg3CnQgmBtg9BlIgUAoIgIAQAxtjLQgXgzAbgqIAVAaQBQBaBhBOIAYATQFnEWHKAyIARACQBLAHBNAAQHCgEHckHQCThQBshWQAiAtgGAqQgDLkAlMSQAmMpBPMRMgslAANQAftGBGsfQBGsYBusvgAVvo0QgoCJg2CDA5r3TQgwg3gehJQgahEgEhOQg1iRA5iqQBPjKDshGQBPgSBTAMQAhACAaAFQA9ALA3AbIACgBQAYgLASgUIAIgKAz+p5QiGmbi2mR");
	this.shape_1582.setTransform(788.079,505.5076);

	this.shape_1583 = new cjs.Shape();
	this.shape_1583.graphics.f("rgba(255,255,255,0.067)").s().p("AUsVIQAogoAcgwQBGh7AYiRIAKggQAcgjAZgtQhJDOhpEVIgQAOQgMgPgTgOgAw3S4Igxh3QAQAgASAeQgSgegQggQgUgpgPgsQgMgmgJgnQAJAnAMAmIhmj7Iial4IgmhVQgqhegxiBQAZAbAYATQCXGfCkGNQAmB0A0BsQAjA2ApAmQgKAKgGALgAxoRBIAAAAgAuRwsQBDiaDyh2QEohwEKDLQBiBLBCBYIgQAqQgngxgZgdQg7hDg7gsQhMg1hRgcIjjgfIgJABIkuB8QgbAYgWAaIhoD1IgGBLQgEAhgPAXQgLhlAvitg");
	this.shape_1583.setTransform(778.625,349.4474);

	this.shape_1584 = new cjs.Shape();
	this.shape_1584.graphics.f("#FFFFFF").s().p("ACIQ9QirgHh1iAQh0iAAIisQAIisB/h1QCAh0CrAIQCtAIB0B/QB0CBgICrQgICth/B0Qh3BtieAAIgXgBgA0YhRQgwgCghgkQghgkACgxQACgwAkgiQAkghAxADQAxACAhAkQAhAkgCAxQgCAxglAhQghAegtAAIgHAAgATpk9Qg/gDgrgvQgqguADhAQADg/AugrQAvgqA/ACQBAADAqAvQArAugDBAQgDBAgvAqQgqAog6AAIgKAAgAofrSQgzgCgkgnQgjgmACg0QADg0AmgjQAngjA0ACQA0ACAjAnQAjAmgCA0QgCA0gnAkQgkAggxAAIgGAAgAHZtZQgvgCgggjQgggjACgvQADgvAiggQAkggAuADQAwABAfAkQAhAjgDAvQgCAvgjAgQghAdgsAAIgFAAg");
	this.shape_1584.setTransform(788.2291,346.2447);

	this.shape_1585 = new cjs.Shape();
	this.shape_1585.graphics.f("#232323").s().p("A0hV8QBGsYBusvQgXgzAbgqIAVAaQBQBaBhBOIAYATQFnEWHKAyIARACQBLAHBNAAQHCgEHckHQCThQBshWQAiAtgGAqQgDLkAlMSQAmMpBPMRMgslAANQAftGBGsfgAhJD3IgRgCQnKgylnkWIgYgTQhhhOhQhaIgVgaQAGgLAKgKQgpgmgig2Qg1hsglh0QiGmbi2mRQgYgTgZgbQgwg3gehJQgahEgEhOQg1iRA5iqQBPjKDshGQBPgSBTAMQAhACAaAFQA9ALA3AbIACgBQAYgLASgUIAIgKQAOgXAFghIAFhLIBoj1QAXgaAagYIEvh8IAIgBIDkAfQBQAcBMA1QA8AsA7BDQAaAdAlAxIARgqQATgtAfgyQBUiGCJhYQCGhRCmAFQCzAOCECQQB0CJgKDEQgBAWgFAXIgBANIALgMQBhhcB8gaQD6gyDIDfQB1CegpDWQADA9gBA6QAACwgWCvQgZClgrCgQgqCsg3CnQgmBtg9BlIgUAoIgIAQQgaAtgbAjIgLAgQgoCJg2CDQgbAwgoAoQATAOALAPQhsBWiTBQQncEHnCAEQhNAAhLgHgAh7zPQiAB1gHCsQgICsB0CAQB1CACqAHQCtAJB/h1QCAh0AIitQAIirh1iBQh0h/isgIIgWAAQidAAh4BsgA1g9XQgkAigDAwQgCAxAhAkQAhAkAxACQAxADAkghQAkghACgxQACgxgggkQghgkgxgCIgHAAQgtAAghAegEASLgiAQgvArgDA/QgDBAArAuQAqAvBAADQBAADAugrQAvgqADhAQADhAgrguQgqgvhAgDIgHAAQg7AAgsAogEgJsgnlQgnAjgDA0QgBA0AiAmQAkAnA0ACQA0ACAmgiQAngkACg0QADg0gkgmQgjgng0gCIgFAAQgxAAgkAhgEAGTgpYQgjAggCAvQgDAvAgAjQAgAjAvACQAvACAjgfQAjggACgvQADgvgggjQgggkgvgBIgHAAQgqAAghAdgATsizIAAAAg");
	this.shape_1585.setTransform(788.079,505.5076);

	this.shape_1586 = new cjs.Shape();
	this.shape_1586.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB1APQgGAwgnAfQgnAdgvgGQgwgGgfgmQgdgnAGgwQAGgwAmgeQAngeAwAGQAwAGAeAnQAeAngGAvg");
	this.shape_1586.setTransform(684.164,317.3428);

	this.shape_1587 = new cjs.Shape();
	this.shape_1587.graphics.f().s("#232323").ss(7,1,1).p("ACDjvQgdArgeAgIgNAgQgjCNhPB1QggAugqAkQAQAQALAQIASgNQB+kLBZjHg");
	this.shape_1587.setTransform(936.5,474.575);

	this.shape_1588 = new cjs.Shape();
	this.shape_1588.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGdA0QgVCriJBqQiJBqipgWQisgVhpiJQhqiIAWiqQAWirCIhqQCIhqCqAWQCrAWBqCIQBqCIgWCqg");
	this.shape_1588.setTransform(822.1821,415.5821);

	this.shape_1589 = new cjs.Shape();
	this.shape_1589.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABxAOQgGAvgmAdQglAdgugGQgugGgdglQgdgmAGguQAFguAmgdQAmgdAtAGQAvAGAdAlQAdAmgGAtg");
	this.shape_1589.setTransform(867.5073,254.6073);

	this.shape_1590 = new cjs.Shape();
	this.shape_1590.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB9AQQgHAzgpAhQgpAfgzgGQgzgGghgqQgfgpAGgzQAHgzApggQApggAzAGQAzAGAgAqQAhApgHAzg");
	this.shape_1590.setTransform(765.214,258.7431);

	this.shape_1591 = new cjs.Shape();
	this.shape_1591.graphics.f().s("#232323").ss(8,1,1).p("AjUrvQAQgVAIghIALhKIB8jtQAYgYAcgVIEhhjQAPgBAPAAIDZAuQBSAjBLA+QA4AwA2BIQAWAeAjA1IAUgpQg7hdhchSQj5jgkwBYQj6BhhPCVQg9CpADBlgAnOUNQAHgKALgJQgmgpgeg4Qgshxgch2QiEmZh1mpQgWgWgXgdQAmCFAjBhIAfBYIB7GDQApCBAoCAQAMAtAQArQAUA+ATA9g");
	this.shape_1591.setTransform(735.2,338.3941);

	this.shape_1592 = new cjs.Shape();
	this.shape_1592.graphics.f().s("#232323").ss(0.1,1,1).p("EABMgpkQAWgsAjgvQBgh+COhNQCNhHClATQCwAcB5CbQBpCRgaDCIgKAtIgCANIAMgLQBohVB+gPQD9geC1DuQBpCog7DRQgCA9gFA6QgOCwglCsQgkCig5CdQg4CnhECjQgvBqhEBfIgXAmIgKAQAT0naQgzCEhAB/Az9k9QgTg0AegpIATAdQBIBfBbBWIAXAVQFPEyHEBXIASADQBKANBNAGQHBAgHvjiQCZhDByhMQAfAvgKAqQhdKqAGMRQAGMpB2LZMgslAASQABt/BmsaQBksTDRtUgA6S5qQgsg6gYhMQgVhFAChPQgoiUBGilQBfjDDxgzQBRgMBRATQAgAEAaAHQA9ARAzAfIADgBQAZgJATgTIAJgJA1sr1QhkmkiVme");
	this.shape_1592.setTransform(815.5589,508.7733);

	this.shape_1593 = new cjs.Shape();
	this.shape_1593.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACYATQgIBAgyAlQgyAog+gIQg/gIgngzQgmgxAHg/QAIg/AygnQAygmA+AIQA/AIAnAyQAnAygIA+g");
	this.shape_1593.setTransform(941.8813,310.8127);

	this.shape_1594 = new cjs.Shape();
	this.shape_1594.graphics.f("rgba(255,255,255,0.067)").s().p("ATjWIQAqglAgguQBQh1AjiOIANgfQAeggAdgrQhaDHh+EMIgSAMQgLgPgQgQgAxvQ4Ignh7QAOAhAQAgQgQgggOghQgQgrgMgtQgJgmgFgnQAFAnAJAmIhRkBIh7mDIgfhZQgihggniEQAXAdAWAVQB1GpCEGZQAdB2ArBwQAeA5AmApQgKAIgIALgAyWO9IAAAAgAsSyXQBPiVD7hiQEwhXD3DfQBdBTA7BdIgTAoQgjg0gXgeQg2hJg4gwQhKg+hSgjIjZgtIgfAAIkhBjQgcAWgYAYIh7DtIgMBJQgIAhgPAWQgEhmA9iog");
	this.shape_1594.setTransform(798.4,353.8191);

	this.shape_1595 = new cjs.Shape();
	this.shape_1595.graphics.f("#FFFFFF").s().p("AAWQrQirgWhpiIQhqiJAWirQAWirCIhqQCIhpCqAVQCrAWBqCIQBqCJgWCrQgVCriJBqQhxBXiJAAQgcAAgdgDgA0ojTQgwgGgfgmQgdgnAGgxQAGgwAmgeQAngeAxAGQAwAGAeAnQAeAngGAwQgGAwgnAfQggAYgnAAIgQgBgATkjxQg/gIgngzQgmgxAHhAQAIg/AygnQAygmA/AIQA/AIAnAyQAnAygIA/QgIBAgyAlQgpAhgzAAIgVgBgAn/sVQgzgGgggqQgggpAGg0QAHgzApggQAqggAzAGQAzAGAhAqQAgApgHA0QgGAzgqAhQgiAagqAAIgRgBgAIBtKQgvgGgdglQgdgmAGgvQAGguAlgdQAngdAtAGQAwAGAcAlQAeAmgHAuQgGAvglAdQgfAYglAAIgQgBg");
	this.shape_1595.setTransform(814.7742,350.2376);

	this.shape_1596 = new cjs.Shape();
	this.shape_1596.graphics.f("#232323").s().p("A4yUqQBksTDRtUQgTg0AegpIATAdQBIBfBbBWIAXAVQFPEyHEBXIASADQBKANBNAGQA4AEA3AAIAAAAIABAAQGPAAGxjGQCZhDByhMQAfAvgKAqQhdKqAGMRQAGMpB2LZMgslAASQABt/BmsagAAGDwQg3AAg4gEQhNgGhKgNIgSgDQnEhXlPkyIgXgVQhbhWhIhfIgTgdQAIgKAKgJQgmgpgeg4Qgrhxgdh2QhkmkiVmeQgWgWgXgdQgsg6gYhMQgVhFAChPQgoiUBGilQBfjDDxgzQBRgMBRATQAgAEAaAHQA9ARAzAfIADgBQAZgJATgTIAJgJQAQgVAHghIAMhKIB7jtQAYgYAcgVIEihjIAegBIDaAuQBSAjBKA+QA4AwA2BIQAWAeAjA1IAUgpQAWgsAjgvQBgh+COhNQCNhHClATQCwAcB5CbQBpCRgaDCIgKAtIgCANIAMgLQBohVB+gPQD9geC1DuQBpCog7DRQgCA9gFA6QgOCwglCsQgkCig5CdQg4CnhECjQgvBqhEBfIgXAmIgKAQQgdArgeAgIgNAgQgzCEhAB/QggAugqAkQAQAQALAQQhyBMiZBDQmxDGmPAAIgBAAIAAAAgAi8zsQiIBqgWCrQgWCrBqCIQBpCJCrAVQCqAWCJhqQCJhqAVirQAWirhqiIQhqiIirgWQgdgEgbAAQiJAAhxBYgA1q/XQgmAfgGAwQgGAwAdAnQAfAnAwAGQAwAGAngeQAngeAGgwQAGgxgegnQgegmgwgGIgRgBQgnAAggAYgEASRgg0QgyAngIA/QgHA/AmAyQAnAyA/AIQA/AJAygoQAygmAIhAQAIg+gngzQgngxg/gJIgUgBQgzAAgqAggEgJEgonQgpAhgHAzQgGA0AgApQAgApAzAHQA1AGAoggQAqggAGgzQAHg1gggoQghgqgzgGIgRgBQgpAAgjAagEAHBgpHQglAdgGAvQgGAuAdAmQAdAlAvAGQAuAHAmgeQAlgdAGguQAHgugegnQgcglgwgGIgPgBQglAAggAYgARShlIAAAAg");
	this.shape_1596.setTransform(815.5589,508.7733);

	this.shape_1597 = new cjs.Shape();
	this.shape_1597.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("AB0AYQgLAwgoAbQgpAbgvgKQgvgLgcgoQgbgpALgvQAKgvAogcQAqgbAuAKQAwALAbAoQAbAqgKAug");
	this.shape_1597.setTransform(710.6381,310.525);

	this.shape_1598 = new cjs.Shape();
	this.shape_1598.graphics.f().s("#232323").ss(7,1,1).p("ACUjlQggAoghAeIgPAeQguCLhZBtQgjAsgtAhQAQARAJARIATgLQCSkABpjAg");
	this.shape_1598.setTransform(949.725,487.575);

	this.shape_1599 = new cjs.Shape();
	this.shape_1599.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACWAfQgNA/g1AiQg1Ajg9gNQg+gNgjg1Qgig1AMg9QAOg+A0gjQA2gjA8ANQA/ANAiA1QAjA1gNA9g");
	this.shape_1599.setTransform(968.0447,324.6331);

	this.shape_1600 = new cjs.Shape();
	this.shape_1600.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGYBVQgjCpiRBfQiQBeiogjQipgjheiRQhfiQAjioQAkipCQhfQCRheCnAjQCpAkBfCQQBeCRgjCng");
	this.shape_1600.setTransform(840.3367,419.475);

	this.shape_1601 = new cjs.Shape();
	this.shape_1601.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABvAXQgJAugoAaQgoAagtgJQgtgKgbgnQgZgpAJgsQAKguAngbQApgZAsAJQAuAKAaAnQAaApgKAsg");
	this.shape_1601.setTransform(898.4081,262.65);

	this.shape_1602 = new cjs.Shape();
	this.shape_1602.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB7AaQgKAygsAdQgsAdgygLQgzgKgcgsQgdgsALgyQAKgyAsgeQArgcAzAKQAyALAdAsQAdArgLAzg");
	this.shape_1602.setTransform(796.125,258.6);

	this.shape_1603 = new cjs.Shape();
	this.shape_1603.graphics.f().s("#232323").ss(8,1,1).p("Ai7r4QASgUAKggIARhJICHjbQAcgaAigWIFFhKQABAAABAAQBuALBgAxQBTAqBJBGQAzA0AwBNIAzBXQAKgSANgVQg0hhhVhaQjmjzk2A/QkBBOhbCOQhKCjgFBlgApYTqQAJgKALgIQgjgtgag6QgihzgTh4QhimihUmyQgUgXgUgeQAcCHAaBjIAYBaIBcGMQAfCGAfCGQAHAqAMApQAPBAAPBAg");
	this.shape_1603.setTransform(763.425,335.0172);

	this.shape_1604 = new cjs.Shape();
	this.shape_1604.graphics.f().s("#232323").ss(0.1,1,1).p("EADXgpjQAagqAngsQBoh2CVhCQCRg7CkAgQCtAqBsCkQBdCagpC/IgNAsIgEAMIANgKQBvhLB+gGQD+gJCjD8QBbCvhMDMQgGA9gLA5QgcCugyCpQgyCehFCYQhECjhRCcQg4BmhLBZIgaAlIgLAPATMmBQg9CAhKB5A0pmwQgOg1AhgmIAQAdQBBBlBTBdIAVAXQE2FLG8B7IAQAFQBKATBMAMQG8BEIAi5QCfg4B3hCQAbAwgNApQiyJrgZMOQgaMlChKmMgslAAVQgYu5CEsTQCDsLE2txgA5T75Qgng+gShNQgPhGAJhPQgdiXBTifQBvi6DzggQBSgFBQAZQAfAGAZAKQA8AVAxAjIADgBQAZgGAVgSIAJgIA10tvQhDmshzmo");
	this.shape_1604.setTransform(833.6632,513.2374);

	this.shape_1605 = new cjs.Shape();
	this.shape_1605.graphics.f("#FFFFFF").s().p("AhcQrQiogjhfiRQheiQAjipQAjipCRhfQCRheCnAjQCpAkBeCQQBfCRgkCoQgjCpiQBfQhpBEh1AAQgtAAgugJgATWiLQg+gMgjg2Qghg0AMg/QANg+A1gjQA1giA+ANQA/ANAiA0QAiA2gNA+QgMA+g2AiQgmAagrAAQgRAAgRgEgA0wk6QgvgKgbgpQgbgpAKgwQAKgvApgbQApgbAwAKQAwAKAaApQAbApgKAwQgKAvgpAbQgdAUgiAAQgNAAgNgDgAImsdQgugJgagoQgagoAKguQAKgtAngbQAogZAuAJQAuAKAZAnQAbApgKAtQgKAugnAaQgeATggAAQgMAAgMgDgAnas5QgzgLgdgsQgcgrAKg0QALgyArgdQAsgdAzALQAzAKAdAsQAcAsgKAzQgLAzgsAdQggAUgjAAQgOAAgNgCg");
	this.shape_1605.setTransform(841.0809,353.5934);

	this.shape_1606 = new cjs.Shape();
	this.shape_1606.graphics.f("rgba(255,255,255,0.067)").s().p("ASQXBQAtghAjgsQBahtAuiMIAPgeQAhgeAggoQhpDAiTEBIgTALQgJgRgQgRgAyeOzIgeiAQAKAjAOAjQgOgjgKgjQgMgpgHgqQgHgpgDgqQADAqAHApIg+kLIhcmMIgYhaQgahjgciIQAUAfAUAXQBUGyBiGhQATB4AiB0QAaA6AjAtQgLAIgJAJgAy8MzIAAAAgAqPz5QBbiOEChNQE1hADmDzQBVBaA0BiQgNAUgKATIgzhYQgwhMgzg0QhJhHhTgqQhfgxhugKIgCgBIlFBKQgiAWgdAaIiHDcIgRBIQgKAhgSAUQAFhmBKijg");
	this.shape_1606.setTransform(818.125,359.8922);

	this.shape_1607 = new cjs.Shape();
	this.shape_1607.graphics.f("#232323").s().p("A7iThQCDsME2twQgOg1AhgnIAQAeQBBBkBTBeIAVAWQE2FMG8B7IAQAEQBKATBMAMQB4ASB7AAIAAAAIABAAQFJAAFriAIAUgHQCfg3B3hCQAbAwgNApQiyJrgZMOQgaMlChKlMgslAAWQgYu5CEsTgAAuD7Qh7AAh4gSQhMgMhKgTIgQgEQm8h7k2lMIgVgWQhThehBhkIgQgeQAIgJALgIQgjgtgZg6Qgih0gTh4QhDmrhzmpQgUgXgVgfQgng9gShNQgPhHAJhOQgdiYBTieQBvi7DzgfQBSgFBQAZQAfAGAZAJQA8AVAxAkIADgBQAZgHAVgRIAJgIQARgUALghIARhIICGjcQAdgaAjgWIFEhKIADABQBtAKBhAxQBSAqBIBHQAzA0AxBMIAzBYQAKgTANgUQAagqAngtQBoh1CVhCQCRg7CkAgQCtAqBsCjQBdCagpC/IgNAsIgEANIANgKQBvhMB+gFQD+gKCjD8QBbCvhMDMQgGA9gLA6QgcCtgyCpQgyCfhFCXQhECjhRCcQg4BmhLBaIgaAkIgLAPQggAoghAeIgQAeQg9CBhKB4QgjAsguAhQAQARAJARQh3BCifA3IgUAHQlrCAlJAAIgBAAIAAAAgAigzxQiRBfgjCpQgjCpBeCQQBfCRCoAjQCoAjCRheQCQhfAjipQAkiohfiRQheiQipgkQgugKgsAAQh1AAhpBFgATs/JQg1AjgNA+QgMA/AhA0QAjA2A+AMQA/AOA0gkQA2giAMg+QANg+gig2Qgig0g/gNQgRgEgQAAQgrAAgnAZgEgUOgg4QgpAbgKAvQgKAwAbApQAbApAvAKQAxAKAogbQApgbAKgvQAKgwgbgpQgagpgwgKQgNgDgMAAQgiAAgeAUgEAJJgoUQgnAbgKAtQgKAuAaAoQAaAoAuAJQAtAKApgaQAngaAKguQAKgtgbgpQgZgngugKQgMgCgMAAQghAAgdASgEgG8gpGQgrAdgLAyQgKA0AcArQAdAsAzALQAzAKArgcQAsgdALgzQAKgzgcgsQgdgsgzgKQgNgDgOAAQgkAAggAVgAQNgFIAAAAg");
	this.shape_1607.setTransform(833.6632,511.1875);

	this.shape_1608 = new cjs.Shape();
	this.shape_1608.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABxAhQgNAvgrAYQgsAXgtgOQgvgOgYgrQgXgqAOguQANgvArgYQAsgXAtAOQAvANAYArQAXArgOAug");
	this.shape_1608.setTransform(737.5867,305.8867);

	this.shape_1609 = new cjs.Shape();
	this.shape_1609.graphics.f().s("#232323").ss(7,1,1).p("ACljZQgjAlgkAcIgRAcQg5CGhiBnQgmApgwAdQAPASAHARIAUgJQCnj0B4i2g");
	this.shape_1609.setTransform(961.875,501.55);

	this.shape_1610 = new cjs.Shape();
	this.shape_1610.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACSArQgSA9g3AeQg4Aeg8gRQg8gSgfg4Qgdg3ARg8QASg+A3geQA4geA8ASQA9ASAeA3QAfA5gTA7g");
	this.shape_1610.setTransform(993.0566,340.5099);

	this.shape_1611 = new cjs.Shape();
	this.shape_1611.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGPB1QgwCmiYBSQiYBUikgyQilgwhTiYQhTiXAxilQAxilCXhTQCYhTCkAxQCmAxBSCXQBUCYgyCkg");
	this.shape_1611.setTransform(858.1617,424.8617);

	this.shape_1612 = new cjs.Shape();
	this.shape_1612.graphics.f().s("#232323").ss(8,1,1).p("Aihr6QAUgTAMgfIAYhHICxjjQATgMAVgMIFMgvIDhBcQBBAsA5BBQAuA3AqBRQATAhAaA6IAZglQgrhmhOhgQjSkEk6AmQkIA4hkCHQhXCcgOBlgArdTAQAIgJAMgHQgggwgUg7QgZh2gIh5QhBmpgxm2QgTgZgRggQARCJASBkIARBdIA8GSIAnEKQAEAwAKAvIATB8g");
	this.shape_1612.setTransform(791.75,333.4581);

	this.shape_1613 = new cjs.Shape();
	this.shape_1613.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB4AjQgOAyguAZQguAZgxgOQgygPgZguQgYgtAOgyQAOgxAugaQAugYAxAOQAyAPAZAtQAZAugPAxg");
	this.shape_1613.setTransform(826.9517,260.9616);

	this.shape_1614 = new cjs.Shape();
	this.shape_1614.graphics.f().s("#232323").ss(0.1,1,1).p("EAGUgpVQAegnAqgpQBxhuCag1QCWgvCgAtQCpA3BfCsQBQCgg4C8IgRArIgEAMIAOgJQB0hDB+AFQD+ALCOEIQBNC1hcDGQgLA8gPA5QgqCqg/ClQg/CahRCSQhRCdhdCVQhABhhSBTIgdAiIgMAOA3W+BQghhAgMhOQgJhHAOhOQgQiaBfiXQB+ixD1gMQBSABBNAgQAfAJAYALQA5AZAvAoQACgBABAAQAZgFAXgPIAJgIA0ZokQgKg2AkgkIAOAfQA5BqBLBjIATAZQEaFjGxCeIAQAGQBIAZBLASQG1BnIOiPQCigsB8g5QAXA0gQAnQkCIkg3MJQg5MfDPJ1MgslAAZQgtv1CjsJQCgsBGduGgATRkpQhIB7hUByA1AvoQghmwhQmv");
	this.shape_1614.setTransform(846.2986,518.9245);

	this.shape_1615 = new cjs.Shape();
	this.shape_1615.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABtAgQgNAtgqAXQgqAXgrgOQgtgNgXgpQgXgqAOgsQANgtApgXQAqgXAsAOQAtANAXApQAXAqgOAsg");
	this.shape_1615.setTransform(928.5832,273.1867);

	this.shape_1616 = new cjs.Shape();
	this.shape_1616.graphics.f("rgba(255,255,255,0.067)").s().p("AQ2XyQAwgdAmgpQBjhmA5iHIARgdQAkgbAjgmQh4C3ioD0IgUAJQgHgRgPgSgAzGMqIgTh9QAIAiAKAgQgKgggIgiQgKgvgEgwQgCgdAAgdIAAgUIAAAUQAAAdACAdIgnkKIg8mRIgRhcQgShlgSiKQASAgATAaQAxG2BAGoQAJB5AZB2QAUA8AgAwQgMAGgJAJgAzZKtIAAAAgAGlyiQgqhQgvg4Qg4hAhBgtIjghbIlMAvQgVALgUANIiyDiIgXBHQgNAggTASQANhkBXidQBmiGEHg5QE6gmDREFQBOBgAsBlIgaAlQgag6gSghg");
	this.shape_1616.setTransform(837.575,367.6081);

	this.shape_1617 = new cjs.Shape();
	this.shape_1617.graphics.f("#FFFFFF").s().p("AjOQxQilgwhTiYQhTiXAximQAxilCXhTQCYhTCkAxQCmAxBSCXQBUCYgyClQgwCmiYBSQhfA1hkAAQg7AAg+gTgATAgWQg8gSgfg4Qgdg2ARg+QASg9A3geQA4geA9ASQA9ASAeA3QAfA4gTA9QgSA9g3AeQgjATgmAAQgVAAgXgHgA0vmSQgvgOgYgrQgXgqAOgvQANgvArgYQAsgXAuAOQAvANAYArQAXArgOAvQgNAvgrAYQgbAOgdAAQgRAAgRgFgAJHrdQgtgNgXgpQgXgqAOgtQANgtApgXQAqgXAtAOQAtANAXApQAXAqgOAtQgNAtgqAXQgaAOgbAAQgRAAgQgFgAm0tLQgygPgZguQgYgtAOgzQAOgxAugaQAugYAyAOQAyAPAZAtQAZAugPAyQgOAyguAZQgdAQgfAAQgRAAgTgFg");
	this.shape_1617.setTransform(867.071,357.4916);

	this.shape_1618 = new cjs.Shape();
	this.shape_1618.graphics.f("#232323").s().p("A9WShQCgsCGduFQgKg3AkgjQAJgJAMgHQgggwgUg7QgZh2gJh5QghmwhQmwQgTgZgSggQghhBgMhOQgJhHAOhOQgQiZBfiYQB+ixD1gMQBSACBNAfQAfAJAYALQA5AaAvAnIADAAQAZgFAXgQIAJgHQATgTANgfIAXhHICyjjQATgMAWgMIFMgvIDgBcQBBAsA4BBQAvA3AqBRQASAhAaA6IAaglQAegoAqgpQBxhuCag1QCWgvCgAtQCpA4BfCrQBQChg4C7IgRArIgEAMIAOgJQB0hCB+AFQD+AKCOEJQBNC1hcDGQgLA8gPA4QgqCrg/ClQg/CahRCRQhRCdhdCVQhABhhSBUIgdAiIgMAOQgjAlgkAcIgRAcQhIB7hUByQgmAogwAdQAPASAHASQh8A5iiArQkyBTkUAAIAAAAIgBAAQjFAAi3grQhLgShIgZIgQgGQmxiekaljIgTgYQhLhjg5hqIgOgfIAOAfQA5BqBLBjIATAYQEaFjGxCeIAQAGQBIAZBLASQC3ArDFAAIABAAIAAAAQEUAAEyhTQCigrB8g5QAXA0gQAnQkCIkg3MIQg5MgDPJ0MgslAAaQgtv1CjsJgAhQzcQiXBTgxClQgxCmBTCXQBTCYCkAwQClAyCYhUQCYhSAwimQAyilhUiYQhSiXimgxQg9gSg8AAQhlAAheA0gAVy9AQg3AegSA9QgRA+AdA2QAfA4A8ASQA9ASA4geQA3geASg9QATg9gfg4Qgeg3g9gSQgXgHgWAAQglAAgjATgEgR3gh8QgrAYgNAvQgOAvAXAqQAYArAvAOQAuAOAsgXQArgYANgvQAOgvgXgrQgYgrgvgNQgRgFgRAAQgdAAgbAOgEAMAgm/QgpAXgNAtQgOAtAXAqQAXApAtANQAsAOAqgXQAqgXANgtQAOgtgXgqQgXgpgtgNQgRgFgQAAQgcAAgaAOgEgD9gpEQguAagOAxQgOAzAYAtQAZAuAyAPQAyAOAugZQAugZAOgyQAPgygZguQgZgtgygPQgSgFgSAAQgfAAgdAPg");
	this.shape_1618.setTransform(846.2986,512.775);

	this.shape_1619 = new cjs.Shape();
	this.shape_1619.graphics.f().s("#FFFFFF").ss(23.5,1,1).p("ABuAqQgRAugtAUQgsAUgugSQgtgRgUgtQgUgsASguQARgtAtgUQAtgUAtASQAtARAUAtQAUAtgSAsg");
	this.shape_1619.setTransform(764.8,303.4);

	this.shape_1620 = new cjs.Shape();
	this.shape_1620.graphics.f().s("#232323").ss(7,1,1).p("AC0jMQglAigmAZIgUAbQhDCBhqBfQgpAlgyAZQANATAGASIAUgHQC6jmCGisg");
	this.shape_1620.setTransform(972.85,516.5);

	this.shape_1621 = new cjs.Shape();
	this.shape_1621.graphics.f().s("#FFFFFF").ss(30.6,1,1).p("ACPA2QgXA8g6AZQg5Abg7gYQg8gWgZg6Qgag6AXg6QAXg7A5gbQA7gYA6AWQA7AWAaA6QAZA6gWA6g");
	this.shape_1621.setTransform(1016.657,358.4068);

	this.shape_1622 = new cjs.Shape();
	this.shape_1622.graphics.f().s("#FFFFFF").ss(83.2,1,1).p("AGFCVQg+CiieBGQidBGigg+Qihg+hHieQhFieA9ifQA+ihCdhHQCfhGCfA+QChA9BGCeQBHCeg+Cgg");
	this.shape_1622.setTransform(875.4749,431.65);

	this.shape_1623 = new cjs.Shape();
	this.shape_1623.graphics.f().s("#FFFFFF").ss(25.1,1,1).p("AB2AtQgTAwgwAWQgvAWgwgTQgwgTgWgwQgVgvASgwQATgwAwgWQAvgVAwASQAwATAWAwQAWAvgTAwg");
	this.shape_1623.setTransform(857.482,265.782);

	this.shape_1624 = new cjs.Shape();
	this.shape_1624.graphics.f().s("#232323").ss(8,1,1).p("AiFr1QAUgRAQgfIAchFICujHQAegSAhgPIFMgVQABAAACABIDABaICJCJQAqA8AkBTQAPAjAVA7IAdgjQgjhnhGhnQi9kUk8AMQkLAjhvB+QhkCVgUBkgAtfSRQAJgJANgGQgbgxgQg+QgPh3AAh6QgemtgOm4QgPgagQgiQAHCKAJBmQAHA2ACAnIAcGWQAJCJAJCKQABAnAFAoQAEBEAFBEg");
	this.shape_1624.setTransform(820.025,333.7479);

	this.shape_1625 = new cjs.Shape();
	this.shape_1625.graphics.f().s("#232323").ss(0.1,1,1).p("EAJRgo5QAhglAtgmQB5hkCegpQCZgjCcA6QClBFBQCzQBDCmhHC3IgUApIgFAMIAOgIQB6g5B9APQD9AfB4ETQA9C7hrC9QgQA8gTA2Qg4CnhMCfQhLCVhcCKQhdCWhpCNQhHBchZBMIgfAgIgOANA1N//QgbhDgHhPQgDhIAUhMQgDiaBqiQQCMimD1AIQBRAHBLAmQAeAMAXANQA4AeArArQACgBABAAQAagDAXgNIAKgHAKzC9QClgeCBgvQATA2gUAmQlMHWhVMAQhYMYECJHMgslAAeQg8wzC/r8QC+r2IEuSQgGg2AoghIALAgQAwBtBDBqIARAZQD9F6GiC/IAQAHQBGAfBJAYATPjTQhSB1hcBrAKzC9Ql1BHpOhsQISCrGxiGgA0BxdQACmxgum1");
	this.shape_1625.setTransform(858.2711,525.7914);

	this.shape_1626 = new cjs.Shape();
	this.shape_1626.graphics.f().s("#FFFFFF").ss(22.7,1,1).p("ABrApQgRAsgrATQgsATgrgQQgsgRgTgrQgTgsARgrQARgsArgTQArgTArAQQAsASATAqQAUAsgRArg");
	this.shape_1626.setTransform(957.8,286.1);

	this.shape_1627 = new cjs.Shape();
	this.shape_1627.graphics.f("rgba(255,255,255,0.067)").s().p("APWYbQAygZApglQBqheBEiCIAUgbQAlgZAmgiQiGCsi7DmIgUAIQgGgSgNgUgAznKeIgJiIQAFAnAJAmQgJgmgFgnQgFgoAAgnIAAgLQAAglAEglQgBB6AQB3QAPA+AcAxQgNAGgJAJgAzwIWIAAAAgA0HC0IgcmVQgCgngHg2QgKhmgHiLQAQAiAQAaQANG5AfGsQgEAlAAAlIAAALIgSkTgAzxFyIAAAAgAIgykQgkhTgqg8IiKiJIjAhaIgDgBIlKAVQgiAPgdASIivDHIgdBFQgPAfgVARQAVhkBjiVQBxh+ELgjQE7gMC8EUQBGBnAkBnIgdAjQgVg7gPgjg");
	this.shape_1627.setTransform(856.675,376.9479);

	this.shape_1628 = new cjs.Shape();
	this.shape_1628.graphics.f("#FFFFFF").s().p("Ak+QxQihg+hHieQhFieA9igQA+ihCdhHQCfhGCgA+QCgA9BGCeQBHCeg+ChQg+ChidBGQhUAmhUAAQhLAAhLgdgASjBeQg8gXgZg6Qgag4AXg8QAXg7A5gaQA7gZA7AWQA7AXAaA5QAZA7gWA6QgXA8g6AZQgeAOgfAAQgcAAgcgLgA0mnoQgtgRgVgtQgTgsARguQASgtAsgVQAtgTAuARQAtASAUAsQAUAtgSAtQgRAugtAUQgXAKgYAAQgVAAgWgIgAJkqYQgsgRgTgrQgTgsARgsQARgsArgTQArgTAsARQAsARATArQAUArgRAsQgRAsgrATQgYAKgXAAQgVAAgUgHgAmKtYQgwgTgWgwQgVgvASgxQATgwAwgWQAvgVAxASQAwATAWAwQAWAvgTAxQgTAwgwAWQgZALgaAAQgWAAgXgIg");
	this.shape_1628.setTransform(892.4885,363.2923);

	this.shape_1629 = new cjs.Shape();
	this.shape_1629.graphics.f("#232323").s().p("A/BRUQC+r1IEuSQgGg3AoggQAJgJANgGQgcgxgPg+QgQh3ABh6QACmwgum2QgQgagQgiQgbhCgHhPQgDhIAUhNQgDiZBqiQQCMinD1AIQBRAIBLAmQAeALAXANQA4AeArArIADAAQAagDAXgNIAKgHQAVgRAPgfIAdhFICvjHQAdgSAigPIFLgVIACABIDBBaICJCJQAqA8AkBTQAPAjAVA7IAdgjQAhgkAtgmQB5hlCegoQCZgjCcA6QClBEBQCzQBDCnhHC2IgUApIgFAMIAOgIQB6g5B9APQD9AfB4ETQA9C7hrC+QgQA7gTA3Qg4CmhMCgQhLCUhcCLQhdCVhpCOQhHBbhZBNIgfAgIgOANQgmAiglAZIgUAbQhSB0hcBrQgpAlgyAZQANAUAGASQATA1gUAmQlMHXhVMAQhYMXECJHMgslAAfQg8wzC/r9gAKzEiQClgeCBgvQiBAvilAeQl1BGpOhrQISCqGxiFgAzSprQAwBuBDBpIARAaQD9F6GiC/IAQAHQBGAfBJAYQhJgYhGgfIgQgHQmii/j9l6IgRgaQhDhpgwhuIgLgfgAACzEQicBGg+ChQg9ChBFCeQBHCeCgA9QChA+CdhGQCehGA+iiQA+ihhHidQhGieihg+QhLgdhKAAQhVAAhVAmgAXx6xQg5AbgXA7QgXA7AaA6QAZA6A8AWQA8AYA5gbQA6gZAXg8QAWg7gZg6Qgag6g7gWQgcgLgcAAQgfAAgfANgEgPWgi2QgsAUgSAtQgRAvATAsQAVAtAtARQAuARAsgTQAtgUARguQASgugUgsQgUgtgtgRQgWgIgVAAQgYAAgYAKgEAO1glfQgrATgRAsQgRArATAsQATArAsARQAsARAsgTQArgUARgrQARgsgUgsQgTgqgsgSQgUgIgVAAQgXAAgXALgEgA6go2QgwAWgTAwQgSAyAVAvQAWAwAwASQAxATAugWQAwgVATgwQATgxgWgwQgWgvgwgTQgXgJgVAAQgaAAgZALg");
	this.shape_1629.setTransform(858.2711,515.7125);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_1420},{t:this.shape_1419},{t:this.shape_1418},{t:this.shape_1417},{t:this.shape_1416},{t:this.shape_1415},{t:this.shape_1414},{t:this.shape_1413},{t:this.shape_1412},{t:this.shape_1411},{t:this.shape_1410}]}).to({state:[{t:this.shape_1431},{t:this.shape_1430},{t:this.shape_1429},{t:this.shape_1428},{t:this.shape_1427},{t:this.shape_1426},{t:this.shape_1425},{t:this.shape_1424},{t:this.shape_1423},{t:this.shape_1422},{t:this.shape_1421}]},1).to({state:[{t:this.shape_1442},{t:this.shape_1441},{t:this.shape_1440},{t:this.shape_1439},{t:this.shape_1438},{t:this.shape_1437},{t:this.shape_1436},{t:this.shape_1435},{t:this.shape_1434},{t:this.shape_1433},{t:this.shape_1432}]},1).to({state:[{t:this.shape_1453},{t:this.shape_1452},{t:this.shape_1451},{t:this.shape_1450},{t:this.shape_1449},{t:this.shape_1448},{t:this.shape_1447},{t:this.shape_1446},{t:this.shape_1445},{t:this.shape_1444},{t:this.shape_1443}]},1).to({state:[{t:this.shape_1464},{t:this.shape_1463},{t:this.shape_1462},{t:this.shape_1461},{t:this.shape_1460},{t:this.shape_1459},{t:this.shape_1458},{t:this.shape_1457},{t:this.shape_1456},{t:this.shape_1455},{t:this.shape_1454}]},1).to({state:[{t:this.shape_1475},{t:this.shape_1474},{t:this.shape_1473},{t:this.shape_1472},{t:this.shape_1471},{t:this.shape_1470},{t:this.shape_1469},{t:this.shape_1468},{t:this.shape_1467},{t:this.shape_1466},{t:this.shape_1465}]},1).to({state:[{t:this.shape_1486},{t:this.shape_1485},{t:this.shape_1484},{t:this.shape_1483},{t:this.shape_1482},{t:this.shape_1481},{t:this.shape_1480},{t:this.shape_1479},{t:this.shape_1478},{t:this.shape_1477},{t:this.shape_1476}]},1).to({state:[{t:this.shape_1497},{t:this.shape_1496},{t:this.shape_1495},{t:this.shape_1494},{t:this.shape_1493},{t:this.shape_1492},{t:this.shape_1491},{t:this.shape_1490},{t:this.shape_1489},{t:this.shape_1488},{t:this.shape_1487}]},1).to({state:[{t:this.shape_1508},{t:this.shape_1507},{t:this.shape_1506},{t:this.shape_1505},{t:this.shape_1504},{t:this.shape_1503},{t:this.shape_1502},{t:this.shape_1501},{t:this.shape_1500},{t:this.shape_1499},{t:this.shape_1498}]},1).to({state:[{t:this.shape_1519},{t:this.shape_1518},{t:this.shape_1517},{t:this.shape_1516},{t:this.shape_1515},{t:this.shape_1514},{t:this.shape_1513},{t:this.shape_1512},{t:this.shape_1511},{t:this.shape_1510},{t:this.shape_1509}]},1).to({state:[{t:this.shape_1530},{t:this.shape_1529},{t:this.shape_1528},{t:this.shape_1527},{t:this.shape_1526},{t:this.shape_1525},{t:this.shape_1524},{t:this.shape_1523},{t:this.shape_1522},{t:this.shape_1521},{t:this.shape_1520}]},1).to({state:[{t:this.shape_1541},{t:this.shape_1540},{t:this.shape_1539},{t:this.shape_1538},{t:this.shape_1537},{t:this.shape_1536},{t:this.shape_1535},{t:this.shape_1534},{t:this.shape_1533},{t:this.shape_1532},{t:this.shape_1531}]},1).to({state:[{t:this.shape_1552},{t:this.shape_1551},{t:this.shape_1550},{t:this.shape_1549},{t:this.shape_1548},{t:this.shape_1547},{t:this.shape_1546},{t:this.shape_1545},{t:this.shape_1544},{t:this.shape_1543},{t:this.shape_1542}]},1).to({state:[{t:this.shape_1563},{t:this.shape_1562},{t:this.shape_1561},{t:this.shape_1560},{t:this.shape_1559},{t:this.shape_1558},{t:this.shape_1557},{t:this.shape_1556},{t:this.shape_1555},{t:this.shape_1554},{t:this.shape_1553}]},1).to({state:[{t:this.shape_1574},{t:this.shape_1573},{t:this.shape_1572},{t:this.shape_1571},{t:this.shape_1570},{t:this.shape_1569},{t:this.shape_1568},{t:this.shape_1567},{t:this.shape_1566},{t:this.shape_1565},{t:this.shape_1564}]},1).to({state:[{t:this.shape_1585},{t:this.shape_1584},{t:this.shape_1583},{t:this.shape_1582},{t:this.shape_1581},{t:this.shape_1580},{t:this.shape_1579},{t:this.shape_1578},{t:this.shape_1577},{t:this.shape_1576},{t:this.shape_1575}]},1).to({state:[{t:this.shape_1596},{t:this.shape_1595},{t:this.shape_1594},{t:this.shape_1593},{t:this.shape_1592},{t:this.shape_1591},{t:this.shape_1590},{t:this.shape_1589},{t:this.shape_1588},{t:this.shape_1587},{t:this.shape_1586}]},1).to({state:[{t:this.shape_1607},{t:this.shape_1606},{t:this.shape_1605},{t:this.shape_1604},{t:this.shape_1603},{t:this.shape_1602},{t:this.shape_1601},{t:this.shape_1600},{t:this.shape_1599},{t:this.shape_1598},{t:this.shape_1597}]},1).to({state:[{t:this.shape_1618},{t:this.shape_1617},{t:this.shape_1616},{t:this.shape_1615},{t:this.shape_1614},{t:this.shape_1613},{t:this.shape_1612},{t:this.shape_1611},{t:this.shape_1610},{t:this.shape_1609},{t:this.shape_1608}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[{t:this.shape_1629},{t:this.shape_1628},{t:this.shape_1627},{t:this.shape_1626},{t:this.shape_1625},{t:this.shape_1624},{t:this.shape_1623},{t:this.shape_1622},{t:this.shape_1621},{t:this.shape_1620},{t:this.shape_1619}]},1).to({state:[]},1).wait(1258));

	// фон1
	this.shape_1630 = new cjs.Shape();
	this.shape_1630.graphics.f("#0B88F0").s().p("EiFSBGvMAAAiNdMEKlAAAMAAACNdg");
	this.shape_1630.setTransform(791.525,406.55);

	this.timeline.addTween(cjs.Tween.get(this.shape_1630).wait(43).to({_off:true},87).wait(1178));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(-1707.7,-1003.5,4996.5,2930.9);
// library properties:
lib.properties = {
	id: '84525DB30A5F4A49B109B0424EB0F430',
	width: 1596,
	height: 809,
	fps: 24,
	color: "#4A4A4A",
	opacity: 1.00,
	manifest: [
		{src:"images/АСЦАЦ6363.png", id:"АСЦАЦ6363"},
		{src:"images/ВКВ22.png", id:"ВКВ22"},
		{src:"images/ВКВ22pngкопия.png", id:"ВКВ22pngкопия"},
		{src:"images/ЫИЫВПМ67.png", id:"ЫИЫВПМ67"},
		{src:"images/вкорме10.png", id:"вкорме10"},
		{src:"images/газета60.png", id:"газета60"},
		{src:"images/городскиежильцыперсонажиЦ2346.png", id:"городскиежильцыперсонажиЦ2346"},
		{src:"images/городскиежильцыперсонажи23.png", id:"городскиежильцыперсонажи23"},
		{src:"images/городскиежильцыперсонажи27.png", id:"городскиежильцыперсонажи27"},
		{src:"images/городскиежильцыперсонажи28.png", id:"городскиежильцыперсонажи28"},
		{src:"images/городскиежильцыперсонажи29.png", id:"городскиежильцыперсонажи29"},
		{src:"images/городскиежильцыперсонажи33.png", id:"городскиежильцыперсонажи33"},
		{src:"images/городскиежильцыперсонажи37.png", id:"городскиежильцыперсонажи37"},
		{src:"images/городскиежильцыперсонажи41.png", id:"городскиежильцыперсонажи41"},
		{src:"images/городскиежильцыперсонажи43.png", id:"городскиежильцыперсонажи43"},
		{src:"images/городскиежильцыперсонажи45.png", id:"городскиежильцыперсонажи45"},
		{src:"images/городскиежильцыперсонажи46.png", id:"городскиежильцыперсонажи46"},
		{src:"images/городскиежильцыперсонажи47.png", id:"городскиежильцыперсонажи47"},
		{src:"images/городскиежильцыперсонажи58.png", id:"городскиежильцыперсонажи58"},
		{src:"images/городскиежильцыперсонажи59pngкопия.png", id:"городскиежильцыперсонажи59pngкопия"},
		{src:"images/городскиежильцыперсонажи60.png", id:"городскиежильцыперсонажи60"},
		{src:"images/городскиежильцыперсонажи61.png", id:"городскиежильцыперсонажи61"},
		{src:"images/городскиежильцыперсонажи62.png", id:"городскиежильцыперсонажи62"},
		{src:"images/городскиежильцыперсонажи63.png", id:"городскиежильцыперсонажи63"},
		{src:"images/городскиежильцыперсонажи64.png", id:"городскиежильцыперсонажи64"},
		{src:"images/_656665.png", id:"_656665"},
		{src:"images/_656665pngкопия.png", id:"_656665pngкопия"},
		{src:"images/_656666.png", id:"_656666"},
		{src:"images/_656666pngкопия.png", id:"_656666pngкопия"},
		{src:"images/_656666pngкопия2.png", id:"_656666pngкопия2"},
		{src:"images/_676867.png", id:"_676867"},
		{src:"images/_676868.png", id:"_676868"},
		{src:"images/фоны_фонкорм.png", id:"фоны_фонкорм"},
		{src:"images/фоны_фонокно.png", id:"фоны_фонокно"},
		{src:"images/фоны_фонприхожаяcopy.png", id:"фоны_фонприхожаяcopy"},
		{src:"images/фоны_фонприхожая.png", id:"фоны_фонприхожая"},
		{src:"images/фоны_фонстол.png", id:"фоны_фонстол"},
		{src:"images/фоны_фонстол2copy3.png", id:"фоны_фонстол2copy3"},
		{src:"images/фоны_фонстол2copy4.png", id:"фоны_фонстол2copy4"},
		{src:"images/фоны_фонстол2copy5.png", id:"фоны_фонстол2copy5"},
		{src:"images/фоны_фонстол2.png", id:"фоны_фонстол2"},
		{src:"sounds/a5230bf64dffcb6.mp3", id:"a5230bf64dffcb6"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['84525DB30A5F4A49B109B0424EB0F430'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;